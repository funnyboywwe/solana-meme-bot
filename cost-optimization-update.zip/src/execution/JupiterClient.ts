import axios from 'axios';
import {
  Connection,
  Keypair,
  VersionedTransaction,
  LAMPORTS_PER_SOL,
} from '@solana/web3.js';
import { createModuleLogger } from '../core/Logger';
import { AppConfig } from '../config/AppConfig';
import { MEVProtection } from './mev/MEVProtection';
import { getRpcManager, RpcManager } from '../core/RpcManager';
import { WriteRpcProvider } from '../core/WriteRpcProvider';

const logger = createModuleLogger('JupiterClient');

const WSOL_MINT = 'So11111111111111111111111111111111111111112';

export interface QuoteResult {
  inputMint: string;
  outputMint: string;
  inAmount: string;
  outAmount: string;
  otherAmountThreshold: string;
  swapMode: string;
  slippageBps: number;
  priceImpactPct: string;
  routePlan: Array<{
    swapInfo: { ammKey: string; label: string; inputMint: string; outputMint: string };
    percent: number;
  }>;
  contextSlot?: number;
  timeTaken?: number;
}

export interface SwapResult {
  success: boolean;
  txHash?: string;
  amountIn: number;
  amountOut: number;
  feeSol: number;
  priceImpactPct: number;
  error?: string;
  // Routing metadata (for cost analytics / smart-routing diagnostics).
  hops?: number;
  routeLabels?: string[];
}

/** Per-quote routing knobs. */
export interface QuoteOptions {
  onlyDirectRoutes?: boolean;
  restrictIntermediateTokens?: boolean;
  maxAccounts?: number;
}

interface RoutingConfig {
  preferDirectRoutes: boolean;
  directRouteTolerancePct: number;
  maxAccounts: number;
  restrictIntermediateTokens: boolean;
}

export class JupiterClient {
  private rpc: RpcManager;
  private get connection(): Connection { return this.rpc.getReadConnection(); }
  private write: WriteRpcProvider;
  private keypair: Keypair;
  private jupiterApiUrl: string;
  private slippageBps: number;
  private priorityFeeMicroLamports: number;
  private simulateBeforeSend: boolean;
  private mevProtection: MEVProtection | null = null;
  private routing: RoutingConfig;

  constructor(cfg: AppConfig, keypair: Keypair) {
    this.rpc = getRpcManager(cfg);
    this.write = new WriteRpcProvider(cfg);
    this.keypair = keypair;
    this.jupiterApiUrl = cfg.execution.jupiterApiUrl;
    this.slippageBps = cfg.execution.slippageBps;
    this.priorityFeeMicroLamports = cfg.execution.priorityFeeMicroLamports;
    this.simulateBeforeSend = cfg.execution.simulateBeforeSend;
    const r = cfg.costControl?.routing;
    this.routing = {
      preferDirectRoutes: r?.preferDirectRoutes ?? true,
      directRouteTolerancePct: r?.directRouteTolerancePct ?? 0.005,
      maxAccounts: r?.maxAccounts ?? 48,
      restrictIntermediateTokens: r?.restrictIntermediateTokens ?? true,
    };
  }

  setMevProtection(mev: MEVProtection): void {
    this.mevProtection = mev;
  }

  /**
   * Get a swap quote from Jupiter. Smart-routing defaults (restrict
   * intermediate tokens + bounded account count) keep routes simple and
   * CU-cheap. FIX: Jupiter V6 /quote returns the QuoteResult object directly.
   */
  async getQuote(
    inputMint: string,
    outputMint: string,
    amountLamports: number | string,
    slippageBps?: number,
    opts?: QuoteOptions,
  ): Promise<QuoteResult> {
    const response = await axios.get<QuoteResult>(
      `${this.jupiterApiUrl}/quote`,
      {
        params: {
          inputMint,
          outputMint,
          amount: amountLamports.toString(),
          slippageBps: slippageBps ?? this.slippageBps,
          onlyDirectRoutes: opts?.onlyDirectRoutes ?? false,
          restrictIntermediateTokens: opts?.restrictIntermediateTokens ?? this.routing.restrictIntermediateTokens,
          asLegacyTransaction: false,
          maxAccounts: opts?.maxAccounts ?? this.routing.maxAccounts,
        },
        timeout: 8000,
      },
    );

    const quote = response.data;
    if (!quote || !quote.outAmount) {
      throw new Error(`No quote available from Jupiter for ${inputMint} → ${outputMint}`);
    }
    return quote;
  }

  /**
   * Smart routing: fetch the best (aggregated) quote, and when it is multi-hop,
   * compare against a direct-route quote. If the direct route is within a small
   * tolerance of the best output, prefer it — fewer hops means fewer accounts,
   * lower compute units and a cheaper, more reliable transaction.
   */
  private async _quoteWithRouting(
    inputMint: string,
    outputMint: string,
    amount: number | string,
    slippageBps: number,
  ): Promise<QuoteResult> {
    const best = await this.getQuote(inputMint, outputMint, amount, slippageBps);
    if (!this.routing.preferDirectRoutes) return best;

    const hops = best.routePlan?.length ?? 1;
    if (hops <= 1) return best;

    try {
      const direct = await this.getQuote(inputMint, outputMint, amount, slippageBps, { onlyDirectRoutes: true });
      const bestOut = parseInt(best.outAmount, 10);
      const directOut = parseInt(direct.outAmount, 10);
      if (directOut > 0 && bestOut > 0) {
        const lossPct = (bestOut - directOut) / bestOut;
        if (lossPct <= this.routing.directRouteTolerancePct) {
          logger.info('Using direct route (cheaper, within tolerance)', {
            lossPct: +(lossPct * 100).toFixed(3),
            bestHops: hops,
          });
          return direct;
        }
      }
    } catch {
      // No direct route available — fall back to the best multi-hop route.
    }
    return best;
  }

  /** Execute a BUY: SOL → token */
  async buy(mint: string, sizeSol: number, maxSlippageBps: number, priorityFeeMicroLamports?: number): Promise<SwapResult> {
    const amountLamports = Math.floor(sizeSol * LAMPORTS_PER_SOL);
    logger.info('Executing buy', { mint, sizeSol, maxSlippageBps });

    const quote = await this._quoteWithRouting(WSOL_MINT, mint, amountLamports, maxSlippageBps);
    return this._executeSwap(quote, priorityFeeMicroLamports);
  }

  /** Execute a SELL: token → SOL (token amount expressed in whole tokens). */
  async sell(mint: string, amountTokens: number, decimals: number, maxSlippageBps: number, priorityFeeMicroLamports?: number): Promise<SwapResult> {
    const amountBase = Math.floor(amountTokens * Math.pow(10, decimals));
    logger.info('Executing sell', { mint, amountTokens, decimals, maxSlippageBps });

    const quote = await this._quoteWithRouting(mint, WSOL_MINT, amountBase, maxSlippageBps);
    return this._executeSwap(quote, priorityFeeMicroLamports);
  }

  /**
   * Execute a SELL using an EXACT raw (base-unit) amount — i.e. the wallet's
   * real on-chain balance, as a string to avoid float precision loss on
   * large-supply memecoins. This is the correct way to exit a position:
   * sell exactly what you hold, never the optimistic quoted amount.
   */
  async sellRaw(mint: string, amountBaseUnits: string, maxSlippageBps: number, priorityFeeMicroLamports?: number): Promise<SwapResult> {
    logger.info('Executing sell (exact balance)', { mint, amountBaseUnits, maxSlippageBps });
    const quote = await this._quoteWithRouting(mint, WSOL_MINT, amountBaseUnits, maxSlippageBps);
    return this._executeSwap(quote, priorityFeeMicroLamports);
  }

  private async _executeSwap(quote: QuoteResult, priorityFeeMicroLamports?: number): Promise<SwapResult> {
    const hops = quote.routePlan?.length ?? 1;
    const routeLabels = (quote.routePlan ?? []).map((r) => r.swapInfo?.label ?? 'unknown');
    try {
      const computeUnitPrice = priorityFeeMicroLamports ?? this.priorityFeeMicroLamports;
      const mint = quote.outputMint !== WSOL_MINT ? quote.outputMint : quote.inputMint;
      // 1. Get serialised swap transaction from Jupiter
      const swapResponse = await axios.post<{ swapTransaction: string; lastValidBlockHeight?: number }>(
        `${this.jupiterApiUrl}/swap`,
        {
          quoteResponse: quote,
          userPublicKey: this.keypair.publicKey.toBase58(),
          wrapAndUnwrapSol: true,
          computeUnitPriceMicroLamports: computeUnitPrice,
          asLegacyTransaction: false,
          dynamicComputeUnitLimit: true,
        },
        { timeout: 15000 },
      );

      const swapTxBase64 = swapResponse.data?.swapTransaction;
      if (!swapTxBase64) throw new Error('Jupiter /swap returned no swapTransaction field');

      // 2. Deserialise + sign
      const txBytes = Buffer.from(swapTxBase64, 'base64');
      const tx = VersionedTransaction.deserialize(txBytes);
      tx.sign([this.keypair]);

      // 3. Pre-flight simulation BEFORE broadcasting.
      if (this.simulateBeforeSend) {
        const sim = await this.write.simulateTransaction(tx, {
          sigVerify: false,
          replaceRecentBlockhash: true,
          commitment: 'processed',
        });
        if (sim.value.err) {
          const simErr = JSON.stringify(sim.value.err);
          logger.warn('Pre-flight simulation failed — aborting swap', {
            mint,
            err: simErr,
            logs: sim.value.logs?.slice(-5),
          });
          return { success: false, amountIn: 0, amountOut: 0, feeSol: 0, priceImpactPct: 0, error: `simulation failed: ${simErr}`, hops, routeLabels };
        }
      }

      // 4. Submit (MEV-protected when wired, else direct RPC).
      let txHash: string | undefined;
      if (this.mevProtection) {
        const res = await this.mevProtection.submit({
          txBase64: swapTxBase64,
          mint,
          expectedOutAmount: parseInt(quote.outAmount, 10),
          slippageBps: quote.slippageBps,
          priorityFeeMicroLamports: computeUnitPrice,
        });
        if (!res.success) {
          return { success: false, amountIn: 0, amountOut: 0, feeSol: 0, priceImpactPct: 0, error: res.error ?? 'MEV submit failed', hops, routeLabels };
        }
        txHash = res.txHash ?? res.bundleId;
      } else {
        txHash = await this.write.sendRawTransaction(tx.serialize(), {
          skipPreflight: this.simulateBeforeSend,
          maxRetries: 2,
          preflightCommitment: 'confirmed',
        });
      }

      logger.info('Transaction submitted', { txHash, viaMev: !!this.mevProtection, hops });

      return {
        success: true,
        txHash,
        amountIn: parseInt(quote.inAmount, 10),
        amountOut: parseInt(quote.outAmount, 10),
        feeSol: computeUnitPrice / 1e9,
        priceImpactPct: parseFloat(quote.priceImpactPct),
        hops,
        routeLabels,
      };
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : String(err);
      logger.error('Swap execution failed', { error: errorMsg });
      return { success: false, amountIn: 0, amountOut: 0, feeSol: 0, priceImpactPct: 0, error: errorMsg, hops, routeLabels };
    }
  }
}

export default JupiterClient;
