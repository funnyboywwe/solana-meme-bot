import { AppConfig } from '../config/AppConfig';
import { createModuleLogger } from '../core/Logger';

const logger = createModuleLogger('SlippageOptimizer');

export interface SlippageConfig {
  enabled: boolean;
  minBps: number;
  maxBps: number;
  referenceOrderUsd: number;
  bufferMultiplier: number;
}

/**
 * Estimate price impact (in bps) for an order against AMM liquidity using the
 * constant-product approximation: impact ≈ orderUsd / liquidityUsd.
 */
export function estimateImpactBps(orderUsd: number, liquidityUsd: number): number {
  if (liquidityUsd <= 0) return Number.POSITIVE_INFINITY;
  return (orderUsd / liquidityUsd) * 10000;
}

/**
 * Compute an optimal slippage tolerance (bps) for a trade.
 *  - Liquid tokens (low impact)   → tight slippage near the floor (less value lost).
 *  - Illiquid tokens (high impact) → wider slippage, capped at maxBps.
 */
export function computeSlippageBps(
  orderUsd: number,
  liquidityUsd: number,
  cfg: SlippageConfig,
): number {
  if (!cfg.enabled) return cfg.maxBps;
  const impactBps = estimateImpactBps(orderUsd, liquidityUsd);
  if (!Number.isFinite(impactBps)) return cfg.maxBps;
  // Safety buffer over raw impact so the swap still lands if the pool moves
  // slightly between quote and execution.
  const buffered = impactBps * cfg.bufferMultiplier;
  return Math.min(Math.max(Math.ceil(buffered), cfg.minBps), cfg.maxBps);
}

export class SlippageOptimizer {
  private cfg: SlippageConfig;

  constructor(appCfg: AppConfig) {
    const ds = appCfg.costControl?.dynamicSlippage;
    this.cfg = {
      enabled: ds?.enabled ?? true,
      minBps: ds?.minBps ?? 50,
      // Never let dynamic slippage exceed the global execution cap.
      maxBps: Math.min(ds?.maxBps ?? appCfg.execution.maxSlippageBps, appCfg.execution.maxSlippageBps),
      referenceOrderUsd: ds?.referenceOrderUsd ?? 300,
      bufferMultiplier: ds?.bufferMultiplier ?? 1.5,
    };
  }

  /** Slippage tolerance (bps) for an order of `sizeSol` against `liquidityUsd`. */
  forOrder(sizeSol: number, solPriceUsd: number, liquidityUsd: number): number {
    const orderUsd = sizeSol * solPriceUsd;
    const bps = computeSlippageBps(orderUsd, liquidityUsd, this.cfg);
    logger.debug('Dynamic slippage', { sizeSol, orderUsd, liquidityUsd, bps });
    return bps;
  }

  /** Worst-case slippage cost in SOL for a given tolerance. */
  estimateCostSol(sizeSol: number, slippageBps: number): number {
    return sizeSol * (slippageBps / 10000);
  }

  getConfig(): SlippageConfig { return this.cfg; }
}

export default SlippageOptimizer;
