import { v4 as uuidv4 } from 'uuid';
import { EventBus, OrderReadyEvent, TradeFilledEvent, CloseSignalEvent } from '../core/EventBus';
import { AppConfig } from '../config/AppConfig';
import { createModuleLogger } from '../core/Logger';
import { Trade, Position } from '../core/types';
import { JupiterClient } from './JupiterClient';
import { TxConfirmation } from './TxConfirmation';
import { FailedTradeRecovery } from './FailedTradeRecovery';
import { PriorityFeeManager } from './PriorityFeeManager';
import { MEVProtection } from './mev/MEVProtection';
import { ExtendedConfig } from '../config/schema';
import { getPositionSizer } from '../risk/PositionSizer';
import TradeRepository from '../db/repositories/TradeRepository';
import TokenRepository from '../db/repositories/TokenRepository';
import PositionRepository from '../db/repositories/PositionRepository';
import { PendingPositions } from '../risk/exposure/PendingPositions';
import { getSolPriceUsd } from '../core/SolPrice';
import { PublicKey } from '@solana/web3.js';
import { ReadRpcProvider } from '../core/ReadRpcProvider';
import { SlippageOptimizer } from './SlippageOptimizer';
import { FeeEstimator } from './FeeEstimator';
import CostAnalytics from '../analytics/CostAnalytics';

const logger = createModuleLogger('ExecutionEngine');

/**
 * ExecutionEngine manages the full trade lifecycle.
 *
 * BUG FIXED (#16): Uses getPositionSizer() singleton — no new Connection or
 * Keypair decode here. RiskManager already initialised the singleton.
 *
 * BUG FIXED (#10): sell() now reads token decimals from TokenRepository
 * instead of hardcoding 6. Pump.fun = 6 decimals, Raydium = typically 9.
 */
export class ExecutionEngine {
  private jupiterClient: JupiterClient;
  private txConfirmation: TxConfirmation;
  private failedTradeRecovery: FailedTradeRecovery;
  private priorityFeeManager: PriorityFeeManager;
  private maxRetries: number;
  private retryDelayMs: number;
  private defaultSlippageBps: number;
  private stopLossPct: number;
  private takeProfitPct: number;
  private trailingStopPct: number;
  private readRpc: ReadRpcProvider;
  private slippageOptimizer: SlippageOptimizer;
  private feeEstimator: FeeEstimator;

  constructor(cfg: AppConfig, extCfg?: ExtendedConfig) {
    // FIX: use singleton keypair — no second decode of private key
    const sizer = getPositionSizer(cfg);
    this.jupiterClient = new JupiterClient(cfg, sizer.getKeypair());
    // Wire MEV protection (pre-flight simulation + Jito bundle fallback +
    // sandwich/front-run defense) into the swap path when extended config
    // is available.
    if (extCfg) {
      this.jupiterClient.setMevProtection(new MEVProtection(cfg, extCfg, sizer.getKeypair()));
    }
    this.txConfirmation = new TxConfirmation(cfg);
    this.failedTradeRecovery = new FailedTradeRecovery(cfg);
    this.priorityFeeManager = new PriorityFeeManager(cfg);
    this.maxRetries = cfg.execution.maxRetries;
    this.retryDelayMs = cfg.execution.retryDelayMs;
    this.defaultSlippageBps = cfg.execution.maxSlippageBps;
    // FIX: use configured risk parameters instead of hardcoded values.
    this.stopLossPct = cfg.risk.stopLossPct;
    this.takeProfitPct = cfg.risk.takeProfitPct;
    this.trailingStopPct = cfg.risk.trailingStopPct;
    this.readRpc = new ReadRpcProvider(cfg);
    // Cost-optimization helpers: dynamic per-trade slippage + cost estimation.
    this.slippageOptimizer = new SlippageOptimizer(cfg);
    this.feeEstimator = new FeeEstimator(cfg, extCfg);

    logger.info('ExecutionEngine initialized', { wallet: sizer.getWalletPublicKey() });
  }

  /** Execute a buy order (ORDER_READY → TRADE_FILLED) */
  async execute(order: OrderReadyEvent): Promise<void> {
    const { mint, strategy, sizeSol, maxSlippageBps } = order;
    try {
    if (!TokenRepository.exists(mint)) {
      logger.warn('Token not in DB — skipping buy', { mint });
      return;
    }

    const tradeId = uuidv4();
    logger.info('Executing buy', { mint, sizeSol: sizeSol.toFixed(4), strategy });

    // BUG FIX: insert the trade row ONCE before the retry loop. Previously the
    // insert lived inside the loop, so every retry re-inserted the same UUID
    // and threw "UNIQUE constraint failed: trades.id", masking the real error.
    const trade: Trade = {
      id: tradeId,
      tokenMint: mint,
      strategy,
      side: 'buy',
      amountSol: sizeSol,
      amountTokens: 0,
      status: 'pending',
      entryAt: Date.now(),
    };
    TradeRepository.insert(trade);

    for (let attempt = 1; attempt <= this.maxRetries; attempt++) {
      try {
        const priorityFee = await this.priorityFeeManager.getRecommendedFee();
        // Dynamic slippage: tight for liquid tokens, wider only when thin —
        // never above the order's max. Cheaper fills, fewer failed swaps.
        const buyTokenInfo = TokenRepository.findByMint(mint);
        const buyLiquidityUsd = buyTokenInfo?.liquidityUsd ?? 0;
        const effSlippageBps = Math.min(
          this.slippageOptimizer.forOrder(sizeSol, getSolPriceUsd(), buyLiquidityUsd),
          maxSlippageBps,
        );
        const swapResult = await this.jupiterClient.buy(mint, sizeSol, effSlippageBps, priorityFee);
        if (!swapResult.success || !swapResult.txHash) {
          logger.warn(`Buy attempt ${attempt} failed`, { mint, error: swapResult.error });
          if (attempt < this.maxRetries) { await this._delay(this.retryDelayMs * attempt); continue; }
          TradeRepository.updateStatus(tradeId, 'failed');
          return;
        }

        TradeRepository.updateStatus(tradeId, 'pending', { txHash: swapResult.txHash });

        const confirmation = await this.txConfirmation.waitForConfirmation(swapResult.txHash);

        if (confirmation.status === 'confirmed') {
          const tokenInfo = TokenRepository.findByMint(mint);
          // FIX: use actual decimals from DB, not hardcoded
          const decimals = tokenInfo?.decimals ?? 9;
          const amountTokens = swapResult.amountOut / Math.pow(10, decimals);
          const priceUsd = amountTokens > 0 ? (sizeSol * getSolPriceUsd()) / amountTokens : 0;

          TradeRepository.updateStatus(tradeId, 'confirmed', {
            txHash: swapResult.txHash,
            confirmedAt: Date.now(),
            feeSol: swapResult.feeSol,
            amountTokens,
            priceUsd,
            slippagePct: swapResult.priceImpactPct,
          });

          const positionId = uuidv4();
          const position: Position = {
            id: positionId,
            tokenMint: mint,
            entryTradeId: tradeId,
            strategy,
            sizeSol,
            entryPriceUsd: priceUsd,
            currentPriceUsd: priceUsd,
            unrealisedPnlSol: 0,
            stopLossPct: this.stopLossPct,
            takeProfitPct: this.takeProfitPct,
            trailingStopPct: this.trailingStopPct,
            trailingStopHighUsd: priceUsd,
            sizeTokens: amountTokens,
            openedAt: Date.now(),
            updatedAt: Date.now(),
            status: 'open',
          };
          PositionRepository.open(position);

          // Cost tracking (buy leg) — feeds the /costs analytics dashboard.
          const buyCongestion = this.priorityFeeManager.getCongestion();
          const buyEstimate = this.feeEstimator.estimate({
            sizeSol,
            liquidityUsd: buyLiquidityUsd,
            solPriceUsd: getSolPriceUsd(),
            priorityFeeMicroLamports: priorityFee,
            slippageBps: effSlippageBps,
            roundTrip: false,
          });
          CostAnalytics.record({
            positionId,
            tradeId,
            tokenMint: mint,
            side: 'buy',
            sizeSol,
            networkFeeSol: buyEstimate.buyNetworkFeeSol,
            priorityFeeSol: buyEstimate.buyPriorityFeeSol,
            priorityFeeMicroLamports: priorityFee,
            jitoTipSol: buyEstimate.jitoTipSol,
            dexFeeSol: buyEstimate.dexFeeSol,
            slippageBps: effSlippageBps,
            slippageCostSol: buyEstimate.slippageCostSol,
            priceImpactPct: swapResult.priceImpactPct,
            totalCostSol: buyEstimate.totalCostSol,
            costPctOfSize: buyEstimate.costPctOfSize,
            congestionLevel: buyCongestion.level,
            ts: Date.now(),
          });

          EventBus.emit('TRADE_FILLED', {
            tradeId,
            mint,
            side: 'buy',
            sizeSol,
            sizeTokens: amountTokens,
            priceUsd,
            txHash: swapResult.txHash,
            feeSol: swapResult.feeSol,
            ts: Date.now(),
          } as TradeFilledEvent);

          // Clear, single-line transaction summary so the buy is easy to find
          // in the logs with full details + a clickable Solscan link.
          logger.info('✅ BUY FILLED', {
            mint,
            tradeId,
            strategy,
            solSpent: sizeSol.toFixed(4),
            tokens: amountTokens.toFixed(2),
            entryPriceUsd: priceUsd.toFixed(8),
            tpTargetUsd: (priceUsd * (1 + this.takeProfitPct)).toFixed(8),
            slTargetUsd: (priceUsd * (1 - this.stopLossPct)).toFixed(8),
            feeSol: swapResult.feeSol,
            tx: 'https://solscan.io/tx/' + swapResult.txHash,
          });
          return;
        }

        if (confirmation.status === 'timeout') {
          const landed = await this.failedTradeRecovery.resolveTimeout(tradeId, swapResult.txHash);
          if (landed) { logger.info('Timed-out buy resolved as confirmed', { tradeId }); return; }
        }

        if (confirmation.status === 'failed') {
          TradeRepository.updateStatus(tradeId, 'failed');
          return;
        }
      } catch (err) {
        logger.error(`Buy attempt ${attempt} error`, { mint, error: String(err) });
        if (attempt < this.maxRetries) await this._delay(this.retryDelayMs * attempt);
      }
    }

    TradeRepository.updateStatus(tradeId, 'failed');
    logger.error('All buy retries exhausted', { mint, tradeId });
    } finally {
      // Release the in-flight slot reservation taken by RiskManager. On a
      // confirmed buy the DB position row now occupies the slot; on failure or
      // timeout the slot is freed for the next candidate. (CONCURRENCY FIX)
      PendingPositions.release(mint);
    }
  }

  /** Execute a sell order (CLOSE_SIGNAL → TRADE_FILLED) */
  async sell(signal: CloseSignalEvent): Promise<void> {
    const { positionId, mint, reason, currentPriceUsd } = signal;

    const position = PositionRepository.findById(positionId);
    if (!position || position.status !== 'open') {
      logger.warn('Position not found or already closed', { positionId });
      return;
    }

    // FIX: read decimals from DB — Pump.fun=6, Raydium=9, others vary
    const tokenInfo = TokenRepository.findByMint(mint);
    const decimals = tokenInfo?.decimals ?? 9;

    // FIX (#11): sell the actual token quantity recorded at entry. Fall back to
    // a price-based estimate only for legacy positions opened before
    // size_tokens was tracked.
    const entryPrice = position.entryPriceUsd > 0 ? position.entryPriceUsd : currentPriceUsd;
    const tokenAmount = position.sizeTokens && position.sizeTokens > 0
      ? position.sizeTokens
      : (entryPrice > 0 ? (position.sizeSol * getSolPriceUsd()) / entryPrice : 0);

    if (tokenAmount <= 0) {
      logger.warn('Cannot compute token amount for sell', { positionId, entryPrice });
      return;
    }

    // BUG FIX: if the wallet no longer holds this token (most often because it
    // was sold manually outside the bot), a swap can only fail with a Jupiter
    // simulation error and the position would stay 'open' forever — blocking
    // every future entry. Detect the empty balance up-front and just close the
    // stale position so trading can resume. (balance < 0 = lookup failed, so we
    // fall through and still attempt the sell.)
    // FIX: size the sell from the EXACT on-chain balance (raw base units), not
    // the optimistic amount recorded at entry. position.sizeTokens is the buy
    // *quote* output; the wallet almost always holds slightly less after
    // slippage, so selling the recorded size asks Jupiter to move more tokens
    // than we actually own → simulation fails every time (forcing a manual sell).
    const onChain = await this._getOnChainRawBalance(mint);
    if (onChain && onChain.raw === 0n) {
      logger.warn('Wallet holds 0 of this token — closing stale position without selling', { positionId, mint });
      this._closeStalePosition(position, currentPriceUsd);
      return;
    }

    const tradeId = uuidv4();
    logger.info('Executing sell', { mint, positionId, reason });

    // BUG FIX: insert the trade row ONCE before the retry loop (same trades.id
    // UNIQUE-constraint bug as the buy path).
    const trade: Trade = {
      id: tradeId,
      tokenMint: mint,
      strategy: position.strategy,
      side: 'sell',
      amountSol: 0,
      amountTokens: tokenAmount,
      status: 'pending',
      entryAt: Date.now(),
    };
    TradeRepository.insert(trade);

    for (let attempt = 1; attempt <= this.maxRetries; attempt++) {
      try {
        // FIX: pass correct decimals from token DB. Exits use 'high' urgency so
        // a position can always be closed promptly, even under congestion.
        const priorityFee = await this.priorityFeeManager.getRecommendedFee('high');
        const sellLiquidityUsd = tokenInfo?.liquidityUsd ?? 0;
        const sellSlippageBps = Math.min(
          this.slippageOptimizer.forOrder(position.sizeSol, getSolPriceUsd(), sellLiquidityUsd),
          this.defaultSlippageBps,
        );
        // Prefer the exact on-chain balance; fall back to the recorded size
        // only when the balance lookup failed (onChain === null).
        const swapResult = onChain && onChain.raw > 0n
          ? await this.jupiterClient.sellRaw(mint, onChain.raw.toString(), sellSlippageBps, priorityFee)
          : await this.jupiterClient.sell(mint, tokenAmount, decimals, sellSlippageBps, priorityFee);

        if (!swapResult.success || !swapResult.txHash) {
          logger.warn(`Sell attempt ${attempt} failed`, { mint, error: swapResult.error });
          if (attempt < this.maxRetries) { await this._delay(this.retryDelayMs * attempt); continue; }
          TradeRepository.updateStatus(tradeId, 'failed');
          return;
        }

        const confirmation = await this.txConfirmation.waitForConfirmation(swapResult.txHash);

        if (confirmation.status === 'confirmed') {
          const solReceived = swapResult.amountOut / 1e9;
          const realisedPnlSol = solReceived - position.sizeSol;
          const holdTimeSecs = Math.floor((Date.now() - position.openedAt) / 1000);

          TradeRepository.updateStatus(tradeId, 'confirmed', {
            txHash: swapResult.txHash,
            confirmedAt: Date.now(),
            feeSol: swapResult.feeSol,
            amountTokens: tokenAmount,
            priceUsd: currentPriceUsd,
          });

          PositionRepository.close(positionId, {
            id: positionId,
            tokenMint: mint,
            strategy: position.strategy,
            sizeSol: position.sizeSol,
            entryPriceUsd: position.entryPriceUsd,
            exitPriceUsd: currentPriceUsd,
            realisedPnlSol,
            holdTimeSecs,
            exitReason: reason,
            openedAt: position.openedAt,
            closedAt: Date.now(),
          });

          // Cost tracking (sell leg) — feeds the /costs analytics dashboard.
          const sellCongestion = this.priorityFeeManager.getCongestion();
          const sellEstimate = this.feeEstimator.estimate({
            sizeSol: position.sizeSol,
            liquidityUsd: sellLiquidityUsd,
            solPriceUsd: getSolPriceUsd(),
            priorityFeeMicroLamports: priorityFee,
            slippageBps: sellSlippageBps,
            roundTrip: false,
          });
          CostAnalytics.record({
            positionId,
            tradeId,
            tokenMint: mint,
            side: 'sell',
            sizeSol: position.sizeSol,
            networkFeeSol: sellEstimate.buyNetworkFeeSol,
            priorityFeeSol: sellEstimate.buyPriorityFeeSol,
            priorityFeeMicroLamports: priorityFee,
            jitoTipSol: sellEstimate.jitoTipSol,
            dexFeeSol: sellEstimate.dexFeeSol,
            slippageBps: sellSlippageBps,
            slippageCostSol: sellEstimate.slippageCostSol,
            priceImpactPct: swapResult.priceImpactPct,
            totalCostSol: sellEstimate.totalCostSol,
            costPctOfSize: sellEstimate.costPctOfSize,
            congestionLevel: sellCongestion.level,
            ts: Date.now(),
          });

          EventBus.emit('TRADE_FILLED', {
            tradeId,
            mint,
            side: 'sell',
            sizeSol: solReceived,
            sizeTokens: tokenAmount,
            priceUsd: currentPriceUsd,
            txHash: swapResult.txHash,
            feeSol: swapResult.feeSol,
            realisedPnlSol,
            ts: Date.now(),
          } as TradeFilledEvent);

          // Clear, single-line transaction summary with realised PnL in SOL and
          // percent, plus a clickable Solscan link for the exit transaction.
          const realisedPnlPct = position.sizeSol > 0 ? (realisedPnlSol / position.sizeSol) * 100 : 0;
          logger.info('✅ SELL FILLED', {
            mint,
            tradeId,
            reason,
            solSpent: position.sizeSol.toFixed(4),
            solReceived: solReceived.toFixed(4),
            realisedPnlSol: realisedPnlSol.toFixed(6),
            realisedPnlPct: realisedPnlPct.toFixed(2) + '%',
            holdTimeSecs,
            tx: 'https://solscan.io/tx/' + swapResult.txHash,
          });
          return;
        }

        if (confirmation.status === 'timeout') {
          const landed = await this.failedTradeRecovery.resolveTimeout(tradeId, swapResult.txHash);
          if (landed) return;
        }

        if (confirmation.status === 'failed') {
          TradeRepository.updateStatus(tradeId, 'failed');
          return;
        }
      } catch (err) {
        logger.error(`Sell attempt ${attempt} error`, { mint, error: String(err) });
        if (attempt < this.maxRetries) await this._delay(this.retryDelayMs * attempt);
      }
    }

    TradeRepository.updateStatus(tradeId, 'failed');
    logger.error('All sell retries exhausted', { positionId, mint });
  }

  /**
   * Sum the wallet's on-chain balance of an SPL token (UI amount). Returns -1
   * when the lookup fails so callers can distinguish "definitely empty" (0)
   * from "couldn't check" (-1).
   */
  private async _getOnChainTokenBalance(mint: string): Promise<number> {
    try {
      const owner = getPositionSizer().getKeypair().publicKey;
      const res = await this.readRpc.getParsedTokenAccountsByOwner(owner, { mint: new PublicKey(mint) });
      let total = 0;
      for (const acc of res.value) {
        const ui = (acc.account.data as any)?.parsed?.info?.tokenAmount?.uiAmount;
        if (typeof ui === 'number') total += ui;
      }
      return total;
    } catch (err) {
      logger.warn('On-chain token balance check failed', { mint, error: String(err) });
      return -1;
    }
  }

  /**
   * Read the wallet's EXACT raw (base-unit) balance + decimals for a mint.
   * Returns null only when the lookup fails (so callers can fall back to the
   * recorded amount). Uses the raw integer string from the token account —
   * NOT uiAmount — to avoid float precision loss on large-supply tokens.
   */
  private async _getOnChainRawBalance(mint: string): Promise<{ raw: bigint; decimals: number } | null> {
    try {
      const owner = getPositionSizer().getKeypair().publicKey;
      const res = await this.readRpc.getParsedTokenAccountsByOwner(owner, { mint: new PublicKey(mint) });
      let raw = 0n;
      let decimals = 0;
      for (const acc of res.value) {
        const ta = (acc.account.data as any)?.parsed?.info?.tokenAmount;
        if (ta?.amount) { raw += BigInt(ta.amount); decimals = ta.decimals ?? decimals; }
      }
      return { raw, decimals };
    } catch (err) {
      logger.warn('On-chain raw balance check failed', { mint, error: String(err) });
      return null;
    }
  }

  /**
   * Mark a position closed in the DB (exit_reason 'manual') without attempting a
   * swap — used when the tokens are no longer in the wallet. Frees the open
   * slot so ExposureManager lets new trades through again.
   */
  private _closeStalePosition(position: Position, currentPriceUsd: number): void {
    const now = Date.now();
    const holdTimeSecs = Math.max(0, Math.floor((now - position.openedAt) / 1000));
    try {
      PositionRepository.close(position.id, {
        id: position.id,
        tokenMint: position.tokenMint,
        strategy: position.strategy,
        sizeSol: position.sizeSol,
        entryPriceUsd: position.entryPriceUsd,
        exitPriceUsd: currentPriceUsd || position.currentPriceUsd,
        realisedPnlSol: 0,
        holdTimeSecs,
        exitReason: 'manual',
        openedAt: position.openedAt,
        closedAt: now,
      });
      logger.info('Stale position closed (manual reconciliation)', { positionId: position.id, mint: position.tokenMint });
    } catch (err) {
      logger.error('Failed to close stale position', { positionId: position.id, error: String(err) });
    }
  }

  private _delay(ms: number): Promise<void> {
    return new Promise((r) => setTimeout(r, ms));
  }
}

export default ExecutionEngine;
