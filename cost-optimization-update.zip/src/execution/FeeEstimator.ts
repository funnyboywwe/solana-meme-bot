import { LAMPORTS_PER_SOL } from '@solana/web3.js';
import { AppConfig } from '../config/AppConfig';
import { ExtendedConfig } from '../config/schema';

// A Jupiter swap on Solana typically consumes 150k–400k compute units. We size
// the priority-fee cost off a conservative default unless told otherwise.
export const DEFAULT_COMPUTE_UNITS = 200_000;

export interface CostInputs {
  sizeSol: number;
  liquidityUsd: number;
  solPriceUsd: number;
  /** microLamports per compute unit (from PriorityFeeManager). */
  priorityFeeMicroLamports: number;
  slippageBps: number;
  /** Include the sell leg in the estimate (default true = full round trip). */
  roundTrip?: boolean;
  computeUnits?: number;
}

export interface TradeCostEstimate {
  buyNetworkFeeSol: number;
  buyPriorityFeeSol: number;
  sellNetworkFeeSol: number;
  sellPriorityFeeSol: number;
  jitoTipSol: number;
  dexFeeSol: number;
  slippageCostSol: number;
  totalCostSol: number;
  /** Total cost as a fraction of position size (0..1). */
  costPctOfSize: number;
}

export interface FeeModelConfig {
  baseTxFeeSol: number;
  dexFeePct: number;
  jitoEnabled: boolean;
  jitoTipLamports: number;
  computeUnits: number;
}

/** Convert microLamports-per-CU × CU → SOL. */
export function priorityFeeSol(microLamportsPerCu: number, computeUnits: number): number {
  // microLamports × CU = total microLamports; /1e6 → lamports; /1e9 → SOL.
  return (microLamportsPerCu * computeUnits) / 1e6 / LAMPORTS_PER_SOL;
}

/**
 * Pure, fully-testable cost model. Breaks a (round-trip) trade into every
 * component cost: base network fee, priority fee, Jito tip, DEX/LP fee and
 * slippage — for both the buy and (optionally) the sell leg.
 */
export function estimateTradeCost(inputs: CostInputs, model: FeeModelConfig): TradeCostEstimate {
  const roundTrip = inputs.roundTrip !== false;
  const cu = inputs.computeUnits ?? model.computeUnits;

  const buyNetworkFeeSol = model.baseTxFeeSol;
  const buyPriorityFeeSol = priorityFeeSol(inputs.priorityFeeMicroLamports, cu);
  const sellNetworkFeeSol = roundTrip ? model.baseTxFeeSol : 0;
  const sellPriorityFeeSol = roundTrip ? priorityFeeSol(inputs.priorityFeeMicroLamports, cu) : 0;

  // Jito tip is paid once per landed bundle (buy). On a round trip the sell may
  // also be bundled, so model both legs.
  const jitoTipSol = model.jitoEnabled
    ? (model.jitoTipLamports / LAMPORTS_PER_SOL) * (roundTrip ? 2 : 1)
    : 0;

  // DEX/LP fee is charged on each swap as a % of notional.
  const dexFeeSol = inputs.sizeSol * model.dexFeePct * (roundTrip ? 2 : 1);

  // Slippage cost: worst-case value lost to the tolerance on each leg.
  const slippageCostSol = inputs.sizeSol * (inputs.slippageBps / 10000) * (roundTrip ? 2 : 1);

  const totalCostSol =
    buyNetworkFeeSol + buyPriorityFeeSol + sellNetworkFeeSol + sellPriorityFeeSol +
    jitoTipSol + dexFeeSol + slippageCostSol;

  const costPctOfSize = inputs.sizeSol > 0 ? totalCostSol / inputs.sizeSol : 1;

  return {
    buyNetworkFeeSol,
    buyPriorityFeeSol,
    sellNetworkFeeSol,
    sellPriorityFeeSol,
    jitoTipSol,
    dexFeeSol,
    slippageCostSol,
    totalCostSol,
    costPctOfSize,
  };
}

/**
 * FeeEstimator wraps the pure cost model with config-derived parameters
 * (base tx fee, DEX fee %, Jito tip, assumed compute units).
 */
export class FeeEstimator {
  private model: FeeModelConfig;

  constructor(cfg: AppConfig, extCfg?: ExtendedConfig) {
    const cc = cfg.costControl;
    this.model = {
      baseTxFeeSol: cc?.baseTxFeeSol ?? 0.000005,
      dexFeePct: cc?.dexFeePct ?? 0.0025,
      jitoEnabled: extCfg?.mevProtection.jitoEnabled ?? false,
      jitoTipLamports: extCfg?.mevProtection.jitoTipLamports ?? 0,
      computeUnits: cc?.assumedComputeUnits ?? DEFAULT_COMPUTE_UNITS,
    };
  }

  estimate(inputs: CostInputs): TradeCostEstimate {
    return estimateTradeCost(inputs, this.model);
  }

  getModel(): FeeModelConfig { return this.model; }
}

export default FeeEstimator;
