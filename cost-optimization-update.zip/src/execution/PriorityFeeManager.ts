import { Connection } from '@solana/web3.js';
import { createModuleLogger } from '../core/Logger';
import { AppConfig } from '../config/AppConfig';
import { getRpcManager, RpcManager } from '../core/RpcManager';

const logger = createModuleLogger('PriorityFeeManager');

export type FeeUrgency = 'low' | 'normal' | 'high';
export type CongestionLevel = 'low' | 'medium' | 'high';

export interface FeeBounds {
  /** Floor (microLamports per compute unit) — used during normal conditions. */
  minMicroLamports: number;
  /** Hard ceiling, even at peak congestion. */
  maxMicroLamports: number;
  /** Median-over-floor ratio above which the network is treated as congested. */
  congestionMultiplier: number;
}

export interface CongestionReport {
  level: CongestionLevel;
  sampleCount: number;
  p25: number;
  p50: number;
  p75: number;
  p90: number;
  recommendedMicroLamports: number;
}

/** Percentile of an ascending-sorted array. p in [0,1]. */
export function percentile(sortedAsc: number[], p: number): number {
  if (sortedAsc.length === 0) return 0;
  const idx = Math.min(sortedAsc.length - 1, Math.max(0, Math.floor(p * (sortedAsc.length - 1))));
  return sortedAsc[idx] ?? 0;
}

/**
 * Pure, RPC-free priority-fee computation so the policy is fully unit-testable.
 *
 * Policy:
 *  - No samples            → pay the floor (cheapest that still lands).
 *  - Normal conditions     → pay the floor (LOW). We do NOT overpay when the
 *                            network is quiet.
 *  - Congestion            → climb toward a percentile of the live market fee
 *                            (p25/p75/p90 by urgency), always clamped to
 *                            [min, max].
 */
export function computeRecommendedFee(
  rawSamples: number[],
  bounds: FeeBounds,
  urgency: FeeUrgency = 'normal',
): CongestionReport {
  const fees = rawSamples
    .filter((f) => Number.isFinite(f) && f > 0)
    .sort((a, b) => a - b);
  const { minMicroLamports, maxMicroLamports, congestionMultiplier } = bounds;

  if (fees.length === 0) {
    return {
      level: 'low', sampleCount: 0, p25: 0, p50: 0, p75: 0, p90: 0,
      recommendedMicroLamports: minMicroLamports,
    };
  }

  const p25 = percentile(fees, 0.25);
  const p50 = percentile(fees, 0.50);
  const p75 = percentile(fees, 0.75);
  const p90 = percentile(fees, 0.90);

  // Congestion = how far the prevailing (median) market fee sits above our floor.
  const congestionRatio = minMicroLamports > 0 ? p50 / minMicroLamports : 1;
  let level: CongestionLevel;
  if (congestionRatio <= 1) level = 'low';
  else if (congestionRatio <= congestionMultiplier) level = 'medium';
  else level = 'high';

  // Choose a target. Normal/quiet network → floor. Congested → market percentile.
  let target: number;
  if (level === 'low') {
    target = minMicroLamports;
  } else {
    target = urgency === 'low' ? p25 : urgency === 'high' ? p90 : p75;
  }

  // Urgency nudges: a high-urgency exit pays at least p75 even when quiet; a
  // low-urgency entry never pays above the median.
  if (urgency === 'high') target = Math.max(target, p75);
  if (urgency === 'low') target = Math.min(target, Math.max(minMicroLamports, p50));

  const recommended = Math.round(
    Math.min(Math.max(target, minMicroLamports), maxMicroLamports),
  );

  return { level, sampleCount: fees.length, p25, p50, p75, p90, recommendedMicroLamports: recommended };
}

/**
 * PriorityFeeManager — adaptive, congestion-aware priority fee.
 *
 * Reads recent prioritization fees from the RPC, classifies congestion, and
 * recommends a microLamports-per-CU value bounded by [min, max] from config
 * (env: MIN_PRIORITY_FEE / MAX_PRIORITY_FEE). Results are cached for
 * `feeRefreshMs` so the hot path never blocks on RPC.
 *
 * The public API (`getRecommendedFee()`) is unchanged so existing callers keep
 * working; an optional `urgency` argument lets exits pay up to land faster.
 */
export class PriorityFeeManager {
  private rpc: RpcManager;
  private get connection(): Connection { return this.rpc.getConnection(); }
  private bounds: FeeBounds;
  private cacheMs: number;
  private cached: CongestionReport;
  private lastSamples: number[] = [];
  private lastFetchedAt = 0;

  constructor(cfg: AppConfig) {
    this.rpc = getRpcManager(cfg);
    const cc = cfg.costControl;
    const base = cfg.execution.priorityFeeMicroLamports;
    this.bounds = {
      minMicroLamports: cc?.minPriorityFeeMicroLamports ?? Math.min(base, 10000),
      maxMicroLamports: cc?.maxPriorityFeeMicroLamports ?? Math.max(base * 3, 1000000),
      congestionMultiplier: cc?.congestionMultiplier ?? 3,
    };
    this.cacheMs = cc?.feeRefreshMs ?? 15000;
    this.cached = {
      level: 'low', sampleCount: 0, p25: 0, p50: 0, p75: 0, p90: 0,
      recommendedMicroLamports: this.bounds.minMicroLamports,
    };
    logger.info('PriorityFeeManager initialized', this.bounds);
  }

  /** Refresh the cached congestion snapshot (rate-limited by feeRefreshMs). */
  async refresh(): Promise<CongestionReport> {
    const now = Date.now();
    if (now - this.lastFetchedAt < this.cacheMs && this.cached.sampleCount > 0) {
      return this.cached;
    }
    try {
      const response = await this.connection.getRecentPrioritizationFees();
      this.lastSamples = (response ?? []).map((f) => f.prioritizationFee);
      this.cached = computeRecommendedFee(this.lastSamples, this.bounds, 'normal');
      this.lastFetchedAt = now;
      logger.debug('Priority fee refreshed', {
        level: this.cached.level,
        recommended: this.cached.recommendedMicroLamports,
        p50: this.cached.p50,
        p75: this.cached.p75,
        samples: this.cached.sampleCount,
      });
    } catch (err) {
      logger.warn('Failed to fetch priority fees, using floor', { error: String(err) });
      this.cached = { ...this.cached, recommendedMicroLamports: this.bounds.minMicroLamports };
    }
    return this.cached;
  }

  /**
   * Recommended priority fee in microLamports per compute unit.
   * @param urgency 'low' (cheapest), 'normal' (default), 'high' (land fast).
   */
  async getRecommendedFee(urgency: FeeUrgency = 'normal'): Promise<number> {
    await this.refresh();
    if (urgency === 'normal' || this.lastSamples.length === 0) {
      return this.cached.recommendedMicroLamports;
    }
    return computeRecommendedFee(this.lastSamples, this.bounds, urgency).recommendedMicroLamports;
  }

  /** Latest congestion snapshot (no RPC). */
  getCongestion(): CongestionReport { return this.cached; }

  getBounds(): FeeBounds { return this.bounds; }
}

export default PriorityFeeManager;
