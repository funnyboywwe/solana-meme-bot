import { AppConfig } from '../config/AppConfig';
import { ExtendedConfig } from '../config/schema';
import { createModuleLogger } from '../core/Logger';
import { FeeEstimator, TradeCostEstimate } from '../execution/FeeEstimator';

const logger = createModuleLogger('FeeAwareFilter');

export interface FeeAwareInput {
  mint: string;
  sizeSol: number;
  liquidityUsd: number;
  solPriceUsd: number;
  priorityFeeMicroLamports: number;
  slippageBps: number;
  /** Gross upside thesis for the trade (e.g. take-profit target), 0..1. */
  expectedGainPct: number;
}

export interface FeeAwareDecision {
  pass: boolean;
  reason: string;
  estimate: TradeCostEstimate;
  /** Total estimated cost as a fraction of size (0..1). */
  costPct: number;
  /** Gross profit % required to enter (0..1). */
  requiredProfitPct: number;
  expectedGainPct: number;
  expectedNetProfitSol: number;
  profitToCostRatio: number;
  feeWarning: boolean;
}

/**
 * FeeAwareFilter implements the pre-trade profitability gate.
 *
 * A trade is only allowed when the expected gross gain comfortably exceeds the
 * estimated round-trip cost:
 *
 *     requiredProfitPct = max(MIN_EXPECTED_PROFIT, costPct × MIN_PROFIT_TO_COST_RATIO)
 *     enter  ⇔  expectedGainPct >= requiredProfitPct
 *
 * Example (defaults): cost 2% → required gain = max(10%, 2% × 5) = 10%.
 */
export class FeeAwareFilter {
  private estimator: FeeEstimator;
  private enabled: boolean;
  private minExpectedProfitPct: number;
  private minProfitToCostRatio: number;
  private feeWarnPctOfSize: number;

  constructor(cfg: AppConfig, extCfg?: ExtendedConfig, estimator?: FeeEstimator) {
    this.estimator = estimator ?? new FeeEstimator(cfg, extCfg);
    const fa = cfg.costControl?.feeAware;
    this.enabled = fa?.enabled ?? true;
    this.minExpectedProfitPct = fa?.minExpectedProfitPct ?? 0.10;
    this.minProfitToCostRatio = fa?.minProfitToCostRatio ?? 5;
    this.feeWarnPctOfSize = fa?.feeWarnPctOfSize ?? 0.05;
  }

  evaluate(input: FeeAwareInput): FeeAwareDecision {
    const estimate = this.estimator.estimate({
      sizeSol: input.sizeSol,
      liquidityUsd: input.liquidityUsd,
      solPriceUsd: input.solPriceUsd,
      priorityFeeMicroLamports: input.priorityFeeMicroLamports,
      slippageBps: input.slippageBps,
      roundTrip: true,
    });

    const costPct = estimate.costPctOfSize;
    const requiredProfitPct = Math.max(
      this.minExpectedProfitPct,
      costPct * this.minProfitToCostRatio,
    );
    const expectedNetProfitSol = input.sizeSol * (input.expectedGainPct - costPct);
    const profitToCostRatio = estimate.totalCostSol > 0
      ? (input.sizeSol * input.expectedGainPct) / estimate.totalCostSol
      : Number.POSITIVE_INFINITY;
    const feeWarning = costPct >= this.feeWarnPctOfSize;

    let pass = true;
    let reason = 'ok';
    if (!this.enabled) {
      reason = 'filter disabled';
    } else if (input.expectedGainPct < requiredProfitPct) {
      pass = false;
      reason =
        `expected gain ${(input.expectedGainPct * 100).toFixed(1)}% < required ` +
        `${(requiredProfitPct * 100).toFixed(1)}% ` +
        `(cost ${(costPct * 100).toFixed(2)}% × ${this.minProfitToCostRatio})`;
    }

    if (feeWarning) {
      logger.warn('Fees are a large share of trade size', {
        mint: input.mint,
        costPct: +(costPct * 100).toFixed(2),
        sizeSol: input.sizeSol,
      });
    }

    return {
      pass,
      reason,
      estimate,
      costPct,
      requiredProfitPct,
      expectedGainPct: input.expectedGainPct,
      expectedNetProfitSol,
      profitToCostRatio,
      feeWarning,
    };
  }
}

export default FeeAwareFilter;
