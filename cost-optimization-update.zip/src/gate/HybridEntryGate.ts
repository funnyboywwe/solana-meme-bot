import { EventBus, MomentumSignalEvent, CopySignalEvent, EntryApprovedEvent, SmartMoneyClusterEvent, MultiWalletConfirmedEvent } from '../core/EventBus';
import { AppConfig } from '../config/AppConfig';
import { ExtendedConfig } from '../config/schema';
import { createModuleLogger } from '../core/Logger';
import TokenRepository from '../db/repositories/TokenRepository';
import { SafetyEngine } from '../engines/safety/SafetyEngine';
import { EntryConditions } from './EntryConditions';
import { SmartMoneyClusterEngine } from '../engines/smart-money/SmartMoneyClusterEngine';
import { LiquidityInflowEngine } from '../engines/liquidity/LiquidityInflowEngine';
import { MultiWalletConfirmation } from '../engines/confirmation/MultiWalletConfirmation';
import { HolderGrowthEngine } from '../engines/holders/HolderGrowthEngine';
import { GlobalKillSwitch } from '../risk/GlobalKillSwitch';
import { FeeAwareFilter } from './FeeAwareFilter';
import { SlippageOptimizer } from '../execution/SlippageOptimizer';
import { getSolPriceUsd } from '../core/SolPrice';

const logger = createModuleLogger('HybridEntryGate');

export class HybridEntryGate {
  private safetyEngine: SafetyEngine;
  private conditions: EntryConditions;
  private clusterEngine: SmartMoneyClusterEngine | null = null;
  private liquidityEngine: LiquidityInflowEngine | null = null;
  private confirmationEngine: MultiWalletConfirmation | null = null;
  private holderEngine: HolderGrowthEngine | null = null;
  private killSwitch: GlobalKillSwitch | null = null;
  private requireBoth: boolean;
  private momentumThreshold: number;
  private copyThreshold: number;
  private minTokenAgeMs: number;
  private maxTokenAgeMs: number;
  private extCfg: ExtendedConfig | null = null;
  private feeAwareFilter: FeeAwareFilter;
  private slippageOptimizer: SlippageOptimizer;
  private feeAwareEnabled: boolean;
  private refSizeSol: number;
  private expectedGainPct: number;
  private basePriorityFee: number;

  constructor(cfg: AppConfig, safetyEngine: SafetyEngine, extCfg?: ExtendedConfig) {
    this.safetyEngine = safetyEngine;
    this.conditions = new EntryConditions(cfg);
    this.requireBoth = cfg.trading.strategies.hybrid.requireBoth;
    this.momentumThreshold = cfg.trading.strategies.momentum.scoreThreshold;
    this.copyThreshold = cfg.trading.strategies.copy.walletScoreThreshold;
    this.minTokenAgeMs = cfg.filters.minTokenAgeMs;
    this.maxTokenAgeMs = cfg.filters.maxTokenAgeMs;
    this.extCfg = extCfg ?? null;
    // Fee-aware profitability gate (cost optimization). Uses a representative
    // trade size because the actual size is decided downstream (RiskManager).
    this.feeAwareFilter = new FeeAwareFilter(cfg, extCfg);
    this.slippageOptimizer = new SlippageOptimizer(cfg);
    this.feeAwareEnabled = cfg.costControl?.feeAware?.enabled ?? true;
    this.refSizeSol = cfg.risk.fixedPositionSizeSol > 0
      ? cfg.risk.fixedPositionSizeSol
      : (cfg.costControl?.feeAware?.referenceSizeSol ?? 0.03);
    this.expectedGainPct = cfg.risk.takeProfitPct;
    this.basePriorityFee = cfg.execution.priorityFeeMicroLamports;

    logger.info('HybridEntryGate initialized', {
      requireBoth: this.requireBoth,
      momentumThreshold: this.momentumThreshold,
      copyThreshold: this.copyThreshold,
    });
  }

  wireEngines(opts: {
    clusterEngine?: SmartMoneyClusterEngine;
    liquidityEngine?: LiquidityInflowEngine;
    confirmationEngine?: MultiWalletConfirmation;
    holderEngine?: HolderGrowthEngine;
    killSwitch?: GlobalKillSwitch;
  }): void {
    this.clusterEngine = opts.clusterEngine ?? null;
    this.liquidityEngine = opts.liquidityEngine ?? null;
    this.confirmationEngine = opts.confirmationEngine ?? null;
    this.holderEngine = opts.holderEngine ?? null;
    this.killSwitch = opts.killSwitch ?? null;
    logger.info('Extended engines wired into entry gate');
  }

  async evaluateMomentum(signal: MomentumSignalEvent): Promise<void> {
    if (signal.score < this.momentumThreshold) return;
    await this._evaluate(signal.mint, 'momentum', signal.score, undefined);
  }

  async evaluateCopy(signal: CopySignalEvent): Promise<void> {
    if (signal.walletScore < this.copyThreshold) return;
    await this._evaluate(signal.mint, 'copy', undefined, signal.walletScore);
  }

  async evaluateSmartMoneyCluster(signal: SmartMoneyClusterEvent): Promise<void> {
    const minConf = this.extCfg?.smartMoney.minConfidenceScore ?? 60;
    if (signal.confidenceScore < minConf) return;
    await this._evaluate(signal.tokenMint, 'hybrid', undefined, undefined);
  }

  async evaluateMultiWalletConfirmed(signal: MultiWalletConfirmedEvent): Promise<void> {
    await this._evaluate(signal.tokenMint, 'hybrid', undefined, undefined);
  }

  private async _evaluate(
    mint: string,
    strategy: 'momentum' | 'copy' | 'hybrid',
    momentumScore?: number,
    walletScore?: number,
  ): Promise<void> {
    try {
      // 1. Kill switch
      if (this.killSwitch?.isActive()) {
        logger.debug('Blocked by kill switch', { mint });
        return;
      }

      // 2. Token age
      const tokenInfo = TokenRepository.findByMint(mint);
      if (!tokenInfo) { logger.warn('Token not in DB', { mint }); return; }
      const tokenAgeMs = Date.now() - tokenInfo.createdAt;
      if (tokenAgeMs < this.minTokenAgeMs) {
        logger.debug('Token too new', { mint });
        return;
      }
      // Final safety net: never buy aged tokens, only fresh launches.
      if (tokenAgeMs > this.maxTokenAgeMs) {
        logger.info('Token too old — only fresh launches allowed', { mint, tokenAgeMs, maxTokenAgeMs: this.maxTokenAgeMs });
        return;
      }

      // 3. Safety
      const safety = await this.safetyEngine.evaluate(mint);
      if (!safety.pass) {
        logger.info('Safety fail', { mint, rugScore: safety.rugScore });
        return;
      }

      // 4. Liquidity health
      if (this.liquidityEngine && !this.liquidityEngine.isLiquidityHealthy(mint)) {
        logger.info('Liquidity declining', { mint });
        return;
      }

      // 5. Holder health (only when the engine is enabled — consistent with the
      //    multi-wallet gate below, which also checks its enabled flag).
      if (this.holderEngine && this.extCfg?.holderGrowth.enabled && !this.holderEngine.isHealthy(mint)) {
        logger.info('Unhealthy holders', { mint });
        return;
      }

      // 6. Multi-wallet confirmation
      if (this.confirmationEngine && this.extCfg?.multiWalletConfirmation.enabled) {
        if (!this.confirmationEngine.hasConfirmation(mint)) {
          logger.debug('No multi-wallet confirmation', {
            mint,
            pending: this.confirmationEngine.getPendingCount(mint),
            required: this.extCfg.multiWalletConfirmation.requiredWallets,
          });
          return;
        }
      }

      // 7. Basic conditions
      if (!this.conditions.checkLiquidity(tokenInfo.liquidityUsd)) return;
      if (!this.conditions.checkMarketCap(tokenInfo.mcapUsd)) return;
      if (!this.conditions.checkSlippage(tokenInfo.liquidityUsd)) return;

      // 8. Fee-aware profitability gate: reject trades whose expected upside
      //    can't comfortably clear the estimated round-trip cost
      //    (requiredProfit = max(MIN_EXPECTED_PROFIT, cost% × MIN_PROFIT_TO_COST_RATIO)).
      if (this.feeAwareEnabled) {
        const solPriceUsd = getSolPriceUsd();
        const slippageBps = this.slippageOptimizer.forOrder(
          this.refSizeSol, solPriceUsd, tokenInfo.liquidityUsd,
        );
        const decision = this.feeAwareFilter.evaluate({
          mint,
          sizeSol: this.refSizeSol,
          liquidityUsd: tokenInfo.liquidityUsd,
          solPriceUsd,
          priorityFeeMicroLamports: this.basePriorityFee,
          slippageBps,
          expectedGainPct: this.expectedGainPct,
        });
        if (!decision.pass) {
          logger.info('Blocked by fee-aware filter', {
            mint,
            reason: decision.reason,
            costPct: +(decision.costPct * 100).toFixed(2),
          });
          return;
        }
      }

      logger.info('Entry approved', { mint, strategy, momentumScore, walletScore });

      EventBus.emit('ENTRY_APPROVED', {
        mint, strategy, momentumScore, walletScore, sizeSol: 0, ts: Date.now(),
      } as EntryApprovedEvent);
    } catch (err) {
      logger.error('Entry gate error', { mint, error: String(err) });
    }
  }
}

export default HybridEntryGate;
