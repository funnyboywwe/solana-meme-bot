import { getDb } from '../Database';
import { createModuleLogger } from '../../core/Logger';

const logger = createModuleLogger('TradeCostRepository');

export interface TradeCostRecord {
  positionId?: string;
  tradeId?: string;
  tokenMint: string;
  side: 'buy' | 'sell';
  sizeSol: number;
  networkFeeSol: number;
  priorityFeeSol: number;
  priorityFeeMicroLamports: number;
  jitoTipSol: number;
  dexFeeSol: number;
  slippageBps: number;
  slippageCostSol: number;
  priceImpactPct: number;
  totalCostSol: number;
  costPctOfSize: number;
  congestionLevel?: string;
  ts: number;
}

export interface CostAverages {
  sampleCount: number;
  avgTotalCostSol: number;
  avgPriorityFeeSol: number;
  avgSlippageCostSol: number;
  avgDexFeeSol: number;
  avgJitoTipSol: number;
  avgNetworkFeeSol: number;
  /** Average cost as a fraction of size (0..1). */
  avgCostPctOfSize: number;
  totalCostSol: number;
}

interface CostRow {
  position_id: string | null;
  trade_id: string | null;
  token_mint: string;
  side: string;
  size_sol: number;
  network_fee_sol: number;
  priority_fee_sol: number;
  priority_fee_microlamports: number;
  jito_tip_sol: number;
  dex_fee_sol: number;
  slippage_bps: number;
  slippage_cost_sol: number;
  price_impact_pct: number;
  total_cost_sol: number;
  cost_pct_of_size: number;
  congestion_level: string | null;
  ts: number;
}

export const TradeCostRepository = {
  record(r: TradeCostRecord): void {
    const db = getDb();
    db.prepare(`
      INSERT INTO trade_costs (position_id, trade_id, token_mint, side, size_sol,
        network_fee_sol, priority_fee_sol, priority_fee_microlamports, jito_tip_sol,
        dex_fee_sol, slippage_bps, slippage_cost_sol, price_impact_pct, total_cost_sol,
        cost_pct_of_size, congestion_level, ts)
      VALUES (@position_id, @trade_id, @token_mint, @side, @size_sol,
        @network_fee_sol, @priority_fee_sol, @priority_fee_microlamports, @jito_tip_sol,
        @dex_fee_sol, @slippage_bps, @slippage_cost_sol, @price_impact_pct, @total_cost_sol,
        @cost_pct_of_size, @congestion_level, @ts)
    `).run({
      position_id: r.positionId ?? null,
      trade_id: r.tradeId ?? null,
      token_mint: r.tokenMint,
      side: r.side,
      size_sol: r.sizeSol,
      network_fee_sol: r.networkFeeSol,
      priority_fee_sol: r.priorityFeeSol,
      priority_fee_microlamports: Math.round(r.priorityFeeMicroLamports),
      jito_tip_sol: r.jitoTipSol,
      dex_fee_sol: r.dexFeeSol,
      slippage_bps: Math.round(r.slippageBps),
      slippage_cost_sol: r.slippageCostSol,
      price_impact_pct: r.priceImpactPct,
      total_cost_sol: r.totalCostSol,
      cost_pct_of_size: r.costPctOfSize,
      congestion_level: r.congestionLevel ?? null,
      ts: r.ts,
    });
  },

  getAverages(sinceMs?: number): CostAverages {
    const db = getDb();
    const since = sinceMs ? Date.now() - sinceMs : 0;
    const row = db.prepare(`
      SELECT
        COUNT(*)                          AS n,
        COALESCE(AVG(total_cost_sol),0)   AS avg_total,
        COALESCE(AVG(priority_fee_sol),0) AS avg_prio,
        COALESCE(AVG(slippage_cost_sol),0)AS avg_slip,
        COALESCE(AVG(dex_fee_sol),0)      AS avg_dex,
        COALESCE(AVG(jito_tip_sol),0)     AS avg_jito,
        COALESCE(AVG(network_fee_sol),0)  AS avg_net,
        COALESCE(AVG(cost_pct_of_size),0) AS avg_pct,
        COALESCE(SUM(total_cost_sol),0)   AS sum_total
      FROM trade_costs WHERE ts >= ?
    `).get(since) as {
      n: number; avg_total: number; avg_prio: number; avg_slip: number;
      avg_dex: number; avg_jito: number; avg_net: number; avg_pct: number; sum_total: number;
    };
    return {
      sampleCount: row.n ?? 0,
      avgTotalCostSol: row.avg_total ?? 0,
      avgPriorityFeeSol: row.avg_prio ?? 0,
      avgSlippageCostSol: row.avg_slip ?? 0,
      avgDexFeeSol: row.avg_dex ?? 0,
      avgJitoTipSol: row.avg_jito ?? 0,
      avgNetworkFeeSol: row.avg_net ?? 0,
      avgCostPctOfSize: row.avg_pct ?? 0,
      totalCostSol: row.sum_total ?? 0,
    };
  },

  recent(limit = 100): TradeCostRecord[] {
    const db = getDb();
    const rows = db.prepare('SELECT * FROM trade_costs ORDER BY ts DESC LIMIT ?').all(limit) as CostRow[];
    return rows.map((row) => ({
      positionId: row.position_id ?? undefined,
      tradeId: row.trade_id ?? undefined,
      tokenMint: row.token_mint,
      side: row.side as 'buy' | 'sell',
      sizeSol: row.size_sol,
      networkFeeSol: row.network_fee_sol,
      priorityFeeSol: row.priority_fee_sol,
      priorityFeeMicroLamports: row.priority_fee_microlamports,
      jitoTipSol: row.jito_tip_sol,
      dexFeeSol: row.dex_fee_sol,
      slippageBps: row.slippage_bps,
      slippageCostSol: row.slippage_cost_sol,
      priceImpactPct: row.price_impact_pct,
      totalCostSol: row.total_cost_sol,
      costPctOfSize: row.cost_pct_of_size,
      congestionLevel: row.congestion_level ?? undefined,
      ts: row.ts,
    }));
  },
};

export default TradeCostRepository;
void logger;
