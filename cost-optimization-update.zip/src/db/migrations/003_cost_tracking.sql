-- ─── Migration 003: Per-trade transaction-cost tracking ──────────────────────
-- Backward-compatible additions. Run after 002_extensions.sql.
-- Stores a full cost breakdown for every executed buy/sell leg so the bot can
-- (a) report average fees / slippage / priority cost on the dashboard and
-- (b) feed historical cost data back into the fee-aware entry filter.

CREATE TABLE IF NOT EXISTS trade_costs (
  id                          INTEGER PRIMARY KEY AUTOINCREMENT,
  position_id                 TEXT,
  trade_id                    TEXT,
  token_mint                  TEXT NOT NULL,
  side                        TEXT NOT NULL CHECK(side IN ('buy','sell')),
  size_sol                    REAL NOT NULL DEFAULT 0,
  network_fee_sol             REAL NOT NULL DEFAULT 0,
  priority_fee_sol            REAL NOT NULL DEFAULT 0,
  priority_fee_microlamports  INTEGER NOT NULL DEFAULT 0,
  jito_tip_sol                REAL NOT NULL DEFAULT 0,
  dex_fee_sol                 REAL NOT NULL DEFAULT 0,
  slippage_bps                INTEGER NOT NULL DEFAULT 0,
  slippage_cost_sol           REAL NOT NULL DEFAULT 0,
  price_impact_pct            REAL NOT NULL DEFAULT 0,
  total_cost_sol              REAL NOT NULL DEFAULT 0,
  cost_pct_of_size            REAL NOT NULL DEFAULT 0,
  congestion_level            TEXT,
  ts                          INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_trade_costs_mint ON trade_costs(token_mint, ts DESC);
CREATE INDEX IF NOT EXISTS idx_trade_costs_ts   ON trade_costs(ts);
CREATE INDEX IF NOT EXISTS idx_trade_costs_side ON trade_costs(side, ts DESC);
