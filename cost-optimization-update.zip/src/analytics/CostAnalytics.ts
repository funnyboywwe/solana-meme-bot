import { createModuleLogger } from '../core/Logger';
import TradeCostRepository, { CostAverages, TradeCostRecord } from '../db/repositories/TradeCostRepository';
import { getDb } from '../db/Database';

const logger = createModuleLogger('CostAnalytics');

export interface CostDashboard {
  windowMs: number;
  averages: CostAverages;
  avgFeePerTradeSol: number;
  avgPriorityFeeSol: number;
  avgSlippageCostSol: number;
  /** Average cost as a percentage of trade size. */
  costPctOfTradeSize: number;
  realisedPnlSol: number;
  totalTrackedCostsSol: number;
  /** Realised PnL is already net of on-chain swap economics. */
  netProfitAfterCostsSol: number;
}

/**
 * CostAnalytics is the single surface for transaction-cost reporting. It
 * persists a per-leg cost breakdown for every executed trade and aggregates it
 * for the dashboard (average fee / priority fee / slippage, cost % of size, and
 * net profit after costs).
 */
export const CostAnalytics = {
  record(r: TradeCostRecord): void {
    try {
      TradeCostRepository.record(r);
    } catch (err) {
      logger.warn('Failed to record trade cost', { error: String(err) });
    }
  },

  getDashboard(windowMs = 7 * 86400000): CostDashboard {
    const averages = TradeCostRepository.getAverages(windowMs);
    const db = getDb();
    const since = Date.now() - windowMs;
    const pnlRow = db
      .prepare('SELECT COALESCE(SUM(realised_pnl_sol),0) AS pnl FROM closed_positions WHERE closed_at >= ?')
      .get(since) as { pnl: number };
    const realisedPnlSol = pnlRow.pnl ?? 0;

    return {
      windowMs,
      averages,
      avgFeePerTradeSol: averages.avgTotalCostSol,
      avgPriorityFeeSol: averages.avgPriorityFeeSol,
      avgSlippageCostSol: averages.avgSlippageCostSol,
      costPctOfTradeSize: averages.avgCostPctOfSize * 100,
      realisedPnlSol,
      totalTrackedCostsSol: averages.totalCostSol,
      // closed_positions PnL already reflects actual on-chain proceeds minus
      // spend, so it is the realised net figure. totalTrackedCostsSol surfaces
      // the explicit fee drag for transparency.
      netProfitAfterCostsSol: realisedPnlSol,
    };
  },
};

export default CostAnalytics;
