import {
  estimateImpactBps,
  computeSlippageBps,
  SlippageConfig,
} from '../../../src/execution/SlippageOptimizer';

const cfg: SlippageConfig = {
  enabled: true,
  minBps: 50,
  maxBps: 300,
  referenceOrderUsd: 300,
  bufferMultiplier: 1.5,
};

describe('estimateImpactBps', () => {
  it('computes constant-product price impact in bps', () => {
    expect(estimateImpactBps(300, 300000)).toBeCloseTo(10, 6); // 0.1% = 10 bps
  });

  it('returns Infinity for zero liquidity', () => {
    expect(estimateImpactBps(300, 0)).toBe(Number.POSITIVE_INFINITY);
  });
});

describe('computeSlippageBps', () => {
  it('clamps to the floor for highly liquid tokens', () => {
    // impact 10 bps x 1.5 = 15 -> below the 50 bps floor
    expect(computeSlippageBps(300, 300000, cfg)).toBe(50);
  });

  it('scales up with price impact for thinner liquidity', () => {
    // impact 60 bps x 1.5 = 90
    expect(computeSlippageBps(300, 50000, cfg)).toBe(90);
  });

  it('caps at maxBps for illiquid tokens', () => {
    // impact 300 bps x 1.5 = 450 -> capped at 300
    expect(computeSlippageBps(300, 10000, cfg)).toBe(300);
  });

  it('returns maxBps when disabled', () => {
    expect(computeSlippageBps(300, 300000, { ...cfg, enabled: false })).toBe(300);
  });

  it('returns maxBps when liquidity is zero (impact = Infinity)', () => {
    expect(computeSlippageBps(300, 0, cfg)).toBe(300);
  });
});
