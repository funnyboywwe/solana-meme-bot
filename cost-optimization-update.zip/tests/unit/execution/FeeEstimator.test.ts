import {
  priorityFeeSol,
  estimateTradeCost,
  DEFAULT_COMPUTE_UNITS,
  FeeModelConfig,
  CostInputs,
} from '../../../src/execution/FeeEstimator';

const model: FeeModelConfig = {
  baseTxFeeSol: 0.000005,
  dexFeePct: 0.0025,
  jitoEnabled: false,
  jitoTipLamports: 0,
  computeUnits: 200000,
};

describe('priorityFeeSol', () => {
  it('converts microLamports/CU x CU to SOL', () => {
    // 10_000 microLamports/CU x 200_000 CU = 2e9 microLamports = 2000 lamports = 2e-6 SOL
    expect(priorityFeeSol(10000, 200000)).toBeCloseTo(0.000002, 9);
  });

  it('is zero when the fee is zero', () => {
    expect(priorityFeeSol(0, 200000)).toBe(0);
  });
});

describe('estimateTradeCost', () => {
  const base: CostInputs = {
    sizeSol: 0.03,
    liquidityUsd: 50000,
    solPriceUsd: 150,
    priorityFeeMicroLamports: 10000,
    slippageBps: 100,
  };

  it('models a full round trip (buy + sell legs)', () => {
    const e = estimateTradeCost({ ...base, roundTrip: true }, model);
    expect(e.buyNetworkFeeSol).toBeCloseTo(0.000005, 9);
    expect(e.sellNetworkFeeSol).toBeCloseTo(0.000005, 9);
    expect(e.dexFeeSol).toBeCloseTo(0.00015, 9); // 0.03 x 0.0025 x 2
    expect(e.slippageCostSol).toBeCloseTo(0.0006, 9); // 0.03 x 0.01 x 2
    expect(e.totalCostSol).toBeCloseTo(0.000764, 9);
    expect(e.costPctOfSize).toBeCloseTo(0.0254667, 5);
  });

  it('models a single leg when roundTrip is false', () => {
    const e = estimateTradeCost({ ...base, roundTrip: false }, model);
    expect(e.sellNetworkFeeSol).toBe(0);
    expect(e.sellPriorityFeeSol).toBe(0);
    expect(e.dexFeeSol).toBeCloseTo(0.000075, 9);
    expect(e.slippageCostSol).toBeCloseTo(0.0003, 9);
    expect(e.totalCostSol).toBeCloseTo(0.000382, 9);
  });

  it('adds a Jito tip on each leg when enabled', () => {
    const e = estimateTradeCost(
      { ...base, roundTrip: true },
      { ...model, jitoEnabled: true, jitoTipLamports: 100000 },
    );
    // 100_000 lamports = 1e-4 SOL per leg x 2 legs = 2e-4 SOL
    expect(e.jitoTipSol).toBeCloseTo(0.0002, 9);
  });

  it('treats a 100% cost as the worst case when size is zero', () => {
    const e = estimateTradeCost({ ...base, sizeSol: 0 }, model);
    expect(e.costPctOfSize).toBe(1);
  });

  it('exposes a sane default compute-unit estimate', () => {
    expect(DEFAULT_COMPUTE_UNITS).toBe(200000);
  });
});
