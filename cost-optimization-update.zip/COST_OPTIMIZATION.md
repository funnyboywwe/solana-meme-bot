# Transaction-Cost Optimization Suite

Lowers the all-in cost of every trade (network + priority + DEX + slippage) while
keeping execution reliable, and rejects trades that can't clear their own cost.
Built for tiny 0.01–0.05 SOL sizes where fees otherwise eat the edge.

## What's included

| # | Feature | Where |
|---|---------|-------|
| 1 | **Dynamic priority-fee manager** — pays the floor when the network is quiet, climbs to a live market percentile only under congestion; exits use `high` urgency. | `src/execution/PriorityFeeManager.ts` |
| 2 | **Smart routing** — prefers a cheaper direct route when it's within tolerance of the best multi-hop quote; bounds account count. | `src/execution/JupiterClient.ts` |
| 3 | **Fee-aware trade filter** — enters only when `expectedGain >= max(MIN_EXPECTED_PROFIT, cost% × MIN_PROFIT_TO_COST_RATIO)`. | `src/gate/FeeAwareFilter.ts`, wired as step 8 in `src/gate/HybridEntryGate.ts` |
| 4 | **Slippage optimization** — tight for liquid tokens, wider only when thin, capped at the global max. | `src/execution/SlippageOptimizer.ts`, wired in `ExecutionEngine` buy+sell |
| 5 | **Per-trade cost tracking** — stores network/priority/DEX/slippage cost per leg. | `src/db/repositories/TradeCostRepository.ts`, table `trade_costs` (migration 003) |
| 6 | **Minimum-profit filter** — same gate as #3 (profit-to-cost ratio). | `FeeAwareFilter` |
| 7 | **Trade-size warning** — logs a warning when est. cost ≥ `feeWarnPctOfSize` of size. | `FeeAwareFilter` (`feeWarning`) |
| 8 | **Config env vars** (see below). | `src/config/schema.ts`, `src/config/AppConfig.ts`, `src/config/default.yaml` |
| 9 | **Analytics dashboard** — avg fee / priority fee / slippage, cost % of size, net profit after costs. | `src/analytics/CostAnalytics.ts`, `GET /costs` in `DashboardAPI.ts` |
| 10 | **Unit tests** + detailed comments. | `tests/unit/execution/*`, `tests/unit/gate/*` |

## New environment variables

All optional — they override `costControl` in `default.yaml`:

| Env var | Overrides | Default |
|---------|-----------|---------|
| `MIN_PRIORITY_FEE` | `costControl.minPriorityFeeMicroLamports` | `10000` |
| `MAX_PRIORITY_FEE` | `costControl.maxPriorityFeeMicroLamports` | `1000000` |
| `MAX_SLIPPAGE` | `costControl.dynamicSlippage.maxBps` **and** `execution.maxSlippageBps` (bps) | `300` |
| `MIN_EXPECTED_PROFIT` | `costControl.feeAware.minExpectedProfitPct` (fraction, e.g. `0.10`) | `0.10` |
| `MIN_PROFIT_TO_COST_RATIO` | `costControl.feeAware.minProfitToCostRatio` | `5` |

## New endpoint

`GET http://localhost:<healthCheckPort>/costs?windowMs=<ms>&limit=<n>`

Returns averages (fee / priority fee / slippage cost), cost as a % of trade
size, realised PnL / net profit after costs, and the most recent per-leg cost
breakdowns. Default window 7 days, default limit 100 rows.

## How to apply

1. Unzip into your project root (preserves `src/...` paths; overwrites the listed files only).
2. Run, in order:
   ```bash
   npm run migrate        # creates the trade_costs table (migration 003)
   npm run build
   npm test               # runs the new unit tests
   pm2 restart solana-meme-bot --update-env
   ```

## Notes

- **`MEVProtection.ts` is intentionally NOT included** — keep your patched Jito-first version.
- Cost figures from `FeeEstimator` are deterministic *estimates* (pre-trade and for analytics), not on-chain receipts; realised PnL in `/costs` comes from actual `closed_positions` proceeds.
- The fee-aware gate uses a representative size (`risk.fixedPositionSizeSol` when > 0, else `costControl.feeAware.referenceSizeSol`) because the exact size is decided downstream.
