import axios from 'axios';
import { EventBus } from '../core/EventBus';
import { createModuleLogger } from '../core/Logger';
import { AppConfig } from '../config/AppConfig';
import { setSolPriceUsd } from '../core/SolPrice';

const WSOL_MINT = 'So11111111111111111111111111111111111111112';

const logger = createModuleLogger('PriceOracle');

// Jupiter Price API V3 returns a FLAT map keyed by mint (no `data` wrapper).
// Each entry exposes `usdPrice` (number). Some mints may be missing/undefined.
type JupiterPriceV3Response = Record<
  string,
  { usdPrice: number; blockId?: number; decimals?: number; priceChange24h?: number } | undefined
>;

/**
 * PriceOracle polls Jupiter Price API v6 every 5 seconds.
 *
 * BUG FIXED (#5 / PriceOracle): Jupiter's price endpoint is on a
 * completely different host: https://price.jup.ag/v6/price
 * NOT on quote-api.jup.ag which only handles quote/swap.
 *
 * Old (broken): `${jupiterApiUrl}/price`  → 404
 * New (correct): `https://price.jup.ag/v6/price`
 */
const JUPITER_PRICE_URL = 'https://lite-api.jup.ag/price/v3';
const BATCH_SIZE = 100; // Jupiter price API max IDs per request

export class PriceOracle {
  private pollInterval: NodeJS.Timeout | null = null;
  private trackedMints = new Set<string>();
  private readonly pollIntervalMs = 5000;
  // In-memory price cache — accessed by other components synchronously
  private priceCache = new Map<string, number>();

  constructor(_cfg: AppConfig) {
    // Always track WSOL so the shared SOL/USD price stays fresh.
    this.trackedMints.add(WSOL_MINT);
  }

  trackToken(mint: string): void {
    this.trackedMints.add(mint);
  }

  untrackToken(mint: string): void {
    this.trackedMints.delete(mint);
    this.priceCache.delete(mint);
  }

  getCachedPrice(mint: string): number {
    return this.priceCache.get(mint) ?? 0;
  }

  start(): void {
    if (this.pollInterval) return;
    logger.info('PriceOracle starting', { endpoint: JUPITER_PRICE_URL });
    void this._poll();
    this.pollInterval = setInterval(() => void this._poll(), this.pollIntervalMs);
    this.pollInterval.unref();
  }

  stop(): void {
    if (this.pollInterval) {
      clearInterval(this.pollInterval);
      this.pollInterval = null;
    }
    logger.info('PriceOracle stopped');
  }

  private async _poll(): Promise<void> {
    if (this.trackedMints.size === 0) return;

    const mints = Array.from(this.trackedMints);

    // Batch requests: Jupiter price API allows max 100 IDs
    for (let i = 0; i < mints.length; i += BATCH_SIZE) {
      const batch = mints.slice(i, i + BATCH_SIZE);
      await this._fetchBatch(batch);
    }
  }

  private async _fetchBatch(mints: string[]): Promise<void> {
    try {
      const ids = mints.join(',');
      const response = await axios.get<JupiterPriceV3Response>(JUPITER_PRICE_URL, {
        params: { ids },
        timeout: 5000,
      });

      const data = response.data ?? {};

      for (const mint of mints) {
        const entry = data[mint];
        if (!entry) continue;

        const priceUsd = typeof entry.usdPrice === 'number'
          ? entry.usdPrice
          : parseFloat(String(entry.usdPrice));
        if (!(priceUsd > 0)) continue;

        // Keep the shared SOL price fresh; don't emit PRICE_UPDATE for WSOL.
        if (mint === WSOL_MINT) {
          setSolPriceUsd(priceUsd);
          continue;
        }

        this.priceCache.set(mint, priceUsd);
        EventBus.emit('PRICE_UPDATE', {
          mint,
          priceUsd,
          liquidityUsd: 0,
          ts: Date.now(),
        });
      }
    } catch (err) {
      logger.warn('PriceOracle batch fetch failed', { error: String(err) });
    }
  }

  getTrackedCount(): number {
    return this.trackedMints.size;
  }
}

export default PriceOracle;
