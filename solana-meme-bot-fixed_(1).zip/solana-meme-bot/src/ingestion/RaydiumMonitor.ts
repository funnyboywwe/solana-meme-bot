import { BaseWebSocketClient } from './BaseWebSocketClient';
import { EventBus, TokenCreatedEvent, PoolUpdateEvent } from '../core/EventBus';
import { createModuleLogger } from '../core/Logger';
import { AppConfig } from '../config/AppConfig';
import { getSolPriceUsd } from '../core/SolPrice';
import axios from 'axios';

const logger = createModuleLogger('RaydiumMonitor');

const RAYDIUM_PAIRS_URL = 'https://api.mainnet.raydium.io/v2/main/pairs';
const WSOL = 'So11111111111111111111111111111111111111112';

interface RaydiumPair {
  name: string;
  ammId: string;
  baseMint: string;
  quoteMint: string;
  price: number;
  baseReserve: number;
  quoteReserve: number;
  volume24h: number;
  fee24h: number;
  apr24h: number;
  lpMint: string;
  lpDecimals: number;
  version: number;
}

/**
 * RaydiumMonitor polls the Raydium pairs API every 10 seconds.
 *
 * BUG FIXED (RaydiumMonitor): Previous code used the wrong endpoint
 * (ammV3/ammPools) with incorrect response shape assumptions (.data.liquidity).
 * Correct endpoint: https://api.mainnet.raydium.io/v2/main/pairs
 * Response: flat array of RaydiumPair objects with baseReserve/quoteReserve.
 */
export class RaydiumMonitor extends BaseWebSocketClient {
  private pollTimer: NodeJS.Timeout | null = null;
  private seenAmmIds = new Set<string>();
  private liquidityCache = new Map<string, number>();
  private firstPoll = true;

  constructor(_cfg: AppConfig) {
    super('wss://api.raydium.io/ws', 'RaydiumMonitor');
  }

  async connect(): Promise<void> {
    logger.info('RaydiumMonitor starting (REST polling)');
    this.connected = true;
    EventBus.emit('WS_STATUS', { client: 'RaydiumMonitor', status: 'connected', ts: Date.now() });
    await this._poll(); // immediate first poll
    this.pollTimer = setInterval(() => void this._poll(), 10000);
    this.pollTimer.unref();
  }

  private async _poll(): Promise<void> {
    try {
      const response = await axios.get<RaydiumPair[]>(RAYDIUM_PAIRS_URL, { timeout: 8000 });
      const pairs: RaydiumPair[] = Array.isArray(response.data) ? response.data : [];

      for (const pair of pairs) {
        // Only track SOL-paired pools
        if (pair.quoteMint !== WSOL && pair.baseMint !== WSOL) continue;

        const mint = pair.quoteMint === WSOL ? pair.baseMint : pair.quoteMint;
        const solReserve = pair.quoteMint === WSOL ? pair.quoteReserve : pair.baseReserve;
        const liquidityUsd = (solReserve ?? 0) * 2 * getSolPriceUsd(); // rough USD

        if (liquidityUsd < 5000) continue; // skip dust pools

        if (!this.seenAmmIds.has(pair.ammId)) {
          this.seenAmmIds.add(pair.ammId);
          this.liquidityCache.set(pair.ammId, liquidityUsd);

          // FIX (#14): on the very first poll every existing pool looks "new".
          // Seed the seen-set silently instead of emitting a flood of
          // TOKEN_CREATED events for pools that already existed.
          if (this.firstPoll) continue;

          logger.info('New Raydium pool detected', { ammId: pair.ammId, mint });

          EventBus.emit('TOKEN_CREATED', {
            mint,
            symbol: pair.name?.split('-')[0]?.trim() ?? 'UNK',
            decimals: 9,
            initialLiquidityUsd: liquidityUsd,
            poolAddress: pair.ammId,
            createdAt: Date.now(),
            source: 'raydium',
          } as TokenCreatedEvent);
        } else {
          // Check for significant liquidity change
          const prev = this.liquidityCache.get(pair.ammId) ?? liquidityUsd;
          const delta = liquidityUsd - prev;

          if (Math.abs(delta) > 5000) {
            this.liquidityCache.set(pair.ammId, liquidityUsd);
            EventBus.emit('POOL_UPDATE', {
              poolAddress: pair.ammId,
              mint,
              liquidityUsd,
              liquidityDeltaUsd: delta,
              ts: Date.now(),
            } as PoolUpdateEvent);
          }
        }
      }
      this.firstPoll = false;
    } catch (err) {
      logger.warn('Raydium poll failed', { error: String(err) });
    }
  }

  protected onMessage(_message: unknown): void {}
  protected resubscribe(_key: string, _state: unknown): void {}

  disconnect(): void {
    if (this.pollTimer) {
      clearInterval(this.pollTimer);
      this.pollTimer = null;
    }
    this.connected = false;
    logger.info('RaydiumMonitor disconnected');
  }
}

export default RaydiumMonitor;
