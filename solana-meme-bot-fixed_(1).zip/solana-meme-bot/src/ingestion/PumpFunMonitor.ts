import { BaseWebSocketClient } from './BaseWebSocketClient';
import { EventBus, TokenCreatedEvent, TradeDetectedEvent } from '../core/EventBus';
import { createModuleLogger } from '../core/Logger';
import { AppConfig } from '../config/AppConfig';

const logger = createModuleLogger('PumpFunMonitor');

// BUG FIXED (#9): removed unused axios import

interface PumpFunNewToken {
  mint: string;
  name: string;
  symbol: string;
  created_timestamp: number;
  raydium_pool_address: string | null;
  virtual_sol_reserves: number;
  virtual_token_reserves: number;
  complete: boolean;
}

interface PumpFunTrade {
  mint: string;
  sol_amount: number;
  token_amount: number;
  is_buy: boolean;
  user: string;
  timestamp: number;
  tx_hash: string;
}

interface PumpFunMessage {
  txType?: 'create' | 'trade';
  // Pump.fun portal sends flat objects with these fields for creates
  mint?: string;
  name?: string;
  symbol?: string;
  created_timestamp?: number;
  raydium_pool_address?: string;
  virtual_sol_reserves?: number;
  // Trade fields
  sol_amount?: number;
  token_amount?: number;
  is_buy?: boolean;
  user?: string;
  timestamp?: number;
  tx_hash?: string;
  // Subscription confirmation
  message?: string;
}

export class PumpFunMonitor extends BaseWebSocketClient {
  private readonly SOL_PRICE_USD = 150; // rough; PriceOracle refines

  constructor(_cfg: AppConfig) {
    super('wss://pumpportal.fun/api/data', 'PumpFunMonitor');
  }

  async connect(): Promise<void> {
    await super.connect();
    this._subscribe();
  }

  private _subscribe(): void {
    // Subscribe to new token events
    this.send({ method: 'subscribeNewToken' });
    // Subscribe to all trades
    this.send({ method: 'subscribeTokenTrade', keys: [] });

    this.subscriptions['new_tokens'] = { method: 'subscribeNewToken' };
    this.subscriptions['trades'] = { method: 'subscribeTokenTrade', keys: [] };

    logger.info('PumpFun subscribed to new tokens and trades');
  }

  protected onMessage(message: unknown): void {
    const msg = message as PumpFunMessage;

    // Subscription confirmation
    if (msg.message) {
      logger.debug('PumpFun subscription response', { message: msg.message });
      return;
    }

    if (msg.txType === 'create' || (msg.mint && msg.symbol && !msg.sol_amount)) {
      this._onNewToken(msg as unknown as PumpFunNewToken);
    } else if (msg.mint && msg.sol_amount !== undefined) {
      this._onTrade(msg as unknown as PumpFunTrade);
    }
  }

  private _onNewToken(data: PumpFunNewToken): void {
    try {
      if (!data.mint) return;

      const createdAt = data.created_timestamp
        ? data.created_timestamp * 1000
        : Date.now();

      // Skip tokens older than 5 minutes
      if (Date.now() - createdAt > 300_000) return;

      const solReserves = data.virtual_sol_reserves ?? 0;
      const liquidityUsd = solReserves * this.SOL_PRICE_USD;

      logger.info('PumpFun new token', { mint: data.mint, symbol: data.symbol });

      EventBus.emit('TOKEN_CREATED', {
        mint: data.mint,
        symbol: data.symbol ?? 'UNK',
        decimals: 6,
        initialLiquidityUsd: liquidityUsd,
        poolAddress: data.raydium_pool_address ?? '',
        createdAt,
        source: 'pumpfun',
      } as TokenCreatedEvent);
    } catch (err) {
      logger.error('PumpFun new token processing failed', { error: String(err) });
    }
  }

  private _onTrade(trade: PumpFunTrade): void {
    try {
      if (!trade.mint) return;

      const priceUsd =
        trade.sol_amount > 0 && trade.token_amount > 0
          ? (trade.sol_amount * this.SOL_PRICE_USD) / trade.token_amount
          : 0;

      EventBus.emit('TRADE_DETECTED', {
        mint: trade.mint,
        side: trade.is_buy ? 'buy' : 'sell',
        amountUsd: trade.sol_amount * this.SOL_PRICE_USD,
        amountSol: trade.sol_amount,
        priceUsd,
        walletAddress: trade.user,
        txHash: trade.tx_hash ?? '',
        ts: (trade.timestamp ?? Math.floor(Date.now() / 1000)) * 1000,
        poolAddress: '',
      } as TradeDetectedEvent);
    } catch (err) {
      logger.error('PumpFun trade processing failed', { error: String(err) });
    }
  }

  protected resubscribe(_key: string, state: unknown): void {
    this.send(state);
  }
}

export default PumpFunMonitor;
