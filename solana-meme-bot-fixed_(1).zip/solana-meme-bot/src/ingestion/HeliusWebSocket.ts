import { BaseWebSocketClient } from './BaseWebSocketClient';
import { EventBus, TradeDetectedEvent } from '../core/EventBus';
import { createModuleLogger } from '../core/Logger';
import { AppConfig } from '../config/AppConfig';

const logger = createModuleLogger('HeliusWebSocket');

interface TokenBalanceEntry {
  mint: string;
  owner: string;
  uiTokenAmount: { amount: string; decimals: number; uiAmount: number | null };
}

interface EnhancedTxValue {
  transaction: { signatures: string[]; message?: unknown };
  meta: {
    err: unknown | null;
    postTokenBalances?: TokenBalanceEntry[];
    preTokenBalances?: TokenBalanceEntry[];
  };
}

/**
 * HeliusWebSocketClient subscribes to Helius enhanced transaction stream.
 *
 * BUG FIXED (#5): API key is now appended to the WS URL as a query param.
 * Helius requires: wss://atlas-mainnet.helius-rpc.com?api-key=<KEY>
 *
 * BUG FIXED (#6): Added maxSupportedTransactionVersion: 0 to subscription
 * params — required for versioned transactions (Jupiter swaps use V0 txs).
 */
export class HeliusWebSocketClient extends BaseWebSocketClient {
  constructor(cfg: AppConfig) {
    // FIX: append api-key query param to the WS URL
    const wsUrl = `${cfg.rpc.heliusWsUrl}?api-key=${cfg.rpc.heliusApiKey}`;
    super(wsUrl, 'HeliusWebSocket');
  }

  async connect(): Promise<void> {
    await super.connect();
    this._subscribeTransactions();
  }

  private _subscribeTransactions(): void {
    // FIX: correct Helius transactionSubscribe params with required fields
    const subscription = {
      jsonrpc: '2.0',
      id: 1,
      method: 'transactionSubscribe',
      params: [
        {
          failed: false,
          accountInclude: [],      // empty = all accounts; add DEX program IDs to narrow
          accountExclude: [],
          accountRequired: [],
        },
        {
          commitment: 'confirmed',
          encoding: 'jsonParsed',
          transactionDetails: 'full',
          showRewards: false,
          maxSupportedTransactionVersion: 0,  // FIX: required for V0 versioned txs
        },
      ],
    };

    this.subscriptions['tx_subscribe'] = subscription;
    this.send(subscription);
    logger.info('Helius transactionSubscribe sent');
  }

  protected onMessage(message: unknown): void {
    const msg = message as Record<string, unknown>;

    // Subscription confirmation
    if (typeof msg['result'] === 'number') {
      logger.info('Helius subscription confirmed', { subscriptionId: msg['result'] });
      return;
    }

    // Transaction notification
    const params = msg['params'] as Record<string, unknown> | undefined;
    if (!params) return;

    const result = params['result'] as Record<string, unknown> | undefined;
    if (!result) return;

    const value = result['value'] as EnhancedTxValue | undefined;
    if (!value?.transaction) return;

    this._processTx(value);
  }

  private _processTx(tx: EnhancedTxValue): void {
    try {
      // Skip failed transactions
      if (tx.meta?.err) return;

      const txHash = tx.transaction?.signatures?.[0];
      if (!txHash) return;

      const preBalances = tx.meta?.preTokenBalances ?? [];
      const postBalances = tx.meta?.postTokenBalances ?? [];

      for (const post of postBalances) {
        const pre = preBalances.find(
          (p) => p.mint === post.mint && p.owner === post.owner,
        );

        const preAmount = pre ? parseFloat(pre.uiTokenAmount.amount) : 0;
        const postAmount = parseFloat(post.uiTokenAmount.amount);

        if (postAmount === preAmount) continue; // no change

        const side = postAmount > preAmount ? 'buy' : 'sell';
        const amountDelta = Math.abs(postAmount - preAmount);
        const decimals = post.uiTokenAmount.decimals;
        const humanDelta = amountDelta / Math.pow(10, decimals);

        // Rough USD estimate — price oracle will refine this
        const roughSol = 0.01;
        const roughUsd = roughSol * 150;
        const priceUsd = humanDelta > 0 ? roughUsd / humanDelta : 0;

        EventBus.emit('TRADE_DETECTED', {
          mint: post.mint,
          side,
          amountUsd: roughUsd,
          amountSol: roughSol,
          priceUsd,
          walletAddress: post.owner,
          txHash,
          ts: Date.now(),
          poolAddress: '',
        } as TradeDetectedEvent);
      }
    } catch (err) {
      logger.error('Helius tx processing failed', { error: String(err) });
    }
  }

  protected resubscribe(_key: string, _state: unknown): void {
    this._subscribeTransactions();
  }
}

export default HeliusWebSocketClient;
