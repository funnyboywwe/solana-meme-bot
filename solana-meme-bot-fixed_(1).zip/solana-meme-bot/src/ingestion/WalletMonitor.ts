import { BaseWebSocketClient } from './BaseWebSocketClient';
import { EventBus, WalletTxEvent } from '../core/EventBus';
import { createModuleLogger } from '../core/Logger';
import { AppConfig } from '../config/AppConfig';
import axios from 'axios';

const logger = createModuleLogger('WalletMonitor');

interface TokenBalance {
  mint: string;
  owner: string;
  amount: string;
  decimals: number;
}

interface AccountUpdate {
  lamports: number;
  owner: string;
  executable: boolean;
  rentEpoch: number;
  data: {
    parsed: {
      info: {
        mint: string;
        owner: string;
        tokenAmount: {
          amount: string;
          decimals: number;
        };
      };
      type: 'account';
    };
  };
}

/**
 * WalletMonitor tracks token account changes for copy trading
 * Polls wallet account state and detects balance changes
 */
export class WalletMonitor extends BaseWebSocketClient {
  private monitoredWallets: Map<string, TokenBalance[]> = new Map();
  private pollInterval: NodeJS.Timeout | null = null;
  private rpcUrl: string;

  constructor(cfg: AppConfig, wallets: string[]) {
    super('wss://api.helius.xyz', 'WalletMonitor');
    this.rpcUrl = cfg.rpc.rpcHttpUrl;

    for (const wallet of wallets) {
      this.monitoredWallets.set(wallet, []);
    }
  }

  async connect(): Promise<void> {
    logger.info('WalletMonitor starting (polling mode)', { walletCount: this.monitoredWallets.size });
    this.connected = true;
    EventBus.emit('WS_STATUS', { client: 'WalletMonitor', status: 'connected', ts: Date.now() });

    // Initial fetch of wallet balances
    for (const wallet of this.monitoredWallets.keys()) {
      await this._fetchWalletBalances(wallet);
    }

    this._startPolling();
  }

  private _startPolling(): void {
    this.pollInterval = setInterval(() => {
      for (const wallet of this.monitoredWallets.keys()) {
        void this._fetchWalletBalances(wallet);
      }
    }, 10000); // Poll every 10 seconds

    this.pollInterval.unref();
  }

  private async _fetchWalletBalances(walletAddress: string): Promise<void> {
    try {
      const response = await axios.post<{ result: { value: AccountUpdate[] } }>(
        this.rpcUrl,
        {
          jsonrpc: '2.0',
          id: 1,
          method: 'getTokenAccountsByOwner',
          params: [
            walletAddress,
            {
              programId: 'TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA',
            },
            {
              encoding: 'jsonParsed',
            },
          ],
        },
        { timeout: 5000 },
      );

      const accounts = response.data?.result?.value || [];
      const newBalances = this._parseTokenAccounts(accounts);
      const prevBalances = this.monitoredWallets.get(walletAddress) || [];

      // Detect changes
      this._detectChanges(walletAddress, prevBalances, newBalances);

      this.monitoredWallets.set(walletAddress, newBalances);
    } catch (err) {
      logger.warn(`Failed to fetch wallet balances for ${walletAddress}`, { error: String(err) });
    }
  }

  private _parseTokenAccounts(accounts: AccountUpdate[]): TokenBalance[] {
    return accounts
      .filter((acc) => acc.data?.parsed?.type === 'account')
      .map((acc) => {
        const info = acc.data.parsed.info;
        return {
          mint: info.mint,
          owner: info.owner,
          amount: info.tokenAmount.amount,
          decimals: info.tokenAmount.decimals,
        };
      });
  }

  private _detectChanges(walletAddress: string, prev: TokenBalance[], current: TokenBalance[]): void {
    for (const curr of current) {
      const prevBalance = prev.find((p) => p.mint === curr.mint);
      if (!prevBalance) {
        // New token acquired (buy)
        const amountTokens = parseFloat(curr.amount) / Math.pow(10, curr.decimals);
        logger.info('Wallet acquired new token', { wallet: walletAddress, mint: curr.mint, amount: amountTokens });

        EventBus.emit('WALLET_TX', {
          walletAddress,
          mint: curr.mint,
          side: 'buy',
          amountSol: 0, // Would need to fetch actual SOL cost from tx
          amountTokens,
          priceUsd: 0, // Would need price oracle
          txHash: '', // Would need to fetch from recent tx
          ts: Date.now(),
          slot: 0,
        } as WalletTxEvent);
      } else {
        const prevAmount = parseFloat(prevBalance.amount) / Math.pow(10, prevBalance.decimals);
        const currAmount = parseFloat(curr.amount) / Math.pow(10, curr.decimals);

        if (currAmount > prevAmount) {
          // Bought more
          const amountAdded = currAmount - prevAmount;
          logger.info('Wallet bought more tokens', { wallet: walletAddress, mint: curr.mint, amount: amountAdded });

          EventBus.emit('WALLET_TX', {
            walletAddress,
            mint: curr.mint,
            side: 'buy',
            amountSol: 0,
            amountTokens: amountAdded,
            priceUsd: 0,
            txHash: '',
            ts: Date.now(),
            slot: 0,
          } as WalletTxEvent);
        } else if (currAmount < prevAmount) {
          // Sold
          const amountSold = prevAmount - currAmount;
          logger.info('Wallet sold tokens', { wallet: walletAddress, mint: curr.mint, amount: amountSold });

          EventBus.emit('WALLET_TX', {
            walletAddress,
            mint: curr.mint,
            side: 'sell',
            amountSol: 0,
            amountTokens: amountSold,
            priceUsd: 0,
            txHash: '',
            ts: Date.now(),
            slot: 0,
          } as WalletTxEvent);
        }
      }
    }

    // Check for token disposals (balance went to 0)
    for (const prev of prev) {
      const currBalance = current.find((c) => c.mint === prev.mint);
      if (!currBalance) {
        const amountSold = parseFloat(prev.amount) / Math.pow(10, prev.decimals);
        logger.info('Wallet disposed of all tokens', { wallet: walletAddress, mint: prev.mint, amount: amountSold });

        EventBus.emit('WALLET_TX', {
          walletAddress,
          mint: prev.mint,
          side: 'sell',
          amountSol: 0,
          amountTokens: amountSold,
          priceUsd: 0,
          txHash: '',
          ts: Date.now(),
          slot: 0,
        } as WalletTxEvent);
      }
    }
  }

  addWallet(address: string): void {
    if (!this.monitoredWallets.has(address)) {
      this.monitoredWallets.set(address, []);
      void this._fetchWalletBalances(address);
      logger.info('Wallet added to monitoring', { wallet: address });
    }
  }

  removeWallet(address: string): void {
    this.monitoredWallets.delete(address);
    logger.info('Wallet removed from monitoring', { wallet: address });
  }

  protected onMessage(message: unknown): void {
    // Not used in polling mode
  }

  protected resubscribe(key: string, state: unknown): void {
    // Not used in polling mode
  }

  disconnect(): void {
    if (this.pollInterval) {
      clearInterval(this.pollInterval);
      this.pollInterval = null;
    }
    this.connected = false;
    logger.info('WalletMonitor disconnected');
  }
}

export default WalletMonitor;
