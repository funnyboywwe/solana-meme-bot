import { EventBus, TradeFilledEvent, PriceUpdateEvent, CloseSignalEvent } from '../core/EventBus';
import { AppConfig } from '../config/AppConfig';
import { createModuleLogger } from '../core/Logger';
import { Position } from '../core/types';
import PositionRepository from '../db/repositories/PositionRepository';

const logger = createModuleLogger('StopLossManager');

/**
 * StopLossManager tracks all open positions and fires CLOSE_SIGNAL when:
 * - Price falls below stopLossPct of entry  (stop loss)
 * - Price rises above takeProfitPct of entry (take profit)
 * - Price falls more than trailingStopPct from the peak (trailing stop)
 *
 * Trailing stop arms only after price exceeds trailingStopActivationPct gain.
 * Re-arms all positions on bot restart from DB.
 */
export class StopLossManager {
  private positions = new Map<string, Position>(); // positionId → Position
  private trailingStopActivationPct: number;
  private stopLossPct: number;
  private takeProfitPct: number;
  private trailingStopPct: number;

  constructor(cfg: AppConfig) {
    this.stopLossPct = cfg.risk.stopLossPct;
    this.takeProfitPct = cfg.risk.takeProfitPct;
    this.trailingStopPct = cfg.risk.trailingStopPct;
    this.trailingStopActivationPct = cfg.risk.trailingStopActivationPct;

    logger.info('StopLossManager initialized', {
      stopLossPct: this.stopLossPct,
      takeProfitPct: this.takeProfitPct,
      trailingStopPct: this.trailingStopPct,
    });
  }

  /**
   * Arm stop loss for a newly filled trade
   */
  arm(event: TradeFilledEvent): void {
    if (event.side !== 'buy') return;

    // Load full position from DB
    const position = PositionRepository.findByToken(event.mint);
    if (!position) {
      logger.warn('Position not found after trade fill', { mint: event.mint });
      return;
    }

    this.positions.set(position.id, position);
    logger.info('Stop loss armed', {
      positionId: position.id,
      mint: event.mint,
      entryPrice: position.entryPriceUsd,
      stopAt: position.entryPriceUsd * (1 - this.stopLossPct),
      tpAt: position.entryPriceUsd * (1 + this.takeProfitPct),
    });
  }

  /**
   * Check all positions against current price
   */
  checkPosition(event: PriceUpdateEvent): void {
    for (const [positionId, position] of this.positions) {
      if (position.tokenMint !== event.mint) continue;
      this._checkOne(positionId, position, event.priceUsd);
    }
  }

  private _checkOne(positionId: string, position: Position, currentPrice: number): void {
    const entry = position.entryPriceUsd;
    if (entry <= 0 || currentPrice <= 0) return;

    const gainPct = (currentPrice - entry) / entry;

    // 1. Stop loss
    if (gainPct <= -this.stopLossPct) {
      logger.info('Stop loss triggered', {
        positionId,
        mint: position.tokenMint,
        entry,
        current: currentPrice,
        lossPct: (gainPct * 100).toFixed(2),
      });
      this._closePosition(positionId, position, currentPrice, 'stop');
      return;
    }

    // 2. Take profit
    if (gainPct >= this.takeProfitPct) {
      logger.info('Take profit triggered', {
        positionId,
        mint: position.tokenMint,
        entry,
        current: currentPrice,
        gainPct: (gainPct * 100).toFixed(2),
      });
      this._closePosition(positionId, position, currentPrice, 'tp');
      return;
    }

    // 3. Trailing stop — only active after activation threshold
    if (gainPct >= this.trailingStopActivationPct) {
      // Update trailing high
      if (currentPrice > position.trailingStopHighUsd) {
        const updated: Position = { ...position, trailingStopHighUsd: currentPrice };
        this.positions.set(positionId, updated);
        PositionRepository.updatePrice(
          positionId,
          currentPrice,
          this._calcUnrealisedPnl(position, currentPrice),
          currentPrice,
        );
        return;
      }

      // Check if fallen from high by trailingStopPct
      const high = position.trailingStopHighUsd;
      if (high > 0) {
        const pullbackFromHigh = (high - currentPrice) / high;
        if (pullbackFromHigh >= this.trailingStopPct) {
          logger.info('Trailing stop triggered', {
            positionId,
            mint: position.tokenMint,
            high,
            current: currentPrice,
            pullbackPct: (pullbackFromHigh * 100).toFixed(2),
          });
          this._closePosition(positionId, position, currentPrice, 'trailing');
          return;
        }
      }
    }

    // Update unrealised PnL
    const unrealisedPnl = this._calcUnrealisedPnl(position, currentPrice);
    PositionRepository.updatePrice(positionId, currentPrice, unrealisedPnl);
    this.positions.set(positionId, { ...position, currentPriceUsd: currentPrice, unrealisedPnlSol: unrealisedPnl });
  }

  private _closePosition(
    positionId: string,
    position: Position,
    currentPrice: number,
    reason: CloseSignalEvent['reason'],
  ): void {
    this.positions.delete(positionId);

    EventBus.emit('CLOSE_SIGNAL', {
      positionId,
      mint: position.tokenMint,
      reason,
      currentPriceUsd: currentPrice,
      ts: Date.now(),
    } as CloseSignalEvent);
  }

  private _calcUnrealisedPnl(position: Position, currentPrice: number): number {
    if (position.entryPriceUsd <= 0) return 0;
    const priceRatio = currentPrice / position.entryPriceUsd;
    return position.sizeSol * (priceRatio - 1);
  }

  /**
   * Restore open positions from DB on bot restart
   */
  async restoreFromDb(): Promise<void> {
    const openPositions = PositionRepository.findOpenPositions();
    for (const position of openPositions) {
      this.positions.set(position.id, position);
    }
    logger.info('Positions restored from DB', { count: openPositions.length });
  }

  getOpenPositionCount(): number {
    return this.positions.size;
  }

  getOpenPositions(): Position[] {
    return Array.from(this.positions.values());
  }
}

export default StopLossManager;
