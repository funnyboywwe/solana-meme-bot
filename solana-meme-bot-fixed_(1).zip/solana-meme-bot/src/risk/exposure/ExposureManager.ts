import { Connection, LAMPORTS_PER_SOL } from '@solana/web3.js';
import { AppConfig } from '../../config/AppConfig';
import { ExtendedConfig } from '../../config/schema';
import { createModuleLogger } from '../../core/Logger';
import { ExposureState } from '../../core/types';
import { EventBus, ExposureLimitEvent, TradeFilledEvent } from '../../core/EventBus';
import PositionRepository from '../../db/repositories/PositionRepository';
import { getPositionSizer } from '../PositionSizer';
import { getDb } from '../../db/Database';

const logger = createModuleLogger('ExposureManager');

/**
 * ExposureManager enforces all portfolio-level risk limits.
 *
 * Limits enforced:
 *   maxCapitalPerTradePct   — max % of balance per single trade
 *   maxCapitalPerTokenSol   — hard SOL cap per token
 *   maxTotalDeployedPct     — max % of balance in open positions
 *   maxOpenPositions        — hard count limit
 *   maxDailyLossSol         — daily P&L floor
 *   maxDrawdownPct          — peak-to-trough halt
 *   maxConsecutiveLosses    — loss streak halt
 *
 * checkEntry() must return true for any trade to proceed.
 * All limit violations emit EXPOSURE_LIMIT events.
 */
export class ExposureManager {
  private cfg: ExtendedConfig['exposure'];
  private connection: Connection;
  private state: ExposureState = {
    totalDeployedSol: 0,
    totalPositions: 0,
    largestPositionSol: 0,
    largestPositionMint: '',
    dailyPnlSol: 0,
    drawdownPct: 0,
    consecutiveLosses: 0,
    killSwitchActive: false,
  };
  private peakBalanceSol = 0;
  private snapshotTimer: NodeJS.Timeout;

  constructor(baseCfg: AppConfig, extCfg: ExtendedConfig) {
    this.cfg = extCfg.exposure;
    this.connection = new Connection(baseCfg.rpc.rpcHttpUrl, baseCfg.rpc.commitment);

    this.snapshotTimer = setInterval(() => void this._updateState(), 30000);
    this.snapshotTimer.unref();

    void this._updateState();
    logger.info('ExposureManager initialized', this.cfg);
  }

  /**
   * Check if a new trade is allowed given current exposure.
   * Returns { allowed: boolean; reason?: string }
   */
  async checkEntry(mint: string, proposedSizeSol: number): Promise<{ allowed: boolean; reason?: string }> {
    await this._updateState();

    // 1. Max open positions
    if (this.state.totalPositions >= this.cfg.maxOpenPositions) {
      return this._reject('max_open_positions', this.state.totalPositions, this.cfg.maxOpenPositions, mint);
    }

    // 2. Already have a position in this token
    const existing = PositionRepository.findByToken(mint);
    if (existing) {
      return this._reject('token_already_held', 1, 0, mint);
    }

    // 3. Max capital per token
    if (proposedSizeSol > this.cfg.maxCapitalPerTokenSol) {
      return this._reject('max_capital_per_token', proposedSizeSol, this.cfg.maxCapitalPerTokenSol, mint);
    }

    // 4. Max capital per trade (% of balance)
    const balanceSol = await this._getBalance();
    const maxPerTradeSol = balanceSol * this.cfg.maxCapitalPerTradePct;
    if (proposedSizeSol > maxPerTradeSol) {
      return this._reject('max_capital_per_trade_pct', proposedSizeSol, maxPerTradeSol, mint);
    }

    // 5. Max total deployed
    const maxDeployedSol = balanceSol * this.cfg.maxTotalDeployedPct;
    if (this.state.totalDeployedSol + proposedSizeSol > maxDeployedSol) {
      return this._reject('max_total_deployed', this.state.totalDeployedSol + proposedSizeSol, maxDeployedSol, mint);
    }

    // 6. Daily loss limit
    if (this.state.dailyPnlSol <= -this.cfg.maxDailyLossSol) {
      return this._reject('max_daily_loss', Math.abs(this.state.dailyPnlSol), this.cfg.maxDailyLossSol, mint);
    }

    // 7. Drawdown limit
    if (this.state.drawdownPct >= this.cfg.maxDrawdownPct) {
      return this._reject('max_drawdown', this.state.drawdownPct, this.cfg.maxDrawdownPct, mint);
    }

    // 8. Consecutive losses
    if (this.state.consecutiveLosses >= this.cfg.maxConsecutiveLosses) {
      return this._reject('max_consecutive_losses', this.state.consecutiveLosses, this.cfg.maxConsecutiveLosses, mint);
    }

    return { allowed: true };
  }

  /**
   * Cap a proposed position size to respect all limits.
   */
  async capSize(mint: string, proposedSizeSol: number): Promise<number> {
    const balanceSol = await this._getBalance();
    const caps = [
      proposedSizeSol,
      this.cfg.maxCapitalPerTokenSol,
      balanceSol * this.cfg.maxCapitalPerTradePct,
      Math.max(0, balanceSol * this.cfg.maxTotalDeployedPct - this.state.totalDeployedSol),
    ];
    const capped = Math.min(...caps);
    if (capped < proposedSizeSol) {
      logger.debug('Position size capped by exposure limits', {
        mint, proposed: proposedSizeSol.toFixed(4), capped: capped.toFixed(4),
      });
    }
    return Math.max(capped, 0);
  }

  /** Called when a trade fills (buy or sell) to update state */
  onTradeFilled(event: TradeFilledEvent): void {
    if (event.side === 'buy') {
      this.state.totalDeployedSol += event.sizeSol;
      this.state.totalPositions++;
      if (event.sizeSol > this.state.largestPositionSol) {
        this.state.largestPositionSol = event.sizeSol;
        this.state.largestPositionMint = event.mint;
      }
    } else {
      // sell
      this.state.totalDeployedSol = Math.max(0, this.state.totalDeployedSol - event.sizeSol);
      this.state.totalPositions = Math.max(0, this.state.totalPositions - 1);
    }
    this._persistSnapshot();
  }

  /** Called after a position is closed to update loss streak */
  onPositionClosed(pnlSol: number): void {
    this.state.dailyPnlSol += pnlSol;
    if (pnlSol < 0) {
      this.state.consecutiveLosses++;
    } else {
      this.state.consecutiveLosses = 0;
    }
  }

  getState(): ExposureState {
    return { ...this.state };
  }

  /** Current wallet balance in SOL (used by circuit-breaker drawdown checks). */
  async getBalanceSol(): Promise<number> {
    return this._getBalance();
  }

  private async _updateState(): Promise<void> {
    try {
      const balance = await this._getBalance();
      if (balance > this.peakBalanceSol) this.peakBalanceSol = balance;

      // Drawdown from peak
      this.state.drawdownPct = this.peakBalanceSol > 0
        ? (this.peakBalanceSol - balance) / this.peakBalanceSol
        : 0;

      // Open positions
      const openPositions = PositionRepository.findOpenPositions();
      this.state.totalPositions = openPositions.length;
      this.state.totalDeployedSol = openPositions.reduce((s, p) => s + p.sizeSol, 0);

      if (openPositions.length > 0) {
        const largest = openPositions.reduce((a, b) => a.sizeSol > b.sizeSol ? a : b);
        this.state.largestPositionSol = largest.sizeSol;
        this.state.largestPositionMint = largest.tokenMint;
      }

      // Daily PnL
      this.state.dailyPnlSol = PositionRepository.getTodayRealisedPnl();

      this._persistSnapshot();
    } catch (err) {
      logger.warn('ExposureManager state update failed', { error: String(err) });
    }
  }

  private async _getBalance(): Promise<number> {
    try {
      const sizer = getPositionSizer();
      const lamports = await this.connection.getBalance(sizer.getKeypair().publicKey);
      return lamports / LAMPORTS_PER_SOL;
    } catch {
      return 0;
    }
  }

  private _reject(limitType: string, current: number, limit: number, mint?: string): { allowed: boolean; reason: string } {
    logger.info('Exposure limit violated', { limitType, current: current.toFixed(4), limit: limit.toFixed(4), mint });
    EventBus.emit('EXPOSURE_LIMIT', { limitType, currentValue: current, limitValue: limit, tokenMint: mint, ts: Date.now() } as ExposureLimitEvent);
    return { allowed: false, reason: limitType };
  }

  private _persistSnapshot(): void {
    try {
      getDb().prepare(`
        INSERT INTO exposure_snapshots
          (total_deployed_sol, total_positions, largest_position_sol, largest_position_mint,
           daily_pnl_sol, drawdown_pct, consecutive_losses, kill_switch_active, ts)
        VALUES (@total_deployed_sol, @total_positions, @largest_position_sol, @largest_position_mint,
                @daily_pnl_sol, @drawdown_pct, @consecutive_losses, @kill_switch_active, @ts)
      `).run({
        total_deployed_sol: this.state.totalDeployedSol,
        total_positions: this.state.totalPositions,
        largest_position_sol: this.state.largestPositionSol,
        largest_position_mint: this.state.largestPositionMint,
        daily_pnl_sol: this.state.dailyPnlSol,
        drawdown_pct: this.state.drawdownPct,
        consecutive_losses: this.state.consecutiveLosses,
        kill_switch_active: this.state.killSwitchActive ? 1 : 0,
        ts: Date.now(),
      });
    } catch { /* non-critical */ }
  }

  stop(): void {
    clearInterval(this.snapshotTimer);
  }
}

export default ExposureManager;
