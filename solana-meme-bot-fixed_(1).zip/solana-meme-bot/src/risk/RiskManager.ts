import { EventBus, EntryApprovedEvent, OrderReadyEvent } from '../core/EventBus';
import { AppConfig } from '../config/AppConfig';
import { createModuleLogger } from '../core/Logger';
import PositionRepository from '../db/repositories/PositionRepository';
import { getPositionSizer } from './PositionSizer';
import { CircuitBreaker } from './CircuitBreaker';
import { CooldownTracker } from './CooldownTracker';
import type { ExposureManager } from './exposure/ExposureManager';
import type { DynamicPositionSizingEngine } from './DynamicPositionSizingEngine';
import type { PositionScoreInput } from '../core/types';

const logger = createModuleLogger('RiskManager');

/**
 * RiskManager gates trade execution through 4 sequential checks.
 *
 * BUG FIXED (#16): Uses getPositionSizer() singleton instead of
 * creating a new PositionSizer (and therefore a new Connection +
 * Keypair decode) on construction.
 */
export class RiskManager {
  private circuitBreaker: CircuitBreaker;
  private cooldownTracker: CooldownTracker;
  private maxConcurrentPositions: number;
  private maxSlippageBps: number;
  private cfg: AppConfig;
  private exposureManager: ExposureManager | null = null;
  private dynamicSizer: DynamicPositionSizingEngine | null = null;

  constructor(cfg: AppConfig) {
    this.cfg = cfg;
    this.circuitBreaker = new CircuitBreaker(cfg);
    this.cooldownTracker = new CooldownTracker(cfg);
    this.maxConcurrentPositions = cfg.risk.maxConcurrentPositions;
    this.maxSlippageBps = cfg.execution.maxSlippageBps;

    // FIX: initialise singleton here so it is created exactly once
    getPositionSizer(cfg);

    logger.info('RiskManager initialized', {
      maxConcurrentPositions: this.maxConcurrentPositions,
      maxDailyLossSol: cfg.risk.maxDailyLossSol,
    });
  }

  /**
   * Wire in portfolio-level exposure controls and the dynamic position sizing
   * engine. These are constructed after RiskManager in bootstrap, so they are
   * injected here rather than via the constructor.
   */
  wireRisk(opts: { exposureManager?: ExposureManager; dynamicSizer?: DynamicPositionSizingEngine }): void {
    this.exposureManager = opts.exposureManager ?? null;
    this.dynamicSizer = opts.dynamicSizer ?? null;
    logger.info('RiskManager wired', {
      exposure: !!this.exposureManager,
      dynamicSizing: !!this.dynamicSizer,
    });
  }

  async evaluate(event: EntryApprovedEvent): Promise<void> {
    try {
      const { mint, strategy } = event;

      // 1. Circuit breaker
      if (this.circuitBreaker.isBroken()) {
        logger.info('Circuit breaker active — trade rejected', { mint, reason: this.circuitBreaker.getBreakReason() });
        return;
      }

      // 2. Open position count
      const openCount = PositionRepository.countOpen();
      if (openCount >= this.maxConcurrentPositions) {
        logger.info('Max concurrent positions reached — trade rejected', { mint, openCount });
        return;
      }

      // 3. Token cooldown
      if (this.cooldownTracker.isInCooldown(mint)) {
        logger.debug('Token in cooldown — trade rejected', {
          mint,
          remainingMs: this.cooldownTracker.remainingCooldownMs(mint),
        });
        return;
      }

      // 4. Position size — base sizing from the singleton sizer
      const sizer = getPositionSizer(); // use singleton, no cfg needed
      let sizeSol = await sizer.calculateSize(event);

      // 4b. Multi-factor dynamic sizing (if wired)
      if (this.dynamicSizer) {
        try {
          const scores: PositionScoreInput = {
            momentumScore: event.momentumScore ?? 50,
            smartMoneyScore: 50,
            liquidityScore: 50,
            riskScore: 50,
            walletConfidenceScore: event.walletScore ?? 0,
            accelerationScore: 0,
            holderGrowthScore: 0,
          };
          const dyn = await this.dynamicSizer.computeSize(scores);
          if (dyn.sizeSol > 0) sizeSol = dyn.sizeSol;
        } catch (err) {
          logger.warn('Dynamic sizing failed — falling back to base size', { mint, error: String(err) });
        }
      }

      if (sizeSol <= 0) {
        logger.warn('Position size zero — trade rejected', { mint });
        return;
      }

      // 4c. Portfolio exposure limits (if wired)
      if (this.exposureManager) {
        const check = await this.exposureManager.checkEntry(mint, sizeSol);
        if (!check.allowed) {
          logger.info('Exposure limit — trade rejected', { mint, reason: check.reason });
          return;
        }
        sizeSol = await this.exposureManager.capSize(mint, sizeSol);
        if (sizeSol <= 0) {
          logger.warn('Exposure capped size to zero — trade rejected', { mint });
          return;
        }
      }

      logger.info('Risk checks passed → ORDER_READY', { mint, strategy, sizeSol: sizeSol.toFixed(4) });

      EventBus.emit('ORDER_READY', {
        mint,
        strategy,
        sizeSol,
        maxSlippageBps: this.maxSlippageBps,
        ts: Date.now(),
      } as OrderReadyEvent);
    } catch (err) {
      logger.error('Risk evaluation error', { error: String(err) });
    }
  }

  getCooldownTracker(): CooldownTracker {
    return this.cooldownTracker;
  }

  getCircuitBreaker(): CircuitBreaker {
    return this.circuitBreaker;
  }
}

export default RiskManager;
