import { z } from 'zod';

export const ConfigSchema = z.object({
  rpc: z.object({
    heliusApiKey: z.string().min(1, 'HELIUS_API_KEY is required'),
    heliusWsUrl: z.string().url(),
    rpcHttpUrl: z.string().url(),
    commitment: z.enum(['processed', 'confirmed', 'finalized']).default('confirmed'),
    quickNodeRpcUrl: z.string().url().optional(),
    quickNodeWsUrl: z.string().url().optional(),
    tritonRpcUrl: z.string().url().optional(),
    tritonWsUrl: z.string().url().optional(),
    fallbackRpcUrls: z.array(z.string().url()).default([]),
    healthCheckIntervalMs: z.number().positive().default(30000),
    maxRpcFailures: z.number().int().positive().default(3),
  }),

  wallet: z.object({
    privateKey: z.string().min(1, 'WALLET_PRIVATE_KEY is required'),
    maxBalancePctPerTrade: z.number().min(0.01).max(0.5).default(0.07),
  }),

  trading: z.object({
    enabled: z.boolean().default(true),
    strategies: z.object({
      momentum: z.object({
        enabled: z.boolean().default(true),
        scoreThreshold: z.number().min(0).max(100).default(65),
      }),
      copy: z.object({
        enabled: z.boolean().default(true),
        walletScoreThreshold: z.number().min(0).max(100).default(65),
        maxCopyDelayMs: z.number().positive().default(30000),
      }),
      hybrid: z.object({
        requireBoth: z.boolean().default(true),
      }),
    }),
  }),

  momentum: z.object({
    volumeSpikeMultiplier: z.number().min(1).default(3.0),
    buyPressureMin: z.number().min(0).max(1).default(0.6),
    txPerMinThreshold: z.number().positive().default(20),
    liquidityGrowthPct: z.number().positive().default(0.15),
    priceAccelThreshold: z.number().positive().default(0.02),
    windowMs: z.number().positive().default(300000), // 5 min
  }),

  safety: z.object({
    minLiquidityUsd: z.number().positive().default(30000),
    maxHolderConcentrationPct: z.number().min(0).max(100).default(20),
    maxRugScore: z.number().min(0).max(100).default(30),
    requireMintDisabled: z.boolean().default(true),
    requireFreezeDisabled: z.boolean().default(true),
    honeypotSimulate: z.boolean().default(true),
    requireLpLock: z.boolean().default(false),
    minLpLockedPct: z.number().min(0).max(100).default(80),
    lpLockRugScoreWeight: z.number().int().min(0).max(100).default(15),
  }),

  risk: z.object({
    maxDailyLossSol: z.number().positive().default(0.5),
    maxConcurrentPositions: z.number().int().positive().default(3),
    positionSizePct: z.number().min(0.01).max(0.5).default(0.07),
    stopLossPct: z.number().min(0.01).max(1).default(0.15),
    takeProfitPct: z.number().min(0.01).default(0.40),
    trailingStopPct: z.number().min(0.01).max(1).default(0.10),
    trailingStopActivationPct: z.number().min(0.01).default(0.20),
    circuitBreakerDrawdownPct: z.number().min(0.01).max(1).default(0.25),
    tokenCooldownMins: z.number().nonnegative().default(30),
    walletCooldownMins: z.number().nonnegative().default(5),
  }),

  execution: z.object({
    jupiterApiUrl: z.string().url().default('https://lite-api.jup.ag/swap/v1'),
    slippageBps: z.number().int().min(1).max(10000).default(100),
    maxSlippageBps: z.number().int().min(1).max(10000).default(300),
    priorityFeeMicroLamports: z.number().int().nonnegative().default(50000),
    maxRetries: z.number().int().min(1).max(10).default(3),
    retryDelayMs: z.number().positive().default(2000),
    txConfirmTimeoutMs: z.number().positive().default(60000),
    simulateBeforeSend: z.boolean().default(true),
  }),

  filters: z.object({
    minMarketCapUsd: z.number().nonnegative().default(50000),
    maxMarketCapUsd: z.number().positive().default(5000000),
    minTokenAgeMs: z.number().nonnegative().default(300000),
  }),

  walletIntel: z.object({
    monitoredWallets: z.array(z.string()).default([]),
    autoDiscoverFromCopies: z.boolean().default(true),
    minTradesForScore: z.number().int().positive().default(10),
    rankingRefreshIntervalMs: z.number().positive().default(3600000),
  }),

  analytics: z.object({
    prometheusEnabled: z.boolean().default(false),
    prometheusPort: z.number().int().positive().default(9090),
    logLevel: z.enum(['debug', 'info', 'warn', 'error']).default('info'),
    logDir: z.string().default('./logs'),
    logRetentionDays: z.number().int().positive().default(14),
  }),

  db: z.object({
    path: z.string().default('./data/bot.db'),
    walCheckpointIntervalMs: z.number().positive().default(60000),
  }),

  process: z.object({
    healthCheckPort: z.number().int().positive().default(3001),
  }),
});

export type AppConfig = z.infer<typeof ConfigSchema>;

// ─── Extended schema — appended by migration 002 ──────────────────────────────

export const ExtendedConfigSchema = z.object({
  smartMoney: z.object({
    enabled: z.boolean().default(true),
    clusterWindowMs: z.number().positive().default(300000),
    minWalletCount: z.number().int().min(1).default(3),
    minConfidenceScore: z.number().min(0).max(100).default(60),
    minWalletQualityScore: z.number().min(0).max(100).default(55),
    expiryMs: z.number().positive().default(600000),
    maxClustersPerToken: z.number().int().positive().default(5),
  }),

  liquidityInflow: z.object({
    enabled: z.boolean().default(true),
    minNetInflowSol: z.number().nonnegative().default(5),
    velocityWindowMs: z.number().positive().default(300000),
    bullishThreshold: z.number().min(0).max(100).default(65),
    bearishThreshold: z.number().min(0).max(100).default(35),
    rejectOnDecline: z.boolean().default(true),
    snapshotIntervalMs: z.number().positive().default(30000),
  }),

  multiWalletConfirmation: z.object({
    enabled: z.boolean().default(true),
    requiredWallets: z.number().int().min(1).default(3),
    confirmationWindowMs: z.number().positive().default(300000),
    minConfirmationScore: z.number().min(0).max(100).default(60),
    expiryMs: z.number().positive().default(600000),
  }),

  volumeAcceleration: z.object({
    enabled: z.boolean().default(true),
    minAccelerationScore: z.number().min(0).max(100).default(50),
    windowMs: z.number().positive().default(300000),
    rankingIntervalMs: z.number().positive().default(60000),
    maxTrackedTokens: z.number().int().positive().default(200),
  }),

  holderGrowth: z.object({
    enabled: z.boolean().default(true),
    snapshotIntervalMs: z.number().positive().default(300000),
    minHolderGrowthPct: z.number().nonnegative().default(5),
    maxWhaleConcentration: z.number().min(0).max(100).default(25),
    minHolderCount: z.number().int().nonnegative().default(50),
    minGrowthScore: z.number().min(0).max(100).default(40),
  }),

  pumpfunMigration: z.object({
    enabled: z.boolean().default(true),
    bondingCurveThreshold: z.number().min(0).max(100).default(85),
    priorityBoostScore: z.number().nonnegative().default(20),
    trackWindowMs: z.number().positive().default(3600000),
    minInitialLiquiditySol: z.number().nonnegative().default(10),
  }),

  mevProtection: z.object({
    jitoEnabled: z.boolean().default(false),
    jitoTipLamports: z.number().int().nonnegative().default(10000),
    jitoBlockEngineUrl: z.string().default('https://mainnet.block-engine.jito.wtf'),
    maxSlippageAdaptBps: z.number().int().min(0).max(10000).default(500),
    sandwichDetectionEnabled: z.boolean().default(true),
    retryWithJitoOnFail: z.boolean().default(true),
    frontRunProtectionMs: z.number().nonnegative().default(2000),
  }),

  positionSizing: z.object({
    mode: z.enum(['conservative', 'balanced', 'aggressive']).default('balanced'),
    conservative: z.object({
      basePct: z.number().min(0.01).max(0.5).default(0.03),
      maxPct: z.number().min(0.01).max(0.5).default(0.05),
      momentumWeight: z.number().min(0).max(1).default(0.2),
      smartMoneyWeight: z.number().min(0).max(1).default(0.3),
      liquidityWeight: z.number().min(0).max(1).default(0.3),
      riskWeight: z.number().min(0).max(1).default(0.2),
    }),
    balanced: z.object({
      basePct: z.number().min(0.01).max(0.5).default(0.05),
      maxPct: z.number().min(0.01).max(0.5).default(0.10),
      momentumWeight: z.number().min(0).max(1).default(0.25),
      smartMoneyWeight: z.number().min(0).max(1).default(0.35),
      liquidityWeight: z.number().min(0).max(1).default(0.25),
      riskWeight: z.number().min(0).max(1).default(0.15),
    }),
    aggressive: z.object({
      basePct: z.number().min(0.01).max(0.5).default(0.08),
      maxPct: z.number().min(0.01).max(0.5).default(0.15),
      momentumWeight: z.number().min(0).max(1).default(0.35),
      smartMoneyWeight: z.number().min(0).max(1).default(0.30),
      liquidityWeight: z.number().min(0).max(1).default(0.20),
      riskWeight: z.number().min(0).max(1).default(0.15),
    }),
  }),

  exposure: z.object({
    maxCapitalPerTradePct: z.number().min(0.01).max(1).default(0.10),
    maxCapitalPerTokenSol: z.number().positive().default(2.0),
    maxTotalDeployedPct: z.number().min(0.01).max(1).default(0.70),
    maxOpenPositions: z.number().int().positive().default(5),
    maxDailyLossSol: z.number().positive().default(1.0),
    maxDrawdownPct: z.number().min(0.01).max(1).default(0.30),
    maxConsecutiveLosses: z.number().int().positive().default(5),
    cooldownAfterKillSwitchMs: z.number().positive().default(3600000),
  }),

  killSwitch: z.object({
    enabled: z.boolean().default(true),
    triggers: z.object({
      dailyDrawdownPct: z.number().min(0.01).max(1).default(0.20),
      consecutiveLosses: z.number().int().positive().default(5),
      rpcErrorRateThreshold: z.number().min(0).max(1).default(0.30),
      liquidityCollapseThreshold: z.number().min(0).max(1).default(0.50),
    }),
    alertWebhook: z.string().default(''),
    alertOnActivation: z.boolean().default(true),
    alertOnDeactivation: z.boolean().default(true),
  }),

  monitoring: z.object({
    metricsRetentionDays: z.number().int().positive().default(30),
    snapshotIntervalMs: z.number().positive().default(60000),
    // Telegram / Discord alert delivery. Secrets are injected from env
    // (TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, DISCORD_WEBHOOK_URL).
    telegramEnabled: z.boolean().default(false),
    telegramBotToken: z.string().default(''),
    telegramChatId: z.string().default(''),
    discordEnabled: z.boolean().default(false),
    discordWebhookUrl: z.string().default(''),
    alertOnTrade: z.boolean().default(true),
    alertOnError: z.boolean().default(true),
    dailyReportEnabled: z.boolean().default(true),
    dailyReportHourUtc: z.number().int().min(0).max(23).default(0),
  }),
});

export type ExtendedConfig = z.infer<typeof ExtendedConfigSchema>;
