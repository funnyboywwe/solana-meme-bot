import { v4 as uuidv4 } from 'uuid';
import { EventBus, OrderReadyEvent, TradeFilledEvent, CloseSignalEvent } from '../core/EventBus';
import { AppConfig } from '../config/AppConfig';
import { createModuleLogger } from '../core/Logger';
import { Trade, Position } from '../core/types';
import { JupiterClient } from './JupiterClient';
import { TxConfirmation } from './TxConfirmation';
import { FailedTradeRecovery } from './FailedTradeRecovery';
import { PriorityFeeManager } from './PriorityFeeManager';
import { MEVProtection } from './mev/MEVProtection';
import { ExtendedConfig } from '../config/schema';
import { getPositionSizer } from '../risk/PositionSizer';
import TradeRepository from '../db/repositories/TradeRepository';
import TokenRepository from '../db/repositories/TokenRepository';
import PositionRepository from '../db/repositories/PositionRepository';
import { getSolPriceUsd } from '../core/SolPrice';

const logger = createModuleLogger('ExecutionEngine');

/**
 * ExecutionEngine manages the full trade lifecycle.
 *
 * BUG FIXED (#16): Uses getPositionSizer() singleton — no new Connection or
 * Keypair decode here. RiskManager already initialised the singleton.
 *
 * BUG FIXED (#10): sell() now reads token decimals from TokenRepository
 * instead of hardcoding 6. Pump.fun = 6 decimals, Raydium = typically 9.
 */
export class ExecutionEngine {
  private jupiterClient: JupiterClient;
  private txConfirmation: TxConfirmation;
  private failedTradeRecovery: FailedTradeRecovery;
  private priorityFeeManager: PriorityFeeManager;
  private maxRetries: number;
  private retryDelayMs: number;
  private defaultSlippageBps: number;
  private stopLossPct: number;
  private takeProfitPct: number;
  private trailingStopPct: number;

  constructor(cfg: AppConfig, extCfg?: ExtendedConfig) {
    // FIX: use singleton keypair — no second decode of private key
    const sizer = getPositionSizer(cfg);
    this.jupiterClient = new JupiterClient(cfg, sizer.getKeypair());
    // Wire MEV protection (pre-flight simulation + Jito bundle fallback +
    // sandwich/front-run defense) into the swap path when extended config
    // is available.
    if (extCfg) {
      this.jupiterClient.setMevProtection(new MEVProtection(cfg, extCfg, sizer.getKeypair()));
    }
    this.txConfirmation = new TxConfirmation(cfg);
    this.failedTradeRecovery = new FailedTradeRecovery(cfg);
    this.priorityFeeManager = new PriorityFeeManager(cfg);
    this.maxRetries = cfg.execution.maxRetries;
    this.retryDelayMs = cfg.execution.retryDelayMs;
    this.defaultSlippageBps = cfg.execution.maxSlippageBps;
    // FIX: use configured risk parameters instead of hardcoded values.
    this.stopLossPct = cfg.risk.stopLossPct;
    this.takeProfitPct = cfg.risk.takeProfitPct;
    this.trailingStopPct = cfg.risk.trailingStopPct;

    logger.info('ExecutionEngine initialized', { wallet: sizer.getWalletPublicKey() });
  }

  /** Execute a buy order (ORDER_READY → TRADE_FILLED) */
  async execute(order: OrderReadyEvent): Promise<void> {
    const { mint, strategy, sizeSol, maxSlippageBps } = order;
    if (!TokenRepository.exists(mint)) {
      logger.warn('Token not in DB — skipping buy', { mint });
      return;
    }

    const tradeId = uuidv4();
    logger.info('Executing buy', { mint, sizeSol: sizeSol.toFixed(4), strategy });

    for (let attempt = 1; attempt <= this.maxRetries; attempt++) {
      try {
        const trade: Trade = {
          id: tradeId,
          tokenMint: mint,
          strategy,
          side: 'buy',
          amountSol: sizeSol,
          amountTokens: 0,
          status: 'pending',
          entryAt: Date.now(),
        };
        TradeRepository.insert(trade);

        const priorityFee = await this.priorityFeeManager.getRecommendedFee();
        const swapResult = await this.jupiterClient.buy(mint, sizeSol, maxSlippageBps, priorityFee);
        if (!swapResult.success || !swapResult.txHash) {
          logger.warn(`Buy attempt ${attempt} failed`, { mint, error: swapResult.error });
          if (attempt < this.maxRetries) { await this._delay(this.retryDelayMs * attempt); continue; }
          TradeRepository.updateStatus(tradeId, 'failed');
          return;
        }

        TradeRepository.updateStatus(tradeId, 'pending', { txHash: swapResult.txHash });

        const confirmation = await this.txConfirmation.waitForConfirmation(swapResult.txHash);

        if (confirmation.status === 'confirmed') {
          const tokenInfo = TokenRepository.findByMint(mint);
          // FIX: use actual decimals from DB, not hardcoded
          const decimals = tokenInfo?.decimals ?? 9;
          const amountTokens = swapResult.amountOut / Math.pow(10, decimals);
          const priceUsd = amountTokens > 0 ? (sizeSol * getSolPriceUsd()) / amountTokens : 0;

          TradeRepository.updateStatus(tradeId, 'confirmed', {
            txHash: swapResult.txHash,
            confirmedAt: Date.now(),
            feeSol: swapResult.feeSol,
            amountTokens,
            priceUsd,
            slippagePct: swapResult.priceImpactPct,
          });

          const positionId = uuidv4();
          const position: Position = {
            id: positionId,
            tokenMint: mint,
            entryTradeId: tradeId,
            strategy,
            sizeSol,
            entryPriceUsd: priceUsd,
            currentPriceUsd: priceUsd,
            unrealisedPnlSol: 0,
            stopLossPct: this.stopLossPct,
            takeProfitPct: this.takeProfitPct,
            trailingStopPct: this.trailingStopPct,
            trailingStopHighUsd: priceUsd,
            sizeTokens: amountTokens,
            openedAt: Date.now(),
            updatedAt: Date.now(),
            status: 'open',
          };
          PositionRepository.open(position);

          EventBus.emit('TRADE_FILLED', {
            tradeId,
            mint,
            side: 'buy',
            sizeSol,
            sizeTokens: amountTokens,
            priceUsd,
            txHash: swapResult.txHash,
            feeSol: swapResult.feeSol,
            ts: Date.now(),
          } as TradeFilledEvent);

          logger.info('Buy confirmed', { mint, tradeId, txHash: swapResult.txHash, sizeSol: sizeSol.toFixed(4) });
          return;
        }

        if (confirmation.status === 'timeout') {
          const landed = await this.failedTradeRecovery.resolveTimeout(tradeId, swapResult.txHash);
          if (landed) { logger.info('Timed-out buy resolved as confirmed', { tradeId }); return; }
        }

        if (confirmation.status === 'failed') {
          TradeRepository.updateStatus(tradeId, 'failed');
          return;
        }
      } catch (err) {
        logger.error(`Buy attempt ${attempt} error`, { mint, error: String(err) });
        if (attempt < this.maxRetries) await this._delay(this.retryDelayMs * attempt);
      }
    }

    TradeRepository.updateStatus(tradeId, 'failed');
    logger.error('All buy retries exhausted', { mint, tradeId });
  }

  /** Execute a sell order (CLOSE_SIGNAL → TRADE_FILLED) */
  async sell(signal: CloseSignalEvent): Promise<void> {
    const { positionId, mint, reason, currentPriceUsd } = signal;

    const position = PositionRepository.findById(positionId);
    if (!position || position.status !== 'open') {
      logger.warn('Position not found or already closed', { positionId });
      return;
    }

    // FIX: read decimals from DB — Pump.fun=6, Raydium=9, others vary
    const tokenInfo = TokenRepository.findByMint(mint);
    const decimals = tokenInfo?.decimals ?? 9;

    const tradeId = uuidv4();
    logger.info('Executing sell', { mint, positionId, reason });

    for (let attempt = 1; attempt <= this.maxRetries; attempt++) {
      try {
        // FIX (#11): sell the actual token quantity recorded at entry. Fall
        // back to a price-based estimate only for legacy positions opened
        // before size_tokens was tracked.
        const entryPrice = position.entryPriceUsd > 0 ? position.entryPriceUsd : currentPriceUsd;
        const tokenAmount = position.sizeTokens && position.sizeTokens > 0
          ? position.sizeTokens
          : (entryPrice > 0 ? (position.sizeSol * getSolPriceUsd()) / entryPrice : 0);

        if (tokenAmount <= 0) {
          logger.warn('Cannot compute token amount for sell', { positionId, entryPrice });
          return;
        }

        const trade: Trade = {
          id: tradeId,
          tokenMint: mint,
          strategy: position.strategy,
          side: 'sell',
          amountSol: 0,
          amountTokens: tokenAmount,
          status: 'pending',
          entryAt: Date.now(),
        };
        TradeRepository.insert(trade);

        // FIX: pass correct decimals from token DB
        const priorityFee = await this.priorityFeeManager.getRecommendedFee();
        const swapResult = await this.jupiterClient.sell(mint, tokenAmount, decimals, this.defaultSlippageBps, priorityFee);

        if (!swapResult.success || !swapResult.txHash) {
          logger.warn(`Sell attempt ${attempt} failed`, { mint, error: swapResult.error });
          if (attempt < this.maxRetries) { await this._delay(this.retryDelayMs * attempt); continue; }
          TradeRepository.updateStatus(tradeId, 'failed');
          return;
        }

        const confirmation = await this.txConfirmation.waitForConfirmation(swapResult.txHash);

        if (confirmation.status === 'confirmed') {
          const solReceived = swapResult.amountOut / 1e9;
          const realisedPnlSol = solReceived - position.sizeSol;
          const holdTimeSecs = Math.floor((Date.now() - position.openedAt) / 1000);

          TradeRepository.updateStatus(tradeId, 'confirmed', {
            txHash: swapResult.txHash,
            confirmedAt: Date.now(),
            feeSol: swapResult.feeSol,
            amountTokens: tokenAmount,
            priceUsd: currentPriceUsd,
          });

          PositionRepository.close(positionId, {
            id: positionId,
            tokenMint: mint,
            strategy: position.strategy,
            sizeSol: position.sizeSol,
            entryPriceUsd: position.entryPriceUsd,
            exitPriceUsd: currentPriceUsd,
            realisedPnlSol,
            holdTimeSecs,
            exitReason: reason,
            openedAt: position.openedAt,
            closedAt: Date.now(),
          });

          EventBus.emit('TRADE_FILLED', {
            tradeId,
            mint,
            side: 'sell',
            sizeSol: solReceived,
            sizeTokens: tokenAmount,
            priceUsd: currentPriceUsd,
            txHash: swapResult.txHash,
            feeSol: swapResult.feeSol,
            realisedPnlSol,
            ts: Date.now(),
          } as TradeFilledEvent);

          logger.info('Sell confirmed', {
            mint,
            tradeId,
            reason,
            realisedPnlSol: realisedPnlSol.toFixed(6),
            holdTimeSecs,
          });
          return;
        }

        if (confirmation.status === 'timeout') {
          const landed = await this.failedTradeRecovery.resolveTimeout(tradeId, swapResult.txHash);
          if (landed) return;
        }

        if (confirmation.status === 'failed') {
          TradeRepository.updateStatus(tradeId, 'failed');
          return;
        }
      } catch (err) {
        logger.error(`Sell attempt ${attempt} error`, { mint, error: String(err) });
        if (attempt < this.maxRetries) await this._delay(this.retryDelayMs * attempt);
      }
    }

    TradeRepository.updateStatus(tradeId, 'failed');
    logger.error('All sell retries exhausted', { positionId, mint });
  }

  private _delay(ms: number): Promise<void> {
    return new Promise((r) => setTimeout(r, ms));
  }
}

export default ExecutionEngine;
