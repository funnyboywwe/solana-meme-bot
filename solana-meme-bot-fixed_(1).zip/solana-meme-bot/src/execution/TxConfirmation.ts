import { Connection, TransactionSignature } from '@solana/web3.js';
import { createModuleLogger } from '../core/Logger';
import { AppConfig } from '../config/AppConfig';
import { getRpcManager, RpcManager } from '../core/RpcManager';

const logger = createModuleLogger('TxConfirmation');

export type ConfirmationStatus = 'confirmed' | 'failed' | 'timeout' | 'not_found';

export interface ConfirmationResult {
  status: ConfirmationStatus;
  slot?: number;
  err?: string;
}

/**
 * TxConfirmation watches a submitted transaction until:
 * - Confirmed (finalized on-chain)
 * - Failed (on-chain error)
 * - Timeout (txConfirmTimeoutMs elapsed)
 *
 * Strategy:
 * 1. Use WebSocket subscription (fast path)
 * 2. Fall back to polling every 2s if WS not received
 * 3. Timeout after cfg.execution.txConfirmTimeoutMs
 */
export class TxConfirmation {
  private rpc: RpcManager;
  private get connection(): Connection { return this.rpc.getConnection(); }
  private timeoutMs: number;

  constructor(cfg: AppConfig) {
    this.rpc = getRpcManager(cfg);
    this.timeoutMs = cfg.execution.txConfirmTimeoutMs;
  }

  /**
   * Wait for transaction confirmation
   */
  async waitForConfirmation(txHash: TransactionSignature): Promise<ConfirmationResult> {
    return new Promise((resolve) => {
      let resolved = false;
      let pollInterval: NodeJS.Timeout | null = null;
      let subscriptionId: number | null = null;

      const cleanup = () => {
        if (pollInterval) clearInterval(pollInterval);
        if (subscriptionId !== null) {
          this.connection.removeSignatureListener(subscriptionId).catch(() => {});
        }
      };

      const finish = (result: ConfirmationResult) => {
        if (resolved) return;
        resolved = true;
        cleanup();
        resolve(result);
      };

      // 1. WebSocket subscription (fast path)
      subscriptionId = this.connection.onSignature(
        txHash,
        (result) => {
          if (result.err) {
            logger.warn('Transaction failed on-chain', { txHash, err: JSON.stringify(result.err) });
            finish({ status: 'failed', err: JSON.stringify(result.err) });
          } else {
            logger.info('Transaction confirmed via WS', { txHash });
            finish({ status: 'confirmed' });
          }
        },
        'confirmed',
      );

      // 2. Polling fallback every 2s
      pollInterval = setInterval(async () => {
        if (resolved) return;
        try {
          const sigStatus = await this.connection.getSignatureStatus(txHash, {
            searchTransactionHistory: true,
          });
          const status = sigStatus?.value;
          if (!status) return; // Not landed yet

          if (status.err) {
            finish({ status: 'failed', slot: status.slot, err: JSON.stringify(status.err) });
          } else if (status.confirmationStatus === 'confirmed' || status.confirmationStatus === 'finalized') {
            logger.info('Transaction confirmed via polling', { txHash, slot: status.slot });
            finish({ status: 'confirmed', slot: status.slot });
          }
        } catch (err) {
          logger.warn('Polling error', { txHash, error: String(err) });
        }
      }, 2000);
      pollInterval.unref();

      // 3. Timeout
      setTimeout(() => {
        if (!resolved) {
          logger.warn('Transaction confirmation timeout', { txHash, timeoutMs: this.timeoutMs });
          finish({ status: 'timeout' });
        }
      }, this.timeoutMs);
    });
  }
}

export default TxConfirmation;
