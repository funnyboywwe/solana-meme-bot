import axios from 'axios';
import {
  Connection,
  Keypair,
  VersionedTransaction,
  LAMPORTS_PER_SOL,
} from '@solana/web3.js';
import { createModuleLogger } from '../core/Logger';
import { AppConfig } from '../config/AppConfig';
import { MEVProtection } from './mev/MEVProtection';
import { getRpcManager, RpcManager } from '../core/RpcManager';

const logger = createModuleLogger('JupiterClient');

const WSOL_MINT = 'So11111111111111111111111111111111111111112';

/**
 * Jupiter V6 API response for GET /quote
 *
 * BUG FIXED (#1, #2): Jupiter V6 /quote returns a direct QuoteResult
 * object — NOT { data: QuoteResult[] }. Previous code tried to index [0]
 * into an object, which returned undefined and crashed silently.
 *
 * Correct response shape (from https://dev.jup.ag/api-reference/swap/quote):
 * {
 *   inputMint, inAmount, outputMint, outAmount,
 *   otherAmountThreshold, swapMode, slippageBps,
 *   priceImpactPct, routePlan, contextSlot, timeTaken
 * }
 */
export interface QuoteResult {
  inputMint: string;
  outputMint: string;
  inAmount: string;
  outAmount: string;
  otherAmountThreshold: string;
  swapMode: string;
  slippageBps: number;
  priceImpactPct: string;
  routePlan: Array<{
    swapInfo: { ammKey: string; label: string; inputMint: string; outputMint: string };
    percent: number;
  }>;
  contextSlot?: number;
  timeTaken?: number;
}

export interface SwapResult {
  success: boolean;
  txHash?: string;
  amountIn: number;
  amountOut: number;
  feeSol: number;
  priceImpactPct: number;
  error?: string;
}

export class JupiterClient {
  private rpc: RpcManager;
  private get connection(): Connection { return this.rpc.getConnection(); }
  private keypair: Keypair;
  private jupiterApiUrl: string;
  private slippageBps: number;
  private priorityFeeMicroLamports: number;
  private simulateBeforeSend: boolean;
  private mevProtection: MEVProtection | null = null;

  constructor(cfg: AppConfig, keypair: Keypair) {
    this.rpc = getRpcManager(cfg);
    this.keypair = keypair;
    this.jupiterApiUrl = cfg.execution.jupiterApiUrl;
    this.slippageBps = cfg.execution.slippageBps;
    this.priorityFeeMicroLamports = cfg.execution.priorityFeeMicroLamports;
    this.simulateBeforeSend = cfg.execution.simulateBeforeSend;
  }

  /** Wire MEV-protected submission (pre-flight sim + Jito bundle + front-run defense). */
  setMevProtection(mev: MEVProtection): void {
    this.mevProtection = mev;
  }

  /**
   * Get swap quote from Jupiter.
   * FIX: response.data IS the QuoteResult directly, not an array.
   */
  async getQuote(
    inputMint: string,
    outputMint: string,
    amountLamports: number,
    slippageBps?: number,
  ): Promise<QuoteResult> {
    const response = await axios.get<QuoteResult>(
      `${this.jupiterApiUrl}/quote`,
      {
        params: {
          inputMint,
          outputMint,
          amount: amountLamports.toString(),
          slippageBps: slippageBps ?? this.slippageBps,
          onlyDirectRoutes: false,
          asLegacyTransaction: false,
          maxAccounts: 64,
        },
        timeout: 8000,
      },
    );

    // FIX: direct object, not array wrapper
    const quote = response.data;
    if (!quote || !quote.outAmount) {
      throw new Error(`No quote available from Jupiter for ${inputMint} → ${outputMint}`);
    }

    return quote;
  }

  /**
   * Execute a BUY: SOL → token
   */
  async buy(mint: string, sizeSol: number, maxSlippageBps: number, priorityFeeMicroLamports?: number): Promise<SwapResult> {
    const amountLamports = Math.floor(sizeSol * LAMPORTS_PER_SOL);
    logger.info('Executing buy', { mint, sizeSol, maxSlippageBps });

    const quote = await this.getQuote(WSOL_MINT, mint, amountLamports, maxSlippageBps);
    return this._executeSwap(quote, priorityFeeMicroLamports);
  }

  /**
   * Execute a SELL: token → SOL
   * BUG FIXED (#10): decimals is now a parameter (not hardcoded to 6).
   * Caller must supply correct decimals (from TokenRepository).
   */
  async sell(mint: string, amountTokens: number, decimals: number, maxSlippageBps: number, priorityFeeMicroLamports?: number): Promise<SwapResult> {
    const amountBase = Math.floor(amountTokens * Math.pow(10, decimals));
    logger.info('Executing sell', { mint, amountTokens, decimals, maxSlippageBps });

    const quote = await this.getQuote(mint, WSOL_MINT, amountBase, maxSlippageBps);
    return this._executeSwap(quote, priorityFeeMicroLamports);
  }

  private async _executeSwap(quote: QuoteResult, priorityFeeMicroLamports?: number): Promise<SwapResult> {
    try {
      // FIX (#8): use the dynamically-recommended priority fee when supplied.
      const computeUnitPrice = priorityFeeMicroLamports ?? this.priorityFeeMicroLamports;
      // Non-SOL mint (for MEV bookkeeping / logs).
      const mint = quote.outputMint !== WSOL_MINT ? quote.outputMint : quote.inputMint;
      // 1. Get serialised swap transaction from Jupiter
      const swapResponse = await axios.post<{ swapTransaction: string; lastValidBlockHeight?: number }>(
        `${this.jupiterApiUrl}/swap`,
        {
          quoteResponse: quote,
          userPublicKey: this.keypair.publicKey.toBase58(),
          wrapAndUnwrapSol: true,
          computeUnitPriceMicroLamports: computeUnitPrice,
          asLegacyTransaction: false,
          dynamicComputeUnitLimit: true,  // let Jupiter compute the right CU limit
        },
        { timeout: 15000 },
      );

      const swapTxBase64 = swapResponse.data?.swapTransaction;
      if (!swapTxBase64) throw new Error('Jupiter /swap returned no swapTransaction field');

      // 2. Deserialise + sign (used for simulation and/or direct submit).
      const txBytes = Buffer.from(swapTxBase64, 'base64');
      const tx = VersionedTransaction.deserialize(txBytes);
      tx.sign([this.keypair]);

      // 3. Pre-flight simulation BEFORE broadcasting. Abort on failure so we
      //    never spend fees / priority tips on a transaction that will revert.
      if (this.simulateBeforeSend) {
        const sim = await this.connection.simulateTransaction(tx, {
          sigVerify: false,
          replaceRecentBlockhash: true,
          commitment: 'processed',
        });
        if (sim.value.err) {
          const simErr = JSON.stringify(sim.value.err);
          logger.warn('Pre-flight simulation failed — aborting swap', {
            mint,
            err: simErr,
            logs: sim.value.logs?.slice(-5),
          });
          return { success: false, amountIn: 0, amountOut: 0, feeSol: 0, priceImpactPct: 0, error: `simulation failed: ${simErr}` };
        }
      }

      // 4. Submit. Prefer MEV-protected submission (Jito bundle fallback +
      //    sandwich detection + front-run delay) when wired; else direct RPC.
      let txHash: string | undefined;
      if (this.mevProtection) {
        const res = await this.mevProtection.submit({
          txBase64: swapTxBase64,
          mint,
          expectedOutAmount: parseInt(quote.outAmount, 10),
          slippageBps: quote.slippageBps,
          priorityFeeMicroLamports: computeUnitPrice,
        });
        if (!res.success) {
          return { success: false, amountIn: 0, amountOut: 0, feeSol: 0, priceImpactPct: 0, error: res.error ?? 'MEV submit failed' };
        }
        // Jito bundles return a bundleId instead of a signature; fall back to it.
        txHash = res.txHash ?? res.bundleId;
      } else {
        txHash = await this.connection.sendRawTransaction(tx.serialize(), {
          skipPreflight: this.simulateBeforeSend, // already simulated above
          maxRetries: 2,
          preflightCommitment: 'confirmed',
        });
      }

      logger.info('Transaction submitted', { txHash, viaMev: !!this.mevProtection });

      return {
        success: true,
        txHash,
        amountIn: parseInt(quote.inAmount, 10),
        amountOut: parseInt(quote.outAmount, 10),
        feeSol: computeUnitPrice / 1e9,
        priceImpactPct: parseFloat(quote.priceImpactPct),
      };
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : String(err);
      logger.error('Swap execution failed', { error: errorMsg });
      return { success: false, amountIn: 0, amountOut: 0, feeSol: 0, priceImpactPct: 0, error: errorMsg };
    }
  }
}

export default JupiterClient;
