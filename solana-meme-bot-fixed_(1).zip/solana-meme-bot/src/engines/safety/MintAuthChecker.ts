import { AppConfig } from '../../config/AppConfig';
import { createModuleLogger } from '../../core/Logger';
import { getMint } from '@solana/spl-token';
import { Connection, PublicKey } from '@solana/web3.js';

const logger = createModuleLogger('MintAuthChecker');

export interface MintAuthResult {
  disabled: boolean;
}

/**
 * MintAuthChecker verifies the token's mint authority is null (disabled).
 *
 * BUG FIXED (#3): Previous code read mintAuthorityOption at byte offset 36,
 * which is actually the start of the `supply` u64 field.
 *
 * SPL Mint account layout (82 bytes total):
 *   Bytes  0– 3  : mintAuthorityOption  (u32: 0=None, 1=Some)
 *   Bytes  4–35  : mintAuthority        (32-byte Pubkey)
 *   Bytes 36–43  : supply               (u64)
 *   Byte  44     : decimals             (u8)
 *   Byte  45     : isInitialized        (bool)
 *   Bytes 46–49  : freezeAuthorityOption (u32)
 *   Bytes 50–81  : freezeAuthority      (32-byte Pubkey)
 *
 * FIX: Use @solana/spl-token getMint() which decodes the layout correctly
 * rather than doing fragile manual byte arithmetic.
 */
export class MintAuthChecker {
  private connection: Connection;

  constructor(cfg: AppConfig) {
    this.connection = new Connection(cfg.rpc.rpcHttpUrl, cfg.rpc.commitment);
  }

  async check(mint: string): Promise<MintAuthResult> {
    try {
      const mintInfo = await getMint(this.connection, new PublicKey(mint), 'confirmed');
      // getMint() returns null when authority is disabled (COption::None)
      return { disabled: mintInfo.mintAuthority === null };
    } catch (err) {
      logger.warn('Mint authority check failed', { mint, error: String(err) });
      // Fail safe: treat as NOT disabled (risky) rather than blocking all tokens
      return { disabled: false };
    }
  }
}
