import { AppConfig } from '../../config/AppConfig';
import { createModuleLogger } from '../../core/Logger';
import { getMint } from '@solana/spl-token';
import { Connection, PublicKey } from '@solana/web3.js';

const logger = createModuleLogger('FreezeAuthChecker');

export interface FreezeAuthResult {
  disabled: boolean;
}

/**
 * FreezeAuthChecker verifies the token's freeze authority is null (disabled).
 *
 * BUG FIXED (#4): Previous code read freezeAuthorityOption at byte offset 40,
 * which lands in the middle of the `supply` u64 field (bytes 36–43).
 * Correct offset for freezeAuthorityOption is byte 46.
 *
 * FIX: Use @solana/spl-token getMint() which decodes the layout correctly.
 */
export class FreezeAuthChecker {
  private connection: Connection;

  constructor(cfg: AppConfig) {
    this.connection = new Connection(cfg.rpc.rpcHttpUrl, cfg.rpc.commitment);
  }

  async check(mint: string): Promise<FreezeAuthResult> {
    try {
      const mintInfo = await getMint(this.connection, new PublicKey(mint), 'confirmed');
      // getMint() returns null when freeze authority is COption::None
      return { disabled: mintInfo.freezeAuthority === null };
    } catch (err) {
      logger.warn('Freeze authority check failed', { mint, error: String(err) });
      return { disabled: false };
    }
  }
}
