import { AppConfig } from '../../config/AppConfig';
import { createModuleLogger } from '../../core/Logger';
import { getSolPriceUsd } from '../../core/SolPrice';
import axios from 'axios';

const logger = createModuleLogger('LiquidityChecker');

export interface LiquidityResult {
  pass: boolean;
  liquidityUsd: number;
}

interface RaydiumPoolInfo {
  id: string;
  baseMint: string;
  quoteMint: string;
  lpMint: string;
  baseDecimals: number;
  quoteDecimals: number;
  lpDecimals: number;
  version: number;
  programId: string;
  authority: string;
  baseVault: string;
  quoteVault: string;
  baseReserve: string;
  quoteReserve: string;
  status: string;
}

/**
 * LiquidityChecker verifies a token has adequate liquidity.
 *
 * BUG FIXED (RaydiumMonitor/LiquidityChecker): The previous code used
 * `response.data.data.liquidity` which does not exist in Raydium's API.
 * The correct Raydium v2 ammV3 pools endpoint returns an array of pool
 * objects. We identify the SOL/token pool and compute liquidity from
 * the quoteReserve (WSOL side) × SOL price.
 *
 * Fallback: If Raydium API fails, attempt Helius getTokenAccountsByOwner
 * to estimate liquidity from pool vault balances.
 */
export class LiquidityChecker {
  private minLiquidityUsd: number;

  constructor(cfg: AppConfig) {
    this.minLiquidityUsd = cfg.safety.minLiquidityUsd;
  }

  async check(mint: string): Promise<LiquidityResult> {
    try {
      // Raydium mainnet API — query pools by baseMint
      const response = await axios.get<RaydiumPoolInfo[] | { data: RaydiumPoolInfo[] }>(
        'https://api.mainnet.raydium.io/v2/main/pairs',
        {
          timeout: 5000,
          params: {},
        },
      );

      // FIX (#4): the pairs endpoint returns a FLAT array, not { data: [...] }.
      const pools: RaydiumPoolInfo[] = Array.isArray(response.data)
        ? response.data
        : (response.data?.data ?? []);
      const WSOL = 'So11111111111111111111111111111111111111112';

      // Find a SOL-paired pool for this mint
      const pool = pools.find(
        (p) =>
          (p.baseMint === mint && p.quoteMint === WSOL) ||
          (p.quoteMint === mint && p.baseMint === WSOL),
      );

      if (!pool) {
        // Pool not yet indexed by Raydium — treat as low liquidity for new tokens
        logger.debug('No Raydium pool found for token', { mint });
        return { pass: false, liquidityUsd: 0 };
      }

      // quoteReserve is SOL side when quoteMint is WSOL
      const solReserve = parseFloat(
        pool.quoteMint === WSOL ? pool.quoteReserve : pool.baseReserve,
      );
      // Multiply by 2 for both sides, × live SOL price.
      const liquidityUsd = solReserve * 2 * getSolPriceUsd();

      return { pass: liquidityUsd >= this.minLiquidityUsd, liquidityUsd };
    } catch (err) {
      logger.warn('Liquidity check failed', { mint, error: String(err) });
      return { pass: false, liquidityUsd: 0 };
    }
  }
}
