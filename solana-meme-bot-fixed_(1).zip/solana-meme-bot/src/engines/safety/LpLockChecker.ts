import { PublicKey } from '@solana/web3.js';
import axios from 'axios';
import { AppConfig } from '../../config/AppConfig';
import { createModuleLogger } from '../../core/Logger';
import { getRpcManager, RpcManager } from '../../core/RpcManager';

const logger = createModuleLogger('LpLockChecker');

const WSOL = 'So11111111111111111111111111111111111111112';

/**
 * Owners that indicate burned / unrecoverable LP. If the LP tokens live in a
 * token account owned by one of these, the liquidity can no longer be pulled
 * by the deployer (the #1 meme-coin rug vector).
 */
const BURN_OWNERS = new Set<string>([
  '1nc1nerator11111111111111111111111111111111', // SPL incinerator
  '11111111111111111111111111111111', // System program / null owner
]);

interface RaydiumPoolInfo {
  baseMint: string;
  quoteMint: string;
  lpMint: string;
  lpDecimals: number;
}

export interface LpLockResult {
  /** false when we could not determine (no pool indexed yet / RPC error). */
  checked: boolean;
  /** true when burned/locked pct >= configured threshold. */
  locked: boolean;
  /** Percentage of LP supply held by burn/null owners (0..100). */
  burnedPct: number;
  lpMint?: string;
  reason?: string;
}

/**
 * LpLockChecker verifies that the LP tokens for a token's SOL pool have been
 * burned (or sent to a null/locker owner), which prevents a "liquidity pull"
 * rug. Strategy:
 *   1. Resolve the Raydium SOL-paired pool's lpMint.
 *   2. Read total LP supply (getTokenSupply).
 *   3. Read the largest LP holders (getTokenLargestAccounts) and resolve each
 *      account's owner (getParsedAccountInfo).
 *   4. Sum LP held by burn/null owners; if supply is zero, treat as fully
 *      burned.
 */
export class LpLockChecker {
  private rpc: RpcManager;
  private minLockedPct: number;

  constructor(cfg: AppConfig) {
    this.rpc = getRpcManager(cfg);
    this.minLockedPct = cfg.safety.minLpLockedPct;
  }

  async check(mint: string): Promise<LpLockResult> {
    try {
      const lpMint = await this._findLpMint(mint);
      if (!lpMint) {
        return { checked: false, locked: false, burnedPct: 0, reason: 'no Raydium pool / lpMint found' };
      }

      const conn = this.rpc.getConnection();
      const lpKey = new PublicKey(lpMint);

      const supplyResp = await conn.getTokenSupply(lpKey);
      const totalSupply = BigInt(supplyResp.value.amount);
      if (totalSupply === 0n) {
        return { checked: true, locked: true, burnedPct: 100, lpMint, reason: 'LP supply is zero (fully burned)' };
      }

      const largest = await conn.getTokenLargestAccounts(lpKey);
      let burned = 0n;
      for (const acct of largest.value) {
        const info = await conn.getParsedAccountInfo(acct.address);
        const data = info.value?.data;
        let owner: string | undefined;
        if (data && typeof data === 'object' && 'parsed' in data) {
          const parsed = (data as { parsed?: { info?: { owner?: string } } }).parsed;
          owner = parsed?.info?.owner;
        }
        if (owner && BURN_OWNERS.has(owner)) {
          burned += BigInt(acct.amount);
        }
      }

      const burnedPct = Number((burned * 10000n) / totalSupply) / 100;
      const locked = burnedPct >= this.minLockedPct;
      logger.info('LP lock check', { mint, lpMint, burnedPct: burnedPct.toFixed(2), locked });
      return { checked: true, locked, burnedPct, lpMint };
    } catch (err) {
      logger.warn('LP lock check failed', { mint, error: err instanceof Error ? err.message : String(err) });
      return { checked: false, locked: false, burnedPct: 0, reason: 'rpc error' };
    }
  }

  private async _findLpMint(mint: string): Promise<string | null> {
    try {
      const response = await axios.get<RaydiumPoolInfo[] | { data: RaydiumPoolInfo[] }>(
        'https://api.mainnet.raydium.io/v2/main/pairs',
        { timeout: 5000 },
      );
      const pools: RaydiumPoolInfo[] = Array.isArray(response.data)
        ? response.data
        : (response.data?.data ?? []);
      const pool = pools.find(
        (p) =>
          (p.baseMint === mint && p.quoteMint === WSOL) ||
          (p.quoteMint === mint && p.baseMint === WSOL),
      );
      return pool?.lpMint ?? null;
    } catch {
      return null;
    }
  }
}

export default LpLockChecker;
