import { AppConfig } from '../../config/AppConfig';
import { createModuleLogger } from '../../core/Logger';
import axios from 'axios';

const logger = createModuleLogger('HolderAnalyzer');

export interface HolderAnalysisResult {
  concentration: number; // % of supply held by top 10 wallets
  holderCount: number;
}

interface HeliusTokenHolder {
  owner: string;
  amount: number;
  decimals: number;
  uiAmount: number;
  uiAmountString: string;
}

interface HeliusHoldersResponse {
  result: HeliusTokenHolder[];
}

/**
 * HolderAnalyzer checks token holder distribution.
 *
 * BUG FIXED (#13): Previous URL was api.helius.xyz/v0/tokens/{mint}/holders
 * which does not exist. The correct Helius endpoint for token holders uses
 * the DAS (Digital Asset Standard) API:
 * POST https://mainnet.helius-rpc.com/?api-key=KEY
 * with method: "getTokenAccounts" and params.mint
 *
 * Alternatively use the Helius /v1/addresses/{mint}/balances endpoint
 * which is the correct REST endpoint for SPL token holders.
 */
export class HolderAnalyzer {
  private maxHolderConcentration: number;
  private rpcUrl: string;
  private apiKey: string;

  constructor(cfg: AppConfig) {
    this.maxHolderConcentration = cfg.safety.maxHolderConcentrationPct;
    this.rpcUrl = cfg.rpc.rpcHttpUrl;
    this.apiKey = cfg.rpc.heliusApiKey;
  }

  async analyze(mint: string): Promise<HolderAnalysisResult> {
    try {
      // Use Helius getTokenAccounts RPC method (DAS API)
      const response = await axios.post<{
        result: {
          token_accounts: Array<{ amount: string; owner: string }>;
          total: number;
        };
      }>(
        this.rpcUrl,
        {
          jsonrpc: '2.0',
          id: 'holder-check',
          method: 'getTokenAccounts',
          params: {
            mint,
            limit: 10,
            page: 1,
            options: { showZeroBalance: false },
          },
        },
        { timeout: 5000 },
      );

      const accounts = response.data?.result?.token_accounts ?? [];
      if (accounts.length === 0) {
        return { concentration: 100, holderCount: 0 };
      }

      // Sum top-10 holder amounts
      const topHolderTotal = accounts.reduce(
        (sum, a) => sum + parseFloat(a.amount),
        0,
      );

      // Get total supply via getTokenSupply RPC
      const supplyResponse = await axios.post<{
        result: { value: { amount: string; decimals: number } };
      }>(
        this.rpcUrl,
        {
          jsonrpc: '2.0',
          id: 'supply-check',
          method: 'getTokenSupply',
          params: [mint],
        },
        { timeout: 5000 },
      );

      const totalSupplyRaw = parseFloat(
        supplyResponse.data?.result?.value?.amount ?? '0',
      );

      if (totalSupplyRaw === 0) {
        return { concentration: 100, holderCount: accounts.length };
      }

      const concentration = Math.min((topHolderTotal / totalSupplyRaw) * 100, 100);
      return { concentration, holderCount: response.data?.result?.total ?? accounts.length };
    } catch (err) {
      logger.warn('Holder analysis failed', { mint, error: String(err) });
      // Fail safe: high concentration = risky, but not 100 (would block everything on network errors)
      return { concentration: 50, holderCount: 0 };
    }
  }
}
