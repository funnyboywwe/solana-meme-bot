import { MomentumState } from '../../core/types';
import { AppConfig } from '../../config/AppConfig';

/**
 * PriceAccel tracks:
 * - Price history (last 10 ticks)
 * - Velocity = rate of price change
 * - Acceleration = rate of velocity change (2nd derivative)
 * - Normalises to 0–20 points
 *
 * High acceleration = price is speeding upward (early pump indicator)
 */
export class PriceAccel {
  private priceAccelThreshold: number;
  private maxPriceHistory = 10;

  constructor(cfg: AppConfig) {
    this.priceAccelThreshold = cfg.momentum.priceAccelThreshold; // 0.02 = 2% accel
  }

  /**
   * Record price tick
   */
  update(state: MomentumState, priceUsd: number, ts: number): void {
    state.priceHistory.push({ price: priceUsd, ts });

    if (state.priceHistory.length > this.maxPriceHistory) {
      state.priceHistory.shift();
    }
  }

  /**
   * Compute acceleration score (0–20 points)
   */
  getScore(state: MomentumState): number {
    if (state.priceHistory.length < 3) return 0;

    const hist = state.priceHistory;

    // Recent velocity (last 2 ticks)
    const last = hist[hist.length - 1];
    const prev = hist[hist.length - 2];
    if (!last || !prev) return 0;
    const p1 = last.price;
    const p0 = prev.price;
    const t1 = last.ts;
    const t0 = prev.ts;

    const dt1 = (t1 - t0) / 1000; // seconds
    const v1 = dt1 > 0 ? (p1 - p0) / dt1 : 0;

    // Previous velocity (2 ticks back)
    if (hist.length < 4) return 0;

    const prev2 = hist[hist.length - 3];
    if (!prev2) return 0;
    const p2 = prev2.price;
    const t2 = prev2.ts;
    const dt2 = (t0 - t2) / 1000;
    const v0 = dt2 > 0 ? (p0 - p2) / dt2 : 0;

    // Acceleration
    const dtMid = (t1 - t2) / 2000; // seconds
    const accel = dtMid > 0 ? (v1 - v0) / dtMid : 0;

    if (p0 === 0) return 0;

    // Normalise relative to price
    const accelNorm = Math.abs(accel / p0);

    if (accelNorm < this.priceAccelThreshold) {
      return 0;
    }

    // Map [threshold, 5x threshold] to [0, 20]
    const normalized = Math.min((accelNorm / this.priceAccelThreshold) * 10, 20);

    return accel > 0 ? normalized : 0; // Only reward upward acceleration
  }
}

export default PriceAccel;
