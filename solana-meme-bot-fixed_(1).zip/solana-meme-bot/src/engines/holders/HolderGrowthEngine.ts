import axios from 'axios';
import { EventBus, TokenCreatedEvent, HolderGrowthEvent } from '../../core/EventBus';
import { AppConfig } from '../../config/AppConfig';
import { ExtendedConfig } from '../../config/schema';
import { createModuleLogger } from '../../core/Logger';
import { HolderSnapshot } from '../../core/types';
import { getDb } from '../../db/Database';

const logger = createModuleLogger('HolderGrowthEngine');

interface HolderState {
  mint: string;
  snapshots: HolderSnapshot[];
  lastSnapshotTs: number;
}

/**
 * HolderGrowthEngine periodically fetches holder counts for tracked tokens.
 *
 * Score formula (0-100):
 *   holderCountScore  = min(holderCount / 1000, 1) * 25
 *   growthScore1h     = min(newHolders1h / 50, 1) * 35
 *   retentionScore    = retentionRate * 20
 *   concentrationPenalty = whaleConcentration / 100 * 20 (negative)
 *
 * Rejects tokens with:
 *   - < minHolderCount holders
 *   - > maxWhaleConcentration top-10 concentration
 *   - growthScore < minGrowthScore
 */
export class HolderGrowthEngine {
  private cfg: ExtendedConfig['holderGrowth'];
  private baseCfg: AppConfig;
  private tracked = new Map<string, HolderState>();
  private snapshotTimer: NodeJS.Timeout;

  constructor(baseCfg: AppConfig, extCfg: ExtendedConfig) {
    this.baseCfg = baseCfg;
    this.cfg = extCfg.holderGrowth;

    this.snapshotTimer = setInterval(() => void this._snapshotAll(), this.cfg.snapshotIntervalMs);
    this.snapshotTimer.unref();

    logger.info('HolderGrowthEngine initialized', {
      snapshotInterval: this.cfg.snapshotIntervalMs,
      minHolders: this.cfg.minHolderCount,
      maxWhale: this.cfg.maxWhaleConcentration,
    });
  }

  registerToken(mint: string): void {
    if (!this.tracked.has(mint)) {
      this.tracked.set(mint, { mint, snapshots: [], lastSnapshotTs: 0 });
    }
  }

  processTokenCreated(event: TokenCreatedEvent): void {
    this.registerToken(event.mint);
  }

  private async _snapshotAll(): Promise<void> {
    for (const [mint] of this.tracked) {
      await this._fetchAndSnapshot(mint);
    }
  }

  private async _fetchAndSnapshot(mint: string): Promise<void> {
    const state = this.tracked.get(mint);
    if (!state) return;

    // Rate-limit: don't fetch more often than snapshotIntervalMs
    const now = Date.now();
    if (now - state.lastSnapshotTs < this.cfg.snapshotIntervalMs - 5000) return;
    state.lastSnapshotTs = now;

    try {
      // Use Helius DAS API for holder count + top holders
      const rpcUrl = this.baseCfg.rpc.rpcHttpUrl;

      const [accountsResp, supplyResp] = await Promise.all([
        axios.post<{ result: { total: number; token_accounts: Array<{ amount: string; owner: string }> } }>(
          rpcUrl,
          { jsonrpc: '2.0', id: 'holder-count', method: 'getTokenAccounts',
            params: { mint, limit: 10, page: 1, options: { showZeroBalance: false } } },
          { timeout: 5000 },
        ),
        axios.post<{ result: { value: { amount: string; decimals: number } } }>(
          rpcUrl,
          { jsonrpc: '2.0', id: 'supply', method: 'getTokenSupply', params: [mint] },
          { timeout: 5000 },
        ),
      ]);

      const holderCount = accountsResp.data?.result?.total ?? 0;
      const topAccounts = accountsResp.data?.result?.token_accounts ?? [];
      const totalSupplyRaw = parseFloat(supplyResp.data?.result?.value?.amount ?? '0');

      // Compute concentration
      const topHolderTotal = topAccounts.reduce(
        (s: number, a: { amount: string | number }) => s + parseFloat(String(a.amount)),
        0,
      );
      const whaleConcentration = totalSupplyRaw > 0
        ? Math.min((topHolderTotal / totalSupplyRaw) * 100, 100)
        : 100;

      // Compute growth by comparing to previous snapshot
      const prev = state.snapshots[state.snapshots.length - 1];
      const newHolders1h = prev && (now - prev.ts) < 3_600_000
        ? Math.max(0, holderCount - prev.holderCount)
        : 0;
      const newHolders24h = state.snapshots.length > 0
        ? Math.max(0, holderCount - (state.snapshots[0]?.holderCount ?? holderCount))
        : 0;

      // Retention rate (stable if holder count not dropping fast)
      const retentionRate = prev && prev.holderCount > 0
        ? Math.min(holderCount / prev.holderCount, 1)
        : 1;

      const growthScore = this._computeGrowthScore(holderCount, newHolders1h, retentionRate, whaleConcentration);
      const healthy = this._isHealthy(holderCount, whaleConcentration, growthScore);

      const snap: HolderSnapshot = {
        tokenMint: mint,
        holderCount,
        newHolders1h,
        newHolders24h,
        uniqueBuyers: holderCount, // approximate
        retentionRate,
        whaleConcentration,
        top10Pct: whaleConcentration,
        growthScore,
        healthy,
        ts: now,
      };

      state.snapshots.push(snap);
      if (state.snapshots.length > 48) state.snapshots.shift(); // keep 24h of 30-min snapshots

      this._persist(snap);

      if (growthScore >= this.cfg.minGrowthScore) {
        EventBus.emit('HOLDER_GROWTH', {
          tokenMint: mint,
          growthScore,
          holderCount,
          newHolders1h,
          healthy,
          ts: now,
        } as HolderGrowthEvent);
      }

      logger.debug('Holder snapshot', { mint: mint.slice(0, 8), holderCount, growthScore: growthScore.toFixed(1), healthy });
    } catch (err) {
      logger.warn('Holder snapshot failed', { mint: mint.slice(0, 8), error: String(err) });
    }
  }

  private _computeGrowthScore(
    holderCount: number,
    newHolders1h: number,
    retentionRate: number,
    whaleConcentration: number,
  ): number {
    const countScore = Math.min(holderCount / 1000, 1) * 25;
    const growthScore = Math.min(newHolders1h / 50, 1) * 35;
    const retentionScore = retentionRate * 20;
    const concentrationPenalty = (whaleConcentration / 100) * 20;
    return Math.max(0, Math.min(100, countScore + growthScore + retentionScore - concentrationPenalty));
  }

  private _isHealthy(holderCount: number, whaleConcentration: number, growthScore: number): boolean {
    if (holderCount < this.cfg.minHolderCount) return false;
    if (whaleConcentration > this.cfg.maxWhaleConcentration) return false;
    if (growthScore < this.cfg.minGrowthScore) return false;
    return true;
  }

  private _persist(snap: HolderSnapshot): void {
    const db = getDb();
    db.prepare(`
      INSERT INTO holder_snapshots
        (token_mint, holder_count, new_holders_1h, new_holders_24h, unique_buyers, retention_rate,
         whale_concentration, top10_pct, growth_score, healthy, ts)
      VALUES (@token_mint, @holder_count, @new_holders_1h, @new_holders_24h, @unique_buyers, @retention_rate,
              @whale_concentration, @top10_pct, @growth_score, @healthy, @ts)
    `).run({
      token_mint: snap.tokenMint,
      holder_count: snap.holderCount,
      new_holders_1h: snap.newHolders1h,
      new_holders_24h: snap.newHolders24h,
      unique_buyers: snap.uniqueBuyers,
      retention_rate: snap.retentionRate,
      whale_concentration: snap.whaleConcentration,
      top10_pct: snap.top10Pct,
      growth_score: snap.growthScore,
      healthy: snap.healthy ? 1 : 0,
      ts: snap.ts,
    });
  }

  isHealthy(mint: string): boolean {
    const state = this.tracked.get(mint);
    const latest = state?.snapshots[state.snapshots.length - 1];
    if (!latest) return true; // no data = allow
    return latest.healthy;
  }

  getGrowthScore(mint: string): number {
    const state = this.tracked.get(mint);
    const latest = state?.snapshots[state.snapshots.length - 1];
    return latest?.growthScore ?? 0;
  }

  getSnapshot(mint: string): HolderSnapshot | undefined {
    const state = this.tracked.get(mint);
    return state?.snapshots[state.snapshots.length - 1];
  }

  stop(): void {
    clearInterval(this.snapshotTimer);
  }
}

export default HolderGrowthEngine;
