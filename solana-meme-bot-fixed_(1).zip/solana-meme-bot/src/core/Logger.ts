import winston from 'winston';
import DailyRotateFile from 'winston-daily-rotate-file';
import * as path from 'path';

const SECRET_FIELDS = new Set(['privateKey', 'apiKey', 'secret', 'password', 'token', 'authorization']);

function redactSecrets(obj: unknown): unknown {
  if (obj === null || obj === undefined) return obj;
  if (typeof obj === 'string') return obj;
  if (Array.isArray(obj)) return obj.map(redactSecrets);
  if (typeof obj === 'object') {
    const result: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(obj as Record<string, unknown>)) {
      result[k] = SECRET_FIELDS.has(k) ? '***' : redactSecrets(v);
    }
    return result;
  }
  return obj;
}

const redactFormat = winston.format((info) => {
  const redacted = redactSecrets(info) as typeof info;
  return redacted;
});

let _logger: winston.Logger | null = null;

export interface LoggerOptions {
  level: string;
  logDir: string;
  retentionDays: number;
}

export function initLogger(opts: LoggerOptions): winston.Logger {
  const { level, logDir, retentionDays } = opts;

  const consoleFormat = winston.format.combine(
    redactFormat(),
    winston.format.colorize(),
    winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss.SSS' }),
    winston.format.printf(({ timestamp, level: lvl, message, module: mod, ...meta }) => {
      const modStr = mod ? `[${mod}] ` : '';
      const metaStr = Object.keys(meta).length ? ' ' + JSON.stringify(meta) : '';
      return `${timestamp} ${lvl} ${modStr}${message}${metaStr}`;
    }),
  );

  const fileFormat = winston.format.combine(
    redactFormat(),
    winston.format.timestamp(),
    winston.format.json(),
  );

  const transports: winston.transport[] = [
    new winston.transports.Console({ format: consoleFormat }),
    new DailyRotateFile({
      dirname: logDir,
      filename: 'bot-%DATE%.log',
      datePattern: 'YYYY-MM-DD',
      maxFiles: `${retentionDays}d`,
      maxSize: '20m',
      format: fileFormat,
    }) as unknown as winston.transport,
    new DailyRotateFile({
      dirname: logDir,
      filename: 'error-%DATE%.log',
      datePattern: 'YYYY-MM-DD',
      level: 'error',
      maxFiles: `${retentionDays}d`,
      maxSize: '20m',
      format: fileFormat,
    }) as unknown as winston.transport,
  ];

  _logger = winston.createLogger({
    level,
    transports,
    exitOnError: false,
  });

  return _logger;
}

export function getLogger(module?: string): winston.Logger {
  if (!_logger) {
    // Fallback logger before initLogger is called (e.g. during config load errors)
    _logger = winston.createLogger({
      level: 'info',
      transports: [new winston.transports.Console()],
    });
  }
  return module ? _logger.child({ module }) : _logger;
}

export function createModuleLogger(moduleName: string): winston.Logger {
  return getLogger(moduleName);
}
