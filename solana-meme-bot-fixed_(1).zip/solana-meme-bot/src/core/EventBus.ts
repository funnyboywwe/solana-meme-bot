import EventEmitter from 'eventemitter3';
import { createModuleLogger } from './Logger';

const logger = createModuleLogger('EventBus');

// ─── Domain event types ─────────────────────────────────────────────────────

export interface TokenCreatedEvent {
  mint: string;
  symbol: string;
  decimals: number;
  initialLiquidityUsd: number;
  poolAddress: string;
  createdAt: number;
  source: 'pumpfun' | 'raydium';
}

export interface TradeDetectedEvent {
  mint: string;
  side: 'buy' | 'sell';
  amountUsd: number;
  amountSol: number;
  priceUsd: number;
  walletAddress: string;
  txHash: string;
  ts: number;
  poolAddress: string;
}

export interface WalletTxEvent {
  walletAddress: string;
  mint: string;
  side: 'buy' | 'sell';
  amountSol: number;
  amountTokens: number;
  priceUsd: number;
  txHash: string;
  ts: number;
  slot: number;
}

export interface PriceUpdateEvent {
  mint: string;
  priceUsd: number;
  liquidityUsd: number;
  ts: number;
}

export interface PoolUpdateEvent {
  poolAddress: string;
  mint: string;
  liquidityUsd: number;
  liquidityDeltaUsd: number;
  ts: number;
}

export interface MomentumSignalEvent {
  mint: string;
  score: number;
  breakdown: {
    volumeScore: number;
    buyScore: number;
    velocityScore: number;
    liquidityScore: number;
    accelScore: number;
  };
  ts: number;
}

export interface CopySignalEvent {
  mint: string;
  walletAddress: string;
  walletScore: number;
  suggestedSizeSol: number;
  originTxHash: string;
  ts: number;
}

export interface EntryApprovedEvent {
  mint: string;
  strategy: 'momentum' | 'copy' | 'hybrid';
  momentumScore?: number;
  walletScore?: number;
  sizeSol: number;
  ts: number;
}

export interface OrderReadyEvent {
  mint: string;
  strategy: 'momentum' | 'copy' | 'hybrid';
  sizeSol: number;
  maxSlippageBps: number;
  ts: number;
}

export interface TradeFilledEvent {
  tradeId: string;
  mint: string;
  side: 'buy' | 'sell';
  sizeSol: number;
  sizeTokens: number;
  priceUsd: number;
  txHash: string;
  feeSol: number;
  realisedPnlSol?: number;   // only set on sell fills
  ts: number;
}

export interface CloseSignalEvent {
  positionId: string;
  mint: string;
  reason: 'stop' | 'tp' | 'trailing' | 'manual' | 'circuit';
  currentPriceUsd: number;
  ts: number;
}

export interface EngineErrorEvent {
  engine: string;
  error: string;
  context?: Record<string, unknown>;
  ts: number;
}

export interface WsStatusEvent {
  client: string;
  status: 'connected' | 'disconnected' | 'reconnecting' | 'error';
  ts: number;
}

// ─── Event map ──────────────────────────────────────────────────────────────

export interface BotEvents {
  TOKEN_CREATED: [TokenCreatedEvent];
  TRADE_DETECTED: [TradeDetectedEvent];
  WALLET_TX: [WalletTxEvent];
  PRICE_UPDATE: [PriceUpdateEvent];
  POOL_UPDATE: [PoolUpdateEvent];
  MOMENTUM_SIGNAL: [MomentumSignalEvent];
  COPY_SIGNAL: [CopySignalEvent];
  ENTRY_APPROVED: [EntryApprovedEvent];
  ORDER_READY: [OrderReadyEvent];
  TRADE_FILLED: [TradeFilledEvent];
  CLOSE_SIGNAL: [CloseSignalEvent];
  ENGINE_ERROR: [EngineErrorEvent];
  WS_STATUS: [WsStatusEvent];
}

export type BotEventName = keyof BotEvents;

// ─── Ring buffer for back-pressure ─────────────────────────────────────────

interface QueuedEvent {
  name: BotEventName;
  payload: BotEvents[BotEventName][0];
}

const RING_BUFFER_SIZE = 2000;

class RingBuffer<T> {
  private buf: (T | undefined)[];
  private head = 0;
  private tail = 0;
  private count = 0;

  constructor(private capacity: number) {
    this.buf = new Array<T | undefined>(capacity);
  }

  push(item: T): boolean {
    if (this.count === this.capacity) {
      // Drop oldest
      this.head = (this.head + 1) % this.capacity;
      this.count--;
    }
    this.buf[this.tail] = item;
    this.tail = (this.tail + 1) % this.capacity;
    this.count++;
    return true;
  }

  shift(): T | undefined {
    if (this.count === 0) return undefined;
    const item = this.buf[this.head];
    this.buf[this.head] = undefined;
    this.head = (this.head + 1) % this.capacity;
    this.count--;
    return item;
  }

  get size(): number {
    return this.count;
  }

  get isEmpty(): boolean {
    return this.count === 0;
  }
}

// ─── Dead-letter queue ──────────────────────────────────────────────────────

interface DeadLetterEntry {
  name: BotEventName;
  payload: unknown;
  error: string;
  ts: number;
}

const MAX_DEAD_LETTER = 100;

// ─── EventBus ───────────────────────────────────────────────────────────────

class EventBusImpl {
  private emitter = new EventEmitter();
  private queue = new RingBuffer<QueuedEvent>(RING_BUFFER_SIZE);
  private deadLetter: DeadLetterEntry[] = [];
  private draining = false;
  // Maps each user handler to its wrapped emitter handler so off() can remove
  // the correct listener. Previously off() passed the original handler, which
  // never matched the wrapped one → listeners were never actually removed.
  private wrappedHandlers = new Map<
    BotEventName,
    Map<(payload: any) => void | Promise<void>, (payload: any) => void>
  >();

  emit<E extends BotEventName>(name: E, payload: BotEvents[E][0]): void {
    this.queue.push({ name, payload: payload as BotEvents[BotEventName][0] });
    if (!this.draining) {
      setImmediate(() => this.drain());
    }
  }

  on<E extends BotEventName>(name: E, handler: (payload: BotEvents[E][0]) => void | Promise<void>): void {
    const wrapped = async (payload: BotEvents[E][0]): Promise<void> => {
      try {
        await handler(payload);
      } catch (err) {
        const errMsg = err instanceof Error ? err.message : String(err);
        logger.error(`Subscriber error on ${name}: ${errMsg}`);
        if (this.deadLetter.length >= MAX_DEAD_LETTER) {
          this.deadLetter.shift();
        }
        this.deadLetter.push({ name, payload, error: errMsg, ts: Date.now() });
      }
    };
    let perEvent = this.wrappedHandlers.get(name);
    if (!perEvent) {
      perEvent = new Map();
      this.wrappedHandlers.set(name, perEvent);
    }
    perEvent.set(handler as (payload: any) => void | Promise<void>, wrapped as (payload: any) => void);
    this.emitter.on(name, wrapped);
  }

  off<E extends BotEventName>(name: E, handler: (payload: BotEvents[E][0]) => void | Promise<void>): void {
    const perEvent = this.wrappedHandlers.get(name);
    const wrapped = perEvent?.get(handler as (payload: any) => void | Promise<void>);
    if (wrapped) {
      this.emitter.off(name, wrapped);
      perEvent!.delete(handler as (payload: any) => void | Promise<void>);
    } else {
      this.emitter.off(name, handler);
    }
  }

  once<E extends BotEventName>(name: E, handler: (payload: BotEvents[E][0]) => void | Promise<void>): void {
    this.emitter.once(name, async (payload: BotEvents[E][0]) => {
      try {
        await handler(payload);
      } catch (err) {
        logger.error(`Once-subscriber error on ${name}: ${err instanceof Error ? err.message : String(err)}`);
      }
    });
  }

  private drain(): void {
    this.draining = true;
    let processed = 0;
    const MAX_PER_TICK = 50;

    while (!this.queue.isEmpty && processed < MAX_PER_TICK) {
      const item = this.queue.shift();
      if (!item) break;
      this.emitter.emit(item.name, item.payload);
      processed++;
    }

    this.draining = false;

    if (!this.queue.isEmpty) {
      setImmediate(() => this.drain());
    }
  }

  getQueueSize(): number {
    return this.queue.size;
  }

  getDeadLetterEntries(): DeadLetterEntry[] {
    return [...this.deadLetter];
  }

  clearDeadLetter(): void {
    this.deadLetter = [];
  }
}

// Singleton export
export const EventBus = new EventBusImpl();

// ─── Extended events — added by migration 002 ─────────────────────────────────

export interface SmartMoneyClusterEvent {
  clusterId: string;
  tokenMint: string;
  walletCount: number;
  confidenceScore: number;
  totalCapitalSol: number;
  ts: number;
}

export interface LiquidityInflowEvent {
  tokenMint: string;
  signal: 'bullish' | 'bearish' | 'neutral';
  signalStrength: number;
  velocityUsdPerMin: number;
  netSolInflow: number;
  ts: number;
}

export interface MultiWalletConfirmedEvent {
  confirmationId: string;
  tokenMint: string;
  walletCount: number;
  confirmationScore: number;
  strategy: string;
  ts: number;
}

export interface VolumeAccelerationEvent {
  tokenMint: string;
  accelerationScore: number;
  rank: number;
  velocity: number;
  buySellRatio: number;
  ts: number;
}

export interface HolderGrowthEvent {
  tokenMint: string;
  growthScore: number;
  holderCount: number;
  newHolders1h: number;
  healthy: boolean;
  ts: number;
}

export interface MigrationDetectedEvent {
  tokenMint: string;
  migrationId: string;
  status: 'bonding' | 'migrating' | 'migrated';
  bondingCurvePct: number;
  initialLiquiditySol: number;
  priorityScore: number;
  ts: number;
}

export interface MEVDetectedEvent {
  eventType: 'sandwich' | 'frontrun' | 'failed_fill';
  tokenMint?: string;
  txHash: string;
  estimatedCostSol: number;
  ts: number;
}

export interface KillSwitchEvent {
  active: boolean;
  reason: string;
  triggerValue?: number;
  threshold?: number;
  ts: number;
}

export interface ExposureLimitEvent {
  limitType: string;
  currentValue: number;
  limitValue: number;
  tokenMint?: string;
  ts: number;
}

// Extend BotEvents map
declare module './EventBus' {
  interface BotEvents {
    SMART_MONEY_CLUSTER: [SmartMoneyClusterEvent];
    LIQUIDITY_INFLOW: [LiquidityInflowEvent];
    MULTI_WALLET_CONFIRMED: [MultiWalletConfirmedEvent];
    VOLUME_ACCELERATION: [VolumeAccelerationEvent];
    HOLDER_GROWTH: [HolderGrowthEvent];
    MIGRATION_DETECTED: [MigrationDetectedEvent];
    MEV_DETECTED: [MEVDetectedEvent];
    KILL_SWITCH: [KillSwitchEvent];
    EXPOSURE_LIMIT: [ExposureLimitEvent];
  }
}
