import { Connection, Commitment } from '@solana/web3.js';
import { AppConfig } from '../config/AppConfig';
import { createModuleLogger } from './Logger';

const logger = createModuleLogger('RpcManager');

interface RpcEndpoint {
  label: string;
  httpUrl: string;
  wsUrl?: string;
  connection: Connection;
  healthy: boolean;
  consecutiveFailures: number;
  latencyMs: number;
  lastCheck: number;
}

export interface RpcEndpointStats {
  label: string;
  healthy: boolean;
  latencyMs: number;
  consecutiveFailures: number;
  active: boolean;
}

/**
 * RpcManager provides multi-provider RPC failover for the trading hot path.
 *
 * - Builds a Connection per configured endpoint (Helius primary + optional
 *   QuickNode / Triton / arbitrary fallbacks).
 * - Periodic health checks measure per-endpoint latency via getSlot().
 * - The lowest-latency healthy endpoint is promoted as the active connection.
 * - withFailover() retries an operation across endpoints on error.
 *
 * Consumers should call getConnection() per-operation (not cache it) so that
 * runtime failover/promotion takes effect.
 */
export class RpcManager {
  private endpoints: RpcEndpoint[];
  private currentIndex = 0;
  private commitment: Commitment;
  private readonly checkIntervalMs: number;
  private readonly maxFailures: number;
  private healthTimer: NodeJS.Timeout | null = null;

  constructor(cfg: AppConfig) {
    this.commitment = cfg.rpc.commitment;
    this.checkIntervalMs = cfg.rpc.healthCheckIntervalMs;
    this.maxFailures = cfg.rpc.maxRpcFailures;

    const specs: Array<{ label: string; httpUrl: string; wsUrl?: string }> = [
      { label: 'helius', httpUrl: cfg.rpc.rpcHttpUrl, wsUrl: cfg.rpc.heliusWsUrl },
    ];
    if (cfg.rpc.quickNodeRpcUrl) {
      specs.push({ label: 'quicknode', httpUrl: cfg.rpc.quickNodeRpcUrl, wsUrl: cfg.rpc.quickNodeWsUrl });
    }
    if (cfg.rpc.tritonRpcUrl) {
      specs.push({ label: 'triton', httpUrl: cfg.rpc.tritonRpcUrl, wsUrl: cfg.rpc.tritonWsUrl });
    }
    cfg.rpc.fallbackRpcUrls.forEach((url, i) => {
      specs.push({ label: `fallback-${i + 1}`, httpUrl: url });
    });

    this.endpoints = specs.map((s) => ({
      label: s.label,
      httpUrl: s.httpUrl,
      wsUrl: s.wsUrl,
      connection: new Connection(
        s.httpUrl,
        s.wsUrl
          ? { commitment: this.commitment, wsEndpoint: s.wsUrl }
          : { commitment: this.commitment },
      ),
      healthy: true,
      consecutiveFailures: 0,
      latencyMs: 0,
      lastCheck: 0,
    }));

    logger.info('RpcManager initialised', {
      endpoints: this.endpoints.map((e) => e.label),
      count: this.endpoints.length,
    });
  }

  /** Return the currently-active connection (lowest-latency healthy endpoint). */
  getConnection(): Connection {
    const ep = this.endpoints[this.currentIndex] ?? this.endpoints[0];
    if (!ep) throw new Error('RpcManager: no RPC endpoints configured');
    return ep.connection;
  }

  getActiveLabel(): string {
    const ep = this.endpoints[this.currentIndex] ?? this.endpoints[0];
    return ep ? ep.label : 'none';
  }

  /**
   * Execute an async RPC operation with automatic failover. Starts from the
   * active endpoint and rotates through the rest on error.
   */
  async withFailover<T>(fn: (c: Connection) => Promise<T>, opName = 'rpc'): Promise<T> {
    const n = this.endpoints.length;
    if (n === 0) throw new Error('RpcManager: no RPC endpoints configured');
    let lastErr: unknown;
    for (let attempt = 0; attempt < n; attempt++) {
      const idx = (this.currentIndex + attempt) % n;
      const ep = this.endpoints[idx];
      if (!ep) continue;
      const start = Date.now();
      try {
        const result = await fn(ep.connection);
        ep.latencyMs = Date.now() - start;
        ep.consecutiveFailures = 0;
        ep.healthy = true;
        if (idx !== this.currentIndex) {
          logger.warn('RPC failover succeeded on alternate endpoint', { op: opName, label: ep.label });
          this.currentIndex = idx;
        }
        return result;
      } catch (err) {
        lastErr = err;
        ep.consecutiveFailures++;
        if (ep.consecutiveFailures >= this.maxFailures) ep.healthy = false;
        logger.warn('RPC operation failed, trying next endpoint', {
          op: opName,
          label: ep.label,
          error: err instanceof Error ? err.message : String(err),
        });
      }
    }
    throw lastErr instanceof Error ? lastErr : new Error(`All RPC endpoints failed for ${opName}`);
  }

  /** Begin periodic health/latency probing. Idempotent. */
  startHealthChecks(): void {
    if (this.healthTimer) return;
    // Run one immediately so the fastest endpoint is chosen before trading.
    void this._checkHealth();
    this.healthTimer = setInterval(() => {
      void this._checkHealth();
    }, this.checkIntervalMs);
    if (typeof this.healthTimer.unref === 'function') this.healthTimer.unref();
    logger.info('RPC health checks started', { intervalMs: this.checkIntervalMs });
  }

  stopHealthChecks(): void {
    if (this.healthTimer) {
      clearInterval(this.healthTimer);
      this.healthTimer = null;
    }
  }

  private async _checkHealth(): Promise<void> {
    await Promise.all(
      this.endpoints.map(async (ep) => {
        const start = Date.now();
        try {
          await ep.connection.getSlot(this.commitment);
          ep.latencyMs = Date.now() - start;
          ep.consecutiveFailures = 0;
          ep.healthy = true;
        } catch {
          ep.consecutiveFailures++;
          if (ep.consecutiveFailures >= this.maxFailures) ep.healthy = false;
          ep.latencyMs = Number.MAX_SAFE_INTEGER;
        }
        ep.lastCheck = Date.now();
      }),
    );

    // Promote the lowest-latency healthy endpoint.
    let best = -1;
    let bestLatency = Number.POSITIVE_INFINITY;
    this.endpoints.forEach((ep, i) => {
      if (ep.healthy && ep.latencyMs < bestLatency) {
        bestLatency = ep.latencyMs;
        best = i;
      }
    });
    if (best >= 0 && best !== this.currentIndex) {
      const target = this.endpoints[best];
      const from = this.endpoints[this.currentIndex];
      if (target) {
        logger.info('RPC active endpoint switched', {
          from: from ? from.label : 'none',
          to: target.label,
          latencyMs: bestLatency,
        });
        this.currentIndex = best;
      }
    }
  }

  getStats(): RpcEndpointStats[] {
    return this.endpoints.map((e, i) => ({
      label: e.label,
      healthy: e.healthy,
      latencyMs: e.latencyMs,
      consecutiveFailures: e.consecutiveFailures,
      active: i === this.currentIndex,
    }));
  }

  /** Fraction of configured endpoints currently unhealthy (0..1). */
  getErrorRate(): number {
    if (this.endpoints.length === 0) return 0;
    const unhealthy = this.endpoints.filter((e) => !e.healthy).length;
    return unhealthy / this.endpoints.length;
  }
}

let _instance: RpcManager | null = null;

export function getRpcManager(cfg: AppConfig): RpcManager {
  if (!_instance) _instance = new RpcManager(cfg);
  return _instance;
}

export function resetRpcManager(): void {
  if (_instance) _instance.stopHealthChecks();
  _instance = null;
}

export default RpcManager;
