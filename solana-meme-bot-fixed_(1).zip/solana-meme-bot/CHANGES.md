# Bug Fixes & Changes

This document summarizes the fixes applied to the Solana meme-coin momentum + copy-trading bot.

## Critical bugs fixed

1. **Extended config was silently ignored** (`src/index.ts`, `src/config/AppConfig.ts`)
   - `ExtendedConfigSchema.safeParse(cfg)` parsed the already-narrowed `AppConfig`, which strips unknown keys, so every extended-module section fell back to schema defaults.
   - Added `loadRawConfig()` and now parse the raw merged YAML+env config.

2. **Tokens were never persisted on creation** (`src/index.ts`)
   - SafetyEngine / HybridEntryGate use `UPDATE ... WHERE mint=?` and `findByMint()`. With no existing row their writes silently no-op and entries never qualified.
   - Added a `TOKEN_CREATED` handler that upserts the token row FIRST (handlers run in registration order).

3. **EventBus.off() never removed listeners** (`src/core/EventBus.ts`)
   - `on()` registered a wrapped async closure but `off()` passed the original handler, which never matched. Listeners leaked forever.
   - Now tracks each handler→wrapped mapping so `off()` removes the correct listener.

4. **Hardcoded SOL price ($150)** (`src/core/SolPrice.ts` [new], `ExecutionEngine`, `LiquidityChecker`, `RaydiumMonitor`)
   - Introduced a shared `SolPrice` helper kept fresh by the PriceOracle (WSOL). All `* 150` sites now use `getSolPriceUsd()`.

5. **PriceOracle used a dead endpoint & wrong response shape** (`src/ingestion/PriceOracle.ts`)
   - Migrated to Jupiter Price API V3 (`https://lite-api.jup.ag/price/v3`), which returns a flat map keyed by mint with `usdPrice`.
   - Oracle now also feeds the shared SOL price from WSOL.

6. **PriceOracle was never wired to positions** (`src/index.ts`)
   - Prices were never polled, so stop-loss / take-profit (driven by `PRICE_UPDATE`) never fired.
   - Now `trackToken` on buy, `untrackToken` on sell, and re-track restored open positions on startup.

7. **Jupiter swap endpoint updated** (`src/config/schema.ts`, `src/config/default.yaml`)
   - Default `jupiterApiUrl` moved to `https://lite-api.jup.ag/swap/v1` (keyless quote + swap).

8. **Priority fee was static** (`src/execution/JupiterClient.ts`, `ExecutionEngine`)
   - Buy/sell now accept a dynamic `priorityFeeMicroLamports` from `PriorityFeeManager.getRecommendedFee()`.

9. **Raydium liquidity response parsed incorrectly** (`src/engines/safety/LiquidityChecker.ts`)
   - The pairs endpoint returns a FLAT array, not `{ data: [...] }`. Now handles both shapes.

10. **Sell sold an estimated token amount** (`src/execution/ExecutionEngine.ts`, `src/core/types.ts`, DB)
    - Positions now record `sizeTokens` (added to `Position`, `schema.sql`, `PositionRepository`). Sells use the real recorded quantity, falling back to the price estimate only for legacy rows.

11. **Hardcoded entry risk parameters** (`src/execution/ExecutionEngine.ts`)
    - Stop-loss / take-profit / trailing-stop now come from `cfg.risk` instead of hardcoded `0.15 / 0.40 / 0.10`.

12. **RaydiumMonitor flooded TOKEN_CREATED on first poll** (`src/ingestion/RaydiumMonitor.ts`)
    - On startup every existing pool looked "new". Added a `firstPoll` guard that seeds the seen-set silently.

13. **RiskManager ignored exposure limits & dynamic sizing** (`src/risk/RiskManager.ts`, `ExposureManager`, `src/index.ts`)
    - Added `wireRisk({ exposureManager, dynamicSizer })`. `evaluate()` now applies multi-factor dynamic sizing and portfolio exposure checks/caps. Added `ExposureManager.getBalanceSol()`.

14. **Closed-position bookkeeping missing** (`src/index.ts`, `src/core/EventBus.ts`)
    - `TradeFilledEvent` now carries `realisedPnlSol`. On each sell fill we update the exposure loss-streak, circuit breaker (with live balance), and kill switch. Also start a token cooldown on `CLOSE_SIGNAL`.

15. **Logger did not redact secrets on the console transport** (`src/core/Logger.ts`)
    - The redact format was applied only to file transports; added it to the console format too.

16. **tsconfig** (`tsconfig.json`)
    - Removed `scripts/**/*` from `include` (was causing rootDir errors) and set `"ignoreDeprecations": "6.0"` for the `moduleResolution` deprecation warning.

## Deferred (documented, not changed)

- **MEV / Jito tip submission** is present (`MEVProtection`) but NOT wired into the swap submission path. Wiring it requires refactoring `JupiterClient` to expose the unsigned transaction so it can be bundled with a tip. Left as-is to avoid destabilizing execution.
- **Raydium host** kept on the legacy `api.mainnet.raydium.io/v2/main/pairs` endpoint rather than migrating to api-v3, to avoid blind breakage without live testing.
- **PnL fee subtraction** and **HolderAnalyzer owner-aggregation** refinements were left for a follow-up pass.
- Items requiring live API keys / on-chain testing (RPC, Helius, wallet keypair) cannot be validated in this environment.

## Build / verification note

The sandbox's `node_modules` was cleared between sessions, so a full `tsc` typecheck could not be completed here without reinstalling dependencies (`npm install`). All fixes are source-level and self-contained. After `npm install`, build with `npm run build` (`tsc --project tsconfig.json`).

---

# Pass 2 — critical fix + deployment infrastructure

17. **Critical: wrong SPL Token program ID** (`src/ingestion/WalletMonitor.ts`)
    - `getTokenAccountsByOwner` used `TokenkegQfeZyiNwAJsyFbPVwwQQUWVLMgiyckPJsLJC` (invalid). Smart-money wallet token-account scans would never match.
    - Corrected to the canonical `TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA`.

18. **Deployment infrastructure added**
    - `Dockerfile` — multi-stage build (compiles native `better-sqlite3`), non-root runtime, `dumb-init` for clean signal handling, runtime YAML/SQL assets copied in.
    - `.dockerignore`, `docker-compose.yml` (persistent `data`/`logs` volumes, healthcheck, 30s graceful stop, log rotation, 1G memory cap).
    - `ecosystem.config.js` — PM2 single-instance fork mode (intentionally NOT clustered; the bot is stateful and would double-trade).
    - `.env.example` — documented secrets (wallet key, Helius/QuickNode/Triton RPCs, Jito, Telegram/Discord).
    - `DEPLOYMENT.md` — architecture + trade-lifecycle Mermaid diagrams, local/Docker/PM2 run steps, AWS EC2 and ECS Fargate guides (secrets via SSM/Secrets Manager, EFS for the DB), and an operational runbook.

## Still outstanding (next passes — require your RPC/API keys + live testing to verify)

- Full Jito **bundle submission** wired into the live swap path + **pre-flight `simulateTransaction`** on every trade.
- **Multi-RPC failover** manager (QuickNode/Triton) with latency monitoring + health checks.
- **Telegram/Discord** alert delivery and the **Sharpe/drawdown** analytics dashboard endpoints.
- **LP-lock verification** and **HolderAnalyzer** owner-aggregation.
- **Unit/integration test** suite and CI.

These are real, sizeable implementations. They must be built against your live credentials and validated on devnet + small-size mainnet before trading real funds.


---

## Pass 3 — MEV protection + pre-flight transaction simulation (fund safety)

Goal: stop spending fees/tips on transactions that will revert, and route live
swaps through the existing MEV defense layer (which was previously never called).

### What changed
1. **`src/config/schema.ts`** — added `execution.simulateBeforeSend` (boolean,
   default `true`). Controls the new pre-flight simulation gate.
2. **`src/execution/JupiterClient.ts`**
   - New optional `mevProtection` dependency + `setMevProtection()` injector.
   - `_executeSwap()` now, after building & signing the Jupiter swap tx:
     a. **Simulates the transaction** via `connection.simulateTransaction()`
        (`replaceRecentBlockhash`, `sigVerify:false`). If `value.err` is set, it
        **aborts before broadcasting** and returns a failed `SwapResult` with the
        simulation error + last log lines. No SOL/tips are spent on a doomed tx.
     b. **Routes submission through `MEVProtection.submit()`** when wired —
        front-run delay, RPC submit, sandwich-pattern detection, and Jito-bundle
        fallback. Falls back to direct `sendRawTransaction` when MEV is not wired
        (with `skipPreflight` set since we already simulated).
   - Derives the traded mint from the quote for MEV bookkeeping/logging.
3. **`src/execution/ExecutionEngine.ts`** — constructor now accepts the
   `ExtendedConfig` and constructs `MEVProtection(cfg, extCfg, keypair)` (reusing
   the singleton keypair), injecting it into `JupiterClient`.
4. **`src/index.ts`** — passes `extCfg` into `new ExecutionEngine(cfg, extCfg)`.

### Behavior / config notes
- Pre-flight simulation is **on by default** (`execution.simulateBeforeSend`).
- MEV protection activates automatically now that it is wired; Jito itself stays
  **off by default** (`mevProtection.jitoEnabled=false`) — enable in config.
- `mevProtection.frontRunProtectionMs` defaults to 2000ms (a 2s delay before each
  submit). For latency-sensitive momentum entries, lower or zero this.

### Known limitation (be aware before live trading)
- In the current `MEVProtection` design, **Jito is a fallback** (tried only when
  the normal RPC submit throws). True mempool-bypass would submit via Jito
  *first*. Also, a Jito bundle returns a `bundleId`, not a tx signature, so
  `TxConfirmation` (which watches a signature) cannot confirm bundle-only
  submissions — those need bundle-status polling. Making Jito the primary path
  with proper bundle confirmation is a further step that must be validated on
  devnet/mainnet with your own keys.

### Still NOT verified by a compiler
- `node_modules` is wiped in this sandbox and the registry is unreachable, so a
  full `tsc` build could not be run here. Run `npm install && npx tsc --noEmit`
  locally to confirm before deploying.


## Pass 4 — Multi-RPC failover, LP-lock rug check, Telegram/Discord alerts & risk analytics

### Multi-RPC failover
- Added `src/core/RpcManager.ts`: health-checked, latency-ranked connection pool over Helius (primary), optional QuickNode/Triton, and arbitrary `FALLBACK_RPC_URLS`. Exposes `getConnection()`, `withFailover()`, `getStats()`, `getErrorRate()`, and periodic `startHealthChecks()`.
- Routed the trading hot path (JupiterClient, MEVProtection, PriorityFeeManager, FailedTradeRecovery, TxConfirmation) through `RpcManager` via a delegating `connection` getter so failover is transparent to existing call sites.
- `schema.ts`: new optional rpc fields (`quickNodeRpcUrl/WsUrl`, `tritonRpcUrl/WsUrl`, `fallbackRpcUrls`, `healthCheckIntervalMs`, `maxRpcFailures`).
- `AppConfig.ts`: injects `HELIUS_WS_URL`, `QUICKNODE_RPC_URL`, `QUICKNODE_WS_URL`, `TRITON_RPC_URL`, `TRITON_WS_URL`, and comma-separated `FALLBACK_RPC_URLS` from env (only when non-empty).
- `index.ts`: starts RPC health checks at bootstrap (after risk wiring).
- `.env.example`: aligned + documented the new RPC env vars.
- NOTE: read/analytics-only paths (position sizing, exposure, mint/freeze auth, replicator) still use a primary-only connection and can be migrated identically later.

### LP-lock / burn rug detection
- Added `src/engines/safety/LpLockChecker.ts`: resolves the Raydium SOL-pool lpMint, reads total LP supply + largest holders, and computes the % of LP held by burn/null owners (incinerator / system program). Zero supply = fully burned.
- `SafetyEngine` now runs this as a 6th check: adds `lpLockRugScoreWeight` to the rug score when LP is not locked, and hard-blocks entry when `safety.requireLpLock` is enabled.
- `schema.ts`: new safety fields `requireLpLock` (default false), `minLpLockedPct` (default 80), `lpLockRugScoreWeight` (default 15).
- `types.ts`: `SafetyReport` gains optional `lpLocked` / `lpLockedPct`.

### Telegram / Discord alerts + PnL / Sharpe / drawdown analytics
- Added `src/analytics/AlertManager.ts`: best-effort Telegram (Bot API) + Discord (webhook) delivery with error throttling; `sendAlert`, `sendError`, `sendTradeAlert`, `sendReport`.
- `StrategyMetrics.getRiskAnalytics()`: portfolio Sharpe, Sortino, volatility, downside deviation, and max drawdown (SOL + %) computed over the realised-PnL equity curve; surfaced in `AnalyticsSnapshot.riskAnalytics`.
- `index.ts`: emits trade alerts on every fill, forwards KILL_SWITCH / EXPOSURE_LIMIT / MEV_DETECTED events to the alert channels, sends a startup ping, and schedules a daily PnL+risk report.
- `schema.ts` monitoring block: `telegramEnabled/BotToken/ChatId`, `discordEnabled/WebhookUrl`, `alertOnTrade`, `alertOnError`, `dailyReportEnabled`, `dailyReportHourUtc`. Secrets injected from env (`TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`, `DISCORD_WEBHOOK_URL`).

### Tests
- `tests/unit/analytics/AlertManager.test.ts`: enable/disable, dual-channel delivery, error throttling, trade-alert gating.
- `tests/unit/analytics/StrategyMetrics.test.ts`: max-drawdown / equity-peak / risk-ratio math.

### Still requires your validation before real funds
- `node_modules` is empty in this build environment, so `tsc` and `jest` could not be executed here. Run `npm install`, then `npm run build` and `npm test` locally, and validate on devnet + small mainnet sizes with your own API keys before trading real funds.


---

## Pass 4 — Multi-RPC, LP-lock, Alerts/Analytics, and a real export bug fix

### Critical bug fixed (found via full `tsc` run)
- **`AppConfig` type was never re-exported.** `src/config/schema.ts` defines `export type AppConfig = z.infer<typeof ConfigSchema>`, and `src/config/AppConfig.ts` imported it locally but did **not** re-export it. Yet **51 files** import `AppConfig` from `../config/AppConfig`. Every one failed to type-check (`TS2459: declares 'AppConfig' locally, but it is not exported`). This was invisible until a full type-check could run.
  - Fix: added `export type { AppConfig } from './schema';` to `src/config/AppConfig.ts`.

### Multi-RPC failover
- New `src/core/RpcManager.ts`: health-checked, failover-aware connection manager (`getConnection`, `withFailover`, `startHealthChecks`, `getStats`, `getErrorRate`; singleton `getRpcManager(cfg)` / `resetRpcManager()`).
- `schema.ts` gained an `rpc` block (helius/quicknode/triton HTTP+WS URLs, `fallbackRpcUrls`, `healthCheckIntervalMs`, `maxRpcFailures`).
- `AppConfig.ts` wires the new RPC env vars (`HELIUS_WS_URL`, `QUICKNODE_RPC_URL`, `QUICKNODE_WS_URL`, `TRITON_RPC_URL`, `TRITON_WS_URL`, `FALLBACK_RPC_URLS`).
- Trading hot-path execution classes use a delegating `get connection()` so swaps/sends transparently fail over. Health checks start at bootstrap in `index.ts`.

### Rug / LP-lock verification
- New `src/engines/safety/LpLockChecker.ts`: checks LP burn/lock percentage (incinerator + system burn owners) against `minLpLockedPct`.
- `SafetyEngine` now runs this as a 6th safety check; pass requires `(!requireLpLock || lpLocked === true)`.
- `types.ts` `SafetyReport` gained `lpLocked?` / `lpLockedPct?`. `schema.ts` `safety` block gained `requireLpLock`, `minLpLockedPct`, `lpLockRugScoreWeight`.

### Telegram / Discord alerts + risk analytics
- New `src/analytics/AlertManager.ts`: Telegram + Discord delivery (best-effort, never throws), error throttling (30s), trade alerts, and report sending.
- `StrategyMetrics.getRiskAnalytics()` computes Sharpe, Sortino, volatility, downside deviation, and max drawdown (SOL + %) over closed positions. Surfaced via `AnalyticsEngine` snapshot.
- `index.ts` sends a startup alert, per-trade alerts (`TRADE_FILLED`), risk alerts (kill switch / exposure / MEV), and an optional daily PnL report.
- `schema.ts` `monitoring` block gained `telegramEnabled/telegramBotToken/telegramChatId/discordEnabled/discordWebhookUrl/alertOnTrade/alertOnError/dailyReportEnabled/dailyReportHourUtc`; `.env.example` updated.

### Tests added
- `tests/unit/analytics/AlertManager.test.ts`
- `tests/unit/analytics/StrategyMetrics.test.ts`

### Build verification status (honest)
- The sandbox could not reliably populate `node_modules` (npm install repeatedly timed out), so a clean end-to-end `tsc` build could not be completed here. The full type-check that *did* run surfaced the `AppConfig` export bug (now fixed) plus the expected "cannot find module" errors that are purely missing-dependency noise. You must run `npm install && npm run build` in your own environment to confirm a clean compile before trading.


---

## Pass 5 — Static-analysis bug fixes (compile-blockers + correctness)

### Compile-blocking fixes (strict `tsconfig`: `noUncheckedIndexedAccess`)
- **`momentum/PriceAccel.ts`** — indexed price-history access (`hist[i].price` / `.ts`) now goes through guarded locals (`const last = hist[...]; if (!last) return 0;`) so it compiles under `noUncheckedIndexedAccess`.
- **`momentum/LiquidityTracker.ts`** — same fix for `liquidityHistory` indexing; baseline/last points are guarded before use.
- **`engines/holders/HolderGrowthEngine.ts`** — typed the `topAccounts.reduce(...)` callback (`s: number, a: { amount: string | number }`) and made it `parseFloat(String(a.amount))` to avoid implicit-any and string/number coercion issues.

### Correctness / removed the last placeholder
- **`engines/copytrading/SignalFilter.ts`** — `_getRugScore()` previously always `return null` (a placeholder), silently disabling the copy-trade rug-score gate. It now reads the persisted rug score via the new `TokenRepository.getSafety(mint)` and returns it (null only when the token hasn't been safety-checked yet).

### LP-lock results now persisted (closes the gap from Pass 4)
- **`db/schema.sql`** — added `lp_locked INTEGER` and `lp_locked_pct REAL` to the `tokens` table.
- **`db/Database.ts`** — added idempotent, guarded `ALTER TABLE tokens ADD COLUMN ...` so existing databases upgrade without crashing.
- **`db/repositories/TokenRepository.ts`** — `updateSafety()` now writes `lpLocked` / `lpLockedPct`; added `getSafety(mint)` to read back all persisted safety fields (rug score, auth flags, holder concentration, LP lock).
- **`engines/safety/SafetyEngine.ts`** — passes `lpLocked` / `lpLockedPct` into `updateSafety()`.

### Verified-not-a-bug (left intact)
- `core/types.ts` already includes `'unknown'` in `TokenInfo.source`, so the earlier `MomentumEngine` source assignment is fine.
- Holder concentration units are consistent: Helius `getTokenAccounts` `amount` and `getTokenSupply` `value.amount` are both raw base units.
- `core/Logger.ts` / `core/RpcManager.ts` implicit-any warnings were cascades from missing dependency type defs (winston / @solana types); they resolve once `npm install` runs.

### Still recommended (not done — needs a verified build loop; see audit list)
- Route the ~6 read/analytics `new Connection(...)` sites through `getRpcManager()` for full failover.
- Align the daily report to `dailyReportHourUtc` instead of a fixed 24h interval.
- Add stale-price protection to the SOL price oracle so a failed fetch blocks trading instead of passing 0.
- Confirm Jito bundle landing via `getBundleStatuses`; adopt Jupiter `dynamicSlippage` + `priceImpactPct` cap; migrate Raydium reads to `api-v3`.

> Build status unchanged: this sandbox has no network to npmjs.org, so a clean `tsc` could not be run here. All Pass 5 edits were made against the verified current source; run `npm install && npm run build` locally to confirm.
