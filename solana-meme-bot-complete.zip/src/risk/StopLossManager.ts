import { EventBus, TradeFilledEvent, PriceUpdateEvent, CloseSignalEvent } from '../core/EventBus';
import { AppConfig } from '../config/AppConfig';
import { createModuleLogger } from '../core/Logger';
import { Position } from '../core/types';
import PositionRepository from '../db/repositories/PositionRepository';

const logger = createModuleLogger('StopLossManager');

/**
 * StopLossManager tracks all open positions and fires CLOSE_SIGNAL when:
 * - Price falls below stopLossPct of entry  (stop loss)
 * - Price rises above takeProfitPct of entry (take profit)
 * - Price falls more than trailingStopPct from the peak (trailing stop)
 *
 * Trailing stop arms only after price exceeds trailingStopActivationPct gain.
 * Re-arms all positions on bot restart from DB.
 */
export class StopLossManager {
  private positions = new Map<string, Position>(); // positionId → Position
  private trailingStopActivationPct: number;
  private stopLossPct: number;
  private takeProfitPct: number;
  private trailingStopPct: number;
  private recoveryEnabled: boolean;

  // ── Stale-position safeguard state ────────────────────────────────────────
  // Last time we received a usable PRICE_UPDATE for a position. A rugged or
  // unpriceable token stops producing prices, so SL/TP/trailing never evaluate
  // and the slot would otherwise be held forever.
  private lastPriceTs = new Map<string, number>();
  // When we FIRST requested a stale exit, and the last time we re-emitted it.
  private firstExitRequestTs = new Map<string, number>();
  private lastExitRequestTs = new Map<string, number>();
  private staleTimer: NodeJS.Timeout | null = null;
  private readonly maxHoldTimeMins: number;
  private readonly stalePriceForceExitMins: number;
  private readonly forceAbandonAfterMins: number;
  private readonly staleSweepIntervalMs: number;

  constructor(cfg: AppConfig) {
    this.stopLossPct = cfg.risk.stopLossPct;
    this.takeProfitPct = cfg.risk.takeProfitPct;
    this.trailingStopPct = cfg.risk.trailingStopPct;
    this.trailingStopActivationPct = cfg.risk.trailingStopActivationPct;
    this.recoveryEnabled = cfg.recovery?.enabled ?? false;
    this.maxHoldTimeMins = cfg.risk.maxHoldTimeMins;
    this.stalePriceForceExitMins = cfg.risk.stalePriceForceExitMins;
    this.forceAbandonAfterMins = cfg.risk.forceAbandonAfterMins;
    this.staleSweepIntervalMs = cfg.risk.staleSweepIntervalMs;

    logger.info('StopLossManager initialized', {
      stopLossPct: this.stopLossPct,
      takeProfitPct: this.takeProfitPct,
      trailingStopPct: this.trailingStopPct,
      maxHoldTimeMins: this.maxHoldTimeMins,
      stalePriceForceExitMins: this.stalePriceForceExitMins,
      forceAbandonAfterMins: this.forceAbandonAfterMins,
    });
  }

  /**
   * Arm stop loss for a newly filled trade
   */
  arm(event: TradeFilledEvent): void {
    if (event.side !== 'buy') return;

    // Load full position from DB
    const position = PositionRepository.findByToken(event.mint);
    if (!position) {
      logger.warn('Position not found after trade fill', { mint: event.mint });
      return;
    }

    this.positions.set(position.id, position);
    // Seed the price-freshness clock so the stale sweep measures from entry.
    this.lastPriceTs.set(position.id, Date.now());
    logger.info('Stop loss armed', {
      positionId: position.id,
      mint: event.mint,
      entryPrice: position.entryPriceUsd,
      stopAt: position.entryPriceUsd * (1 - this.stopLossPct),
      tpAt: position.entryPriceUsd * (1 + this.takeProfitPct),
    });
  }

  /**
   * Check all positions against current price
   */
  checkPosition(event: PriceUpdateEvent): void {
    for (const [positionId, position] of this.positions) {
      if (position.tokenMint !== event.mint) continue;
      this._checkOne(positionId, position, event.priceUsd);
    }
  }

  private _checkOne(positionId: string, position: Position, currentPrice: number): void {
    const entry = position.entryPriceUsd;
    if (entry <= 0 || currentPrice <= 0) return;

    // A usable price arrived — refresh the freshness clock for the stale sweep.
    this.lastPriceTs.set(positionId, Date.now());

    const gainPct = (currentPrice - entry) / entry;

    // 1. Stop loss
    if (gainPct <= -this.stopLossPct) {
      logger.info('Stop loss triggered', {
        positionId,
        mint: position.tokenMint,
        entry,
        current: currentPrice,
        lossPct: (gainPct * 100).toFixed(2),
      });
      this._closePosition(positionId, position, currentPrice, 'stop');
      return;
    }

    // 2. Take profit (skipped while Capital Recovery owns the exit path)
    if (!this.recoveryEnabled && gainPct >= this.takeProfitPct) {
      logger.info('Take profit triggered', {
        positionId,
        mint: position.tokenMint,
        entry,
        current: currentPrice,
        gainPct: (gainPct * 100).toFixed(2),
      });
      this._closePosition(positionId, position, currentPrice, 'tp');
      return;
    }

    // 3. Trailing stop — only active after activation threshold (skipped while Capital Recovery owns the exit path)
    if (!this.recoveryEnabled && gainPct >= this.trailingStopActivationPct) {
      // Update trailing high
      if (currentPrice > position.trailingStopHighUsd) {
        const updated: Position = { ...position, trailingStopHighUsd: currentPrice };
        this.positions.set(positionId, updated);
        PositionRepository.updatePrice(
          positionId,
          currentPrice,
          this._calcUnrealisedPnl(position, currentPrice),
          currentPrice,
        );
        return;
      }

      // Check if fallen from high by trailingStopPct
      const high = position.trailingStopHighUsd;
      if (high > 0) {
        const pullbackFromHigh = (high - currentPrice) / high;
        if (pullbackFromHigh >= this.trailingStopPct) {
          logger.info('Trailing stop triggered', {
            positionId,
            mint: position.tokenMint,
            high,
            current: currentPrice,
            pullbackPct: (pullbackFromHigh * 100).toFixed(2),
          });
          this._closePosition(positionId, position, currentPrice, 'trailing');
          return;
        }
      }
    }

    // Update unrealised PnL
    const unrealisedPnl = this._calcUnrealisedPnl(position, currentPrice);
    PositionRepository.updatePrice(positionId, currentPrice, unrealisedPnl);
    this.positions.set(positionId, { ...position, currentPriceUsd: currentPrice, unrealisedPnlSol: unrealisedPnl });
  }

  private _closePosition(
    positionId: string,
    position: Position,
    currentPrice: number,
    reason: CloseSignalEvent['reason'],
  ): void {
    this._forgetPosition(positionId);

    EventBus.emit('CLOSE_SIGNAL', {
      positionId,
      mint: position.tokenMint,
      reason,
      currentPriceUsd: currentPrice,
      ts: Date.now(),
    } as CloseSignalEvent);
  }

  private _calcUnrealisedPnl(position: Position, currentPrice: number): number {
    if (position.entryPriceUsd <= 0) return 0;
    const priceRatio = currentPrice / position.entryPriceUsd;
    return position.sizeSol * (priceRatio - 1);
  }

  /**
   * Restore open positions from DB on bot restart
   */
  async restoreFromDb(): Promise<void> {
    const openPositions = PositionRepository.findOpenPositions();
    const now = Date.now();
    for (const position of openPositions) {
      this.positions.set(position.id, position);
      // We don't know when the last price actually arrived across a restart;
      // start the stale clock now so a genuinely dead token still expires.
      this.lastPriceTs.set(position.id, now);
    }
    logger.info('Positions restored from DB', { count: openPositions.length });
  }

  // ── Stale-position safeguard ────────────────────────────────────────────────

  /**
   * Start the periodic sweep that force-exits positions which have either been
   * held too long (maxHoldTimeMins) or whose price feed has gone stale
   * (stalePriceForceExitMins) — and, as a last resort, abandons positions that
   * remain unsellable (forceAbandonAfterMins) by marking them closed in the DB
   * so they stop blocking new entries. Idempotent.
   */
  startStaleSweep(): void {
    if (this.staleTimer) return;
    if (this.maxHoldTimeMins <= 0 && this.stalePriceForceExitMins <= 0) {
      logger.info('Stale-position sweep disabled (no thresholds configured)');
      return;
    }
    this.staleTimer = setInterval(() => this._sweepStale(), this.staleSweepIntervalMs);
    if (typeof this.staleTimer.unref === 'function') this.staleTimer.unref();
    logger.info('Stale-position sweep started', {
      intervalMs: this.staleSweepIntervalMs,
      maxHoldTimeMins: this.maxHoldTimeMins,
      stalePriceForceExitMins: this.stalePriceForceExitMins,
      forceAbandonAfterMins: this.forceAbandonAfterMins,
    });
  }

  stopStaleSweep(): void {
    if (this.staleTimer) {
      clearInterval(this.staleTimer);
      this.staleTimer = null;
    }
  }

  private _sweepStale(): void {
    const now = Date.now();
    // Don't spam CLOSE_SIGNAL (and waste fees on repeated failing sells); only
    // re-emit an exit request every couple of minutes.
    const reemitMs = Math.max(this.staleSweepIntervalMs, 120_000);

    for (const [positionId, position] of this.positions) {
      // 1. Reconcile with the DB first. A successful sell closes the position
      //    elsewhere (ExecutionEngine -> PositionRepository.close); drop it.
      const dbPos = PositionRepository.findById(positionId);
      if (!dbPos || dbPos.status !== 'open') {
        this._forgetPosition(positionId);
        continue;
      }

      const holdMins = (now - position.openedAt) / 60_000;
      const lastPrice = this.lastPriceTs.get(positionId) ?? position.openedAt;
      const sinceLastPriceMins = (now - lastPrice) / 60_000;

      const expiredByHold = this.maxHoldTimeMins > 0 && holdMins >= this.maxHoldTimeMins;
      const expiredByStalePrice =
        this.stalePriceForceExitMins > 0 && sinceLastPriceMins >= this.stalePriceForceExitMins;
      if (!expiredByHold && !expiredByStalePrice) continue;

      const firstReq = this.firstExitRequestTs.get(positionId);

      // 2. Last resort: still open long after the first exit attempt -> abandon.
      if (
        this.forceAbandonAfterMins > 0 &&
        firstReq !== undefined &&
        (now - firstReq) / 60_000 >= this.forceAbandonAfterMins
      ) {
        this._forceAbandon(positionId, position, now);
        continue;
      }

      // 3. Request a normal exit via CLOSE_SIGNAL (rate-limited re-emits).
      const lastReq = this.lastExitRequestTs.get(positionId) ?? 0;
      if (now - lastReq < reemitMs) continue;
      if (firstReq === undefined) this.firstExitRequestTs.set(positionId, now);
      this.lastExitRequestTs.set(positionId, now);

      logger.warn('Stale position force-exit requested', {
        positionId,
        mint: position.tokenMint,
        reason: expiredByHold ? 'max-hold-time' : 'stale-price',
        holdMins: Number(holdMins.toFixed(1)),
        sinceLastPriceMins: Number(sinceLastPriceMins.toFixed(1)),
      });
      EventBus.emit('CLOSE_SIGNAL', {
        positionId,
        mint: position.tokenMint,
        reason: 'manual',
        currentPriceUsd: position.currentPriceUsd,
        ts: now,
      } as CloseSignalEvent);
    }
  }

  /**
   * Mark a stuck/unsellable position closed in the DB so it stops consuming an
   * open slot. The tokens may remain stranded in the wallet (they're likely
   * worthless), but the bot can resume trading. realisedPnl is best-effort
   * (last known unrealised PnL).
   */
  private _forceAbandon(positionId: string, position: Position, now: number): void {
    const holdTimeSecs = Math.max(0, Math.floor((now - position.openedAt) / 1000));
    logger.warn('Abandoning unsellable stale position (marking closed to free the slot)', {
      positionId,
      mint: position.tokenMint,
      holdTimeSecs,
    });
    try {
      PositionRepository.close(positionId, {
        id: positionId,
        tokenMint: position.tokenMint,
        strategy: position.strategy,
        sizeSol: position.sizeSol,
        entryPriceUsd: position.entryPriceUsd,
        exitPriceUsd: position.currentPriceUsd,
        realisedPnlSol: position.unrealisedPnlSol ?? 0,
        holdTimeSecs,
        exitReason: 'manual',
        openedAt: position.openedAt,
        closedAt: now,
      });
    } catch (err) {
      logger.error('Force-abandon DB close failed', {
        positionId,
        error: err instanceof Error ? err.message : String(err),
      });
    }
    this._forgetPosition(positionId);
  }

  /** Remove a position and all its safeguard bookkeeping. */
  private _forgetPosition(positionId: string): void {
    this.positions.delete(positionId);
    this.lastPriceTs.delete(positionId);
    this.firstExitRequestTs.delete(positionId);
    this.lastExitRequestTs.delete(positionId);
  }

  /**
   * Stop managing a position (by mint) here — used when the Capital Recovery
   * subsystem takes over a position as a moonbag with its own trailing stop.
   */
  releaseManaged(mint: string): void {
    for (const [positionId, position] of this.positions) {
      if (position.tokenMint === mint) {
        this._forgetPosition(positionId);
        logger.info('Released position to Capital Recovery subsystem', { positionId, mint });
      }
    }
  }

  getOpenPositionCount(): number {
    return this.positions.size;
  }

  getOpenPositions(): Position[] {
    return Array.from(this.positions.values());
  }
}

export default StopLossManager;
