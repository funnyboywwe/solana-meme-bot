-- Migration 004: Capital Recovery + Moonbag + Trailing Stop
-- Analytics table that records the full lifecycle of every managed position.
-- (The per-position state/fee columns are added idempotently to the existing
--  positions table by Database.ts via guarded ALTER TABLE statements.)
CREATE TABLE IF NOT EXISTS moonbag_lifecycle (
  position_id TEXT PRIMARY KEY,
  token_mint TEXT NOT NULL,
  entry_price_usd REAL,
  entry_sol_amount REAL,
  recovery_price_usd REAL,
  recovery_sell_tokens REAL,
  capital_recovered_sol REAL,
  moonbag_tokens REAL,
  highest_price_usd REAL,
  trailing_stop_usd REAL,
  final_exit_price_usd REAL,
  total_profit_sol REAL,
  exit_reason TEXT,
  state TEXT,
  created_at INTEGER,
  updated_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_moonbag_mint ON moonbag_lifecycle(token_mint);
CREATE INDEX IF NOT EXISTS idx_moonbag_state ON moonbag_lifecycle(state);
