import Database from 'better-sqlite3';
import * as fs from 'fs';
import * as path from 'path';
import { createModuleLogger } from '../core/Logger';

const logger = createModuleLogger('Database');

let _db: Database.Database | null = null;

export function getDb(): Database.Database {
  if (!_db) throw new Error('Database not initialised. Call initDatabase() first.');
  return _db;
}

export function initDatabase(dbPath: string, walCheckpointIntervalMs: number): Database.Database {
  if (_db) return _db;

  // Ensure directory exists
  const dir = path.dirname(dbPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  logger.info(`Opening SQLite database at ${dbPath}`);

  const db = new Database(dbPath, {
    verbose: process.env['NODE_ENV'] === 'debug'
      ? (msg) => logger.debug(String(msg))
      : undefined,
  });

  // Performance and safety pragmas
  db.pragma('journal_mode = WAL');
  db.pragma('synchronous = NORMAL');
  db.pragma('cache_size = -8000');    // ~8 MB page cache
  db.pragma('foreign_keys = ON');
  db.pragma('temp_store = MEMORY');
  db.pragma('mmap_size = 67108864'); // 64 MB memory-mapped I/O

  // Run all schema migrations in order
  const schemaFiles = [
    'schema.sql',
    path.join('migrations', '002_extensions.sql'),
    path.join('migrations', '003_cost_tracking.sql'),
    path.join('migrations', '004_capital_recovery.sql'),
  ];
  for (const schemaFile of schemaFiles) {
    const schemaPath = path.join(__dirname, schemaFile);
    if (!fs.existsSync(schemaPath)) {
      logger.warn(`Schema file not found, skipping: ${schemaPath}`);
      continue;
    }
    const schema = fs.readFileSync(schemaPath, 'utf-8');
    // Strip full-line comments BEFORE splitting on ';'. Otherwise a statement
    // that follows a "-- section" comment header lands in a chunk beginning
    // with "--" and was being silently dropped by the comment filter, so many
    // CREATE TABLE/INDEX statements (e.g. the trades table) never ran.
    const statements = schema
      .split('\n')
      .filter((line) => !line.trim().startsWith('--'))
      .join('\n')
      .split(';')
      .map((s) => s.trim())
      .filter((s) => s.length > 0);
    for (const stmt of statements) {
      try {
        db.exec(stmt + ';');
      } catch (err) {
        logger.error(`Schema statement failed in ${schemaFile}: ${stmt.slice(0, 80)}`, { error: err });
        throw err;
      }
    }
    logger.info(`Schema file applied: ${schemaFile}`);
  }
  // Idempotent column additions so existing databases upgrade cleanly.
  // SQLite throws if a column already exists, so each ALTER is guarded.
  const columnAdditions = [
    'ALTER TABLE tokens ADD COLUMN lp_locked INTEGER',
    'ALTER TABLE tokens ADD COLUMN lp_locked_pct REAL',
    'ALTER TABLE positions ADD COLUMN lifecycle_state TEXT DEFAULT \'open\'',
    'ALTER TABLE positions ADD COLUMN entry_sol_amount REAL',
    'ALTER TABLE positions ADD COLUMN buy_network_fee_sol REAL',
    'ALTER TABLE positions ADD COLUMN buy_priority_fee_sol REAL',
    'ALTER TABLE positions ADD COLUMN recovery_price_usd REAL',
    'ALTER TABLE positions ADD COLUMN capital_recovered_sol REAL',
    'ALTER TABLE positions ADD COLUMN moonbag_tokens REAL',
    'ALTER TABLE positions ADD COLUMN highest_price_usd REAL',
    'ALTER TABLE positions ADD COLUMN trailing_stop_usd REAL',
  ];
  for (const stmt of columnAdditions) {
    try {
      db.exec(stmt + ';');
    } catch {
      // Column already exists — safe to ignore.
    }
  }

  logger.info('All schema migrations applied successfully');
  _db = db;

  // Periodic WAL checkpoint (low-priority, runs outside busy windows)
  const checkpointInterval = setInterval(() => {
    try {
      if (_db) {
        const result = _db.pragma('wal_checkpoint(PASSIVE)') as Array<{ busy: number; log: number; checkpointed: number }>;
        if (result[0] && result[0].log > 1000) {
          logger.debug('WAL checkpoint', result[0]);
        }
      }
    } catch (err) {
      logger.warn('WAL checkpoint error', { error: err });
    }
  }, walCheckpointIntervalMs);

  // Don't prevent process exit
  checkpointInterval.unref();

  return db;
}

export function closeDatabase(): void {
  if (_db) {
    try {
      _db.pragma('wal_checkpoint(TRUNCATE)');
      _db.close();
      logger.info('Database closed');
    } catch (err) {
      logger.error('Error closing database', { error: err });
    }
    _db = null;
  }
}

// Utility: run multiple statements in a transaction
export function runInTransaction<T>(fn: (db: Database.Database) => T): T {
  const db = getDb();
  const tx = db.transaction(fn);
  return tx(db);
}
