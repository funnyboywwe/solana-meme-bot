import { getDb } from '../Database';

/**
 * MoonbagRepository — persistence for the Capital Recovery + Moonbag subsystem.
 *
 * Per-position state lives on the existing `positions` table (extra columns are
 * added idempotently by Database.ts). A dedicated `moonbag_lifecycle` table
 * (migration 004) stores the full analytics record for every managed position
 * so the lifecycle survives restarts and is queryable for reporting.
 */

export type ManagedState = 'open' | 'recovering' | 'moonbag' | 'closed';

export interface ManagedPositionRow {
  id: string;
  tokenMint: string;
  lifecycleState: ManagedState;
  entryPriceUsd: number;
  entrySolAmount: number;
  buyNetworkFeeSol: number;
  buyPriorityFeeSol: number;
  recoveryPriceUsd: number | null;
  capitalRecoveredSol: number | null;
  moonbagTokens: number | null;
  highestPriceUsd: number | null;
  trailingStopUsd: number | null;
  sizeTokens: number;
  strategy: string;
  openedAt: number;
}

export interface MoonbagLifecycleRecord {
  positionId: string;
  tokenMint: string;
  entryPriceUsd: number;
  entrySolAmount: number;
  recoveryPriceUsd?: number | null;
  recoverySellTokens?: number | null;
  capitalRecoveredSol?: number | null;
  moonbagTokens?: number | null;
  highestPriceUsd?: number | null;
  trailingStopUsd?: number | null;
  finalExitPriceUsd?: number | null;
  totalProfitSol?: number | null;
  exitReason?: string | null;
  state: string;
}

interface RawPositionRow {
  id: string;
  token_mint: string;
  lifecycle_state: string | null;
  entry_price_usd: number | null;
  entry_sol_amount: number | null;
  buy_network_fee_sol: number | null;
  buy_priority_fee_sol: number | null;
  recovery_price_usd: number | null;
  capital_recovered_sol: number | null;
  moonbag_tokens: number | null;
  highest_price_usd: number | null;
  trailing_stop_usd: number | null;
  size_tokens: number | null;
  strategy: string | null;
  opened_at: number | null;
}

function mapRow(r: RawPositionRow): ManagedPositionRow {
  return {
    id: r.id,
    tokenMint: r.token_mint,
    lifecycleState: (r.lifecycle_state as ManagedState | null) ?? 'open',
    entryPriceUsd: r.entry_price_usd ?? 0,
    entrySolAmount: r.entry_sol_amount ?? 0,
    buyNetworkFeeSol: r.buy_network_fee_sol ?? 0,
    buyPriorityFeeSol: r.buy_priority_fee_sol ?? 0,
    recoveryPriceUsd: r.recovery_price_usd,
    capitalRecoveredSol: r.capital_recovered_sol,
    moonbagTokens: r.moonbag_tokens,
    highestPriceUsd: r.highest_price_usd,
    trailingStopUsd: r.trailing_stop_usd,
    sizeTokens: r.size_tokens ?? 0,
    strategy: r.strategy ?? 'momentum',
    openedAt: r.opened_at ?? Date.now(),
  };
}

const SELECT_COLS = `id, token_mint, lifecycle_state, entry_price_usd, entry_sol_amount,
  buy_network_fee_sol, buy_priority_fee_sol, recovery_price_usd, capital_recovered_sol,
  moonbag_tokens, highest_price_usd, trailing_stop_usd, size_tokens, strategy, opened_at`;

export const MoonbagRepository = {
  /** Record entry costs and mark the position as managed (state = open). */
  initManaged(
    positionId: string,
    data: { entrySolAmount: number; buyNetworkFeeSol: number; buyPriorityFeeSol: number },
  ): void {
    getDb()
      .prepare(
        `UPDATE positions
         SET lifecycle_state = 'open',
             entry_sol_amount = ?,
             buy_network_fee_sol = ?,
             buy_priority_fee_sol = ?
         WHERE id = ?`,
      )
      .run(data.entrySolAmount, data.buyNetworkFeeSol, data.buyPriorityFeeSol, positionId);
  },

  setRecovering(positionId: string): void {
    getDb().prepare(`UPDATE positions SET lifecycle_state = 'recovering' WHERE id = ?`).run(positionId);
  },

  /** Mark the position as a moonbag and persist recovery results. */
  setMoonbag(
    positionId: string,
    data: {
      recoveryPriceUsd: number;
      capitalRecoveredSol: number;
      moonbagTokens: number;
      highestPriceUsd: number;
      trailingStopUsd: number;
    },
  ): void {
    getDb()
      .prepare(
        `UPDATE positions
         SET lifecycle_state = 'moonbag',
             recovery_price_usd = ?,
             capital_recovered_sol = ?,
             moonbag_tokens = ?,
             highest_price_usd = ?,
             trailing_stop_usd = ?,
             size_tokens = ?
         WHERE id = ?`,
      )
      .run(
        data.recoveryPriceUsd,
        data.capitalRecoveredSol,
        data.moonbagTokens,
        data.highestPriceUsd,
        data.trailingStopUsd,
        data.moonbagTokens,
        positionId,
      );
  },

  updateTrailing(positionId: string, highestPriceUsd: number, trailingStopUsd: number): void {
    getDb()
      .prepare(`UPDATE positions SET highest_price_usd = ?, trailing_stop_usd = ? WHERE id = ?`)
      .run(highestPriceUsd, trailingStopUsd, positionId);
  },

  setClosedState(positionId: string): void {
    getDb().prepare(`UPDATE positions SET lifecycle_state = 'closed' WHERE id = ?`).run(positionId);
  },

  /** Open moonbag positions to restore after a restart. */
  findMoonbagPositions(): ManagedPositionRow[] {
    const rows = getDb()
      .prepare(`SELECT ${SELECT_COLS} FROM positions WHERE lifecycle_state = 'moonbag' AND status = 'open'`)
      .all() as RawPositionRow[];
    return rows.map(mapRow);
  },

  getByMint(mint: string): ManagedPositionRow | null {
    const row = getDb()
      .prepare(`SELECT ${SELECT_COLS} FROM positions WHERE token_mint = ? AND status = 'open' LIMIT 1`)
      .get(mint) as RawPositionRow | undefined;
    return row ? mapRow(row) : null;
  },

  /** Upsert the analytics lifecycle record (preserves created_at on update). */
  recordLifecycle(rec: MoonbagLifecycleRecord): void {
    const now = Date.now();
    getDb()
      .prepare(
        `INSERT INTO moonbag_lifecycle (
           position_id, token_mint, entry_price_usd, entry_sol_amount, recovery_price_usd,
           recovery_sell_tokens, capital_recovered_sol, moonbag_tokens, highest_price_usd,
           trailing_stop_usd, final_exit_price_usd, total_profit_sol, exit_reason, state,
           created_at, updated_at
         ) VALUES (
           @position_id, @token_mint, @entry_price_usd, @entry_sol_amount, @recovery_price_usd,
           @recovery_sell_tokens, @capital_recovered_sol, @moonbag_tokens, @highest_price_usd,
           @trailing_stop_usd, @final_exit_price_usd, @total_profit_sol, @exit_reason, @state,
           @created_at, @updated_at
         )
         ON CONFLICT(position_id) DO UPDATE SET
           recovery_price_usd = excluded.recovery_price_usd,
           recovery_sell_tokens = excluded.recovery_sell_tokens,
           capital_recovered_sol = excluded.capital_recovered_sol,
           moonbag_tokens = excluded.moonbag_tokens,
           highest_price_usd = excluded.highest_price_usd,
           trailing_stop_usd = excluded.trailing_stop_usd,
           final_exit_price_usd = excluded.final_exit_price_usd,
           total_profit_sol = excluded.total_profit_sol,
           exit_reason = excluded.exit_reason,
           state = excluded.state,
           updated_at = excluded.updated_at`,
      )
      .run({
        position_id: rec.positionId,
        token_mint: rec.tokenMint,
        entry_price_usd: rec.entryPriceUsd,
        entry_sol_amount: rec.entrySolAmount,
        recovery_price_usd: rec.recoveryPriceUsd ?? null,
        recovery_sell_tokens: rec.recoverySellTokens ?? null,
        capital_recovered_sol: rec.capitalRecoveredSol ?? null,
        moonbag_tokens: rec.moonbagTokens ?? null,
        highest_price_usd: rec.highestPriceUsd ?? null,
        trailing_stop_usd: rec.trailingStopUsd ?? null,
        final_exit_price_usd: rec.finalExitPriceUsd ?? null,
        total_profit_sol: rec.totalProfitSol ?? null,
        exit_reason: rec.exitReason ?? null,
        state: rec.state,
        created_at: now,
        updated_at: now,
      });
  },
};

export default MoonbagRepository;
