import { Connection, PublicKey } from '@solana/web3.js';
import { AppConfig } from '../../config/AppConfig';
import { createModuleLogger } from '../../core/Logger';
import { EventBus, PriceUpdateEvent, TradeFilledEvent } from '../../core/EventBus';
import { ClosedPosition } from '../../core/types';
import PositionRepository from '../../db/repositories/PositionRepository';
import MoonbagRepository, { ManagedState } from '../../db/repositories/MoonbagRepository';
import { getSolPriceUsd } from '../../core/SolPrice';
import { getPositionSizer } from '../../risk/PositionSizer';
import { FeeEstimator } from '../FeeEstimator';
import { AxiosHttpClient } from '../multi-aggregator/http';
import { IAggregator, LoggerLike } from '../multi-aggregator/types';
import { createMultiAggregatorEngine, MultiAggregatorEngine } from '../multi-aggregator/engine';
import { CapitalRecoveryManager } from './CapitalRecoveryManager';
import { TrailingStopManager } from './TrailingStopManager';
import {
  DexScreenerMarketSource,
  EmergencyThresholds,
  RecoveryExitReason,
  detectMoonbagEmergency,
} from './MarketGuard';

/**
 * RecoveryOrchestrator — the brain of the Capital Recovery + Moonbag + Trailing
 * Stop subsystem.
 *
 * Lifecycle of a managed position:
 *
 *   BUY (TRADE_FILLED)
 *     -> state = open, entry costs recorded
 *   PRICE_UPDATE, gain >= CAPITAL_RECOVERY_TRIGGER_PERCENT
 *     -> recoverCapital(): sell ONLY enough tokens to return
 *        capital + buy fees + estimated exit fees + safety buffer
 *     -> keep the remaining tokens, state = moonbag (risk now = 0)
 *     -> activate a trailing stop immediately
 *   PRICE_UPDATE while moonbag
 *     -> ratchet the trailing stop up; exit when price falls to the stop
 *   Emergency poll while moonbag
 *     -> exit on volume/liquidity/buy-sell/whale/stale-price/no-route triggers
 *
 * This subsystem is fully self-contained: it builds its own multi-aggregator
 * engine and never mutates the primary execution path, so it can be wired in
 * (and removed) with a single block in index.ts.
 */

const logger = createModuleLogger('RecoveryOrchestrator') as unknown as LoggerLike;

export interface RecoveryOrchestratorDeps {
  /**
   * Tell the StopLossManager to stop managing this mint once it becomes a
   * moonbag — the trailing stop here takes over, and the original SL/TP must
   * not also fire on the same position.
   */
  releaseFromStopLoss: (mint: string) => void;
}

/** In-memory view of one managed position. */
interface Managed {
  positionId: string;
  mint: string;
  state: ManagedState;
  entryPriceUsd: number;
  entrySolAmount: number;
  buyNetworkFeeSol: number;
  buyPriorityFeeSol: number;
  sizeTokens: number;
  capitalRecoveredSol: number;
  recoveryPriceUsd: number;
  peakLiquidityUsd: number;
  peakVolumeUsd: number;
  openedAt: number;
}

/** Birdeye top-10 holder concentration, normalised to a 0-100 percentage. */
async function fetchBirdeyeWhalePct(
  http: AxiosHttpClient,
  mint: string,
  apiKey: string,
): Promise<number | undefined> {
  try {
    const res = await http.get<{ data?: { top10HolderPercent?: number } }>(
      'https://public-api.birdeye.so/defi/token_overview',
      {
        params: { address: mint },
        headers: { 'X-API-KEY': apiKey, 'x-chain': 'solana' },
        timeoutMs: 6000,
      },
    );
    const pct = res.data?.data?.top10HolderPercent;
    if (typeof pct !== 'number') return undefined;
    // Birdeye returns a fraction (0-1) on some plans and a percent on others.
    return pct <= 1 ? pct * 100 : pct;
  } catch {
    return undefined;
  }
}

export class RecoveryOrchestrator {
  private readonly triggerPct: number;
  private readonly thresholds: EmergencyThresholds;

  private readonly managed = new Map<string, Managed>(); // positionId -> Managed
  private readonly mintToPosition = new Map<string, string>(); // mint -> positionId
  private emergencyTimer: NodeJS.Timeout | null = null;

  private readonly onTradeFilledBound = (e: TradeFilledEvent): Promise<void> => this.onTradeFilled(e);
  private readonly onPriceUpdateBound = (e: PriceUpdateEvent): Promise<void> => this.onPriceUpdate(e);

  private constructor(
    private readonly cfg: AppConfig,
    private readonly connection: Connection,
    private readonly walletPubkey: string,
    private readonly engine: MultiAggregatorEngine,
    private readonly recoveryManager: CapitalRecoveryManager,
    private readonly trailing: TrailingStopManager,
    private readonly marketSource: DexScreenerMarketSource,
    private readonly deps: RecoveryOrchestratorDeps,
  ) {
    this.triggerPct = cfg.recovery.capitalRecoveryTriggerPct;
    this.thresholds = {
      liquidityDropExitPct: cfg.recovery.liquidityDropExitPct,
      volumeDropExitPct: cfg.recovery.volumeDropExitPct,
      minBuySellRatio: cfg.recovery.minBuySellRatio,
      whaleConcentrationExitPct: cfg.recovery.whaleConcentrationExitPct,
      stalePriceMs: cfg.recovery.stalePriceSeconds * 1000,
    };
  }

  /** Build a fully-wired orchestrator using the bot's own wallet + engine. */
  static createDefault(cfg: AppConfig, deps: RecoveryOrchestratorDeps): RecoveryOrchestrator {
    const sizer = getPositionSizer(cfg);
    const keypair = sizer.getKeypair();
    const connection = sizer.getConnection();
    const walletPubkey = sizer.getWalletPublicKey();

    const engine = createMultiAggregatorEngine(cfg, keypair, {
      // The moonbag subsystem only ever SELLS tokens it already holds, so the
      // pre-trade safety gate is a no-op here.
      safetyEvaluate: async () => ({ pass: true }),
      birdeyeApiKey: process.env['BIRDEYE_API_KEY'] || undefined,
    });

    const http = new AxiosHttpClient();
    const birdeyeKey = process.env['BIRDEYE_API_KEY'];
    const whaleSource = birdeyeKey
      ? (mint: string): Promise<number | undefined> => fetchBirdeyeWhalePct(http, mint, birdeyeKey)
      : undefined;
    const marketSource = new DexScreenerMarketSource(http, {
      logger,
      getWhaleConcentrationPct: whaleSource,
    });

    const feeEstimator = new FeeEstimator(cfg);
    const recoveryManager = new CapitalRecoveryManager(feeEstimator, {
      safetyBufferPct: cfg.recovery.safetyBufferPct,
      slippageBps: cfg.execution.maxSlippageBps,
      priorityFeeMicroLamports: cfg.execution.priorityFeeMicroLamports,
      logger,
    });
    const trailing = new TrailingStopManager(cfg.recovery.trailingStopPct, logger);

    return new RecoveryOrchestrator(
      cfg,
      connection,
      walletPubkey,
      engine,
      recoveryManager,
      trailing,
      marketSource,
      deps,
    );
  }

  /** Subscribe to fills + prices and start the emergency poll. */
  start(): void {
    if (!this.cfg.recovery.enabled) {
      logger.info('Recovery orchestrator disabled via config (recovery.enabled = false)');
      return;
    }
    EventBus.on('TRADE_FILLED', this.onTradeFilledBound);
    EventBus.on('PRICE_UPDATE', this.onPriceUpdateBound);
    this.emergencyTimer = setInterval(() => {
      void this.runEmergencySweep();
    }, this.cfg.recovery.emergencyPollMs);
    this.emergencyTimer.unref();
    logger.info('Recovery orchestrator started', {
      capitalRecoveryTriggerPct: this.triggerPct,
      trailingStopPct: this.cfg.recovery.trailingStopPct,
      emergencyPollMs: this.cfg.recovery.emergencyPollMs,
    });
  }

  /** Stop the poll and unsubscribe. */
  stop(): void {
    if (this.emergencyTimer) {
      clearInterval(this.emergencyTimer);
      this.emergencyTimer = null;
    }
    try {
      EventBus.off('TRADE_FILLED', this.onTradeFilledBound);
      EventBus.off('PRICE_UPDATE', this.onPriceUpdateBound);
    } catch {
      // ignore unsubscribe errors on shutdown
    }
    logger.info('Recovery orchestrator stopped');
  }

  /** Re-arm moonbag positions (and their trailing stops) after a restart. */
  async restoreFromDb(): Promise<void> {
    if (!this.cfg.recovery.enabled) return;
    let rows;
    try {
      rows = MoonbagRepository.findMoonbagPositions();
    } catch (err) {
      logger.warn('restoreFromDb: could not load moonbag positions', {
        error: err instanceof Error ? err.message : String(err),
      });
      return;
    }
    for (const r of rows) {
      const m: Managed = {
        positionId: r.id,
        mint: r.tokenMint,
        state: 'moonbag',
        entryPriceUsd: r.entryPriceUsd,
        entrySolAmount: r.entrySolAmount,
        buyNetworkFeeSol: r.buyNetworkFeeSol,
        buyPriorityFeeSol: r.buyPriorityFeeSol,
        sizeTokens: r.moonbagTokens ?? r.sizeTokens ?? 0,
        capitalRecoveredSol: r.capitalRecoveredSol ?? 0,
        recoveryPriceUsd: r.recoveryPriceUsd ?? 0,
        peakLiquidityUsd: 0,
        peakVolumeUsd: 0,
        openedAt: r.openedAt,
      };
      this.managed.set(m.positionId, m);
      this.mintToPosition.set(m.mint, m.positionId);
      const high = r.highestPriceUsd ?? r.recoveryPriceUsd ?? r.entryPriceUsd;
      this.trailing.activate(m.positionId, high);
    }
    if (rows.length) {
      logger.info('Restored moonbag positions from DB', { count: rows.length });
    }
  }

  // ── Event handlers ─────────────────────────────────────────────────────────

  private async onTradeFilled(e: TradeFilledEvent): Promise<void> {
    if (e.side !== 'buy') return;
    const position = PositionRepository.findByToken(e.mint);
    if (!position) return;
    if (this.managed.has(position.id)) return;

    // Split the observed buy fee into base network fee + priority fee so the
    // recovery requirement can repay both precisely.
    const buyNetworkFeeSol = Math.min(this.cfg.costControl.baseTxFeeSol, e.feeSol);
    const buyPriorityFeeSol = Math.max(0, e.feeSol - buyNetworkFeeSol);

    const m: Managed = {
      positionId: position.id,
      mint: e.mint,
      state: 'open',
      entryPriceUsd: e.priceUsd > 0 ? e.priceUsd : position.entryPriceUsd,
      entrySolAmount: e.sizeSol,
      buyNetworkFeeSol,
      buyPriorityFeeSol,
      sizeTokens: e.sizeTokens || position.sizeTokens || 0,
      capitalRecoveredSol: 0,
      recoveryPriceUsd: 0,
      peakLiquidityUsd: 0,
      peakVolumeUsd: 0,
      openedAt: position.openedAt || Date.now(),
    };
    this.managed.set(m.positionId, m);
    this.mintToPosition.set(m.mint, m.positionId);

    try {
      MoonbagRepository.initManaged(m.positionId, {
        entrySolAmount: m.entrySolAmount,
        buyNetworkFeeSol: m.buyNetworkFeeSol,
        buyPriorityFeeSol: m.buyPriorityFeeSol,
      });
    } catch (err) {
      logger.warn('initManaged persistence failed', {
        positionId: m.positionId,
        error: err instanceof Error ? err.message : String(err),
      });
    }
    logger.info('Recovery tracking armed', {
      positionId: m.positionId,
      mint: m.mint,
      entryPriceUsd: m.entryPriceUsd,
      entrySolAmount: m.entrySolAmount,
      buyNetworkFeeSol,
      buyPriorityFeeSol,
    });
  }

  private async onPriceUpdate(e: PriceUpdateEvent): Promise<void> {
    const positionId = this.mintToPosition.get(e.mint);
    if (!positionId) return;
    const m = this.managed.get(positionId);
    if (!m || e.priceUsd <= 0) return;

    if (m.state === 'open') {
      const gain = (e.priceUsd - m.entryPriceUsd) / m.entryPriceUsd;
      if (gain >= this.triggerPct) {
        await this.recoverCapital(m, e.priceUsd, e.liquidityUsd ?? 0);
      }
    } else if (m.state === 'moonbag') {
      const st = this.trailing.update(m.positionId, e.priceUsd);
      if (st) {
        try {
          MoonbagRepository.updateTrailing(m.positionId, st.highestPriceUsd, st.stopPriceUsd);
        } catch {
          // best-effort persistence
        }
      }
      if (this.trailing.isHit(m.positionId, e.priceUsd)) {
        await this.exitMoonbag(m, e.priceUsd, 'TRAILING_STOP_HIT');
      }
    }
  }

  // ── Core actions ─────────────────────────────────────────────────────────

  private async recoverCapital(m: Managed, currentPriceUsd: number, liquidityUsd: number): Promise<void> {
    if (m.state !== 'open') return;
    // Flip state synchronously BEFORE any await so a burst of PRICE_UPDATEs
    // can't trigger a second recovery sell.
    m.state = 'recovering';
    try {
      MoonbagRepository.setRecovering(m.positionId);
    } catch {
      // best-effort
    }

    try {
      const balance = await this.readRawBalance(m.mint);
      if (!balance || balance.raw <= 0n) {
        logger.warn('Capital recovery aborted: no token balance', { mint: m.mint });
        m.state = 'open';
        return;
      }
      const decimals = balance.decimals;
      const totalTokens = Number(balance.raw) / Math.pow(10, decimals);
      const solPriceUsd = getSolPriceUsd();

      const plan = this.recoveryManager.buildPlan(
        {
          entrySolAmount: m.entrySolAmount,
          buyNetworkFeeSol: m.buyNetworkFeeSol,
          buyPriorityFeeSol: m.buyPriorityFeeSol,
        },
        currentPriceUsd,
        solPriceUsd,
        totalTokens,
        liquidityUsd,
      );
      if (plan.tokensToSell <= 0) {
        m.state = 'open';
        return;
      }

      let rawToSell = BigInt(Math.floor(plan.tokensToSell * Math.pow(10, decimals)));
      if (rawToSell > balance.raw) rawToSell = balance.raw;
      if (rawToSell <= 0n) {
        m.state = 'open';
        return;
      }

      const result = await this.engine.executor.executeSell(
        m.mint,
        rawToSell.toString(),
        this.cfg.execution.maxSlippageBps,
        this.cfg.execution.priorityFeeMicroLamports,
      );
      if (!result.success) {
        logger.error('Capital recovery sell failed — reverting to open', {
          mint: m.mint,
          error: result.error,
        });
        m.state = 'open';
        return;
      }

      const capitalRecoveredSol = result.amountOut / 1e9;
      m.capitalRecoveredSol = capitalRecoveredSol;
      m.recoveryPriceUsd = currentPriceUsd;

      const remainingRaw = balance.raw - rawToSell;
      const remainingTokens = Number(remainingRaw) / Math.pow(10, decimals);

      if (remainingRaw <= 0n || remainingTokens <= 0) {
        // Nothing left to keep — treat as a normal full exit.
        logger.info('Recovery sold full balance; closing position (no moonbag)', {
          mint: m.mint,
        });
        m.state = 'moonbag'; // so finalizeClose's guard passes
        m.sizeTokens = 0;
        this.finalizeClose(m, currentPriceUsd, 0, 'TRAILING_STOP_HIT');
        return;
      }

      // Enter moonbag: original risk is now zero (capital + fees recovered).
      m.state = 'moonbag';
      m.sizeTokens = remainingTokens;
      const tstate = this.trailing.activate(m.positionId, currentPriceUsd);

      try {
        MoonbagRepository.setMoonbag(m.positionId, {
          recoveryPriceUsd: currentPriceUsd,
          capitalRecoveredSol,
          moonbagTokens: remainingTokens,
          highestPriceUsd: tstate.highestPriceUsd,
          trailingStopUsd: tstate.stopPriceUsd,
        });
      } catch (err) {
        logger.warn('setMoonbag persistence failed', {
          positionId: m.positionId,
          error: err instanceof Error ? err.message : String(err),
        });
      }

      // Hand the position over to OUR trailing stop.
      this.deps.releaseFromStopLoss(m.mint);

      try {
        MoonbagRepository.recordLifecycle({
          positionId: m.positionId,
          tokenMint: m.mint,
          entryPriceUsd: m.entryPriceUsd,
          entrySolAmount: m.entrySolAmount,
          recoveryPriceUsd: currentPriceUsd,
          recoverySellTokens: plan.tokensToSell,
          capitalRecoveredSol,
          moonbagTokens: remainingTokens,
          highestPriceUsd: tstate.highestPriceUsd,
          trailingStopUsd: tstate.stopPriceUsd,
          state: 'moonbag',
        });
      } catch {
        // analytics best-effort
      }

      logger.info('Capital recovered — moonbag created', {
        positionId: m.positionId,
        mint: m.mint,
        capitalRecoveredSol,
        requiredRecoverySol: plan.requiredRecoverySol,
        recoverySellTokens: plan.tokensToSell,
        moonbagTokens: remainingTokens,
        trailingStopUsd: tstate.stopPriceUsd,
      });
    } catch (err) {
      logger.error('recoverCapital encountered an error — reverting to open', {
        mint: m.mint,
        error: err instanceof Error ? err.message : String(err),
      });
      m.state = 'open';
    }
  }

  private async exitMoonbag(m: Managed, exitPriceUsd: number, reason: RecoveryExitReason): Promise<void> {
    if (m.state !== 'moonbag') return;
    // Synchronous guard so concurrent triggers (trailing + emergency) can't
    // double-sell.
    m.state = 'closed';
    try {
      const balance = await this.readRawBalance(m.mint);
      if (!balance || balance.raw <= 0n) {
        logger.warn('Moonbag exit: no balance to sell, finalizing', { mint: m.mint });
        this.finalizeClose(m, exitPriceUsd, 0, reason);
        return;
      }
      const result = await this.engine.executor.executeSell(
        m.mint,
        balance.raw.toString(),
        this.cfg.execution.maxSlippageBps,
        this.cfg.execution.priorityFeeMicroLamports,
      );
      if (!result.success) {
        logger.error('Moonbag exit sell failed — reverting to moonbag for retry', {
          mint: m.mint,
          reason,
          error: result.error,
        });
        m.state = 'moonbag';
        return;
      }
      const proceedsSol = result.amountOut / 1e9;
      this.finalizeClose(m, exitPriceUsd, proceedsSol, reason);
    } catch (err) {
      logger.error('exitMoonbag encountered an error — reverting to moonbag', {
        mint: m.mint,
        error: err instanceof Error ? err.message : String(err),
      });
      m.state = 'moonbag';
    }
  }

  private finalizeClose(
    m: Managed,
    exitPriceUsd: number,
    proceedsSol: number,
    reason: RecoveryExitReason,
  ): void {
    const totalProfitSol = m.capitalRecoveredSol + proceedsSol - m.entrySolAmount;
    const closedExitReason: ClosedPosition['exitReason'] =
      reason === 'TRAILING_STOP_HIT' ? 'trailing' : 'circuit';
    const now = Date.now();
    const closed: ClosedPosition = {
      id: m.positionId,
      tokenMint: m.mint,
      strategy: 'momentum',
      sizeSol: m.entrySolAmount,
      entryPriceUsd: m.entryPriceUsd,
      exitPriceUsd,
      realisedPnlSol: totalProfitSol,
      holdTimeSecs: Math.max(0, Math.round((now - m.openedAt) / 1000)),
      exitReason: closedExitReason,
      openedAt: m.openedAt,
      closedAt: now,
    };
    try {
      PositionRepository.close(m.positionId, closed);
    } catch (err) {
      logger.error('PositionRepository.close failed', {
        positionId: m.positionId,
        error: err instanceof Error ? err.message : String(err),
      });
    }
    try {
      MoonbagRepository.setClosedState(m.positionId);
    } catch {
      // best-effort
    }
    try {
      MoonbagRepository.recordLifecycle({
        positionId: m.positionId,
        tokenMint: m.mint,
        entryPriceUsd: m.entryPriceUsd,
        entrySolAmount: m.entrySolAmount,
        recoveryPriceUsd: m.recoveryPriceUsd,
        capitalRecoveredSol: m.capitalRecoveredSol,
        moonbagTokens: m.sizeTokens,
        finalExitPriceUsd: exitPriceUsd,
        totalProfitSol,
        exitReason: reason,
        state: 'closed',
      });
    } catch {
      // analytics best-effort
    }

    this.trailing.remove(m.positionId);
    this.managed.delete(m.positionId);
    this.mintToPosition.delete(m.mint);

    // Let the rest of the bot know a sell settled so exposure/risk slots free up.
    EventBus.emit('TRADE_FILLED', {
      tradeId: `moonbag-exit-${m.positionId}`,
      mint: m.mint,
      side: 'sell',
      sizeSol: m.capitalRecoveredSol + proceedsSol,
      sizeTokens: m.sizeTokens,
      priceUsd: exitPriceUsd,
      txHash: '',
      feeSol: 0,
      realisedPnlSol: totalProfitSol,
      ts: now,
    });

    logger.info('Moonbag closed', {
      positionId: m.positionId,
      mint: m.mint,
      reason,
      capitalRecoveredSol: m.capitalRecoveredSol,
      moonbagProceedsSol: proceedsSol,
      totalProfitSol,
    });
  }

  // ── Emergency monitoring ───────────────────────────────────────────────────

  private async runEmergencySweep(): Promise<void> {
    const moonbags = [...this.managed.values()].filter((m) => m.state === 'moonbag');
    for (const m of moonbags) {
      try {
        const priceAgeMs = this.engine.priceManager.getPriceAgeMs(m.mint);
        const sellRouteOk = await this.hasSellRoute(m);
        const snapshot = await this.marketSource.getSnapshot(m.mint);
        if (snapshot) {
          if (snapshot.liquidityUsd > m.peakLiquidityUsd) m.peakLiquidityUsd = snapshot.liquidityUsd;
          if (snapshot.volumeUsd > m.peakVolumeUsd) m.peakVolumeUsd = snapshot.volumeUsd;
        }
        const reason = detectMoonbagEmergency(
          {
            priceAgeMs,
            sellRouteOk,
            snapshot,
            peakLiquidityUsd: m.peakLiquidityUsd,
            peakVolumeUsd: m.peakVolumeUsd,
          },
          this.thresholds,
        );
        if (reason) {
          const cached = this.engine.priceManager.getCached(m.mint);
          const price = cached?.priceUsd ?? m.recoveryPriceUsd ?? m.entryPriceUsd;
          logger.warn('Moonbag emergency exit triggered', { mint: m.mint, reason });
          await this.exitMoonbag(m, price, reason);
        }
      } catch (err) {
        logger.warn('Emergency sweep error', {
          mint: m.mint,
          error: err instanceof Error ? err.message : String(err),
        });
      }
    }
  }

  /** Probe every aggregator for a live sell route for the full balance. */
  private async hasSellRoute(m: Managed): Promise<boolean> {
    try {
      const balance = await this.readRawBalance(m.mint);
      if (!balance || balance.raw <= 0n) return false;
      const amount = balance.raw.toString();
      for (const agg of this.engine.aggregators as IAggregator[]) {
        try {
          const q = await agg.getSellQuote(m.mint, amount, this.cfg.execution.maxSlippageBps);
          if (q && Number(q.outAmount) > 0) return true;
        } catch {
          // try the next aggregator
        }
      }
      return false;
    } catch {
      return false;
    }
  }

  /** Read the wallet's raw SPL-token balance for a mint. */
  private async readRawBalance(mint: string): Promise<{ raw: bigint; decimals: number } | null> {
    try {
      const owner = new PublicKey(this.walletPubkey);
      const res = (await this.connection.getParsedTokenAccountsByOwner(owner, {
        mint: new PublicKey(mint),
      })) as unknown as { value: Array<{ account: { data: { parsed: { info: { tokenAmount: { amount: string; decimals: number } } } } } }> };
      const accounts = res?.value ?? [];
      let raw = 0n;
      let decimals = 0;
      for (const acc of accounts) {
        const info = (acc as any)?.account?.data?.parsed?.info?.tokenAmount;
        if (info && typeof info.amount === 'string') {
          raw += BigInt(info.amount);
          decimals = info.decimals;
        }
      }
      if (raw === 0n && decimals === 0) return null;
      return { raw, decimals };
    } catch (err) {
      logger.warn('readRawBalance failed', {
        mint,
        error: err instanceof Error ? err.message : String(err),
      });
      return null;
    }
  }
}

export default RecoveryOrchestrator;
