import { LoggerLike, noopLogger } from '../multi-aggregator/types';

/**
 * TrailingStopManager (Requirement #6).
 *
 * Tracks a per-position trailing stop that:
 *   - activates immediately after capital recovery,
 *   - follows the highest price seen since activation,
 *   - only ever moves UP (never down),
 *   - fires when price falls to/through the current stop.
 *
 * The class is pure in-memory state + tiny helpers so it is trivially
 * unit-testable with no network/RPC/wallet.
 */

/** Immutable snapshot of a single position's trailing-stop state. */
export interface TrailingState {
  /** Highest price observed since the trailing stop was activated. */
  highestPriceUsd: number;
  /** Current stop price = highestPriceUsd * (1 - trailingPct). Ratchets up only. */
  stopPriceUsd: number;
  /** Trailing distance as a fraction (0.10 = 10%). */
  trailingPct: number;
}

/** Pure helper: the stop price for a high-water mark and trailing fraction. */
export function computeStopPrice(highestPriceUsd: number, trailingPct: number): number {
  return highestPriceUsd * (1 - trailingPct);
}

export class TrailingStopManager {
  private readonly states = new Map<string, TrailingState>();
  private readonly trailingPct: number;
  private readonly logger: LoggerLike;

  constructor(trailingPct: number, logger: LoggerLike = noopLogger) {
    this.trailingPct = trailingPct;
    this.logger = logger;
  }

  /** Activate (or re-activate) the trailing stop at the given price. */
  activate(key: string, currentPriceUsd: number): TrailingState {
    const state: TrailingState = {
      highestPriceUsd: currentPriceUsd,
      stopPriceUsd: computeStopPrice(currentPriceUsd, this.trailingPct),
      trailingPct: this.trailingPct,
    };
    this.states.set(key, state);
    this.logger.info('Trailing stop activated', {
      key,
      highestPriceUsd: currentPriceUsd,
      stopPriceUsd: state.stopPriceUsd,
    });
    return state;
  }

  /**
   * Feed a new price. When it makes a new high the stop ratchets up; otherwise
   * the stop is left unchanged (it never moves down). Returns the current state,
   * or null when the key was never activated.
   */
  update(key: string, currentPriceUsd: number): TrailingState | null {
    const state = this.states.get(key);
    if (!state) return null;
    if (currentPriceUsd > state.highestPriceUsd) {
      const updated: TrailingState = {
        highestPriceUsd: currentPriceUsd,
        stopPriceUsd: computeStopPrice(currentPriceUsd, this.trailingPct),
        trailingPct: this.trailingPct,
      };
      this.states.set(key, updated);
      this.logger.info('Trailing stop raised', {
        key,
        highestPriceUsd: currentPriceUsd,
        stopPriceUsd: updated.stopPriceUsd,
      });
      return updated;
    }
    return state;
  }

  /** True when the price has fallen to/through the current stop. */
  isHit(key: string, currentPriceUsd: number): boolean {
    const state = this.states.get(key);
    if (!state) return false;
    return currentPriceUsd <= state.stopPriceUsd;
  }

  get(key: string): TrailingState | null {
    return this.states.get(key) ?? null;
  }

  remove(key: string): void {
    this.states.delete(key);
  }
}

export default TrailingStopManager;
