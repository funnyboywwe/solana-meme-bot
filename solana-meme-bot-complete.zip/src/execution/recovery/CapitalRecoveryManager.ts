import { FeeEstimator } from '../FeeEstimator';
import { LoggerLike, noopLogger } from '../multi-aggregator/types';

/**
 * CapitalRecoveryManager (Requirements #2, #3, #4).
 *
 * Computes EXACTLY how many tokens must be sold so that, after the sell lands,
 * the trade has returned:
 *
 *     Initial Investment
 *   + Buy Network Fee
 *   + Buy Priority Fee
 *   + Estimated Sell Network Fee
 *   + Estimated Sell Priority Fee
 *   + Safety Buffer (slippage + DEX fee + margin)
 *
 * Only after that requirement is met may a moonbag be created — this guarantees
 * all capital and costs are recovered before any "free" upside is kept.
 *
 * The math helpers are pure (no I/O) so they can be unit-tested directly.
 */

export interface EntryCosts {
  /** SOL spent entering the position (the buy size). */
  entrySolAmount: number;
  /** Network (base signature) fee paid on the buy, in SOL. */
  buyNetworkFeeSol: number;
  /** Priority fee paid on the buy, in SOL. */
  buyPriorityFeeSol: number;
}

export interface RecoveryPlan {
  /** Total SOL that must be returned to fully recover capital + all fees. */
  requiredRecoverySol: number;
  /** USD value that must be returned (requiredRecoverySol * solPriceUsd). */
  requiredRecoveryUsd: number;
  /** Whole-token quantity to sell to realise requiredRecoveryUsd at current price. */
  tokensToSell: number;
  /** Estimated sell-side network fee included in the requirement (SOL). */
  estSellNetworkFeeSol: number;
  /** Estimated sell-side priority fee included in the requirement (SOL). */
  estSellPriorityFeeSol: number;
  /** Explicit safety buffer included in the requirement (SOL). */
  safetyBufferSol: number;
}

/** Pure: sum of everything that must be recovered before a moonbag is created. */
export function computeRequiredRecoverySol(
  entry: EntryCosts,
  estSellNetworkFeeSol: number,
  estSellPriorityFeeSol: number,
  safetyBufferSol: number,
): number {
  return (
    entry.entrySolAmount +
    entry.buyNetworkFeeSol +
    entry.buyPriorityFeeSol +
    estSellNetworkFeeSol +
    estSellPriorityFeeSol +
    safetyBufferSol
  );
}

/**
 * Pure: how many whole tokens to sell to realise `requiredUsd` at
 * `currentPriceUsd`, capped at the tokens actually held.
 */
export function computeTokensToSell(
  requiredUsd: number,
  currentPriceUsd: number,
  totalTokens: number,
): number {
  if (currentPriceUsd <= 0 || requiredUsd <= 0) return 0;
  const needed = requiredUsd / currentPriceUsd;
  return Math.min(needed, totalTokens);
}

export class CapitalRecoveryManager {
  private readonly feeEstimator: FeeEstimator;
  private readonly safetyBufferPct: number;
  private readonly slippageBps: number;
  private readonly priorityFeeMicroLamports: number;
  private readonly logger: LoggerLike;

  constructor(
    feeEstimator: FeeEstimator,
    opts: {
      safetyBufferPct: number;
      slippageBps: number;
      priorityFeeMicroLamports: number;
      logger?: LoggerLike;
    },
  ) {
    this.feeEstimator = feeEstimator;
    this.safetyBufferPct = opts.safetyBufferPct;
    this.slippageBps = opts.slippageBps;
    this.priorityFeeMicroLamports = opts.priorityFeeMicroLamports;
    this.logger = opts.logger ?? noopLogger;
  }

  /**
   * Build the recovery plan. Uses the shared FeeEstimator to price the exit
   * (sell network + priority fee, DEX fee and slippage) so the requirement is
   * consistent with the rest of the bot's cost model.
   */
  buildPlan(
    entry: EntryCosts,
    currentPriceUsd: number,
    solPriceUsd: number,
    totalTokens: number,
    liquidityUsd: number,
  ): RecoveryPlan {
    const est = this.feeEstimator.estimate({
      sizeSol: entry.entrySolAmount,
      liquidityUsd,
      solPriceUsd,
      priorityFeeMicroLamports: this.priorityFeeMicroLamports,
      slippageBps: this.slippageBps,
      roundTrip: true,
    });

    // Safety buffer = configured % of capital + the modelled exit slippage and
    // DEX fee, so a small adverse move on the sell can't leave us short of full
    // capital recovery.
    const safetyBufferSol =
      entry.entrySolAmount * this.safetyBufferPct + est.dexFeeSol + est.slippageCostSol;

    const requiredRecoverySol = computeRequiredRecoverySol(
      entry,
      est.sellNetworkFeeSol,
      est.sellPriorityFeeSol,
      safetyBufferSol,
    );
    const requiredRecoveryUsd = requiredRecoverySol * solPriceUsd;
    const tokensToSell = computeTokensToSell(requiredRecoveryUsd, currentPriceUsd, totalTokens);

    this.logger.info('Recovery plan built', {
      entrySolAmount: entry.entrySolAmount,
      requiredRecoverySol,
      requiredRecoveryUsd,
      currentPriceUsd,
      tokensToSell,
      totalTokens,
    });

    return {
      requiredRecoverySol,
      requiredRecoveryUsd,
      tokensToSell,
      estSellNetworkFeeSol: est.sellNetworkFeeSol,
      estSellPriorityFeeSol: est.sellPriorityFeeSol,
      safetyBufferSol,
    };
  }
}

export default CapitalRecoveryManager;
