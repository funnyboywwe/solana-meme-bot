import { HttpClient, LoggerLike, noopLogger } from '../multi-aggregator/types';

/**
 * MarketGuard (Requirement #7 — Emergency Exit Rules).
 *
 * Provides:
 *   1. A pure decision function `detectMoonbagEmergency` covering ALL six
 *      emergency conditions, so the rules are unit-testable with no network.
 *   2. A DexScreener-backed market-stats source (liquidity, 1h volume, 1h
 *      buy/sell counts). Whale concentration is supplied by an optional
 *      injected holder source (Birdeye), since DexScreener does not expose
 *      holder distribution — when unavailable the whale rule is simply skipped.
 */

export type RecoveryExitReason =
  | 'TRAILING_STOP_HIT'
  | 'EMERGENCY_STALE_PRICE'
  | 'EMERGENCY_NO_SELL_ROUTE'
  | 'EMERGENCY_LIQUIDITY_DROP'
  | 'EMERGENCY_VOLUME_DROP'
  | 'EMERGENCY_BUY_SELL_RATIO'
  | 'EMERGENCY_WHALE_DISTRIBUTION';

export interface MarketSnapshot {
  liquidityUsd: number;
  /** Trailing 1-hour volume in USD. */
  volumeUsd: number;
  /** Trailing 1-hour buy count. */
  buys: number;
  /** Trailing 1-hour sell count. */
  sells: number;
  /** Top-holder concentration as a percentage (0-100), if available. */
  whaleConcentrationPct?: number;
}

export interface EmergencyThresholds {
  /** Liquidity fall from peak (fraction) that forces an exit. */
  liquidityDropExitPct: number;
  /** Volume fall from peak (fraction) that forces an exit. */
  volumeDropExitPct: number;
  /** Minimum acceptable buy/sell ratio; below this forces an exit. */
  minBuySellRatio: number;
  /** Whale concentration (percent) that forces an exit. */
  whaleConcentrationExitPct: number;
  /** Price staleness (ms) that forces an exit. */
  stalePriceMs: number;
}

export interface EmergencyInputs {
  priceAgeMs: number;
  sellRouteOk: boolean;
  snapshot: MarketSnapshot | null;
  /** Peak liquidity seen since entry (high-water mark). */
  peakLiquidityUsd: number;
  /** Peak 1h volume seen since entry (high-water mark). */
  peakVolumeUsd: number;
}

/**
 * Pure decision function for the six moonbag emergency exit rules. Returns the
 * FIRST reason that fires (priority order), or null when the position is
 * healthy.
 */
export function detectMoonbagEmergency(
  i: EmergencyInputs,
  t: EmergencyThresholds,
): RecoveryExitReason | null {
  // 5. Stale price > N seconds.
  if (i.priceAgeMs >= t.stalePriceMs) return 'EMERGENCY_STALE_PRICE';
  // 6. No sell route available.
  if (!i.sellRouteOk) return 'EMERGENCY_NO_SELL_ROUTE';

  const s = i.snapshot;
  if (s) {
    // 2. Liquidity drop > X% from the peak.
    if (i.peakLiquidityUsd > 0) {
      const drop = (i.peakLiquidityUsd - s.liquidityUsd) / i.peakLiquidityUsd;
      if (drop >= t.liquidityDropExitPct) return 'EMERGENCY_LIQUIDITY_DROP';
    }
    // 1. Volume drop > Y% from the peak.
    if (i.peakVolumeUsd > 0) {
      const drop = (i.peakVolumeUsd - s.volumeUsd) / i.peakVolumeUsd;
      if (drop >= t.volumeDropExitPct) return 'EMERGENCY_VOLUME_DROP';
    }
    // 3. Buy/Sell ratio < 1 (more selling than buying).
    if (s.sells > 0) {
      const ratio = s.buys / s.sells;
      if (ratio < t.minBuySellRatio) return 'EMERGENCY_BUY_SELL_RATIO';
    }
    // 4. Whale distribution detected (top-holder concentration too high).
    if (typeof s.whaleConcentrationPct === 'number' && s.whaleConcentrationPct >= t.whaleConcentrationExitPct) {
      return 'EMERGENCY_WHALE_DISTRIBUTION';
    }
  }
  return null;
}

/** Shape of the bits of a DexScreener pair we consume. */
interface DexPair {
  liquidity?: { usd?: number };
  volume?: { h1?: number };
  txns?: { h1?: { buys?: number; sells?: number } };
}

/**
 * DexScreener market-stats source. Picks the most-liquid pair for the mint and
 * returns liquidity, 1h volume and 1h buy/sell counts. Whale concentration is
 * delegated to an optional holder source.
 */
export class DexScreenerMarketSource {
  private readonly http: HttpClient;
  private readonly baseUrl: string;
  private readonly logger: LoggerLike;
  private readonly getWhaleConcentrationPct?: (mint: string) => Promise<number | undefined>;

  constructor(
    http: HttpClient,
    opts: {
      baseUrl?: string;
      logger?: LoggerLike;
      getWhaleConcentrationPct?: (mint: string) => Promise<number | undefined>;
    } = {},
  ) {
    this.http = http;
    this.baseUrl = opts.baseUrl ?? 'https://api.dexscreener.com/tokens/v1/solana';
    this.logger = opts.logger ?? noopLogger;
    this.getWhaleConcentrationPct = opts.getWhaleConcentrationPct;
  }

  async getSnapshot(mint: string): Promise<MarketSnapshot | null> {
    try {
      const res = await this.http.get<DexPair[]>(`${this.baseUrl}/${mint}`, { timeoutMs: 6000 });
      const pairs = Array.isArray(res.data) ? res.data : [];
      let best: DexPair | null = null;
      let bestLiq = -1;
      for (const p of pairs) {
        const liq = p.liquidity?.usd ?? 0;
        if (liq > bestLiq) {
          bestLiq = liq;
          best = p;
        }
      }
      if (!best) return null;
      const snapshot: MarketSnapshot = {
        liquidityUsd: best.liquidity?.usd ?? 0,
        volumeUsd: best.volume?.h1 ?? 0,
        buys: best.txns?.h1?.buys ?? 0,
        sells: best.txns?.h1?.sells ?? 0,
      };
      if (this.getWhaleConcentrationPct) {
        try {
          snapshot.whaleConcentrationPct = await this.getWhaleConcentrationPct(mint);
        } catch {
          // optional signal — ignore holder-source failures
        }
      }
      return snapshot;
    } catch (err) {
      this.logger.warn('DexScreener market snapshot failed', {
        mint,
        error: err instanceof Error ? err.message : String(err),
      });
      return null;
    }
  }
}

export default DexScreenerMarketSource;
