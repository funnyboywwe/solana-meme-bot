import { describe, expect, it } from '@jest/globals';
import {
  TrailingStopManager,
  computeStopPrice,
} from '../../../../src/execution/recovery/TrailingStopManager';

describe('computeStopPrice', () => {
  it('is high * (1 - pct)', () => {
    expect(computeStopPrice(100, 0.1)).toBeCloseTo(90);
    expect(computeStopPrice(2.5, 0.2)).toBeCloseTo(2.0);
  });
});

describe('TrailingStopManager', () => {
  it('activates at the given price with the stop pct below', () => {
    const t = new TrailingStopManager(0.1);
    const s = t.activate('p1', 100);
    expect(s.highestPriceUsd).toBe(100);
    expect(s.stopPriceUsd).toBeCloseTo(90);
  });

  it('ratchets the stop UP on new highs and never down', () => {
    const t = new TrailingStopManager(0.1);
    t.activate('p1', 100);
    t.update('p1', 120); // new high -> stop 108
    expect(t.get('p1')!.stopPriceUsd).toBeCloseTo(108);
    t.update('p1', 110); // below high -> stop unchanged
    expect(t.get('p1')!.highestPriceUsd).toBe(120);
    expect(t.get('p1')!.stopPriceUsd).toBeCloseTo(108);
  });

  it('isHit is true only when price <= stop', () => {
    const t = new TrailingStopManager(0.1);
    t.activate('p1', 100); // stop 90
    expect(t.isHit('p1', 95)).toBe(false);
    expect(t.isHit('p1', 90)).toBe(true);
    expect(t.isHit('p1', 89)).toBe(true);
  });

  it('returns null for unknown keys and after remove', () => {
    const t = new TrailingStopManager(0.1);
    expect(t.update('nope', 1)).toBeNull();
    expect(t.isHit('nope', 1)).toBe(false);
    t.activate('p1', 100);
    t.remove('p1');
    expect(t.get('p1')).toBeNull();
  });
});
