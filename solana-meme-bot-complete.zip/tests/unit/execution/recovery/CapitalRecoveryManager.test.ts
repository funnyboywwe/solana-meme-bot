import { describe, expect, it } from '@jest/globals';
import {
  CapitalRecoveryManager,
  computeRequiredRecoverySol,
  computeTokensToSell,
} from '../../../../src/execution/recovery/CapitalRecoveryManager';
import type { FeeEstimator } from '../../../../src/execution/FeeEstimator';

describe('computeRequiredRecoverySol', () => {
  it('sums capital + buy fees + estimated exit fees + buffer', () => {
    const v = computeRequiredRecoverySol(
      { entrySolAmount: 0.04, buyNetworkFeeSol: 0.000005, buyPriorityFeeSol: 0.0001 },
      0.000005,
      0.0001,
      0.001,
    );
    expect(v).toBeCloseTo(0.04 + 0.000005 + 0.0001 + 0.000005 + 0.0001 + 0.001);
  });
});

describe('computeTokensToSell', () => {
  it('returns requiredUsd / price, capped at total held', () => {
    expect(computeTokensToSell(30, 0.0001, 1_000_000)).toBeCloseTo(300_000);
    expect(computeTokensToSell(30, 0.0001, 100_000)).toBe(100_000); // capped at holdings
  });
  it('is 0 for non-positive price or requirement', () => {
    expect(computeTokensToSell(0, 0.0001, 100)).toBe(0);
    expect(computeTokensToSell(30, 0, 100)).toBe(0);
  });
});

describe('CapitalRecoveryManager.buildPlan', () => {
  // Inject a deterministic fee estimate so the test never touches real config.
  const fakeFee = {
    estimate: () => ({
      buyNetworkFeeSol: 0.000005,
      sellNetworkFeeSol: 0.000005,
      sellPriorityFeeSol: 0.0001,
      dexFeeSol: 0.0001,
      slippageCostSol: 0.0003,
      jitoTipSol: 0,
      totalCostSol: 0.00055,
      costPctOfSize: 0.0137,
    }),
  } as unknown as FeeEstimator;

  it('requires more than the entry capital and sells a capped, positive amount', () => {
    const mgr = new CapitalRecoveryManager(fakeFee, {
      safetyBufferPct: 0.02,
      slippageBps: 300,
      priorityFeeMicroLamports: 100000,
    });
    const entry = { entrySolAmount: 0.04, buyNetworkFeeSol: 0.000005, buyPriorityFeeSol: 0.0001 };
    const plan = mgr.buildPlan(entry, 0.0002, 150, 50_000, 20_000);
    expect(plan.requiredRecoverySol).toBeGreaterThan(entry.entrySolAmount);
    expect(plan.tokensToSell).toBeGreaterThan(0);
    expect(plan.tokensToSell).toBeLessThanOrEqual(50_000);
    // buffer = entrySol*pct + dexFeeSol + slippageCostSol
    expect(plan.safetyBufferSol).toBeCloseTo(0.04 * 0.02 + 0.0001 + 0.0003);
  });
});
