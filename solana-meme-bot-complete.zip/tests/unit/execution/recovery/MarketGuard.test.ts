import { describe, expect, it } from '@jest/globals';
import {
  EmergencyThresholds,
  MarketSnapshot,
  detectMoonbagEmergency,
} from '../../../../src/execution/recovery/MarketGuard';

const thresholds: EmergencyThresholds = {
  liquidityDropExitPct: 0.30,
  volumeDropExitPct: 0.70,
  minBuySellRatio: 1.0,
  whaleConcentrationExitPct: 40,
  stalePriceMs: 60_000,
};

const healthy: MarketSnapshot = {
  liquidityUsd: 10_000,
  volumeUsd: 5_000,
  buys: 50,
  sells: 25,
  whaleConcentrationPct: 10,
};

function base() {
  return {
    priceAgeMs: 1_000,
    sellRouteOk: true,
    snapshot: { ...healthy } as MarketSnapshot,
    peakLiquidityUsd: 10_000,
    peakVolumeUsd: 5_000,
  };
}

describe('detectMoonbagEmergency', () => {
  it('returns null when the position is healthy', () => {
    expect(detectMoonbagEmergency(base(), thresholds)).toBeNull();
  });
  it('detects stale price', () => {
    expect(detectMoonbagEmergency({ ...base(), priceAgeMs: 61_000 }, thresholds)).toBe('EMERGENCY_STALE_PRICE');
  });
  it('detects no sell route', () => {
    expect(detectMoonbagEmergency({ ...base(), sellRouteOk: false }, thresholds)).toBe('EMERGENCY_NO_SELL_ROUTE');
  });
  it('detects liquidity drop > 30%', () => {
    const i = base();
    i.snapshot.liquidityUsd = 6_000; // 40% below peak 10k
    expect(detectMoonbagEmergency(i, thresholds)).toBe('EMERGENCY_LIQUIDITY_DROP');
  });
  it('detects volume drop > 70%', () => {
    const i = base();
    i.snapshot.volumeUsd = 1_000; // 80% below peak 5k
    expect(detectMoonbagEmergency(i, thresholds)).toBe('EMERGENCY_VOLUME_DROP');
  });
  it('detects buy/sell ratio < 1', () => {
    const i = base();
    i.snapshot.buys = 10;
    i.snapshot.sells = 25;
    expect(detectMoonbagEmergency(i, thresholds)).toBe('EMERGENCY_BUY_SELL_RATIO');
  });
  it('detects whale distribution', () => {
    const i = base();
    i.snapshot.whaleConcentrationPct = 55;
    expect(detectMoonbagEmergency(i, thresholds)).toBe('EMERGENCY_WHALE_DISTRIBUTION');
  });
  it('applies priority order (stale beats all)', () => {
    const i = base();
    i.priceAgeMs = 61_000;
    i.sellRouteOk = false;
    i.snapshot.liquidityUsd = 0;
    expect(detectMoonbagEmergency(i, thresholds)).toBe('EMERGENCY_STALE_PRICE');
  });
});
