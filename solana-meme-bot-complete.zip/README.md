# Capital Recovery + Moonbag + Trailing Stop

Production-ready capital-protection layer for the Solana meme momentum bot.

**Strategy:** BUY -> monitor profit -> at **+20%** sell only enough tokens to
recover *capital + all buy fees + priority fees + estimated exit fees + a safety
buffer* -> keep the rest as a **moonbag** (risk now = 0) -> ride it with a **10%
trailing stop** -> exit on the trailing stop or on any emergency signal.

Before recovery the original **-15% stop-loss stays active**. The original
take-profit and old trailing logic are disabled while recovery is enabled, so the
two systems never fight. After recovery the position is handed entirely to this
subsystem's trailing stop.

---

## How to install (server, from the project root)

```bash
# 1. extract — adds new files, overwrites nothing existing
unzip -o recovery-moonbag.zip -d .

# 2. patch the existing files in place (idempotent, writes .bak backups)
node recovery-apply.js

# 3. build + test + restart
npm run build
npm test
pm2 restart solana-meme-bot --update-env
```

`recovery-apply.js` prints `PATCHED` / `SKIP` / `ANCHOR` per file and exits
non-zero if a required patch fails (no file is half-written). Re-running is safe.

---

## What files to replace / add

**You do NOT manually replace anything.** `unzip -o` drops in the new files and
`node recovery-apply.js` edits the existing ones for you. For transparency:

### NEW files (added by the zip)

| File | Purpose |
|---|---|
| `src/execution/recovery/TrailingStopManager.ts` | Ratchet-up-only 10% trailing stop |
| `src/execution/recovery/CapitalRecoveryManager.ts` | Computes exactly how many tokens to sell to recover capital + all fees + buffer |
| `src/execution/recovery/MarketGuard.ts` | DexScreener snapshots + all 6 emergency-exit rules |
| `src/execution/recovery/RecoveryOrchestrator.ts` | The brain: wires events, recovery, moonbag, trailing, emergencies |
| `src/db/repositories/MoonbagRepository.ts` | Persistence for lifecycle + moonbag analytics |
| `src/db/migrations/004_capital_recovery.sql` | `moonbag_lifecycle` table + indexes |
| `tests/unit/execution/recovery/TrailingStopManager.test.ts` | Unit tests |
| `tests/unit/execution/recovery/CapitalRecoveryManager.test.ts` | Unit tests |
| `tests/unit/execution/recovery/MarketGuard.test.ts` | Unit tests |

### PATCHED files (edited in place by `recovery-apply.js`)

| File | Change |
|---|---|
| `src/config/schema.ts` | Adds the `recovery` config block |
| `src/config/AppConfig.ts` | Applies the `*_PERCENT` / position env overrides |
| `src/db/Database.ts` | Registers migration `004` + adds 9 columns to `positions` |
| `src/risk/StopLossManager.ts` | Gates TP/old-trailing behind `recoveryEnabled`; adds `releaseManaged()` |
| `src/index.ts` | Boots `RecoveryOrchestrator` on startup, stops it on shutdown |
| `src/config/default.yaml` | `fixedPositionSizeSol 0.01 -> 0.04`, `maxConcurrentPositions 1 -> 2`, `maxOpenPositions 1 -> 2`, adds a `recovery:` block |

---

## Config & env vars

Defaults live in `src/config/default.yaml` (`recovery:` block) and `schema.ts`.
Env vars override them (percent values are whole numbers, divided by 100):

| Env var | Default | Meaning |
|---|---|---|
| `CAPITAL_RECOVERY_TRIGGER_PERCENT` | `20` | Recover capital at +20% |
| `TRAILING_STOP_PERCENT` | `10` | Moonbag trailing stop |
| `LIQUIDITY_DROP_EXIT_PERCENT` | `30` | Emergency exit on liquidity drop |
| `VOLUME_DROP_EXIT_PERCENT` | `70` | Emergency exit on volume drop |
| `STALE_PRICE_SECONDS` | `60` | Emergency exit on stale price |
| `RECOVERY_ENABLED` | `true` | Master on/off |
| `BIRDEYE_API_KEY` | _(unset)_ | Optional; enables the whale-distribution check. If unset, that one check is skipped — everything else still works. |

Buy amount is now **0.04 SOL/order** and up to **2 open positions** as requested.

---

## Notes

- The partial recovery sell does **not** decrement the exposure manager; the
  position stays "open" until the moonbag fully exits.
- When a moonbag exits, a synthetic `TRADE_FILLED` (sell) event is emitted so
  exposure/risk slots free up correctly.
- `closed_positions.exit_reason` is constrained, so trailing exits map to
  `trailing` and emergency exits map to `circuit`; the precise reason
  (e.g. `EMERGENCY_VOLUME_DROP`) is recorded in `moonbag_lifecycle`.
- Price sources fall back automatically: Jupiter -> Birdeye -> DexScreener -> Pool.
