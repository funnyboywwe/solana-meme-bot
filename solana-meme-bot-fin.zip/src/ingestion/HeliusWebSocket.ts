import { BaseWebSocketClient } from './BaseWebSocketClient';
import { EventBus, TradeDetectedEvent, TokenCreatedEvent } from '../core/EventBus';
import { createModuleLogger } from '../core/Logger';
import { AppConfig } from '../config/AppConfig';

import { getSolPriceUsd } from '../core/SolPrice';

const logger = createModuleLogger('HeliusWebSocket');

// DEX / AMM program IDs whose transactions represent real swap / trade activity.
// Narrowing transactionSubscribe's accountInclude to these gives us a focused
// live trade stream (volume, buy pressure, velocity) instead of an empty
// accountInclude that yields no usable TRADE_DETECTED events. accountInclude is
// OR-matched: any tx touching ANY of these programs is delivered.
const DEX_PROGRAM_IDS = [
  '675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8', // Raydium Liquidity Pool AMM V4
  'pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA',  // Pump AMM (PumpSwap) — post-migration trading
  '6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P',  // Pump.fun bonding curve
];

// Quote-side mints that are never the "new" token in a fresh pool.
const WSOL_MINT = 'So11111111111111111111111111111111111111112';
const QUOTE_MINTS = new Set<string>([
  WSOL_MINT,
  'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v', // USDC
  'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB', // USDT
]);

interface TokenBalanceEntry {
  mint: string;
  owner: string;
  uiTokenAmount: { amount: string; decimals: number; uiAmount: number | null };
}

interface EnhancedTxValue {
  transaction: { signatures: string[]; message?: unknown };
  meta: {
    err: unknown | null;
    postTokenBalances?: TokenBalanceEntry[];
    preTokenBalances?: TokenBalanceEntry[];
    logMessages?: string[];
  };
}

/**
 * HeliusWebSocketClient subscribes to Helius enhanced transaction stream.
 *
 * BUG FIXED (#5): API key is now appended to the WS URL as a query param.
 * Helius requires: wss://atlas-mainnet.helius-rpc.com?api-key=<KEY>
 *
 * BUG FIXED (#6): Added maxSupportedTransactionVersion: 0 to subscription
 * params — required for versioned transactions (Jupiter swaps use V0 txs).
 */
export class HeliusWebSocketClient extends BaseWebSocketClient {
  // Live new-launch detection: de-dupe mints we've already announced so a
  // burst of post-creation swaps doesn't re-emit TOKEN_CREATED for the same token.
  private seenNewMints = new Map<string, number>();
  private readonly NEW_MINT_TTL_MS = 10 * 60 * 1000;

  constructor(cfg: AppConfig) {
    // Build the WS URL robustly. HELIUS_WS_URL may or may not already carry
    // the api-key query param. Appending a second "?api-key=" produced a
    // malformed URL (two query strings) and a 401 handshake rejection.
    const base = cfg.rpc.heliusWsUrl;
    let wsUrl: string;
    if (/[?&]api-key=/.test(base)) {
      // Key already present in the configured URL — use as-is.
      wsUrl = base;
    } else if (cfg.rpc.heliusApiKey) {
      const sep = base.includes('?') ? '&' : '?';
      wsUrl = `${base}${sep}api-key=${cfg.rpc.heliusApiKey}`;
    } else {
      wsUrl = base;
    }
    super(wsUrl, 'HeliusWebSocket');
  }

  override async connect(): Promise<void> {
    await super.connect();
    this._subscribeTransactions();
  }

  private _subscribeTransactions(): void {
    // FIX: correct Helius transactionSubscribe params with required fields
    const subscription = {
      jsonrpc: '2.0',
      id: 1,
      method: 'transactionSubscribe',
      params: [
        {
          failed: false,
          accountInclude: DEX_PROGRAM_IDS,  // narrow to Raydium/Pump AMM swap activity
          accountExclude: [],
          accountRequired: [],
        },
        {
          commitment: 'confirmed',
          encoding: 'jsonParsed',
          transactionDetails: 'full',
          showRewards: false,
          maxSupportedTransactionVersion: 0,  // FIX: required for V0 versioned txs
        },
      ],
    };

    this.subscriptions['tx_subscribe'] = subscription;
    this.send(subscription);
    logger.info('Helius transactionSubscribe sent');
  }

  protected onMessage(message: unknown): void {
    const msg = message as Record<string, unknown>;

    // Subscription confirmation
    if (typeof msg['result'] === 'number') {
      logger.info('Helius subscription confirmed', { subscriptionId: msg['result'] });
      return;
    }

    // Transaction notification
    const params = msg['params'] as Record<string, unknown> | undefined;
    if (!params) return;

    const result = params['result'] as Record<string, unknown> | undefined;
    if (!result) return;

    const value = result['value'] as EnhancedTxValue | undefined;
    if (!value?.transaction) return;

    this._processTx(value);
  }

  private _processTx(tx: EnhancedTxValue): void {
    try {
      // Skip failed transactions
      if (tx.meta?.err) return;

      const txHash = tx.transaction?.signatures?.[0];
      if (!txHash) return;

      // NEW: detect a brand-new launch from this tx in real time (no 10s poll lag).
      this._maybeEmitNewPool(tx, txHash);

      const preBalances = tx.meta?.preTokenBalances ?? [];
      const postBalances = tx.meta?.postTokenBalances ?? [];

      for (const post of postBalances) {
        const pre = preBalances.find(
          (p) => p.mint === post.mint && p.owner === post.owner,
        );

        const preAmount = pre ? parseFloat(pre.uiTokenAmount.amount) : 0;
        const postAmount = parseFloat(post.uiTokenAmount.amount);

        if (postAmount === preAmount) continue; // no change

        const side = postAmount > preAmount ? 'buy' : 'sell';
        const amountDelta = Math.abs(postAmount - preAmount);
        const decimals = post.uiTokenAmount.decimals;
        const humanDelta = amountDelta / Math.pow(10, decimals);

        // Rough USD estimate — price oracle will refine this
        const roughSol = 0.01;
        const roughUsd = roughSol * getSolPriceUsd();
        const priceUsd = humanDelta > 0 ? roughUsd / humanDelta : 0;

        EventBus.emit('TRADE_DETECTED', {
          mint: post.mint,
          side,
          amountUsd: roughUsd,
          amountSol: roughSol,
          priceUsd,
          walletAddress: post.owner,
          txHash,
          ts: Date.now(),
          poolAddress: '',
        } as TradeDetectedEvent);
      }
    } catch (err) {
      logger.error('Helius tx processing failed', { error: String(err) });
    }
  }

  /**
   * Detect a brand-new launch from the live transaction stream and emit
   * TOKEN_CREATED immediately — far faster than the 10s Raydium poll.
   *
   * We only treat a tx as a launch when its logs contain a pool/token
   * *creation* instruction (not a swap). The new token mint is read from the
   * token balances (the non-quote mint). createdAt is "now" because we are
   * witnessing the creation live, which naturally satisfies the
   * fresh-launch-only requirement (the gate's max-age check still applies).
   */
  private _maybeEmitNewPool(tx: EnhancedTxValue, txHash: string): void {
    const logs = tx.meta?.logMessages;
    if (!logs || logs.length === 0) return;

    let source: 'pumpfun' | 'raydium' | null = null;
    for (const line of logs) {
      // Pump.fun bonding-curve token creation
      if (line.includes('Instruction: Create') || line.includes('Instruction: InitializeMint2')) {
        source = 'pumpfun';
        break;
      }
      // Raydium AMM V4 new pool initialization
      if (line.includes('initialize2') || line.includes('Instruction: Initialize2')) {
        source = 'raydium';
        break;
      }
    }
    if (!source) return;

    // Identify the newly created (non-quote) token mint from balances.
    const balances = [
      ...(tx.meta?.postTokenBalances ?? []),
      ...(tx.meta?.preTokenBalances ?? []),
    ];
    let mint: string | undefined;
    let decimals = 9;
    for (const b of balances) {
      if (!QUOTE_MINTS.has(b.mint)) {
        mint = b.mint;
        decimals = b.uiTokenAmount?.decimals ?? 9;
        break;
      }
    }
    if (!mint) return;

    // De-dupe: announce each new mint only once within the TTL window.
    const now = Date.now();
    const lastSeen = this.seenNewMints.get(mint);
    if (lastSeen && now - lastSeen < this.NEW_MINT_TTL_MS) return;
    this.seenNewMints.set(mint, now);
    if (this.seenNewMints.size > 5000) {
      this.seenNewMints.forEach((ts, k) => {
        if (now - ts > this.NEW_MINT_TTL_MS) this.seenNewMints.delete(k);
      });
    }

    logger.info('New launch detected from live stream', { mint, source, txHash });
    EventBus.emit('TOKEN_CREATED', {
      mint,
      symbol: '',
      decimals,
      initialLiquidityUsd: 0,
      poolAddress: '',
      createdAt: now,
      source,
    } as TokenCreatedEvent);
  }

  protected resubscribe(_key: string, _state: unknown): void {
    this._subscribeTransactions();
  }
}

export default HeliusWebSocketClient;
