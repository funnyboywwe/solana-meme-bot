import { BaseWebSocketClient } from './BaseWebSocketClient';
import {
  EventBus,
  TokenCreatedEvent,
  PriceUpdateEvent,
  MomentumSignalEvent,
} from '../core/EventBus';
import { createModuleLogger } from '../core/Logger';
import { AppConfig } from '../config/AppConfig';
import { ExtendedConfig } from '../config/schema';
import axios from 'axios';

const logger = createModuleLogger('DexScreenerMonitor');

// ─── DexScreener public REST API (no key required) ───────────────────────────
// Docs: https://docs.dexscreener.com/api/reference
//  - /token-boosts/top/v1        → trending/boosted tokens (rate-limit 60/min)
//  - /tokens/v1/{chain}/{addrs}  → full pair data for up to 30 token addresses
//  - /latest/dex/search?q=...    → up to 30 matching pairs (rate-limit 300/min)
// These aggregate endpoints already expose volume / priceChange / txns /
// liquidity over 5m & 1h windows, so we can compute momentum WITHOUT a live
// transaction stream (the Helius transactionSubscribe feed is Atlas-only and
// delivers nothing on the standard endpoint).
const DS_BASE = 'https://api.dexscreener.com';
const BOOSTS_URL = `${DS_BASE}/token-boosts/top/v1`;
const TOKENS_URL = `${DS_BASE}/tokens/v1`; // /{chainId}/{comma-separated addrs}
const SEARCH_URL = `${DS_BASE}/latest/dex/search`;
const WSOL = 'So11111111111111111111111111111111111111112';
const USDC = 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v';
const USDT = 'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB';
const QUOTE_MINTS = new Set<string>([WSOL, USDC, USDT]);

// ─── DexScreener response shapes (only the fields we consume) ─────────────────
interface DsBoostEntry {
  chainId: string;
  tokenAddress: string;
  amount?: number;
  totalAmount?: number;
}

interface DsTxnWindow {
  buys?: number;
  sells?: number;
}

interface DsPair {
  chainId: string;
  dexId?: string;
  pairAddress: string;
  baseToken: { address: string; name?: string; symbol?: string };
  quoteToken: { address: string; symbol?: string };
  priceUsd?: string;
  liquidity?: { usd?: number; base?: number; quote?: number };
  fdv?: number;
  marketCap?: number;
  pairCreatedAt?: number;
  volume?: { m5?: number; h1?: number; h6?: number; h24?: number };
  priceChange?: { m5?: number; h1?: number; h6?: number; h24?: number };
  txns?: {
    m5?: DsTxnWindow;
    h1?: DsTxnWindow;
    h6?: DsTxnWindow;
    h24?: DsTxnWindow;
  };
}

interface ScoredCandidate {
  pair: DsPair;
  mint: string;
  symbol: string;
  priceUsd: number;
  liquidityUsd: number;
  score: number;
  breakdown: MomentumSignalEvent['breakdown'];
}

/**
 * DexScreenerMonitor — trending-momentum ingestion.
 *
 * Strategy (per user request #65): pull the hottest trending Solana tokens from
 * DexScreener, pick the top N by a momentum score computed from the aggregate
 * 5m/1h volume, price change, buy/sell pressure and liquidity, then drive the
 * existing pipeline:
 *   1. emit TOKEN_CREATED   → persists the token row + runs SafetyEngine
 *   2. emit PRICE_UPDATE    → feeds PriceOracle / stop-loss / momentum
 *   3. emit MOMENTUM_SIGNAL → HybridEntryGate re-checks safety + conditions and,
 *                             if it passes, approves the entry → risk → execute.
 *
 * This replaces the dead Helius trade stream as the momentum source. It does not
 * need any websocket; it mirrors RaydiumMonitor's REST-poll pattern (extends
 * BaseWebSocketClient but overrides connect() to run a timer instead of opening
 * a socket).
 */
export class DexScreenerMonitor extends BaseWebSocketClient {
  private cfg: ExtendedConfig['dexScreener'];
  private pollTimer: NodeJS.Timeout | null = null;
  private seenMints = new Set<string>();

  constructor(_baseCfg: AppConfig, extCfg: ExtendedConfig) {
    // No real socket URL — connect() is overridden to poll REST instead.
    super('wss://io.dexscreener.com/dex/screener', 'DexScreenerMonitor');
    this.cfg = extCfg.dexScreener;
  }

  override async connect(): Promise<void> {
    if (!this.cfg.enabled) {
      logger.info('DexScreenerMonitor disabled via config');
      return;
    }
    logger.info('DexScreenerMonitor starting (REST polling)', {
      pollIntervalMs: this.cfg.pollIntervalMs,
      topN: this.cfg.topN,
      minLiquidityUsd: this.cfg.minLiquidityUsd,
      minScoreToSignal: this.cfg.minScoreToSignal,
    });
    this.connected = true;
    EventBus.emit('WS_STATUS', { client: 'DexScreenerMonitor', status: 'connected', ts: Date.now() });
    await this._poll(); // immediate first poll
    this.pollTimer = setInterval(() => void this._poll(), this.cfg.pollIntervalMs);
    this.pollTimer.unref();
  }

  private async _poll(): Promise<void> {
    try {
      const addresses = await this._discoverTrendingAddresses();
      if (addresses.length === 0) {
        logger.debug('DexScreener: no trending Solana tokens discovered this cycle');
        return;
      }

      const pairs = await this._fetchPairs(addresses);
      if (pairs.length === 0) {
        logger.debug('DexScreener: no pair data returned this cycle');
        return;
      }

      // Keep the single best (most liquid) SOL/stable-quoted pair per token.
      const bestByMint = new Map<string, DsPair>();
      for (const p of pairs) {
        if (p.chainId !== this.cfg.chainId) continue;
        const base = p.baseToken?.address;
        if (!base || base === WSOL) continue;
        // Only momentum-trade tokens quoted in SOL or a major stable.
        if (!QUOTE_MINTS.has(p.quoteToken?.address ?? '')) continue;
        const liq = p.liquidity?.usd ?? 0;
        const existing = bestByMint.get(base);
        if (!existing || liq > (existing.liquidity?.usd ?? 0)) bestByMint.set(base, p);
      }

      // Score every candidate and rank.
      const candidates: ScoredCandidate[] = [];
      for (const p of bestByMint.values()) {
        const liquidityUsd = p.liquidity?.usd ?? 0;
        if (liquidityUsd < this.cfg.minLiquidityUsd) continue;
        const v5 = p.volume?.m5 ?? 0;
        if (v5 < this.cfg.minVolume5mUsd) continue;
        const priceUsd = Number(p.priceUsd ?? 0);
        if (!Number.isFinite(priceUsd) || priceUsd <= 0) continue;

        const { total, breakdown } = this._score(p);
        candidates.push({
          pair: p,
          mint: p.baseToken.address,
          symbol: p.baseToken.symbol ?? 'UNK',
          priceUsd,
          liquidityUsd,
          score: total,
          breakdown,
        });
      }

      candidates.sort((a, b) => b.score - a.score);
      const top = candidates.slice(0, this.cfg.topN);

      if (top.length === 0) {
        logger.debug('DexScreener: no candidates cleared liquidity/volume floors');
        return;
      }

      logger.info('DexScreener trending scan complete', {
        discovered: addresses.length,
        scored: candidates.length,
        top: top.length,
        leader: top[0] ? { mint: top[0].mint, symbol: top[0].symbol, score: Number(top[0].score.toFixed(1)) } : null,
      });

      const now = Date.now();
      for (const c of top) {
        // 1) Register the token once (persist row + run safety + holder tracking).
        if (!this.seenMints.has(c.mint)) {
          this.seenMints.add(c.mint);
          const createdAt =
            c.pair.pairCreatedAt && c.pair.pairCreatedAt > 0 ? c.pair.pairCreatedAt : now;
          logger.info('New trending token from DexScreener', {
            mint: c.mint,
            symbol: c.symbol,
            score: Number(c.score.toFixed(1)),
            liquidityUsd: Math.round(c.liquidityUsd),
          });
          EventBus.emit('TOKEN_CREATED', {
            mint: c.mint,
            symbol: c.symbol,
            decimals: 6,
            initialLiquidityUsd: c.liquidityUsd,
            poolAddress: c.pair.pairAddress,
            createdAt,
            source: 'unknown',
          } as TokenCreatedEvent);
        }

        // 2) Feed price + liquidity so PriceOracle/stop-loss/momentum stay fresh.
        EventBus.emit('PRICE_UPDATE', {
          mint: c.mint,
          priceUsd: c.priceUsd,
          liquidityUsd: c.liquidityUsd,
          ts: now,
        } as PriceUpdateEvent);

        // 3) Emit a momentum signal for tokens whose momentum clears the floor.
        //    HybridEntryGate re-checks safety + age + liquidity/mcap before any buy.
        if (c.score >= this.cfg.minScoreToSignal) {
          logger.info('DexScreener momentum signal', {
            mint: c.mint,
            symbol: c.symbol,
            score: Number(c.score.toFixed(1)),
            breakdown: {
              buy: Number(c.breakdown.buyScore.toFixed(0)),
              accel: Number(c.breakdown.accelScore.toFixed(0)),
              volume: Number(c.breakdown.volumeScore.toFixed(0)),
            },
          });
          EventBus.emit('MOMENTUM_SIGNAL', {
            mint: c.mint,
            score: c.score,
            breakdown: c.breakdown,
            ts: now,
          } as MomentumSignalEvent);
        }
      }
    } catch (err) {
      logger.warn('DexScreener poll failed', { error: String(err) });
    }
  }

  /**
   * Discover trending Solana token addresses from (a) the boosted/trending list
   * and (b) a broad SOL search. Returns a de-duplicated list capped at 30 (the
   * batch limit of the /tokens endpoint).
   */
  private async _discoverTrendingAddresses(): Promise<string[]> {
    const found = new Set<string>();

    // (a) Boosted / trending tokens.
    try {
      const res = await axios.get<DsBoostEntry[]>(BOOSTS_URL, { timeout: 12000 });
      const list = Array.isArray(res.data) ? res.data : [];
      for (const b of list) {
        if (b.chainId === this.cfg.chainId && b.tokenAddress) found.add(b.tokenAddress);
      }
    } catch (err) {
      logger.debug('DexScreener boosts fetch failed', { error: String(err) });
    }

    // (b) Broad search to surface hot SOL pairs not currently boosted.
    try {
      const res = await axios.get<{ pairs?: DsPair[] }>(SEARCH_URL, {
        timeout: 12000,
        params: { q: 'SOL' },
      });
      const pairs = Array.isArray(res.data?.pairs) ? res.data.pairs : [];
      for (const p of pairs) {
        if (p.chainId !== this.cfg.chainId) continue;
        const base = p.baseToken?.address;
        if (base && base !== WSOL && QUOTE_MINTS.has(p.quoteToken?.address ?? '')) {
          found.add(base);
        }
      }
    } catch (err) {
      logger.debug('DexScreener search fetch failed', { error: String(err) });
    }

    return Array.from(found).slice(0, 30);
  }

  /** Fetch full pair data for the given token addresses (batched, max 30). */
  private async _fetchPairs(addresses: string[]): Promise<DsPair[]> {
    const joined = addresses.slice(0, 30).join(',');
    const url = `${TOKENS_URL}/${this.cfg.chainId}/${joined}`;
    const res = await axios.get<DsPair[]>(url, { timeout: 15000 });
    return Array.isArray(res.data) ? res.data : [];
  }

  /**
   * Compute a 0-100 momentum score from DexScreener aggregate metrics.
   * Higher = stronger short-term upward momentum.
   */
  private _score(p: DsPair): { total: number; breakdown: MomentumSignalEvent['breakdown'] } {
    const liq = p.liquidity?.usd ?? 0;
    const v5 = p.volume?.m5 ?? 0;
    const pc5 = p.priceChange?.m5 ?? 0;
    const pc1h = p.priceChange?.h1 ?? 0;
    const b5 = p.txns?.m5?.buys ?? 0;
    const s5 = p.txns?.m5?.sells ?? 0;
    const tx5 = b5 + s5;

    const clamp = (n: number): number => Math.max(0, Math.min(100, n));

    // Buy pressure: 0.5 ratio → 0, 1.0 ratio → 100.
    const buyRatio = tx5 > 0 ? b5 / tx5 : 0.5;
    const buyScore = clamp((buyRatio - 0.5) * 200);

    // Price acceleration: weight recent 5m change heavily, add some 1h trend.
    const accelScore = clamp(pc5 * 4 + pc1h);

    // Volume turnover: 5m volume relative to liquidity (10% in 5m → 100).
    const turnover = liq > 0 ? v5 / liq : 0;
    const volumeScore = clamp(turnover * 1000);

    // Trade velocity: number of 5m txns (50 txns → 100).
    const velocityScore = clamp(tx5 * 2);

    // Liquidity depth: mild contribution ($100k → 100).
    const liquidityScore = clamp((liq / 100000) * 100);

    const total =
      buyScore * 0.3 +
      accelScore * 0.3 +
      volumeScore * 0.25 +
      velocityScore * 0.1 +
      liquidityScore * 0.05;

    return {
      total,
      breakdown: { volumeScore, buyScore, velocityScore, liquidityScore, accelScore },
    };
  }

  protected onMessage(_message: unknown): void {}
  protected resubscribe(_key: string, _state: unknown): void {}

  override disconnect(): void {
    if (this.pollTimer) {
      clearInterval(this.pollTimer);
      this.pollTimer = null;
    }
    this.connected = false;
    logger.info('DexScreenerMonitor disconnected');
  }
}

export default DexScreenerMonitor;
