import axios from 'axios';
import { Connection, VersionedTransaction, Keypair } from '@solana/web3.js';
import { createModuleLogger } from '../../core/Logger';
import { AppConfig } from '../../config/AppConfig';
import { ExtendedConfig } from '../../config/schema';
import { EventBus, MEVDetectedEvent } from '../../core/EventBus';
import { getDb } from '../../db/Database';
import { getRpcManager, RpcManager } from '../../core/RpcManager';
import { getWriteRpcProvider, WriteRpcProvider } from '../../core/WriteRpcProvider';

const logger = createModuleLogger('MEVProtection');

export interface MEVSubmitOptions {
  txBase64: string;
  mint?: string;
  expectedOutAmount: number;
  slippageBps: number;
  priorityFeeMicroLamports: number;
}

export interface MEVSubmitResult {
  success: boolean;
  txHash?: string;
  bundleId?: string;
  usedJito: boolean;
  tipLamports: number;
  error?: string;
}

/**
 * MEVProtection handles:
 * 1. Sandwich attack detection (price moved before/after quote)
 * 2. Front-run protection (delay between quote and submit)
 * 3. Jito bundle submission (bypasses mempool, prevents sandwiching)
 * 4. Dynamic priority fee adaptation (higher fee under congestion)
 * 5. Failed-fill detection (actual out < expected - slippage)
 * 6. Automatic retry with Jito if normal submit fails
 */
export class MEVProtection {
  private cfg: ExtendedConfig['mevProtection'];
  private rpc: RpcManager;
  // C-5: broadcast through the WRITE pool (OrbitFlare primary + failover) rather
  // than the read connection, which was the wrong endpoint for sends.
  private write: WriteRpcProvider;
  private get connection(): Connection { return this.rpc.getConnection(); }
  private keypair: Keypair;
  private rpcUrl: string;
  private jitoUrl: string;
  private consecutiveFailures = 0;
  private readonly MAX_CONSECUTIVE_FAILURES = 3;

  constructor(baseCfg: AppConfig, extCfg: ExtendedConfig, keypair: Keypair) {
    this.cfg = extCfg.mevProtection;
    this.rpc = getRpcManager(baseCfg);
    this.write = getWriteRpcProvider(baseCfg);
    this.keypair = keypair;
    this.rpcUrl = baseCfg.rpc.rpcHttpUrl;
    this.jitoUrl = this.cfg.jitoBlockEngineUrl;
  }

  /**
   * Submit transaction with MEV protection.
   * Tries normal RPC first; falls back to Jito if enabled and fails.
   */
  async submit(opts: MEVSubmitOptions): Promise<MEVSubmitResult> {
    const { txBase64, mint } = opts;

    // Front-run protection: small delay between quote and submit
    if (this.cfg.frontRunProtectionMs > 0) {
      await this._sleep(this.cfg.frontRunProtectionMs);
    }

    // Deserialise and sign
    const txBytes = Buffer.from(txBase64, 'base64');
    const tx = VersionedTransaction.deserialize(txBytes);
    tx.sign([this.keypair]);
    const signedBytes = tx.serialize();

    // Try normal RPC submission first
    try {
      const txHash = await this.write.sendRawTransaction(signedBytes, {
        skipPreflight: false,
        maxRetries: 0,
        preflightCommitment: 'confirmed',
      });

      this.consecutiveFailures = 0;
      logger.info('Transaction submitted via RPC', { txHash, mint });
      return { success: true, txHash, usedJito: false, tipLamports: 0 };
    } catch (rpcErr) {
      const errMsg = rpcErr instanceof Error ? rpcErr.message : String(rpcErr);
      this.consecutiveFailures++;

      // Detect sandwich / front-run patterns
      if (this.cfg.sandwichDetectionEnabled && this._isSandwichError(errMsg)) {
        logger.warn('Potential sandwich attack detected', { mint, error: errMsg });
        this._logMEVEvent({ eventType: 'sandwich', mint, txHash: '', costSol: 0, slippageActualBps: opts.slippageBps * 2, slippageExpectedBps: opts.slippageBps });
        EventBus.emit('MEV_DETECTED', { eventType: 'sandwich', tokenMint: mint, txHash: '', estimatedCostSol: 0.001, ts: Date.now() } as MEVDetectedEvent);
      }

      // Retry with Jito if enabled
      if (this.cfg.jitoEnabled && this.cfg.retryWithJitoOnFail) {
        logger.info('Retrying via Jito bundle', { mint });
        return this._submitViaJito(tx, mint);
      }

      return { success: false, usedJito: false, tipLamports: 0, error: errMsg };
    }
  }

  /** Submit transaction as a Jito bundle to bypass public mempool */
  private async _submitViaJito(tx: VersionedTransaction, mint?: string): Promise<MEVSubmitResult> {
    if (!this.cfg.jitoEnabled) {
      return { success: false, usedJito: false, tipLamports: 0, error: 'Jito disabled' };
    }

    const tipLamports = this.cfg.jitoTipLamports;

    try {
      // Jito bundles API — send bundle of transactions
      const txBase64 = Buffer.from(tx.serialize()).toString('base64');
      const response = await axios.post<{ result: string }>(
        `${this.jitoUrl}/api/v1/bundles`,
        {
          jsonrpc: '2.0',
          id: 1,
          method: 'sendBundle',
          params: [[txBase64]],
        },
        {
          headers: { 'Content-Type': 'application/json' },
          timeout: 15000,
        },
      );

      const bundleId = response.data?.result;
      if (!bundleId) throw new Error('No bundle ID returned from Jito');

      this._logMEVEvent({ eventType: 'jito_bundle', mint, txHash: '', costSol: tipLamports / 1e9, slippageActualBps: 0, slippageExpectedBps: 0, bundleId, tipLamports });
      logger.info('Jito bundle submitted', { bundleId, mint, tipLamports });

      return { success: true, bundleId, usedJito: true, tipLamports };
    } catch (err) {
      const errMsg = err instanceof Error ? err.message : String(err);
      logger.error('Jito bundle submission failed', { error: errMsg });
      return { success: false, usedJito: true, tipLamports, error: errMsg };
    }
  }

  /**
   * Compute adaptive priority fee based on network congestion.
   * Under heavy load (many consecutive failures), increase fee.
   */
  computeAdaptivePriorityFee(baseFee: number): number {
    const multiplier = Math.min(1 + this.consecutiveFailures * 0.5, 3.0);
    const adapted = Math.round(baseFee * multiplier);
    const capped = Math.min(adapted, baseFee + this.cfg.maxSlippageAdaptBps * 100);
    if (multiplier > 1) {
      logger.debug('Adaptive priority fee', { baseFee, adapted, multiplier });
    }
    return capped;
  }

  /**
   * Detect if actual output is below the expected threshold (failed fill / sandwich).
   */
  /** sandwichDetectionEnabled guards both attack-pattern and failed-fill detection */
  detectFailedFill(expectedOut: number, actualOut: number, slippageBps: number, mint?: string): boolean {
    if (!this.cfg.sandwichDetectionEnabled) return false;
    const minAcceptable = expectedOut * (1 - slippageBps / 10000);
    if (actualOut < minAcceptable) {
      const lossRatio = (expectedOut - actualOut) / expectedOut;
      logger.warn('Failed fill detected', { expectedOut, actualOut, lossRatio: (lossRatio * 100).toFixed(2) + '%', mint });
      this._logMEVEvent({
        eventType: 'failed_fill',
        mint,
        txHash: '',
        costSol: (expectedOut - actualOut) / 1e9,
        slippageActualBps: Math.round(lossRatio * 10000),
        slippageExpectedBps: slippageBps,
      });
      EventBus.emit('MEV_DETECTED', { eventType: 'failed_fill', tokenMint: mint, txHash: '', estimatedCostSol: (expectedOut - actualOut) / 1e9, ts: Date.now() } as MEVDetectedEvent);
      return true;
    }
    return false;
  }

  private _isSandwichError(errMsg: string): boolean {
    const sandwichPatterns = ['slippage tolerance exceeded', 'custom program error: 0x1771', 'AmountOutBelowMinimum', 'slippage'];
    return sandwichPatterns.some((p) => errMsg.toLowerCase().includes(p.toLowerCase()));
  }

  private _logMEVEvent(event: { eventType: string; mint?: string; txHash: string; costSol: number; slippageActualBps: number; slippageExpectedBps: number; bundleId?: string; tipLamports?: number }): void {
    try {
      getDb().prepare(`
        INSERT INTO mev_events (tx_hash, event_type, token_mint, cost_sol, slippage_actual_bps, slippage_expected_bps, bundle_id, tip_lamports, detected_ts, resolved)
        VALUES (@tx_hash, @event_type, @token_mint, @cost_sol, @slippage_actual_bps, @slippage_expected_bps, @bundle_id, @tip_lamports, @detected_ts, 0)
      `).run({
        tx_hash: event.txHash,
        event_type: event.eventType,
        token_mint: event.mint ?? null,
        cost_sol: event.costSol,
        slippage_actual_bps: event.slippageActualBps,
        slippage_expected_bps: event.slippageExpectedBps,
        bundle_id: event.bundleId ?? null,
        tip_lamports: event.tipLamports ?? 0,
        detected_ts: Date.now(),
      });
    } catch { /* non-critical */ }
  }

  resetFailureCount(): void {
    this.consecutiveFailures = 0;
  }

  private _sleep(ms: number): Promise<void> {
    return new Promise((r) => setTimeout(r, ms));
  }
}

export default MEVProtection;
