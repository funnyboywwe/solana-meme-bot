import { Connection, TransactionSignature } from '@solana/web3.js';
import { createModuleLogger } from '../core/Logger';
import { AppConfig } from '../config/AppConfig';
import { getRpcManager, RpcManager } from '../core/RpcManager';
import { getWriteRpcProvider, WriteRpcProvider } from '../core/WriteRpcProvider';

const logger = createModuleLogger('TxConfirmation');

export type ConfirmationStatus = 'confirmed' | 'failed' | 'timeout' | 'not_found';

export interface ConfirmationResult {
  status: ConfirmationStatus;
  slot?: number;
  err?: string;
}

/**
 * TxConfirmation watches a submitted transaction until:
 * - Confirmed (finalized on-chain)
 * - Failed (on-chain error)
 * - Timeout (txConfirmTimeoutMs elapsed)
 *
 * Strategy:
 * 1. Use WebSocket subscription (fast path)
 * 2. Fall back to polling every 2s if WS not received
 * 3. Timeout after cfg.execution.txConfirmTimeoutMs
 */
export class TxConfirmation {
  private rpc: RpcManager;
  private get connection(): Connection { return this.rpc.getReadConnection(); }
  // Confirmation is a WRITE-role concern: poll the same provider family that
  // broadcast the tx (OrbitFlare primary, QuickNode fallback).
  private write: WriteRpcProvider;
  private timeoutMs: number;

  constructor(cfg: AppConfig) {
    this.rpc = getRpcManager(cfg);
    this.write = getWriteRpcProvider(cfg);
    this.timeoutMs = cfg.execution.txConfirmTimeoutMs;
  }

  /**
   * Wait for transaction confirmation
   */
  async waitForConfirmation(txHash: TransactionSignature): Promise<ConfirmationResult> {
    return new Promise((resolve) => {
      let resolved = false;
      let pollInterval: NodeJS.Timeout | null = null;
      let subscriptionId: number | null = null;
      // A signature subscription is bound to ONE connection, so we pin the
      // current active write connection and use it for both subscribe and
      // unsubscribe. The polling fallback below still fails over independently.
      const subConn = this.write.getActiveConnection();
      // FIX: also watch the tx via the READ provider (Helius). The write
      // provider (OrbitFlare) broadcasts well but was NOT delivering signature
      // notifications here, and its status lookups kept missing landed txs, so
      // confirmations timed out at 60s even though the swap had executed —
      // causing wasteful duplicate re-broadcasts and "All sell retries
      // exhausted" on trades that had actually filled. Watching Helius in
      // parallel gives a dependable confirmation path. A subscription is bound
      // to ONE connection, so each id is removed on the connection that made it.
      const readConn = this.connection;
      let readSubscriptionId: number | null = null;

      const cleanup = () => {
        if (pollInterval) clearInterval(pollInterval);
        if (subscriptionId !== null) {
          subConn.removeSignatureListener(subscriptionId).catch(() => {});
        }
        if (readSubscriptionId !== null) {
          readConn.removeSignatureListener(readSubscriptionId).catch(() => {});
        }
      };

      const finish = (result: ConfirmationResult) => {
        if (resolved) return;
        resolved = true;
        cleanup();
        resolve(result);
      };

      // 1. WebSocket subscription (fast path)
      subscriptionId = subConn.onSignature(
        txHash,
        (result) => {
          if (result.err) {
            logger.warn('Transaction failed on-chain', { txHash, err: JSON.stringify(result.err) });
            finish({ status: 'failed', err: JSON.stringify(result.err) });
          } else {
            logger.info('Transaction confirmed via WS', { txHash });
            finish({ status: 'confirmed' });
          }
        },
        'confirmed',
      );

      // 1b. Second WS subscription on the READ provider (Helius). Whichever
      // path confirms first wins — finish() guards against double-resolve.
      try {
        readSubscriptionId = readConn.onSignature(
          txHash,
          (result) => {
            if (result.err) {
              logger.warn('Transaction failed on-chain', { txHash, err: JSON.stringify(result.err) });
              finish({ status: 'failed', err: JSON.stringify(result.err) });
            } else {
              logger.info('Transaction confirmed via WS (read)', { txHash });
              finish({ status: 'confirmed' });
            }
          },
          'confirmed',
        );
      } catch (err) {
        logger.warn('Read WS subscribe failed', { txHash, error: String(err) });
      }

      // 2. Polling fallback every 1.5s — query BOTH the read provider (Helius)
      // and the write provider and accept the first landed status. Previously
      // this polled only the write provider, which is why confirmations of
      // already-landed txs were missed and timed out.
      const checkStatus = async (): Promise<void> => {
        if (resolved) return;
        const [readRes, writeRes] = await Promise.allSettled([
          readConn.getSignatureStatuses([txHash], { searchTransactionHistory: true }),
          this.write.getSignatureStatus(txHash, { searchTransactionHistory: true }),
        ]);
        const candidates: any[] = [];
        if (readRes.status === 'fulfilled') candidates.push(readRes.value?.value?.[0]);
        if (writeRes.status === 'fulfilled') candidates.push(writeRes.value?.value);
        for (const status of candidates) {
          if (!status) continue; // not landed yet on this provider
          if (status.err) {
            finish({ status: 'failed', slot: status.slot, err: JSON.stringify(status.err) });
            return;
          }
          if (status.confirmationStatus === 'confirmed' || status.confirmationStatus === 'finalized') {
            logger.info('Transaction confirmed via polling', { txHash, slot: status.slot });
            finish({ status: 'confirmed', slot: status.slot });
            return;
          }
        }
      };
      pollInterval = setInterval(() => {
        checkStatus().catch((err) => logger.warn('Polling error', { txHash, error: String(err) }));
      }, 1500);
      pollInterval.unref();

      // 3. Timeout
      setTimeout(() => {
        if (!resolved) {
          logger.warn('Transaction confirmation timeout', { txHash, timeoutMs: this.timeoutMs });
          finish({ status: 'timeout' });
        }
      }, this.timeoutMs);
    });
  }
}

export default TxConfirmation;
