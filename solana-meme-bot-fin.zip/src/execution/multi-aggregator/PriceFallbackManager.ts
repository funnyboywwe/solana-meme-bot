import { IPriceSource, PriceQuote, LoggerLike, noopLogger } from './types';

/**
 * Price Fallback Manager (Requirement #5).
 *
 * Resolves a token's USD price by trying ordered price sources until one returns
 * a valid (> 0) price. Priority is Jupiter → Birdeye → DexScreener → pool
 * reserves. The last good price is cached per mint so callers can detect a stale
 * feed — this powers the position monitor's "no valid price for 60s" rule.
 */
export interface PriceFallbackConfig {
  /** A cached price older than this (ms) is considered stale and not returned. */
  maxStaleMs: number;
}

export const DEFAULT_PRICE_FALLBACK_CONFIG: PriceFallbackConfig = {
  maxStaleMs: 60_000,
};

interface CacheEntry {
  quote: PriceQuote;
  ts: number;
}

export class PriceFallbackManager {
  private readonly sources: IPriceSource[];
  private readonly cfg: PriceFallbackConfig;
  private readonly logger: LoggerLike;
  private readonly now: () => number;
  private readonly cache = new Map<string, CacheEntry>();

  constructor(
    sources: IPriceSource[],
    opts: { config?: Partial<PriceFallbackConfig>; logger?: LoggerLike; now?: () => number } = {},
  ) {
    this.sources = sources;
    this.cfg = { ...DEFAULT_PRICE_FALLBACK_CONFIG, ...(opts.config ?? {}) };
    this.logger = opts.logger ?? noopLogger;
    this.now = opts.now ?? (() => Date.now());
  }

  /**
   * Try each source in priority order, returning the first valid price. If every
   * live source fails, fall back to the cached price when it is not yet stale.
   */
  async getPrice(mint: string): Promise<PriceQuote | null> {
    for (const source of this.sources) {
      try {
        const quote = await source.getPrice(mint);
        if (quote && quote.priceUsd > 0) {
          const entry: CacheEntry = {
            quote: { ...quote, source: quote.source || source.name },
            ts: this.now(),
          };
          this.cache.set(mint, entry);
          return entry.quote;
        }
      } catch (err) {
        this.logger.warn('Price source failed, falling back to next', {
          source: source.name,
          mint,
          error: err instanceof Error ? err.message : String(err),
        });
      }
    }
    const cached = this.cache.get(mint);
    if (cached && this.now() - cached.ts <= this.cfg.maxStaleMs) {
      return cached.quote;
    }
    return null;
  }

  getCached(mint: string): PriceQuote | null {
    return this.cache.get(mint)?.quote ?? null;
  }

  /** Age (ms) of the last good price for a mint, or +Infinity if never priced. */
  getPriceAgeMs(mint: string): number {
    const cached = this.cache.get(mint);
    if (!cached) return Number.POSITIVE_INFINITY;
    return this.now() - cached.ts;
  }

  sourceNames(): string[] {
    return this.sources.map((s) => s.name);
  }
}

export default PriceFallbackManager;
