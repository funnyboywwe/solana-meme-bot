import { Keypair } from '@solana/web3.js';
import { AppConfig } from '../../config/schema';
import { createModuleLogger } from '../../core/Logger';
import { getRpcManager } from '../../core/RpcManager';
import { WriteRpcProvider } from '../../core/WriteRpcProvider';
import { getSolPriceUsd } from '../../core/SolPrice';
import { JupiterClient } from '../JupiterClient';
import { AxiosHttpClient, RaydiumTxSubmitter } from './http';
import { JupiterAggregatorAdapter } from './JupiterAggregatorAdapter';
import { RaydiumDirectClient } from './RaydiumDirectClient';
import { RouteHealthMonitor } from './RouteHealthMonitor';
import { RouteAnalytics } from './RouteAnalytics';
import { PriceFallbackManager } from './PriceFallbackManager';
import {
  BirdeyePriceSource,
  DexScreenerPriceSource,
  JupiterPriceSource,
  PoolReservePriceSource,
  PoolReserves,
} from './priceSources';
import { RouteValidator, SafetyEvaluator } from './RouteValidator';
import { MultiAggregatorExecutor, ExecutorConfig } from './MultiAggregatorExecutor';
import { PositionProtectionMonitor, ProtectionDeps } from './PositionProtectionMonitor';
import { IAggregator, JupiterLike, LoggerLike } from './types';

const logger: LoggerLike = createModuleLogger('MultiAggregatorEngine');

/** Fully-wired engine handed back to the bot's orchestration layer. */
export interface MultiAggregatorEngine {
  aggregators: IAggregator[];
  health: RouteHealthMonitor;
  analytics: RouteAnalytics;
  priceManager: PriceFallbackManager;
  validator: RouteValidator;
  executor: MultiAggregatorExecutor;
  /** Build a position-protection monitor wired to the same price chain. */
  createProtectionMonitor: (deps: ProtectionDeps) => PositionProtectionMonitor;
}

export interface EngineWiringDeps {
  /** Adapter over the bot's SafetyEngine.evaluate(mint). */
  safetyEvaluate: SafetyEvaluator;
  /** Optional raw-reserve fetcher to enable the pool-reserve price fallback. */
  getReserves?: (mint: string) => Promise<PoolReserves | null>;
  /** Birdeye API key (defaults to process.env.BIRDEYE_API_KEY). */
  birdeyeApiKey?: string;
  /**
   * M-8: reuse an existing, already-MEV-protected JupiterClient as the primary
   * aggregator. When omitted, a fresh JupiterClient is constructed (used by
   * standalone/test wiring) — note a fresh client has NO MEV protection, so
   * production callers should always pass their configured client.
   */
  jupiterClient?: JupiterLike;
  /** Restrict which aggregators are wired, in preference order (by name). */
  enabledAggregators?: string[];
  /** Optional executor tuning (sell retries, retry delay, route comparison). */
  executorConfig?: Partial<ExecutorConfig>;
}

/**
 * Compose the production Multi-Aggregator Trade Execution Engine.
 *
 * Wires:
 *   - Primary aggregator  : the existing MEV-protected JupiterClient (adapter).
 *   - Fallback aggregator : Raydium Direct over the Trade API + write-RPC pool.
 *   - Price fallback chain: Jupiter -> Birdeye -> DexScreener -> pool reserves.
 *   - Multi-RPC          : Helius (read) / OrbitFlare (write) / QuickNode
 *                           (fallback) via the shared RpcManager + WriteRpcProvider.
 *   - Route health, analytics, pre-trade validation, execution, and the
 *     position-protection monitor factory.
 */
export function createMultiAggregatorEngine(
  cfg: AppConfig,
  keypair: Keypair,
  deps: EngineWiringDeps,
): MultiAggregatorEngine {
  const http = new AxiosHttpClient();
  const rpc = getRpcManager(cfg);
  const write = new WriteRpcProvider(cfg);

  // Primary aggregator: reuse the caller's existing, MEV-protected JupiterClient
  // when provided (M-8) so the Jupiter route keeps pre-flight simulation + Jito
  // bundle protection. Only fall back to a fresh client for standalone wiring.
  const jupiterClient: JupiterLike =
    deps.jupiterClient ?? (new JupiterClient(cfg, keypair) as unknown as JupiterLike);
  const jupiter = new JupiterAggregatorAdapter(jupiterClient, { logger });

  // Fallback aggregator: Raydium Direct, broadcasting through the write-RPC pool.
  const submitter = new RaydiumTxSubmitter(keypair, write, cfg.execution.simulateBeforeSend);
  const raydium = new RaydiumDirectClient(http, keypair.publicKey.toBase58(), submitter, {
    config: {
      priorityFeeMicroLamports: cfg.execution.priorityFeeMicroLamports,
      defaultSlippageBps: cfg.execution.slippageBps,
    },
    logger,
  });

  let aggregators: IAggregator[] = [jupiter, raydium];
  // Honour an explicit aggregator allow-list (execution.multiAggregator.aggregators)
  // while never allowing the list to disable every provider.
  if (deps.enabledAggregators && deps.enabledAggregators.length > 0) {
    const allow = new Set(deps.enabledAggregators);
    const filtered = aggregators.filter((a) => allow.has(a.name));
    if (filtered.length > 0) aggregators = filtered;
  }

  const health = new RouteHealthMonitor({ logger });
  const analytics = new RouteAnalytics();

  // Price fallback chain in priority order (Requirement #5).
  const birdeyeKey = deps.birdeyeApiKey ?? process.env.BIRDEYE_API_KEY ?? '';
  const priceManager = new PriceFallbackManager(
    [
      new JupiterPriceSource(http),
      new BirdeyePriceSource(http, birdeyeKey),
      new DexScreenerPriceSource(http),
      ...(deps.getReserves ? [new PoolReservePriceSource(deps.getReserves, getSolPriceUsd)] : []),
    ],
    { logger },
  );

  const validator = new RouteValidator(
    aggregators,
    priceManager,
    deps.safetyEvaluate,
    { minLiquidityUsd: cfg.safety.minLiquidityUsd, rejectOnUnknownLiquidity: false },
    { logger },
  );

  const executor = new MultiAggregatorExecutor(aggregators, health, analytics, {
    logger,
    config: deps.executorConfig,
  });

  logger.info('Multi-aggregator engine wired', {
    aggregators: aggregators.map((a) => a.name),
    priceSources: priceManager.sourceNames(),
    writeLabel: rpc.getActiveWriteLabel(),
  });

  return {
    aggregators,
    health,
    analytics,
    priceManager,
    validator,
    executor,
    createProtectionMonitor: (pdeps: ProtectionDeps) => new PositionProtectionMonitor(pdeps, { logger }),
  };
}
