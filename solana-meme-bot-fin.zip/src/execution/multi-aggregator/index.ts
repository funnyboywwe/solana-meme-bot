/**
 * Multi-Aggregator Trade Execution Engine.
 *
 * A drop-in execution layer that never depends on a single aggregator, a single
 * RPC, or a single price source:
 *   - Aggregators : Jupiter (primary) + Raydium Direct (fallback).
 *   - Price feeds : Jupiter -> Birdeye -> DexScreener -> pool reserves.
 *   - RPC         : Helius (read) / OrbitFlare (write) / QuickNode (fallback).
 *
 * The pure logic (types, health, analytics, price fallback, validation,
 * execution, position protection) is dependency-injected and has no network or
 * wallet imports, so it is fully unit-testable. The axios/@solana/web3.js wiring
 * lives only in `http.ts` and `engine.ts`.
 */
export * from './types';
export * from './RouteHealthMonitor';
export * from './RouteAnalytics';
export * from './PriceFallbackManager';
export * from './priceSources';
export * from './RaydiumDirectClient';
export * from './JupiterAggregatorAdapter';
export * from './RouteValidator';
export * from './MultiAggregatorExecutor';
export * from './PositionProtectionMonitor';
export * from './http';
export * from './engine';
