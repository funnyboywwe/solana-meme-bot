import { LoggerLike, noopLogger } from './types';

export type EmergencyReason = 'no_price' | 'no_sell_route' | 'liquidity_drop' | 'volume_collapse';

export interface ProtectionThresholds {
  /** No valid price for this long (ms) => emergency exit. */
  maxPriceStaleMs: number;
  /** No valid sell route for this long (ms) => emergency exit. */
  maxSellRouteStaleMs: number;
  /** Liquidity drop from baseline (0..1) => emergency exit. */
  maxLiquidityDropPct: number;
  /** Volume collapse from baseline (0..1) => emergency exit. */
  maxVolumeDropPct: number;
}

export const DEFAULT_PROTECTION_THRESHOLDS: ProtectionThresholds = {
  maxPriceStaleMs: 60_000,
  maxSellRouteStaleMs: 60_000,
  maxLiquidityDropPct: 0.3,
  maxVolumeDropPct: 0.7,
};

/** Everything needed to judge a single position's health on one tick. */
export interface PositionSnapshot {
  priceAgeMs: number;
  sellRouteAgeMs: number;
  liquidityUsd: number;
  baselineLiquidityUsd: number;
  volumeUsd: number;
  baselineVolumeUsd: number;
}

/**
 * Pure decision function (no I/O) so it is trivially unit-testable. Returns the
 * FIRST emergency reason that fires, or null when the position is healthy.
 */
export function detectEmergency(snap: PositionSnapshot, t: ProtectionThresholds): EmergencyReason | null {
  if (snap.priceAgeMs >= t.maxPriceStaleMs) return 'no_price';
  if (snap.sellRouteAgeMs >= t.maxSellRouteStaleMs) return 'no_sell_route';
  if (snap.baselineLiquidityUsd > 0) {
    const drop = (snap.baselineLiquidityUsd - snap.liquidityUsd) / snap.baselineLiquidityUsd;
    if (drop >= t.maxLiquidityDropPct) return 'liquidity_drop';
  }
  if (snap.baselineVolumeUsd > 0) {
    const drop = (snap.baselineVolumeUsd - snap.volumeUsd) / snap.baselineVolumeUsd;
    if (drop >= t.maxVolumeDropPct) return 'volume_collapse';
  }
  return null;
}

export interface MonitoredPosition {
  positionId: string;
  mint: string;
}

export interface MarketStats {
  liquidityUsd: number;
  volumeUsd: number;
}

export interface ProtectionDeps {
  /** Open positions to watch. */
  getOpenPositions: () => MonitoredPosition[];
  /** Age (ms) of the last valid price for a mint; Infinity if never priced. */
  getPriceAgeMs: (mint: string) => number;
  /** Whether a sell route currently exists for a mint. */
  hasSellRoute: (mint: string) => Promise<boolean>;
  /** Current market stats (liquidity + recent volume) for a mint. */
  getMarketStats: (mint: string) => Promise<MarketStats | null>;
  /** Fired exactly once per position when an emergency condition trips. */
  emergencyExit: (position: MonitoredPosition, reason: EmergencyReason) => void;
}

interface BaselineState {
  baselineLiquidityUsd: number;
  baselineVolumeUsd: number;
  lastSellRouteOkTs: number;
  triggered: boolean;
}

/**
 * Position Protection Monitor (Requirement #6).
 *
 * For every open position it periodically evaluates the four emergency
 * conditions and fires a single emergency exit per position. Liquidity/volume
 * baselines track the PEAK value seen, so a relative collapse from the
 * high-water mark trips protection even if we entered after the peak.
 */
export class PositionProtectionMonitor {
  private readonly thresholds: ProtectionThresholds;
  private readonly logger: LoggerLike;
  private readonly now: () => number;
  private readonly intervalMs: number;
  private readonly state = new Map<string, BaselineState>();
  private timer: ReturnType<typeof setInterval> | null = null;

  constructor(
    private deps: ProtectionDeps,
    opts: { thresholds?: Partial<ProtectionThresholds>; logger?: LoggerLike; now?: () => number; intervalMs?: number } = {},
  ) {
    this.thresholds = { ...DEFAULT_PROTECTION_THRESHOLDS, ...(opts.thresholds ?? {}) };
    this.logger = opts.logger ?? noopLogger;
    this.now = opts.now ?? (() => Date.now());
    this.intervalMs = opts.intervalMs ?? 10_000;
  }

  start(): void {
    if (this.timer) return;
    this.timer = setInterval(() => {
      void this.tick();
    }, this.intervalMs);
    // Don't keep the event loop alive solely for this monitor.
    if (this.timer && typeof (this.timer as { unref?: () => void }).unref === 'function') {
      (this.timer as { unref: () => void }).unref();
    }
    this.logger.info('PositionProtectionMonitor started', { intervalMs: this.intervalMs });
  }

  stop(): void {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }

  private getState(mint: string): BaselineState {
    let s = this.state.get(mint);
    if (!s) {
      s = { baselineLiquidityUsd: 0, baselineVolumeUsd: 0, lastSellRouteOkTs: this.now(), triggered: false };
      this.state.set(mint, s);
    }
    return s;
  }

  /** One monitoring pass over all open positions. Public for unit testing. */
  async tick(): Promise<void> {
    const positions = this.deps.getOpenPositions();
    const liveMints = new Set(positions.map((p) => p.mint));
    // Drop state for positions that have since closed.
    for (const mint of [...this.state.keys()]) {
      if (!liveMints.has(mint)) this.state.delete(mint);
    }

    for (const pos of positions) {
      const st = this.getState(pos.mint);
      if (st.triggered) continue;

      // Refresh sell-route freshness.
      let sellRouteOk = false;
      try {
        sellRouteOk = await this.deps.hasSellRoute(pos.mint);
      } catch {
        sellRouteOk = false;
      }
      if (sellRouteOk) st.lastSellRouteOkTs = this.now();

      // Refresh market stats and track peak baselines.
      let stats: MarketStats | null = null;
      try {
        stats = await this.deps.getMarketStats(pos.mint);
      } catch {
        stats = null;
      }
      if (stats) {
        st.baselineLiquidityUsd = Math.max(st.baselineLiquidityUsd, stats.liquidityUsd);
        st.baselineVolumeUsd = Math.max(st.baselineVolumeUsd, stats.volumeUsd);
      }

      const snap: PositionSnapshot = {
        priceAgeMs: this.deps.getPriceAgeMs(pos.mint),
        sellRouteAgeMs: this.now() - st.lastSellRouteOkTs,
        liquidityUsd: stats?.liquidityUsd ?? 0,
        baselineLiquidityUsd: st.baselineLiquidityUsd,
        volumeUsd: stats?.volumeUsd ?? 0,
        baselineVolumeUsd: st.baselineVolumeUsd,
      };

      const reason = detectEmergency(snap, this.thresholds);
      if (reason) {
        st.triggered = true;
        this.logger.error('Emergency exit triggered', { mint: pos.mint, positionId: pos.positionId, reason });
        this.deps.emergencyExit(pos, reason);
      }
    }
  }
}

export default PositionProtectionMonitor;
