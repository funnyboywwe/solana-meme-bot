import { AggregatorQuote, IAggregator, SwapExecution, LoggerLike, noopLogger } from './types';
import { RouteHealthMonitor } from './RouteHealthMonitor';
import { RouteAnalytics } from './RouteAnalytics';

export interface ExecutorConfig {
  /** Number of full provider rounds to attempt for a sell before escalating. */
  maxRetries: number;
  /** Base delay between sell retry rounds (multiplied by the round number). */
  retryDelayMs: number;
  /** Route cost comparison: quote all healthy providers and try cheapest first. */
  compareRoutes: boolean;
}

export const DEFAULT_EXECUTOR_CONFIG: ExecutorConfig = {
  maxRetries: 2,
  retryDelayMs: 400,
  compareRoutes: true,
};

export interface ExecuteResult extends SwapExecution {
  attempts: number;
  triedProviders: string[];
}

export type EmergencyHandler = (info: {
  mint: string;
  amountBaseUnits: string;
  triedProviders: string[];
}) => void;

/**
 * Multi-Aggregator Executor (Requirements #2, #3, #8).
 *
 *   BUY : Jupiter -> Raydium -> abort.
 *   SELL: Jupiter -> Raydium -> retry rounds -> emergency monitoring hand-off.
 *
 * Providers are ordered by health (Requirement #4) and, when route cost
 * comparison is enabled, by the cheapest valid route (most output for the size,
 * tie-broken by lower fee — Requirement #8). Every quote and swap outcome is fed
 * back into the health monitor and analytics.
 */
export class MultiAggregatorExecutor {
  private readonly cfg: ExecutorConfig;
  private readonly logger: LoggerLike;
  private readonly sleep: (ms: number) => Promise<void>;

  constructor(
    private aggregators: IAggregator[],
    private health: RouteHealthMonitor,
    private analytics: RouteAnalytics,
    opts: { config?: Partial<ExecutorConfig>; logger?: LoggerLike; sleep?: (ms: number) => Promise<void> } = {},
  ) {
    this.cfg = { ...DEFAULT_EXECUTOR_CONFIG, ...(opts.config ?? {}) };
    this.logger = opts.logger ?? noopLogger;
    this.sleep = opts.sleep ?? ((ms) => new Promise((resolve) => setTimeout(resolve, ms)));
    for (const agg of this.aggregators) this.health.register(agg.name);
  }

  /** Provider instances ordered best-first by health. */
  private ordered(): IAggregator[] {
    const names = this.health.orderByHealth(this.aggregators.map((a) => a.name));
    const byName = new Map(this.aggregators.map((a) => [a.name, a]));
    const out: IAggregator[] = [];
    for (const name of names) {
      const agg = byName.get(name);
      if (agg) out.push(agg);
    }
    return out;
  }

  /**
   * Quote every healthy provider for a side and order them cheapest-first.
   * Providers that fail to quote are dropped here and counted as route failures,
   * which also feeds the health monitor's quote stats.
   */
  private async orderByCost(
    side: 'buy' | 'sell',
    mint: string,
    sizeSol: number,
    amountBaseUnits: string,
    slippageBps: number,
  ): Promise<IAggregator[]> {
    const scored: Array<{ agg: IAggregator; out: number; fee: number }> = [];
    for (const agg of this.ordered()) {
      const start = Date.now();
      try {
        const quote: AggregatorQuote =
          side === 'buy'
            ? await agg.getBuyQuote(mint, sizeSol, slippageBps)
            : await agg.getSellQuote(mint, amountBaseUnits, slippageBps);
        const out = parseInt(quote.outAmount, 10) || 0;
        this.health.recordQuote(agg.name, { ok: out > 0, latencyMs: Date.now() - start, routeAvailable: out > 0 });
        if (out > 0) scored.push({ agg, out, fee: quote.estFeeSol });
        else this.analytics.recordRouteFailure(agg.name);
      } catch (err) {
        this.health.recordQuote(agg.name, { ok: false, latencyMs: Date.now() - start });
        this.analytics.recordRouteFailure(agg.name);
        this.logger.info(`Quote failed on ${agg.name}`, {
          mint,
          side,
          error: err instanceof Error ? err.message : String(err),
        });
      }
    }
    // Cheapest valid route = most output for the given size; tie-break lower fee.
    scored.sort((a, b) => b.out - a.out || a.fee - b.fee);
    return scored.map((s) => s.agg);
  }

  /** Buy flow: try providers in cost/health order; abort only if all fail. */
  async executeBuy(
    mint: string,
    sizeSol: number,
    slippageBps: number,
    priorityFeeMicroLamports?: number,
  ): Promise<ExecuteResult> {
    const tried: string[] = [];
    const ranked = this.cfg.compareRoutes
      ? await this.orderByCost('buy', mint, sizeSol, '0', slippageBps)
      : this.ordered();
    // If cost comparison eliminated everyone (all quotes failed), still attempt
    // execution in health order — a transient quote failure is not a swap failure.
    const candidates = ranked.length > 0 ? ranked : this.ordered();

    let attempts = 0;
    let lastError: string | undefined;
    for (const agg of candidates) {
      tried.push(agg.name);
      attempts++;
      const res = await this.safeSwap(() => agg.buy(mint, sizeSol, slippageBps, priorityFeeMicroLamports), agg.name);
      this.health.recordSwap(agg.name, res.success);
      this.analytics.recordTrade('buy', { success: res.success, feeSol: res.feeSol, slippageBps });
      if (res.success) {
        this.logger.info('Buy filled', { mint, provider: agg.name, txHash: res.txHash });
        return { ...res, attempts, triedProviders: tried };
      }
      this.analytics.recordRouteFailure(agg.name);
      lastError = res.error;
      this.logger.warn('Buy route failed, trying next', { mint, provider: agg.name, error: res.error });
    }

    this.logger.error('All buy routes failed — aborting trade', { mint, tried });
    return {
      success: false,
      aggregator: 'none',
      amountIn: 0,
      amountOut: 0,
      feeSol: 0,
      priceImpactPct: 0,
      error: lastError ?? 'all_buy_routes_failed',
      attempts,
      triedProviders: tried,
    };
  }

  /** Sell flow: try providers per round, retry, then escalate to emergency. */
  async executeSell(
    mint: string,
    amountBaseUnits: string,
    slippageBps: number,
    priorityFeeMicroLamports?: number,
    onEmergency?: EmergencyHandler,
  ): Promise<ExecuteResult> {
    const tried: string[] = [];
    let attempts = 0;
    let lastError: string | undefined;

    for (let round = 1; round <= this.cfg.maxRetries; round++) {
      const ranked = this.cfg.compareRoutes
        ? await this.orderByCost('sell', mint, 0, amountBaseUnits, slippageBps)
        : this.ordered();
      const candidates = ranked.length > 0 ? ranked : this.ordered();

      for (const agg of candidates) {
        if (!tried.includes(agg.name)) tried.push(agg.name);
        attempts++;
        const res = await this.safeSwap(
          () => agg.sellRaw(mint, amountBaseUnits, slippageBps, priorityFeeMicroLamports),
          agg.name,
        );
        this.health.recordSwap(agg.name, res.success);
        this.analytics.recordTrade('sell', { success: res.success, feeSol: res.feeSol, slippageBps });
        if (res.success) {
          this.logger.info('Sell filled', { mint, provider: agg.name, txHash: res.txHash, round });
          return { ...res, attempts, triedProviders: tried };
        }
        this.analytics.recordRouteFailure(agg.name);
        lastError = res.error;
        this.logger.warn('Sell route failed, trying next', { mint, provider: agg.name, round, error: res.error });
      }

      if (round < this.cfg.maxRetries) await this.sleep(this.cfg.retryDelayMs * round);
    }

    // Every aggregator failed across all retry rounds. Escalate to emergency
    // monitoring so the position-protection layer can keep attempting / alerting
    // rather than silently leaving an open, unsellable position.
    this.logger.error('All sell routes failed across retries — escalating to emergency monitoring', { mint, tried });
    if (onEmergency) onEmergency({ mint, amountBaseUnits, triedProviders: tried });
    return {
      success: false,
      aggregator: 'none',
      amountIn: 0,
      amountOut: 0,
      feeSol: 0,
      priceImpactPct: 0,
      error: lastError ?? 'all_sell_routes_failed',
      attempts,
      triedProviders: tried,
    };
  }

  /** Never let a thrown swap crash the loop — normalise to a failed execution. */
  private async safeSwap(fn: () => Promise<SwapExecution>, provider: string): Promise<SwapExecution> {
    try {
      return await fn();
    } catch (err) {
      const error = err instanceof Error ? err.message : String(err);
      this.logger.warn('Swap threw', { provider, error });
      return { success: false, aggregator: provider, amountIn: 0, amountOut: 0, feeSol: 0, priceImpactPct: 0, error };
    }
  }
}

export default MultiAggregatorExecutor;
