import { LoggerLike, noopLogger } from './types';

/**
 * Route Health Monitor (Requirement #4).
 *
 * Tracks per-provider route availability, quote latency, execution success
 * rate, and failed quote/swap counts. Providers are automatically marked
 * UNHEALTHY after too many consecutive failures or a low success rate, and are
 * re-probed (half-open) after a recovery window so a temporary outage doesn't
 * permanently disable an aggregator.
 */
export interface RouteHealthConfig {
  /** Mark unhealthy after this many straight failures. */
  maxConsecutiveFailures: number;
  /** Minimum executed swaps before the success-rate gate applies. */
  minSamples: number;
  /** Below this success rate (with enough samples) => unhealthy. */
  minSuccessRate: number;
  /** Probation window (ms) before an unhealthy provider is re-probed. */
  recoveryMs: number;
}

export const DEFAULT_ROUTE_HEALTH_CONFIG: RouteHealthConfig = {
  maxConsecutiveFailures: 3,
  minSamples: 5,
  minSuccessRate: 0.5,
  recoveryMs: 60_000,
};

export interface RouteStats {
  provider: string;
  available: boolean; // last quote produced a usable route
  healthy: boolean;
  quotesTotal: number;
  quotesFailed: number;
  swapsTotal: number;
  swapsFailed: number;
  consecutiveFailures: number;
  avgQuoteLatencyMs: number;
  lastLatencyMs: number;
  successRate: number; // executed-swap success rate (0..1)
  markedUnhealthyAt: number;
}

export class RouteHealthMonitor {
  private readonly cfg: RouteHealthConfig;
  private readonly logger: LoggerLike;
  private readonly now: () => number;
  private readonly stats = new Map<string, RouteStats>();

  constructor(opts: { config?: Partial<RouteHealthConfig>; logger?: LoggerLike; now?: () => number } = {}) {
    this.cfg = { ...DEFAULT_ROUTE_HEALTH_CONFIG, ...(opts.config ?? {}) };
    this.logger = opts.logger ?? noopLogger;
    this.now = opts.now ?? (() => Date.now());
  }

  /** Idempotently create (or fetch) the stats record for a provider. */
  register(provider: string): RouteStats {
    let s = this.stats.get(provider);
    if (!s) {
      s = {
        provider,
        available: true,
        healthy: true,
        quotesTotal: 0,
        quotesFailed: 0,
        swapsTotal: 0,
        swapsFailed: 0,
        consecutiveFailures: 0,
        avgQuoteLatencyMs: 0,
        lastLatencyMs: 0,
        successRate: 1,
        markedUnhealthyAt: 0,
      };
      this.stats.set(provider, s);
    }
    return s;
  }

  /** Record the outcome + latency of a quote attempt. */
  recordQuote(provider: string, result: { ok: boolean; latencyMs: number; routeAvailable?: boolean }): void {
    const s = this.register(provider);
    s.quotesTotal++;
    s.lastLatencyMs = result.latencyMs;
    // Exponential moving average so a single spike doesn't dominate latency.
    s.avgQuoteLatencyMs =
      s.avgQuoteLatencyMs === 0 ? result.latencyMs : s.avgQuoteLatencyMs * 0.7 + result.latencyMs * 0.3;
    s.available = result.ok && (result.routeAvailable ?? true);
    if (!result.ok) {
      s.quotesFailed++;
      this.registerFailure(s, 'quote');
    } else {
      this.registerSuccess(s);
    }
  }

  /** Record the outcome of an executed swap (the strongest health signal). */
  recordSwap(provider: string, ok: boolean): void {
    const s = this.register(provider);
    s.swapsTotal++;
    if (!ok) {
      s.swapsFailed++;
      this.registerFailure(s, 'swap');
    } else {
      this.registerSuccess(s);
    }
    s.successRate = s.swapsTotal === 0 ? 1 : (s.swapsTotal - s.swapsFailed) / s.swapsTotal;
    this.evaluateSuccessRate(s);
  }

  private registerSuccess(s: RouteStats): void {
    s.consecutiveFailures = 0;
    if (!s.healthy) {
      s.healthy = true;
      s.markedUnhealthyAt = 0;
      this.logger.info('Route recovered', { provider: s.provider });
    }
  }

  private registerFailure(s: RouteStats, kind: string): void {
    s.consecutiveFailures++;
    if (s.consecutiveFailures >= this.cfg.maxConsecutiveFailures && s.healthy) {
      s.healthy = false;
      s.markedUnhealthyAt = this.now();
      this.logger.warn('Route marked unhealthy', {
        provider: s.provider,
        kind,
        consecutiveFailures: s.consecutiveFailures,
      });
    }
  }

  private evaluateSuccessRate(s: RouteStats): void {
    if (s.healthy && s.swapsTotal >= this.cfg.minSamples && s.successRate < this.cfg.minSuccessRate) {
      s.healthy = false;
      s.markedUnhealthyAt = this.now();
      this.logger.warn('Route marked unhealthy (low success rate)', {
        provider: s.provider,
        successRate: +s.successRate.toFixed(3),
      });
    }
  }

  /**
   * A provider is usable if it is healthy, or its probation window has elapsed
   * (in which case we flip it half-open and allow a single re-probe).
   */
  isHealthy(provider: string): boolean {
    const s = this.stats.get(provider);
    if (!s) return true; // unknown providers are optimistically tried once
    if (s.healthy) return true;
    if (s.markedUnhealthyAt > 0 && this.now() - s.markedUnhealthyAt >= this.cfg.recoveryMs) {
      s.healthy = true;
      s.consecutiveFailures = 0;
      s.markedUnhealthyAt = 0;
      this.logger.info('Route probation elapsed — re-probing', { provider: s.provider });
      return true;
    }
    return false;
  }

  /** Order providers best-first: healthy first, then success rate, then latency. */
  orderByHealth(providers: string[]): string[] {
    return [...providers].sort((a, b) => {
      const ha = this.isHealthy(a) ? 1 : 0;
      const hb = this.isHealthy(b) ? 1 : 0;
      if (ha !== hb) return hb - ha;
      const sa = this.stats.get(a);
      const sb = this.stats.get(b);
      const ra = sa?.successRate ?? 1;
      const rb = sb?.successRate ?? 1;
      if (rb !== ra) return rb - ra;
      const la = sa?.avgQuoteLatencyMs ?? 0;
      const lb = sb?.avgQuoteLatencyMs ?? 0;
      return la - lb;
    });
  }

  getStats(provider: string): RouteStats | undefined {
    return this.stats.get(provider);
  }

  getAll(): RouteStats[] {
    return [...this.stats.values()];
  }
}

export default RouteHealthMonitor;
