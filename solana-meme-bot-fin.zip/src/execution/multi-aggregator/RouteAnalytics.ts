import { TradeSide } from './types';

/**
 * Analytics report (Requirement #9): buy/sell success rates, per-provider route
 * failures, average fees & slippage, and profit after costs.
 */
export interface RouteAnalyticsReport {
  buys: number;
  buySuccess: number;
  buySuccessRate: number;
  sells: number;
  sellSuccess: number;
  sellSuccessRate: number;
  routeFailures: Record<string, number>;
  totalRouteFailures: number;
  avgFeeSol: number;
  avgSlippageBps: number;
  grossProfitSol: number;
  totalFeesSol: number;
  /** Profit after subtracting all recorded execution fees. */
  profitAfterCostsSol: number;
}

/**
 * In-memory analytics for the multi-aggregator engine. Cheap to update on the
 * hot path and cheap to query for a dashboard / status endpoint.
 */
export class RouteAnalytics {
  private buys = 0;
  private buySuccess = 0;
  private sells = 0;
  private sellSuccess = 0;
  private readonly routeFailures = new Map<string, number>();
  private feeSamples = 0;
  private feeSumSol = 0;
  private slippageSamples = 0;
  private slippageSumBps = 0;
  private grossProfitSol = 0;
  private totalFeesSol = 0;

  /** Record a buy/sell attempt and (when filled) its fee + slippage. */
  recordTrade(side: TradeSide, outcome: { success: boolean; feeSol?: number; slippageBps?: number }): void {
    if (side === 'buy') {
      this.buys++;
      if (outcome.success) this.buySuccess++;
    } else {
      this.sells++;
      if (outcome.success) this.sellSuccess++;
    }
    if (outcome.success) {
      if (typeof outcome.feeSol === 'number') {
        this.feeSamples++;
        this.feeSumSol += outcome.feeSol;
        this.totalFeesSol += outcome.feeSol;
      }
      if (typeof outcome.slippageBps === 'number') {
        this.slippageSamples++;
        this.slippageSumBps += outcome.slippageBps;
      }
    }
  }

  recordRouteFailure(provider: string): void {
    this.routeFailures.set(provider, (this.routeFailures.get(provider) ?? 0) + 1);
  }

  /** Record realised GROSS profit (SOL) for a closed round-trip, before costs. */
  recordProfit(grossSol: number): void {
    this.grossProfitSol += grossSol;
  }

  getReport(): RouteAnalyticsReport {
    const routeFailures: Record<string, number> = {};
    let totalRouteFailures = 0;
    for (const [provider, count] of this.routeFailures) {
      routeFailures[provider] = count;
      totalRouteFailures += count;
    }
    return {
      buys: this.buys,
      buySuccess: this.buySuccess,
      buySuccessRate: this.buys === 0 ? 0 : this.buySuccess / this.buys,
      sells: this.sells,
      sellSuccess: this.sellSuccess,
      sellSuccessRate: this.sells === 0 ? 0 : this.sellSuccess / this.sells,
      routeFailures,
      totalRouteFailures,
      avgFeeSol: this.feeSamples === 0 ? 0 : this.feeSumSol / this.feeSamples,
      avgSlippageBps: this.slippageSamples === 0 ? 0 : this.slippageSumBps / this.slippageSamples,
      grossProfitSol: this.grossProfitSol,
      totalFeesSol: this.totalFeesSol,
      profitAfterCostsSol: this.grossProfitSol - this.totalFeesSol,
    };
  }

  reset(): void {
    this.buys = this.buySuccess = this.sells = this.sellSuccess = 0;
    this.routeFailures.clear();
    this.feeSamples = this.feeSumSol = this.slippageSamples = this.slippageSumBps = 0;
    this.grossProfitSol = this.totalFeesSol = 0;
  }
}

export default RouteAnalytics;
