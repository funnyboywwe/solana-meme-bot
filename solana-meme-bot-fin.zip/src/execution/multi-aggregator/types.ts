/**
 * Shared types for the Multi-Aggregator Trade Execution Engine.
 *
 * The engine is built around small, dependency-injected interfaces so every unit
 * can be tested without a live network, RPC node, or wallet. Concrete production
 * wiring (axios + @solana/web3.js) lives only in `http.ts` and `engine.ts`.
 */

/** Wrapped SOL mint — the quote/settlement asset for every meme trade. */
export const WSOL_MINT = 'So11111111111111111111111111111111111111112';

export type TradeSide = 'buy' | 'sell';

/**
 * Minimal HTTP client surface. The default implementation (see `http.ts`) wraps
 * axios; tests inject a fake so no network is required.
 */
export interface HttpClient {
  get<T = unknown>(url: string, config?: HttpRequestConfig): Promise<HttpResponse<T>>;
  post<T = unknown>(url: string, body?: unknown, config?: HttpRequestConfig): Promise<HttpResponse<T>>;
}

export interface HttpRequestConfig {
  params?: Record<string, string | number | boolean | undefined>;
  headers?: Record<string, string>;
  timeoutMs?: number;
}

export interface HttpResponse<T = unknown> {
  data: T;
  status: number;
}

/**
 * A normalised quote from any trading aggregator. Amounts are integer base-unit
 * strings (lamports for SOL, raw token units otherwise) to avoid float drift on
 * large-supply memecoins.
 */
export interface AggregatorQuote {
  aggregator: string;
  inputMint: string;
  outputMint: string;
  inAmount: string;
  outAmount: string;
  priceImpactPct: number;
  slippageBps: number;
  /** Estimated all-in execution cost in SOL — used for route cost comparison. */
  estFeeSol: number;
  /** Aggregator-specific payload needed to build/submit the swap. */
  raw?: unknown;
}

/** Result of an executed swap on a specific aggregator. */
export interface SwapExecution {
  success: boolean;
  aggregator: string;
  txHash?: string;
  amountIn: number; // base units
  amountOut: number; // base units
  feeSol: number;
  priceImpactPct: number;
  error?: string;
}

/**
 * A trading aggregator (Jupiter primary, Raydium Direct fallback, ...). Every
 * aggregator exposes both quote and execute methods for buys and sells so the
 * router can probe routes cheaply (quote) before committing (execute).
 */
export interface IAggregator {
  readonly name: string;
  getBuyQuote(mint: string, sizeSol: number, slippageBps: number): Promise<AggregatorQuote>;
  getSellQuote(mint: string, amountBaseUnits: string, slippageBps: number): Promise<AggregatorQuote>;
  buy(mint: string, sizeSol: number, slippageBps: number, priorityFeeMicroLamports?: number): Promise<SwapExecution>;
  sellRaw(mint: string, amountBaseUnits: string, slippageBps: number, priorityFeeMicroLamports?: number): Promise<SwapExecution>;
}

/** A USD price reading from a single price source. */
export interface PriceQuote {
  mint: string;
  priceUsd: number;
  liquidityUsd?: number;
  source: string;
  ts: number;
}

/** A single price source (Jupiter price API, Birdeye, DexScreener, pool reserves). */
export interface IPriceSource {
  readonly name: string;
  getPrice(mint: string): Promise<PriceQuote | null>;
}

/** Signs the bot wallet's swap transaction and broadcasts it via the write-RPC pool. */
export interface TxSubmitter {
  submit(txBase64: string, opts?: { priorityFeeMicroLamports?: number; mint?: string }): Promise<string>;
}

/**
 * Minimal Jupiter surface the adapter needs. Declaring it here (rather than
 * importing JupiterClient) keeps web3/axios out of the unit-testable core.
 */
export interface JupiterLike {
  getQuote(
    inputMint: string,
    outputMint: string,
    amountLamports: number | string,
    slippageBps?: number,
  ): Promise<JupiterQuote>;
  buy(mint: string, sizeSol: number, maxSlippageBps: number, priorityFeeMicroLamports?: number): Promise<JupiterSwapResult>;
  sellRaw(mint: string, amountBaseUnits: string, maxSlippageBps: number, priorityFeeMicroLamports?: number): Promise<JupiterSwapResult>;
}

export interface JupiterQuote {
  inAmount: string;
  outAmount: string;
  priceImpactPct: string;
  slippageBps: number;
  routePlan?: unknown[];
}

export interface JupiterSwapResult {
  success: boolean;
  txHash?: string;
  amountIn: number;
  amountOut: number;
  feeSol: number;
  priceImpactPct: number;
  error?: string;
}

/** Simple logger surface (winston's logger satisfies it; tests use noopLogger). */
export interface LoggerLike {
  info(msg: string, meta?: Record<string, unknown>): void;
  warn(msg: string, meta?: Record<string, unknown>): void;
  error(msg: string, meta?: Record<string, unknown>): void;
}

export const noopLogger: LoggerLike = {
  info: () => {},
  warn: () => {},
  error: () => {},
};
