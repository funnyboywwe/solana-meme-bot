import {
  AggregatorQuote,
  HttpClient,
  IAggregator,
  SwapExecution,
  TxSubmitter,
  WSOL_MINT,
  LoggerLike,
  noopLogger,
} from './types';

/** Subset of Raydium's /compute/swap-base-in response that we consume. */
interface RaydiumComputeResponse {
  id?: string;
  success?: boolean;
  msg?: string;
  data?: {
    inputAmount?: string;
    outputAmount?: string;
    otherAmountThreshold?: string;
    priceImpactPct?: number;
    [k: string]: unknown; // full object is echoed to /transaction/swap-base-in
  };
}

/** Subset of Raydium's /transaction/swap-base-in response. */
interface RaydiumTxResponse {
  id?: string;
  success?: boolean;
  msg?: string;
  data?: Array<{ transaction?: string }>;
}

export interface RaydiumClientConfig {
  computeUrl: string;
  swapUrl: string;
  priorityFeeMicroLamports: number;
  defaultSlippageBps: number;
  txVersion: 'V0' | 'LEGACY';
}

export const DEFAULT_RAYDIUM_CONFIG: RaydiumClientConfig = {
  computeUrl: 'https://transaction-v1.raydium.io/compute/swap-base-in',
  swapUrl: 'https://transaction-v1.raydium.io/transaction/swap-base-in',
  priorityFeeMicroLamports: 50_000,
  defaultSlippageBps: 100,
  txVersion: 'V0',
};

/**
 * Raydium Direct fallback aggregator (Requirement: fallback trading aggregator).
 *
 * Implements the same IAggregator contract as the Jupiter adapter so the router
 * uses them interchangeably. Quote + transaction building happen over Raydium's
 * Trade API; signing/broadcast is delegated to an injected TxSubmitter (wallet +
 * write-RPC pool), keeping this class free of web3/wallet concerns and fully
 * unit-testable with a fake HttpClient + TxSubmitter.
 */
export class RaydiumDirectClient implements IAggregator {
  readonly name = 'raydium';
  private readonly cfg: RaydiumClientConfig;
  private readonly logger: LoggerLike;

  constructor(
    private http: HttpClient,
    private walletPubkey: string,
    private submitter: TxSubmitter,
    opts: { config?: Partial<RaydiumClientConfig>; logger?: LoggerLike } = {},
  ) {
    this.cfg = { ...DEFAULT_RAYDIUM_CONFIG, ...(opts.config ?? {}) };
    this.logger = opts.logger ?? noopLogger;
  }

  async getBuyQuote(mint: string, sizeSol: number, slippageBps: number): Promise<AggregatorQuote> {
    const amountLamports = Math.floor(sizeSol * 1e9).toString();
    return this.compute(WSOL_MINT, mint, amountLamports, slippageBps);
  }

  async getSellQuote(mint: string, amountBaseUnits: string, slippageBps: number): Promise<AggregatorQuote> {
    return this.compute(mint, WSOL_MINT, amountBaseUnits, slippageBps);
  }

  /** Call Raydium's compute endpoint and normalise to an AggregatorQuote. */
  private async compute(
    inputMint: string,
    outputMint: string,
    amount: string,
    slippageBps: number,
  ): Promise<AggregatorQuote> {
    const effectiveSlippage = slippageBps || this.cfg.defaultSlippageBps;
    const res = await this.http.get<RaydiumComputeResponse>(this.cfg.computeUrl, {
      params: { inputMint, outputMint, amount, slippageBps: effectiveSlippage, txVersion: this.cfg.txVersion },
      timeoutMs: 8000,
    });
    const body = res.data;
    if (!body || body.success === false || !body.data || !body.data.outputAmount) {
      throw new Error(`Raydium: no route for ${inputMint} → ${outputMint}${body?.msg ? ` (${body.msg})` : ''}`);
    }
    return {
      aggregator: this.name,
      inputMint,
      outputMint,
      inAmount: body.data.inputAmount ?? amount,
      outAmount: String(body.data.outputAmount),
      priceImpactPct: Number(body.data.priceImpactPct ?? 0),
      slippageBps: effectiveSlippage,
      estFeeSol: this.cfg.priorityFeeMicroLamports / 1e9,
      raw: body, // echoed verbatim to /transaction/swap-base-in
    };
  }

  async buy(mint: string, sizeSol: number, slippageBps: number, priorityFeeMicroLamports?: number): Promise<SwapExecution> {
    const quote = await this.getBuyQuote(mint, sizeSol, slippageBps);
    return this.execute(quote, mint, priorityFeeMicroLamports, true);
  }

  async sellRaw(mint: string, amountBaseUnits: string, slippageBps: number, priorityFeeMicroLamports?: number): Promise<SwapExecution> {
    const quote = await this.getSellQuote(mint, amountBaseUnits, slippageBps);
    return this.execute(quote, mint, priorityFeeMicroLamports, false);
  }

  /** Build the swap transaction from a quote, sign + broadcast via submitter. */
  private async execute(
    quote: AggregatorQuote,
    mint: string,
    priorityFeeMicroLamports: number | undefined,
    isBuy: boolean,
  ): Promise<SwapExecution> {
    const fee = priorityFeeMicroLamports ?? this.cfg.priorityFeeMicroLamports;
    try {
      const swapResponse = (quote.raw as RaydiumComputeResponse | undefined) ?? null;
      const txRes = await this.http.post<RaydiumTxResponse>(
        this.cfg.swapUrl,
        {
          computeUnitPriceMicroLamports: String(fee),
          swapResponse,
          txVersion: this.cfg.txVersion,
          wallet: this.walletPubkey,
          wrapSol: isBuy, // wrap SOL when buying
          unwrapSol: !isBuy, // unwrap back to SOL when selling
        },
        { timeoutMs: 15000 },
      );

      const txBase64 = txRes.data?.data?.[0]?.transaction;
      if (!txBase64) throw new Error('Raydium: /transaction returned no transaction');

      const txHash = await this.submitter.submit(txBase64, { priorityFeeMicroLamports: fee, mint });
      this.logger.info('Raydium swap submitted', { mint, txHash, isBuy });
      return {
        success: true,
        aggregator: this.name,
        txHash,
        amountIn: parseInt(quote.inAmount, 10) || 0,
        amountOut: parseInt(quote.outAmount, 10) || 0,
        feeSol: fee / 1e9,
        priceImpactPct: quote.priceImpactPct,
      };
    } catch (err) {
      const error = err instanceof Error ? err.message : String(err);
      this.logger.error('Raydium swap failed', { mint, error });
      return { success: false, aggregator: this.name, amountIn: 0, amountOut: 0, feeSol: 0, priceImpactPct: 0, error };
    }
  }
}

export default RaydiumDirectClient;
