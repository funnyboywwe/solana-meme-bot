import { IAggregator, LoggerLike, noopLogger } from './types';
import { PriceFallbackManager } from './PriceFallbackManager';

export interface SafetyResult {
  pass: boolean;
  rugScore?: number;
  reason?: string;
}

/** Injected adapter over the bot's SafetyEngine.evaluate(mint). */
export type SafetyEvaluator = (mint: string) => Promise<SafetyResult>;

export interface RouteValidationResult {
  ok: boolean;
  mint: string;
  reasons: string[];
  buyProvider?: string;
  sellProvider?: string;
  liquidityUsd?: number;
  priceUsd?: number;
}

export interface RouteValidatorConfig {
  minLiquidityUsd: number;
  /** When liquidity can't be determined, reject (safe) vs allow. Default: allow. */
  rejectOnUnknownLiquidity: boolean;
}

/**
 * Pre-Trade Validation gate (Requirement #1).
 *
 * Before ANY buy we require ALL of:
 *   1. token passes safety checks,
 *   2. liquidity >= minimum threshold,
 *   3. a BUY route exists on at least one aggregator,
 *   4. a SELL route exists on at least one aggregator.
 *
 * (4) is the entire reason this engine exists: if nothing can sell the token we
 * must NOT buy it, otherwise the position becomes an unsellable bag. The sell
 * route is probed with the buy quote's expected output so we validate a
 * realistic exit size, not a token dust amount.
 */
export class RouteValidator {
  private readonly logger: LoggerLike;

  constructor(
    private aggregators: IAggregator[],
    private priceManager: PriceFallbackManager,
    private safetyEvaluate: SafetyEvaluator,
    private cfg: RouteValidatorConfig,
    opts: { logger?: LoggerLike } = {},
  ) {
    this.logger = opts.logger ?? noopLogger;
  }

  async validateBuy(mint: string, sizeSol: number, slippageBps: number): Promise<RouteValidationResult> {
    const reasons: string[] = [];
    const result: RouteValidationResult = { ok: false, mint, reasons };

    // 1. Safety checks.
    let safetyPass = false;
    try {
      const safety = await this.safetyEvaluate(mint);
      safetyPass = safety.pass;
      if (!safety.pass) reasons.push(`safety_failed${safety.reason ? `:${safety.reason}` : ''}`);
    } catch (err) {
      reasons.push('safety_error');
      this.logger.warn('Safety check threw', { mint, error: err instanceof Error ? err.message : String(err) });
    }

    // 2. Liquidity (+ price snapshot) via the price fallback chain.
    const price = await this.priceManager.getPrice(mint);
    if (price) {
      result.priceUsd = price.priceUsd;
      result.liquidityUsd = price.liquidityUsd;
    }
    let liquidityOk = true;
    if (typeof result.liquidityUsd === 'number') {
      if (result.liquidityUsd < this.cfg.minLiquidityUsd) {
        liquidityOk = false;
        reasons.push('liquidity_below_min');
      }
    } else if (this.cfg.rejectOnUnknownLiquidity) {
      liquidityOk = false;
      reasons.push('liquidity_unknown');
    }

    // 3. Buy route must exist on some aggregator.
    const buy = await this.firstRoute('buy', mint, sizeSol, slippageBps);
    if (buy) result.buyProvider = buy.provider;
    else reasons.push('no_buy_route');

    // 4. Sell route must exist — probe with the buy quote's expected output.
    if (buy) {
      const sell = await this.firstRoute('sell', mint, sizeSol, slippageBps, buy.outAmount);
      if (sell) result.sellProvider = sell.provider;
      else reasons.push('no_sell_route');
    }

    result.ok = safetyPass && liquidityOk && !!result.buyProvider && !!result.sellProvider;
    if (!result.ok) this.logger.warn('Pre-trade validation rejected buy', { mint, reasons });
    return result;
  }

  /** Return the first aggregator that can quote the requested side, or null. */
  private async firstRoute(
    side: 'buy' | 'sell',
    mint: string,
    sizeSol: number,
    slippageBps: number,
    sellAmountBaseUnits?: string,
  ): Promise<{ provider: string; outAmount: string } | null> {
    for (const agg of this.aggregators) {
      try {
        const quote =
          side === 'buy'
            ? await agg.getBuyQuote(mint, sizeSol, slippageBps)
            : await agg.getSellQuote(mint, sellAmountBaseUnits ?? '0', slippageBps);
        if (quote && quote.outAmount && parseInt(quote.outAmount, 10) > 0) {
          return { provider: agg.name, outAmount: quote.outAmount };
        }
      } catch (err) {
        this.logger.info(`No ${side} route on ${agg.name}`, {
          mint,
          error: err instanceof Error ? err.message : String(err),
        });
      }
    }
    return null;
  }
}

export default RouteValidator;
