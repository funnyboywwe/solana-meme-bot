import { HttpClient, IPriceSource, PriceQuote } from './types';

/**
 * Concrete price sources for the PriceFallbackManager. Each takes an injected
 * HttpClient (no direct axios import) so they can be unit-tested with a fake
 * transport and reused on the server with the real AxiosHttpClient.
 */

/** 1) Jupiter Price API v3 — flat map keyed by mint, `usdPrice` per entry. */
export class JupiterPriceSource implements IPriceSource {
  readonly name = 'jupiter';
  constructor(private http: HttpClient, private url = 'https://lite-api.jup.ag/price/v3') {}

  async getPrice(mint: string): Promise<PriceQuote | null> {
    const res = await this.http.get<Record<string, { usdPrice?: number } | undefined>>(this.url, {
      params: { ids: mint },
      timeoutMs: 5000,
    });
    const price = res.data?.[mint]?.usdPrice;
    if (typeof price !== 'number' || price <= 0) return null;
    return { mint, priceUsd: price, source: this.name, ts: Date.now() };
  }
}

/** 2) Birdeye public price API. Requires an API key (X-API-KEY header). */
export class BirdeyePriceSource implements IPriceSource {
  readonly name = 'birdeye';
  constructor(
    private http: HttpClient,
    private apiKey: string,
    private url = 'https://public-api.birdeye.so/defi/price',
  ) {}

  async getPrice(mint: string): Promise<PriceQuote | null> {
    if (!this.apiKey) return null; // skip silently when unconfigured
    const res = await this.http.get<{ data?: { value?: number; liquidity?: number } }>(this.url, {
      params: { address: mint },
      headers: { 'X-API-KEY': this.apiKey, 'x-chain': 'solana' },
      timeoutMs: 5000,
    });
    const value = res.data?.data?.value;
    if (typeof value !== 'number' || value <= 0) return null;
    return { mint, priceUsd: value, liquidityUsd: res.data?.data?.liquidity, source: this.name, ts: Date.now() };
  }
}

/** 3) DexScreener token endpoint — picks the most-liquid pair. */
export class DexScreenerPriceSource implements IPriceSource {
  readonly name = 'dexscreener';
  constructor(private http: HttpClient, private baseUrl = 'https://api.dexscreener.com/tokens/v1/solana') {}

  async getPrice(mint: string): Promise<PriceQuote | null> {
    const res = await this.http.get<Array<{ priceUsd?: string; liquidity?: { usd?: number } }>>(
      `${this.baseUrl}/${mint}`,
      { timeoutMs: 6000 },
    );
    const pairs = Array.isArray(res.data) ? res.data : [];
    let best: { priceUsd: number; liquidityUsd: number } | null = null;
    for (const pair of pairs) {
      const price = pair.priceUsd ? parseFloat(pair.priceUsd) : 0;
      const liquidityUsd = pair.liquidity?.usd ?? 0;
      if (price > 0 && (!best || liquidityUsd > best.liquidityUsd)) {
        best = { priceUsd: price, liquidityUsd };
      }
    }
    if (!best) return null;
    return { mint, priceUsd: best.priceUsd, liquidityUsd: best.liquidityUsd, source: this.name, ts: Date.now() };
  }
}

export interface PoolReserves {
  solReserve: number; // WSOL reserve, denominated in SOL
  tokenReserve: number; // token reserve, denominated in whole tokens
}

/**
 * 4) Last-resort price from raw AMM pool reserves:
 *      priceUsd = (solReserve * solPriceUsd) / tokenReserve
 * The reserve fetch is injected (it needs an RPC connection / pool decoder),
 * keeping this source network-agnostic and unit-testable.
 */
export class PoolReservePriceSource implements IPriceSource {
  readonly name = 'pool-reserve';
  constructor(
    private getReserves: (mint: string) => Promise<PoolReserves | null>,
    private getSolPriceUsd: () => number,
  ) {}

  async getPrice(mint: string): Promise<PriceQuote | null> {
    const reserves = await this.getReserves(mint);
    if (!reserves || reserves.tokenReserve <= 0 || reserves.solReserve <= 0) return null;
    const solUsd = this.getSolPriceUsd();
    if (solUsd <= 0) return null;
    const priceUsd = (reserves.solReserve * solUsd) / reserves.tokenReserve;
    if (priceUsd <= 0) return null;
    const liquidityUsd = reserves.solReserve * solUsd * 2; // both legs of the pool
    return { mint, priceUsd, liquidityUsd, source: this.name, ts: Date.now() };
  }
}
