import axios from 'axios';
import { Keypair, VersionedTransaction } from '@solana/web3.js';
import { HttpClient, HttpRequestConfig, HttpResponse, TxSubmitter } from './types';
import { WriteRpcProvider } from '../../core/WriteRpcProvider';

/**
 * Production transport + transaction submission for the multi-aggregator engine.
 *
 * These are the ONLY files in the engine that import axios / @solana/web3.js,
 * so all the trading, routing, validation, health, price-fallback, and
 * position-protection logic stays free of network/wallet concerns and is fully
 * unit-testable with injected fakes.
 */

/** Default axios-backed HttpClient used by the price sources + Raydium client. */
export class AxiosHttpClient implements HttpClient {
  async get<T = unknown>(url: string, config?: HttpRequestConfig): Promise<HttpResponse<T>> {
    const res = await axios.get<T>(url, {
      params: config?.params,
      headers: config?.headers,
      timeout: config?.timeoutMs,
    });
    return { data: res.data, status: res.status };
  }

  async post<T = unknown>(url: string, body?: unknown, config?: HttpRequestConfig): Promise<HttpResponse<T>> {
    const res = await axios.post<T>(url, body, {
      params: config?.params,
      headers: config?.headers,
      timeout: config?.timeoutMs,
    });
    return { data: res.data, status: res.status };
  }
}

/**
 * Production TxSubmitter for Raydium Direct. Deserialises Raydium's base64 V0
 * transaction, signs it with the bot wallet, optionally simulates, then
 * broadcasts via the WRITE-RPC pool (OrbitFlare -> QuickNode failover) — the
 * exact same multi-RPC path the Jupiter executor uses.
 */
export class RaydiumTxSubmitter implements TxSubmitter {
  constructor(
    private keypair: Keypair,
    private write: WriteRpcProvider,
    private simulateBeforeSend = true,
  ) {}

  async submit(txBase64: string): Promise<string> {
    const tx = VersionedTransaction.deserialize(Buffer.from(txBase64, 'base64'));
    tx.sign([this.keypair]);

    if (this.simulateBeforeSend) {
      const sim = await this.write.simulateTransaction(tx, {
        sigVerify: false,
        replaceRecentBlockhash: true,
        commitment: 'processed',
      });
      if (sim.value.err) {
        throw new Error(`Raydium simulation failed: ${JSON.stringify(sim.value.err)}`);
      }
    }

    return this.write.sendRawTransaction(tx.serialize(), {
      skipPreflight: this.simulateBeforeSend,
      maxRetries: 2,
      preflightCommitment: 'confirmed',
    });
  }
}
