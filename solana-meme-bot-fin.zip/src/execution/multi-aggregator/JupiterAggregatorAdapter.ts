import {
  AggregatorQuote,
  IAggregator,
  JupiterLike,
  JupiterQuote,
  JupiterSwapResult,
  SwapExecution,
  WSOL_MINT,
  LoggerLike,
  noopLogger,
} from './types';

/**
 * Adapts the bot's existing (MEV-protected) JupiterClient to the IAggregator
 * contract so the router can treat Jupiter (primary) and Raydium Direct
 * (fallback) interchangeably. This is pure delegation + result normalisation —
 * no new Jupiter trading logic lives here.
 */
export class JupiterAggregatorAdapter implements IAggregator {
  readonly name = 'jupiter';
  private readonly logger: LoggerLike;

  constructor(private jupiter: JupiterLike, opts: { logger?: LoggerLike } = {}) {
    this.logger = opts.logger ?? noopLogger;
  }

  async getBuyQuote(mint: string, sizeSol: number, slippageBps: number): Promise<AggregatorQuote> {
    const lamports = Math.floor(sizeSol * 1e9);
    const quote = await this.jupiter.getQuote(WSOL_MINT, mint, lamports, slippageBps);
    return this.toQuote(WSOL_MINT, mint, quote, slippageBps);
  }

  async getSellQuote(mint: string, amountBaseUnits: string, slippageBps: number): Promise<AggregatorQuote> {
    const quote = await this.jupiter.getQuote(mint, WSOL_MINT, amountBaseUnits, slippageBps);
    return this.toQuote(mint, WSOL_MINT, quote, slippageBps);
  }

  private toQuote(inputMint: string, outputMint: string, q: JupiterQuote, slippageBps: number): AggregatorQuote {
    if (!q || !q.outAmount) throw new Error(`Jupiter: no route for ${inputMint} → ${outputMint}`);
    return {
      aggregator: this.name,
      inputMint,
      outputMint,
      inAmount: q.inAmount,
      outAmount: q.outAmount,
      priceImpactPct: parseFloat(q.priceImpactPct ?? '0') || 0,
      slippageBps: q.slippageBps ?? slippageBps,
      // Jupiter applies the network/priority fee at execution time inside
      // JupiterClient; we surface 0 here so route cost comparison ranks purely on
      // output for Jupiter and lets the explicit Raydium fee break ties.
      estFeeSol: 0,
    };
  }

  async buy(mint: string, sizeSol: number, slippageBps: number, priorityFeeMicroLamports?: number): Promise<SwapExecution> {
    const result = await this.jupiter.buy(mint, sizeSol, slippageBps, priorityFeeMicroLamports);
    return this.toExecution(result);
  }

  async sellRaw(mint: string, amountBaseUnits: string, slippageBps: number, priorityFeeMicroLamports?: number): Promise<SwapExecution> {
    const result = await this.jupiter.sellRaw(mint, amountBaseUnits, slippageBps, priorityFeeMicroLamports);
    return this.toExecution(result);
  }

  private toExecution(r: JupiterSwapResult): SwapExecution {
    if (!r.success || !r.txHash) {
      this.logger.warn('Jupiter swap did not fill', { error: r.error });
    }
    return {
      success: r.success && !!r.txHash,
      aggregator: this.name,
      txHash: r.txHash,
      amountIn: r.amountIn,
      amountOut: r.amountOut,
      feeSol: r.feeSol,
      priceImpactPct: r.priceImpactPct,
      error: r.error,
    };
  }
}

export default JupiterAggregatorAdapter;
