import { LAMPORTS_PER_SOL } from '@solana/web3.js';
import { AppConfig } from '../config/AppConfig';
import { ExtendedConfig } from '../config/schema';
import { createModuleLogger } from '../core/Logger';
import { PositionScoreInput, PositionSizeResult } from '../core/types';
import { getPositionSizer } from './PositionSizer';
import { getReadRpcProvider, ReadRpcProvider } from '../core/ReadRpcProvider';

const logger = createModuleLogger('DynamicPositionSizingEngine');

type SizingMode = 'conservative' | 'balanced' | 'aggressive';

interface ModeConfig {
  basePct: number;
  maxPct: number;
  momentumWeight: number;
  smartMoneyWeight: number;
  liquidityWeight: number;
  riskWeight: number;
}

/**
 * DynamicPositionSizingEngine computes position size using a multi-factor
 * weighted model instead of a flat percentage.
 *
 * Composite score (0-100):
 *   compositeScore = (momentum   * momentumWeight)
 *                  + (smartMoney * smartMoneyWeight)
 *                  + (liquidity  * liquidityWeight)
 *                  + (risk       * riskWeight)
 *
 * Position size:
 *   sizePct = basePct + (maxPct - basePct) * (compositeScore / 100)
 *   sizeSol = balance * sizePct
 *
 * Hard caps applied by ExposureManager after this calculation.
 */
export class DynamicPositionSizingEngine {
  private cfg: ExtendedConfig['positionSizing'];
  private read: ReadRpcProvider;
  private mode: SizingMode;

  constructor(baseCfg: AppConfig, extCfg: ExtendedConfig) {
    this.cfg = extCfg.positionSizing;
    this.mode = this.cfg.mode;
    this.read = getReadRpcProvider(baseCfg);

    logger.info('DynamicPositionSizingEngine initialized', { mode: this.mode });
  }

  /**
   * Compute position size from multi-factor scores.
   * Returns sizeSol and full breakdown for logging.
   */
  async computeSize(scores: PositionScoreInput, balanceSol?: number): Promise<PositionSizeResult> {
    // Fetch wallet balance if not provided
    let balance = balanceSol;
    if (balance === undefined) {
      try {
        const sizer = getPositionSizer();
        const lamports = await this.read.getBalance(sizer.getKeypair().publicKey);
        balance = lamports / LAMPORTS_PER_SOL;
      } catch {
        balance = 0;
      }
    }

    const modeCfg = this.cfg[this.mode] as ModeConfig;

    // Composite score
    const weightSum = modeCfg.momentumWeight + modeCfg.smartMoneyWeight
      + modeCfg.liquidityWeight + modeCfg.riskWeight;

    const compositeScore = weightSum > 0
      ? (scores.momentumScore    * modeCfg.momentumWeight
       + scores.smartMoneyScore  * modeCfg.smartMoneyWeight
       + scores.liquidityScore   * modeCfg.liquidityWeight
       + scores.riskScore        * modeCfg.riskWeight) / weightSum
      : 50;

    // Bonus from acceleration and holder growth (additive, capped at +10 pts)
    const bonusScore = Math.min((scores.accelerationScore + scores.holderGrowthScore) / 20, 10);
    const finalScore = Math.min(compositeScore + bonusScore, 100);

    // Interpolate between basePct and maxPct
    const t = finalScore / 100;
    const sizePct = modeCfg.basePct + (modeCfg.maxPct - modeCfg.basePct) * t;

    // Reserve 10% of balance for fees
    const effectiveBalance = balance * 0.9;
    let sizeSol = effectiveBalance * sizePct;

    // Wallet confidence multiplier: reduce size if wallet confidence is low
    if (scores.walletConfidenceScore > 0) {
      const confidenceMultiplier = 0.5 + (scores.walletConfidenceScore / 100) * 0.5;
      sizeSol *= confidenceMultiplier;
    }

    let cappedBy = 'none';
    const minSize = 0.01;
    if (sizeSol < minSize) {
      sizeSol = 0;
      cappedBy = 'min_size';
    }

    logger.debug('Dynamic position size', {
      mode: this.mode,
      compositeScore: compositeScore.toFixed(1),
      finalScore: finalScore.toFixed(1),
      sizePct: (sizePct * 100).toFixed(2) + '%',
      sizeSol: sizeSol.toFixed(4),
      balance: balance.toFixed(4),
    });

    return {
      sizeSol,
      pct: sizePct,
      breakdown: scores,
      mode: this.mode,
      cappedBy,
    };
  }

  setMode(mode: SizingMode): void {
    this.mode = mode;
    logger.info('Position sizing mode changed', { mode });
  }

  getMode(): SizingMode {
    return this.mode;
  }
}

export default DynamicPositionSizingEngine;
