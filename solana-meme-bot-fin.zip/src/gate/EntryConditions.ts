import { AppConfig } from '../config/AppConfig';

/**
 * EntryConditions validates each entry condition independently
 */
export class EntryConditions {
  private minLiquidityUsd: number;
  private minMarketCapUsd: number;
  private maxMarketCapUsd: number;
  private maxSlippageBps: number;

  constructor(cfg: AppConfig) {
    this.minLiquidityUsd = cfg.safety.minLiquidityUsd;
    this.minMarketCapUsd = cfg.filters.minMarketCapUsd;
    this.maxMarketCapUsd = cfg.filters.maxMarketCapUsd;
    this.maxSlippageBps = cfg.execution.maxSlippageBps;
  }

  /**
   * Check minimum liquidity
   */
  checkLiquidity(liquidityUsd: number): boolean {
    return liquidityUsd >= this.minLiquidityUsd;
  }

  /**
   * Check market cap is within range
   */
  checkMarketCap(mcapUsd: number): boolean {
    return mcapUsd >= this.minMarketCapUsd && mcapUsd <= this.maxMarketCapUsd;
  }

  /**
   * Estimate slippage based on liquidity
   * Rule: slippage ≈ (orderSize / liquidity) * 10000 bps
   * For fixed order size (assume 1 SOL = $150):
   */
  checkSlippage(liquidityUsd: number): boolean {
    if (liquidityUsd === 0) return false;

    // Assume typical order size
    const typicalOrderUsd = 500;
    const estimatedSlippageBps = (typicalOrderUsd / liquidityUsd) * 10000;

    return estimatedSlippageBps <= this.maxSlippageBps;
  }
}

export default EntryConditions;
