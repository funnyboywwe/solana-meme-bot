import { AppConfig } from './AppConfig';
import { ExtendedConfig } from './schema';
import { createModuleLogger } from '../core/Logger';

const logger = createModuleLogger('ProductionGuard');

/**
 * H-1: Production safety guard.
 *
 * The development config (default.yaml) intentionally ships permissive
 * "LIVE TEST" values: a tiny fixed position size, relaxed safety thresholds and
 * fail-open safety. Running those values under a real production deployment
 * would be dangerous, so when CONFIG_ENV / NODE_ENV resolves to "production" we
 * refuse to start unless the dangerous live-test knobs have been overridden with
 * safe production values (see production.yaml).
 *
 * In non-production environments we only log warnings, so live testing is
 * never blocked.
 */
export function assertProductionSafety(cfg: AppConfig, extCfg: ExtendedConfig): void {
  const env = process.env.CONFIG_ENV || process.env.NODE_ENV || 'development';
  const isProduction = env === 'production';

  const violations: string[] = [];

  if (cfg.risk.fixedPositionSizeSol > 0) {
    violations.push(
      `risk.fixedPositionSizeSol is ${cfg.risk.fixedPositionSizeSol} (live-test fixed sizing); set to 0 for production`,
    );
  }
  if (!cfg.safety.failClosedOnUnknownSafety) {
    violations.push('safety.failClosedOnUnknownSafety must be true in production');
  }
  if (!cfg.safety.requireMintDisabled) {
    violations.push('safety.requireMintDisabled must be true in production');
  }
  if (!cfg.safety.requireFreezeDisabled) {
    violations.push('safety.requireFreezeDisabled must be true in production');
  }
  if (cfg.safety.minLiquidityUsd < 10000) {
    violations.push(
      `safety.minLiquidityUsd is ${cfg.safety.minLiquidityUsd}; expected >= 10000 in production`,
    );
  }
  if (cfg.safety.maxRugScore > 50) {
    violations.push(
      `safety.maxRugScore is ${cfg.safety.maxRugScore}; expected <= 50 in production`,
    );
  }
  if (extCfg.exposure.maxOpenPositions !== cfg.risk.maxConcurrentPositions) {
    violations.push(
      `exposure.maxOpenPositions (${extCfg.exposure.maxOpenPositions}) must equal ` +
        `risk.maxConcurrentPositions (${cfg.risk.maxConcurrentPositions})`,
    );
  }

  if (violations.length === 0) {
    logger.info('Config safety guard passed', { env, isProduction });
    return;
  }

  if (isProduction) {
    logger.error('Production config guard FAILED — refusing to start', { env, violations });
    throw new Error(
      `Production safety guard failed:\n  - ${violations.join('\n  - ')}\n` +
        'Refusing to start with live-test/unsafe config under production. ' +
        'Override these in production.yaml (or correct CONFIG_ENV).',
    );
  }

  logger.warn('Config contains live-test/unsafe values (allowed in non-production)', {
    env,
    violations,
  });
}

export default assertProductionSafety;
