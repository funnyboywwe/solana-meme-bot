import 'dotenv/config';
import * as http from 'http';
import { loadConfig, loadRawConfig, redactedConfig } from './config/AppConfig';
import { ExtendedConfigSchema } from './config/schema';
import { initLogger, getLogger } from './core/Logger';
import { initDatabase, closeDatabase } from './db/Database';
import { EventBus } from './core/EventBus';
import { AlertManager } from './analytics/AlertManager';
import TokenRepository from './db/repositories/TokenRepository';
import PositionRepository from './db/repositories/PositionRepository';
import type { TokenInfo } from './core/types';

async function bootstrap(): Promise<void> {
  // 1. Load base config
  const cfg = loadConfig();

  // 2. Load extended config (new modules)
  // FIX: parse the RAW merged config (yaml + env), not the already-narrowed
  // AppConfig. ConfigSchema strips unknown keys, so parsing `cfg` always
  // discarded the extended module sections and silently used schema defaults.
  const extResult = ExtendedConfigSchema.safeParse(loadRawConfig());
  if (!extResult.success) {
    console.error('Extended config validation failed:', extResult.error.issues);
    process.exit(1);
  }
  const extCfg = extResult.data;

  // 3. Logger
  initLogger({ level: cfg.analytics.logLevel, logDir: cfg.analytics.logDir, retentionDays: cfg.analytics.logRetentionDays });
  const logger = getLogger('Bootstrap');
  logger.info('Solana Meme Bot starting', { config: redactedConfig(cfg) });

  // H-1: production safety guard — refuse to start with live-test/unsafe config
  // when running under production (CONFIG_ENV/NODE_ENV === 'production').
  const { assertProductionSafety } = await import('./config/productionGuard');
  assertProductionSafety(cfg, extCfg);

  // 4. Database (runs schema.sql + 002_extensions.sql)
  initDatabase(cfg.db.path, cfg.db.walCheckpointIntervalMs);
  logger.info('Database initialised');

  // ── 5. Import all modules ───────────────────────────────────────────────────
  const { SafetyEngine }               = await import('./engines/safety/SafetyEngine');
  const { MomentumEngine }             = await import('./engines/momentum/MomentumEngine');
  const { WalletIntelEngine }          = await import('./engines/wallet-intel/WalletIntelEngine');
  const { CopyTradingEngine }          = await import('./engines/copytrading/CopyTradingEngine');
  const { HybridEntryGate }            = await import('./gate/HybridEntryGate');
  const { RiskManager }                = await import('./risk/RiskManager');
  const { StopLossManager }            = await import('./risk/StopLossManager');
  const { ExecutionEngine }            = await import('./execution/ExecutionEngine');
  const { PnLTracker }                 = await import('./analytics/PnLTracker');
  const { AnalyticsEngine }            = await import('./analytics/AnalyticsEngine');
  const { DashboardAPI }               = await import('./analytics/DashboardAPI');
  const { MetricsExporter }            = await import('./analytics/MetricsExporter');

  // New engines
  const { SmartMoneyClusterEngine }    = await import('./engines/smart-money/SmartMoneyClusterEngine');
  const { LiquidityInflowEngine }      = await import('./engines/liquidity/LiquidityInflowEngine');
  const { MultiWalletConfirmation }    = await import('./engines/confirmation/MultiWalletConfirmation');
  const { VolumeAccelerationEngine }   = await import('./engines/volume/VolumeAccelerationEngine');
  const { HolderGrowthEngine }         = await import('./engines/holders/HolderGrowthEngine');
  const { PumpfunMigrationEngine }     = await import('./engines/migration/PumpfunMigrationEngine');
  const { GlobalKillSwitch }           = await import('./risk/GlobalKillSwitch');
  const { ExposureManager }            = await import('./risk/exposure/ExposureManager');
  const { DynamicPositionSizingEngine }= await import('./risk/DynamicPositionSizingEngine');

  // ── 6. Instantiate engines ─────────────────────────────────────────────────
  const safetyEngine       = new SafetyEngine(cfg);
  const momentumEngine     = new MomentumEngine(cfg);
  const walletIntel        = new WalletIntelEngine(cfg);
  const copyEngine         = new CopyTradingEngine(cfg, walletIntel);
  const entryGate          = new HybridEntryGate(cfg, safetyEngine, extCfg);
  const riskManager        = new RiskManager(cfg);
  const stopLossManager    = new StopLossManager(cfg);
  const executionEngine    = new ExecutionEngine(cfg, extCfg, {
    // C-3: when every aggregator fails to sell a position across all retry
    // rounds, surface a loud alert so the position isn't silently stranded.
    // (alertManager is constructed just below; this closure only runs at trade
    // time, well after bootstrap finishes.)
    onEmergencySell: (info) => {
      logger.error('EMERGENCY: position unsellable across all aggregators', info);
      void alertManager.sendAlert(
        `\u26a0\ufe0f EMERGENCY: ${info.mint} could not be sold via any aggregator (tried: ${info.triedProviders.join(', ')}). Position may be stuck \u2014 check manually.`,
        'error',
      );
    },
  });
  const pnlTracker         = new PnLTracker();

  // New engines
  const clusterEngine      = new SmartMoneyClusterEngine(cfg, extCfg);
  const liquidityEngine    = new LiquidityInflowEngine(cfg, extCfg);
  const confirmationEngine = new MultiWalletConfirmation(cfg, extCfg);
  const volumeAccelEngine  = new VolumeAccelerationEngine(cfg, extCfg);
  const holderEngine       = new HolderGrowthEngine(cfg, extCfg);
  const migrationEngine    = new PumpfunMigrationEngine(cfg, extCfg);
  const killSwitch         = new GlobalKillSwitch(cfg, extCfg);
  const alertManager       = new AlertManager(extCfg.monitoring);
  const exposureManager    = new ExposureManager(cfg, extCfg);
  const dynamicSizer       = new DynamicPositionSizingEngine(cfg, extCfg);

  // Wire extended engines into entry gate
  entryGate.wireEngines({ clusterEngine, liquidityEngine, confirmationEngine, holderEngine, killSwitch });

  // FIX: give RiskManager portfolio exposure limits + dynamic sizing.
  riskManager.wireRisk({ exposureManager, dynamicSizer });

  // Multi-RPC failover: start periodic health/latency probing so the trading
  // hot path automatically routes to the fastest healthy endpoint and fails
  // over when one provider degrades.
  const { getRpcManager } = await import('./core/RpcManager');
  getRpcManager(cfg).startHealthChecks();

  // ── 7. Event subscriptions ─────────────────────────────────────────────────

  // Core ingestion
  // FIX: persist the token row FIRST. SafetyEngine/HybridEntryGate use
  // UPDATE ... WHERE mint=? and findByMint(); without an existing row their
  // writes silently no-op and entries never qualify. Handlers run in
  // registration order, so this upsert completes before the safety handler.
  EventBus.on('TOKEN_CREATED', (e) => {
    const token: TokenInfo = {
      mint: e.mint,
      symbol: e.symbol,
      decimals: e.decimals,
      createdAt: e.createdAt,
      mcapUsd: 0,
      liquidityUsd: e.initialLiquidityUsd,
      poolAddress: e.poolAddress,
      source: e.source,
    };
    TokenRepository.upsert(token);
  });
  EventBus.on('TOKEN_CREATED', async (e) => {
    // LIVE TEST: evaluate safety (persists rug data to DB for the entry gate) and
    // price-track ONLY tokens that PASS — these are the real entry candidates.
    // Polling tokens that fail safety wastes Jupiter calls since the gate blocks
    // them anyway. priceOracle is created later in bootstrap; this closure runs at
    // event time (after monitors connect), so the reference is initialized by then.
    const report = await safetyEngine.evaluate(e.mint);
    if (report.pass) priceOracle.trackToken(e.mint);
  });
  EventBus.on('TOKEN_CREATED', (e) => momentumEngine.registerToken(e));
  EventBus.on('TOKEN_CREATED', (e) => holderEngine.processTokenCreated(e));
  EventBus.on('TOKEN_CREATED', (e) => migrationEngine.processTokenCreated(e));

  EventBus.on('TRADE_DETECTED', (e) => momentumEngine.processTrade(e));
  EventBus.on('TRADE_DETECTED', (e) => volumeAccelEngine.processTrade(e));
  EventBus.on('TRADE_DETECTED', (e) => liquidityEngine.recordTrade(e.mint, e.side, e.amountUsd));

  EventBus.on('POOL_UPDATE', (e) => momentumEngine.processPoolUpdate(e));
  EventBus.on('POOL_UPDATE', (e) => liquidityEngine.processPoolUpdate(e));
  EventBus.on('POOL_UPDATE', (e) => migrationEngine.processPoolUpdate(e));

  EventBus.on('PRICE_UPDATE', (e) => momentumEngine.processPriceUpdate(e));
  EventBus.on('PRICE_UPDATE', (e) => liquidityEngine.processPriceUpdate(e));
  EventBus.on('PRICE_UPDATE', (e) => stopLossManager.checkPosition(e));

  // Wallet tracking
  EventBus.on('WALLET_TX', (e) => void copyEngine.processTx(e));
  EventBus.on('WALLET_TX', (e) => walletIntel.processWalletTx(e));
  EventBus.on('WALLET_TX', (e) => clusterEngine.processWalletBuy(e));
  EventBus.on('WALLET_TX', (e) => { if (e.side === 'buy') confirmationEngine.recordBuy(e); });

  // Signals → entry gate
  EventBus.on('MOMENTUM_SIGNAL',        (e) => void entryGate.evaluateMomentum(e));
  EventBus.on('COPY_SIGNAL',            (e) => void entryGate.evaluateCopy(e));
  EventBus.on('SMART_MONEY_CLUSTER',    (e) => void entryGate.evaluateSmartMoneyCluster(e));
  EventBus.on('MULTI_WALLET_CONFIRMED', (e) => void entryGate.evaluateMultiWalletConfirmed(e));

  // Entry → risk → execution
  EventBus.on('ENTRY_APPROVED', (e) => void riskManager.evaluate(e));
  EventBus.on('ORDER_READY',    (e) => void executionEngine.execute(e));

  // Trade lifecycle
  EventBus.on('TRADE_FILLED', (e) => stopLossManager.arm(e));
  EventBus.on('TRADE_FILLED', (e) => pnlTracker.openPosition(e));
  EventBus.on('TRADE_FILLED', (e) => { if (e.side === 'sell') pnlTracker.closePosition(e); });
  EventBus.on('TRADE_FILLED', (e) => exposureManager.onTradeFilled(e));
  EventBus.on('TRADE_FILLED', (e) => {
    void alertManager.sendTradeAlert({
      side: e.side,
      mint: e.mint,
      sizeSol: e.sizeSol,
      priceUsd: e.priceUsd,
      pnlSol: e.realisedPnlSol,
      txHash: e.txHash,
    });
  });
  EventBus.on('CLOSE_SIGNAL',  (e) => void executionEngine.sell(e));
  // FIX: start a token cooldown as soon as we decide to exit, so we don't
  // immediately re-enter the same token right after closing it.
  EventBus.on('CLOSE_SIGNAL',  (e) => riskManager.getCooldownTracker().startTokenCooldown(e.mint));

  // Risk monitoring (also forwarded to Telegram/Discord when configured)
  EventBus.on('KILL_SWITCH',     (e) => { logger.warn('Kill switch event', e); void alertManager.sendAlert(`Kill switch: ${JSON.stringify(e)}`, 'error'); });
  EventBus.on('EXPOSURE_LIMIT',  (e) => { logger.warn('Exposure limit hit', e); void alertManager.sendAlert(`Exposure limit hit: ${JSON.stringify(e)}`, 'warning'); });
  EventBus.on('MEV_DETECTED',    (e) => { logger.warn('MEV detected', e); void alertManager.sendAlert(`MEV detected: ${JSON.stringify(e)}`, 'warning'); });

  // Position-close bookkeeping: update loss streak, circuit breaker and kill
  // switch whenever a sell fills.
  EventBus.on('TRADE_FILLED', (e) => {
    if (e.side !== 'sell') return;
    void (async () => {
      const realisedPnlSol = e.realisedPnlSol ?? 0;
      exposureManager.onPositionClosed(realisedPnlSol);
      try {
        const balanceSol = await exposureManager.getBalanceSol();
        riskManager.getCircuitBreaker().update(realisedPnlSol, balanceSol);
      } catch (err) {
        logger.warn('Circuit breaker update failed', { error: String(err) });
      }
      const state = exposureManager.getState();
      killSwitch.evaluate({
        dailyDrawdownPct: state.drawdownPct,
        consecutiveLosses: state.consecutiveLosses,
      });
    })();
  });

  logger.info('All event subscriptions wired');

  // ── 8. Start ingestion streams ─────────────────────────────────────────────
  const { HeliusWebSocketClient } = await import('./ingestion/HeliusWebSocket');
  const { PumpFunMonitor }        = await import('./ingestion/PumpFunMonitor');
  const { RaydiumMonitor }        = await import('./ingestion/RaydiumMonitor');
  const { DexScreenerMonitor }    = await import('./ingestion/DexScreenerMonitor');
  const { WalletMonitor }         = await import('./ingestion/WalletMonitor');
  const { PriceOracle }           = await import('./ingestion/PriceOracle');

  const helius       = new HeliusWebSocketClient(cfg);
  const pumpFun      = new PumpFunMonitor(cfg);
  const raydium      = new RaydiumMonitor(cfg);
  // Trending-momentum source (replaces the dead Helius trade stream). Polls
  // DexScreener for the hottest Solana tokens, scores momentum, and feeds the
  // top N into the entry pipeline (TOKEN_CREATED + PRICE_UPDATE + MOMENTUM_SIGNAL).
  const dexScreener  = new DexScreenerMonitor(cfg, extCfg);
  const walletMonitor = new WalletMonitor(cfg, walletIntel.getMonitoredWallets());
  const priceOracle  = new PriceOracle(cfg);

  // FIX: actually track/untrack prices over a position's lifecycle. Without
  // this the PriceOracle never polled token prices, so stop-loss/take-profit
  // (driven by PRICE_UPDATE) never fired.
  EventBus.on('TRADE_FILLED', (e) => {
    if (e.side === 'buy') priceOracle.trackToken(e.mint);
    else priceOracle.untrackToken(e.mint);
  });

  await helius.connect();
  await pumpFun.connect();
  await raydium.connect();
  await dexScreener.connect();
  await walletMonitor.connect();
  priceOracle.start();

  // LIVE TEST: backfill the existing backlog. New pools are price-tracked on safety
  // pass via the TOKEN_CREATED handler, but tokens discovered in PRIOR sessions are
  // otherwise invisible after a restart (only fresh post-startup pools get tracked).
  // Re-track recently-seen tokens that already passed safety so the bot keeps
  // watching its known good candidates instead of starting from near-zero coverage.
  {
    const recent = TokenRepository.getRecentTokens(2 * 60 * 60 * 1000, 200);
    let backfilled = 0;
    for (const t of recent) {
      const s = TokenRepository.getSafety(t.mint);
      const safe =
        !!s &&
        !s.isHoneypot &&
        s.mintDisabled &&
        s.freezeDisabled &&
        (s.holderConcentration ?? 100) <= cfg.safety.maxHolderConcentrationPct &&
        s.rugScore <= cfg.safety.maxRugScore &&
        t.liquidityUsd >= cfg.safety.minLiquidityUsd;
      if (safe) {
        priceOracle.trackToken(t.mint);
        backfilled++;
      }
    }
    logger.info('PriceOracle backlog backfill complete', {
      scanned: recent.length,
      tracked: backfilled,
    });
  }

  // ── 9. Reconcile wallet vs DB ──────────────────────────────────────────────
  // Close any 'open' positions whose tokens are no longer in the wallet (e.g.
  // sold manually outside the bot). Must run BEFORE restoreFromDb so these
  // ghost positions never get loaded into the StopLoss map or price tracker,
  // and stop consuming ExposureManager open-position slots.
  const { WalletReconciler } = await import('./risk/WalletReconciler');
  await new WalletReconciler(cfg).reconcileOpenPositions();

  // ── 9b. Restore open positions ─────────────────────────────────────────────
  await stopLossManager.restoreFromDb();
  // FIX: re-track prices for positions restored from a previous session.
  for (const pos of PositionRepository.findOpenPositions()) {
    priceOracle.trackToken(pos.tokenMint);
  }
  // Stale-position safeguard: periodically force-exit (and ultimately abandon)
  // positions that never hit TP/SL because their price feed went dead — so a
  // single unpriceable/rugged token can't hold an open slot forever.
  stopLossManager.startStaleSweep();
  logger.info('Open positions restored');

  // Reconcile pending trades from previous session
  const { FailedTradeRecovery } = await import('./execution/FailedTradeRecovery');
  await new FailedTradeRecovery(cfg).reconcilePendingTrades();

  // ── 10. Analytics & Dashboard ──────────────────────────────────────────────
  const analyticsEngine = new AnalyticsEngine(
    cfg,
    () => stopLossManager.getOpenPositionCount(),
    () => require('./db/repositories/PositionRepository').default.findOpenPositions(),
  );

  const wsStatusFn = () => ({
    helius: helius.isConnected(),
    pumpFun: pumpFun.isConnected(),
    raydium: raydium.isConnected(),
    dexScreener: dexScreener.isConnected(),
    walletMonitor: walletMonitor.isConnected(),
  });

  const dashboardAPI = new DashboardAPI(cfg, analyticsEngine, wsStatusFn);
  dashboardAPI.start();

  let metricsExporter: InstanceType<typeof MetricsExporter> | null = null;
  if (cfg.analytics.prometheusEnabled) {
    metricsExporter = new MetricsExporter(
      cfg,
      () => stopLossManager.getOpenPositionCount(),
      () => require('./db/repositories/PositionRepository').default
               .findOpenPositions()
               .reduce((s: number, p: { unrealisedPnlSol: number }) => s + p.unrealisedPnlSol, 0),
    );
    metricsExporter.start();
  }

  // Startup notification + periodic daily PnL / risk report (Telegram/Discord)
  if (alertManager.isEnabled()) {
    void alertManager.sendAlert('Bot started and monitoring markets', 'success');
    if (extCfg.monitoring.dailyReportEnabled) {
      const sendDailyReport = (): void => {
        const summary = analyticsEngine.getSummary();
        const risk = analyticsEngine.getStrategyMetrics().getRiskAnalytics();
        void alertManager.sendReport('Daily PnL Report', {
          'Open positions': summary.openPositions,
          'Today PnL (SOL)': summary.todayPnlSol.toFixed(4),
          'Total PnL (SOL)': summary.totalPnlSol.toFixed(4),
          'Win rate %': summary.winRatePct,
          Trades: summary.totalTrades,
          Sharpe: risk.sharpe.toFixed(2),
          Sortino: risk.sortino.toFixed(2),
          'Max drawdown (SOL)': risk.maxDrawdownSol.toFixed(4),
          'Max drawdown %': risk.maxDrawdownPct.toFixed(1),
        });
      };
      const reportTimer = setInterval(sendDailyReport, 24 * 60 * 60 * 1000);
      if (typeof reportTimer.unref === 'function') reportTimer.unref();
    }
  }

  logger.info('Bot fully started');

  // ── 11. Graceful shutdown ──────────────────────────────────────────────────
  async function gracefulShutdown(signal: string): Promise<void> {
    logger.warn(`Received ${signal}, shutting down gracefully...`);
    dashboardAPI.stop();
    if (metricsExporter) metricsExporter.stop();
    priceOracle.stop();
    stopLossManager.stopStaleSweep();
    helius.disconnect();
    pumpFun.disconnect();
    raydium.disconnect();
    dexScreener.disconnect();
    walletMonitor.disconnect();
    walletIntel.stop();
    clusterEngine.stop();
    liquidityEngine.stop();
    confirmationEngine.stop();
    volumeAccelEngine.stop();
    holderEngine.stop();
    migrationEngine.stop();
    exposureManager.stop();
    closeDatabase();
    logger.info('Shutdown complete');
    process.exit(0);
  }

  process.on('SIGTERM', () => void gracefulShutdown('SIGTERM'));
  process.on('SIGINT',  () => void gracefulShutdown('SIGINT'));
  process.on('unhandledRejection', (r) => logger.error('Unhandled rejection', { reason: String(r) }));
  process.on('uncaughtException',  (e) => {
    logger.error('Uncaught exception', { error: e.message, stack: e.stack });
    void gracefulShutdown('uncaughtException');
  });
}

bootstrap().catch((err) => {
  console.error('Bootstrap failed:', err);
  process.exit(1);
});
