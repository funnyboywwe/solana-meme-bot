import { EventBus } from '../../core/EventBus';
import { AppConfig } from '../../config/AppConfig';
import { createModuleLogger } from '../../core/Logger';
import { SafetyReport } from '../../core/types';
import TokenRepository from '../../db/repositories/TokenRepository';
import { LiquidityChecker } from './LiquidityChecker';
import { MintAuthChecker } from './MintAuthChecker';
import { FreezeAuthChecker } from './FreezeAuthChecker';
import { HolderAnalyzer } from './HolderAnalyzer';
import { HoneypotDetector } from './HoneypotDetector';
import { LpLockChecker } from './LpLockChecker';

const logger = createModuleLogger('SafetyEngine');

/**
 * SafetyEngine orchestrates 6 concurrent safety checks:
 * 1. LiquidityChecker - min liquidity required
 * 2. MintAuthChecker - mint authority should be disabled
 * 3. FreezeAuthChecker - freeze authority should be disabled
 * 4. HolderAnalyzer - concentration of top holders
 * 5. HoneypotDetector - simulate sell to detect traps
 * 6. Composite rug score (0–100)
 *
 * Returns SafetyReport with pass/fail and detailed scores
 */
export class SafetyEngine {
  private liquidityChecker: LiquidityChecker;
  private mintAuthChecker: MintAuthChecker;
  private freezeAuthChecker: FreezeAuthChecker;
  private holderAnalyzer: HolderAnalyzer;
  private honeypotDetector: HoneypotDetector;
  private lpLockChecker: LpLockChecker;
  private minLiquidityUsd: number;
  private maxHolderConcentration: number;
  private maxRugScore: number;
  private requireLpLock: boolean;
  private lpLockRugScoreWeight: number;
  private failClosedOnUnknownSafety: boolean;

  constructor(cfg: AppConfig) {
    this.liquidityChecker = new LiquidityChecker(cfg);
    this.mintAuthChecker = new MintAuthChecker(cfg);
    this.freezeAuthChecker = new FreezeAuthChecker(cfg);
    this.holderAnalyzer = new HolderAnalyzer(cfg);
    this.honeypotDetector = new HoneypotDetector(cfg);
    this.lpLockChecker = new LpLockChecker(cfg);
    this.minLiquidityUsd = cfg.safety.minLiquidityUsd;
    this.maxHolderConcentration = cfg.safety.maxHolderConcentrationPct;
    this.maxRugScore = cfg.safety.maxRugScore;
    this.requireLpLock = cfg.safety.requireLpLock;
    this.lpLockRugScoreWeight = cfg.safety.lpLockRugScoreWeight;
    this.failClosedOnUnknownSafety = cfg.safety.failClosedOnUnknownSafety;

    logger.info('SafetyEngine initialized', {
      minLiquidityUsd: this.minLiquidityUsd,
      maxHolderConcentration: this.maxHolderConcentration,
      maxRugScore: this.maxRugScore,
    });
  }

  /**
   * Evaluate token safety
   */
  async evaluate(mint: string): Promise<SafetyReport> {
    try {
      const now = Date.now();
      const report: SafetyReport = {
        mint,
        rugScore: 0,
        liquidityOk: false,
        mintDisabled: false,
        freezeDisabled: false,
        holderConcentrationPct: 0,
        isHoneypot: false,
        liquidityUsd: 0,
        checkedAt: now,
        pass: false,
      };

      // 1. Check liquidity
      const liqResult = await this.liquidityChecker.check(mint);
      report.liquidityUsd = liqResult.liquidityUsd;
      report.liquidityOk = liqResult.pass;
      if (!report.liquidityOk) report.rugScore += 20;

      // 2. Check mint authority
      const mintAuthResult = await this.mintAuthChecker.check(mint);
      report.mintDisabled = mintAuthResult.disabled;
      if (!report.mintDisabled) report.rugScore += 25;

      // 3. Check freeze authority
      const freezeAuthResult = await this.freezeAuthChecker.check(mint);
      report.freezeDisabled = freezeAuthResult.disabled;
      if (!report.freezeDisabled) report.rugScore += 25;

      // 4. Check holder concentration
      const holderResult = await this.holderAnalyzer.analyze(mint);
      report.holderConcentrationPct = holderResult.concentration;
      if (holderResult.concentration > this.maxHolderConcentration) {
        report.rugScore += 20;
      }

      // 5. Check honeypot
      const honeypotResult = await this.honeypotDetector.detect(mint);
      report.isHoneypot = honeypotResult.isHoneypot;
      if (report.isHoneypot) report.rugScore += 40;

      // 6. Check LP lock / burn — un-burned LP lets the deployer pull liquidity
      //    (the most common meme-coin rug). Adds to rug score when not locked,
      //    and hard-blocks when safety.requireLpLock is enabled.
      const lpResult = await this.lpLockChecker.check(mint);
      report.lpLocked = lpResult.locked;
      report.lpLockedPct = lpResult.burnedPct;
      if (lpResult.checked && !lpResult.locked) report.rugScore += this.lpLockRugScoreWeight;

      // Fail-closed on incomplete safety data (H-2/H-3): if the honeypot or
      // holder check could not produce a definitive verdict (e.g. Jupiter or RPC
      // unavailable), block the token instead of trading blind. Gated by
      // safety.failClosedOnUnknownSafety (enabled in production.yaml, off in the
      // live-test default so a Jupiter blip doesn't halt all trading).
      const safetyDataUnknown =
        honeypotResult.status === 'unknown' || holderResult.status === 'unknown';
      if (safetyDataUnknown && this.failClosedOnUnknownSafety) {
        report.rugScore = Math.max(report.rugScore, this.maxRugScore + 1);
        logger.warn('Safety data incomplete; failing closed', {
          mint,
          honeypotStatus: honeypotResult.status,
          holderStatus: holderResult.status,
        });
      }

      // Final: compute pass/fail
      report.rugScore = Math.min(report.rugScore, 100);
      report.pass =
        report.liquidityOk &&
        report.mintDisabled &&
        report.freezeDisabled &&
        report.holderConcentrationPct <= this.maxHolderConcentration &&
        !report.isHoneypot &&
        (!this.requireLpLock || report.lpLocked === true) &&
        report.rugScore <= this.maxRugScore;

      // Persist to DB
      TokenRepository.updateSafety(mint, {
        rugScore: report.rugScore,
        mintDisabled: report.mintDisabled,
        freezeDisabled: report.freezeDisabled,
        holderConcentration: report.holderConcentrationPct,
        isHoneypot: report.isHoneypot,
        lpLocked: report.lpLocked,
        lpLockedPct: report.lpLockedPct,
      });

      logger.info('Safety check completed', {
        mint,
        rugScore: report.rugScore,
        pass: report.pass,
        liquidityOk: report.liquidityOk,
        liquidityUsd: report.liquidityUsd,
        mintDisabled: report.mintDisabled,
        freezeDisabled: report.freezeDisabled,
        holderConcentrationPct: report.holderConcentrationPct,
        isHoneypot: report.isHoneypot,
        lpLocked: report.lpLocked,
      });

      return report;
    } catch (err) {
      logger.error('Safety check failed', { mint, error: String(err) });
      return {
        mint,
        rugScore: 100, // Fail closed
        liquidityOk: false,
        mintDisabled: false,
        freezeDisabled: false,
        holderConcentrationPct: 100,
        isHoneypot: true,
        liquidityUsd: 0,
        checkedAt: Date.now(),
        pass: false,
      };
    }
  }
}

export default SafetyEngine;
