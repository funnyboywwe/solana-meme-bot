import { AppConfig } from '../../config/AppConfig';
import { createModuleLogger } from '../../core/Logger';
import axios from 'axios';

const logger = createModuleLogger('HoneypotDetector');

export interface HoneypotDetectionResult {
  isHoneypot: boolean;
  // Tri-state verdict (H-2):
  //   'safe'    – sell route confirmed, tax within bounds
  //   'unsafe'  – confirmed honeypot / no route / extreme tax
  //   'unknown' – could not determine (Jupiter rate-limited / unavailable)
  status: 'safe' | 'unsafe' | 'unknown';
  sellTaxPct?: number;
  reason?: string;
}

/**
 * HoneypotDetector simulates a sell to detect tokens that cannot be sold.
 *
 * BUG FIXED (#12): Previous version returned isHoneypot:true on ANY
 * network/API error, including Jupiter being rate-limited or temporarily
 * unavailable. This caused ALL tokens to fail safety whenever Jupiter
 * had a blip.
 *
 * FIX: On network error return isHoneypot:false (allow through) with a
 * log warning. Only return isHoneypot:true when we CONFIRM the swap is
 * unavailable (404 from Jupiter quote, explicit no-route error) or the
 * computed sell tax exceeds 50%.
 *
 * Honeypot signals (true positives):
 * - Jupiter /quote returns no route for the sell direction
 * - Sell tax > 50% (price impact is extreme)
 *
 * Non-honeypot signals (false positives to avoid):
 * - Network timeout
 * - Jupiter 429 rate limit
 * - Any non-route-specific error
 */
export class HoneypotDetector {
  private jupiterApiUrl: string;
  private readonly HIGH_SELL_TAX_PCT = 50;

  constructor(cfg: AppConfig) {
    this.jupiterApiUrl = cfg.execution.jupiterApiUrl;
  }

  async detect(mint: string): Promise<HoneypotDetectionResult> {
    const wsolMint = 'So11111111111111111111111111111111111111112';

    try {
      const response = await axios.get<{
        outAmount: string;
        inAmount: string;
        priceImpactPct: string;
      }>(
        `${this.jupiterApiUrl}/quote`,
        {
          params: {
            inputMint: mint,
            outputMint: wsolMint,
            amount: '1000000000',
            slippageBps: 1000,
          },
          timeout: 5000,
        },
      );

      const data = response.data;
      if (!data?.outAmount) {
        // Explicit empty response = no route = likely honeypot
        logger.warn('Honeypot suspected: no sell route from Jupiter', { mint });
        return { isHoneypot: true, status: 'unsafe', reason: 'no_sell_route' };
      }

      // Check effective sell tax from price impact
      const priceImpact = parseFloat(data.priceImpactPct ?? '0');
      if (priceImpact > this.HIGH_SELL_TAX_PCT) {
        logger.warn('Honeypot suspected: extreme sell tax', { mint, sellTaxPct: priceImpact });
        return { isHoneypot: true, status: 'unsafe', sellTaxPct: priceImpact, reason: 'extreme_sell_tax' };
      }

      return { isHoneypot: false, status: 'safe', sellTaxPct: priceImpact };
    } catch (err: unknown) {
      // FIX: distinguish "no route" (404/specific error) from network issues
      if (axios.isAxiosError(err)) {
        const status = err.response?.status;
        const errorData = err.response?.data as Record<string, unknown> | undefined;

        // Jupiter returns 400 with specific error messages for no-route scenarios
        if (status === 400) {
          const errMsg = String(errorData?.error ?? '');
          if (errMsg.includes('Could not find any route') || errMsg.includes('No routes')) {
            logger.warn('Honeypot confirmed: Jupiter explicitly says no route', { mint });
            return { isHoneypot: true, status: 'unsafe', reason: 'no_route_400' };
          }
        }

        // Rate limit or server error = network issue, not a honeypot signal
        if (status === 429 || (status !== undefined && status >= 500)) {
          logger.warn('Honeypot check skipped: Jupiter API error (not a honeypot signal)', { mint, status });
          return { isHoneypot: false, status: 'unknown', reason: 'api_unavailable' };
        }
      }

      // Unknown error — log and allow through (do not block on uncertainty)
      logger.warn('Honeypot detection error, allowing token through', { mint, error: String(err) });
      return { isHoneypot: false, status: 'unknown', reason: 'detection_error' };
    }
  }
}
