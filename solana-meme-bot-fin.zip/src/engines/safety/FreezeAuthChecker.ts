import { AppConfig } from '../../config/AppConfig';
import { createModuleLogger } from '../../core/Logger';
import { getMint, TOKEN_PROGRAM_ID, TOKEN_2022_PROGRAM_ID } from '@solana/spl-token';
import { PublicKey } from '@solana/web3.js';

import { getReadRpcProvider, ReadRpcProvider } from '../../core/ReadRpcProvider';

const logger = createModuleLogger('FreezeAuthChecker');

export interface FreezeAuthResult {
  disabled: boolean;
}

/**
 * FreezeAuthChecker verifies the token's freeze authority is null (disabled).
 *
 * BUG FIXED (#4): Previous code read freezeAuthorityOption at byte offset 40,
 * which lands in the middle of the `supply` u64 field (bytes 36–43).
 * Correct offset for freezeAuthorityOption is byte 46.
 *
 * FIX: Use @solana/spl-token getMint() which decodes the layout correctly.
 */
export class FreezeAuthChecker {
  private read: ReadRpcProvider;

  constructor(cfg: AppConfig) {
    // M-1: use the managed RPC pool (failover + rate-limit backoff) instead of a
    // private Connection that bypassed RpcManager and contributed to 429 storms.
    this.read = getReadRpcProvider(cfg);
  }

  async check(mint: string): Promise<FreezeAuthResult> {
    try {
      const mintPk = new PublicKey(mint);
      // Token-2022 mints are owned by a different program. getMint() defaults to
      // the legacy SPL Token program and throws TokenInvalidAccountOwnerError on
      // Token-2022 mints, which previously forced every such token to fail.
      // Detect the owning program first, then decode with the correct one.
      const programId = await this._resolveTokenProgram(mintPk);
      const mintInfo = await this.read.read((c) => getMint(c, mintPk, 'confirmed', programId), 'getMint');
      // getMint() returns null when freeze authority is COption::None
      return { disabled: mintInfo.freezeAuthority === null };
    } catch (err) {
      logger.warn('Freeze authority check failed', { mint, error: String(err) });
      return { disabled: false };
    }
  }

  /** Returns the token program that owns this mint (legacy SPL or Token-2022). */
  private async _resolveTokenProgram(mintPk: PublicKey): Promise<PublicKey> {
    const acct = await this.read.getAccountInfo(mintPk, 'confirmed');
    if (acct && acct.owner.equals(TOKEN_2022_PROGRAM_ID)) return TOKEN_2022_PROGRAM_ID;
    return TOKEN_PROGRAM_ID;
  }
}
