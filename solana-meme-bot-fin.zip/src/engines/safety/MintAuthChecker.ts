import { AppConfig } from '../../config/AppConfig';
import { createModuleLogger } from '../../core/Logger';
import { getMint, TOKEN_PROGRAM_ID, TOKEN_2022_PROGRAM_ID } from '@solana/spl-token';
import { PublicKey } from '@solana/web3.js';

import { getReadRpcProvider, ReadRpcProvider } from '../../core/ReadRpcProvider';

const logger = createModuleLogger('MintAuthChecker');

export interface MintAuthResult {
  disabled: boolean;
}

/**
 * MintAuthChecker verifies the token's mint authority is null (disabled).
 *
 * BUG FIXED (#3): Previous code read mintAuthorityOption at byte offset 36,
 * which is actually the start of the `supply` u64 field.
 *
 * SPL Mint account layout (82 bytes total):
 *   Bytes  0– 3  : mintAuthorityOption  (u32: 0=None, 1=Some)
 *   Bytes  4–35  : mintAuthority        (32-byte Pubkey)
 *   Bytes 36–43  : supply               (u64)
 *   Byte  44     : decimals             (u8)
 *   Byte  45     : isInitialized        (bool)
 *   Bytes 46–49  : freezeAuthorityOption (u32)
 *   Bytes 50–81  : freezeAuthority      (32-byte Pubkey)
 *
 * FIX: Use @solana/spl-token getMint() which decodes the layout correctly
 * rather than doing fragile manual byte arithmetic.
 */
export class MintAuthChecker {
  private read: ReadRpcProvider;

  constructor(cfg: AppConfig) {
    // M-1: use the managed RPC pool (failover + rate-limit backoff) instead of a
    // private Connection that bypassed RpcManager and contributed to 429 storms.
    this.read = getReadRpcProvider(cfg);
  }

  async check(mint: string): Promise<MintAuthResult> {
    try {
      const mintPk = new PublicKey(mint);
      // Token-2022 mints are owned by a different program. getMint() defaults to
      // the legacy SPL Token program and throws TokenInvalidAccountOwnerError on
      // Token-2022 mints, which previously forced every such token to fail.
      // Detect the owning program first, then decode with the correct one.
      const programId = await this._resolveTokenProgram(mintPk);
      const mintInfo = await this.read.read((c) => getMint(c, mintPk, 'confirmed', programId), 'getMint');
      // getMint() returns null when authority is disabled (COption::None)
      return { disabled: mintInfo.mintAuthority === null };
    } catch (err) {
      logger.warn('Mint authority check failed', { mint, error: String(err) });
      // Fail safe: treat as NOT disabled (risky) rather than blocking all tokens
      return { disabled: false };
    }
  }

  /** Returns the token program that owns this mint (legacy SPL or Token-2022). */
  private async _resolveTokenProgram(mintPk: PublicKey): Promise<PublicKey> {
    const acct = await this.read.getAccountInfo(mintPk, 'confirmed');
    if (acct && acct.owner.equals(TOKEN_2022_PROGRAM_ID)) return TOKEN_2022_PROGRAM_ID;
    return TOKEN_PROGRAM_ID;
  }
}
