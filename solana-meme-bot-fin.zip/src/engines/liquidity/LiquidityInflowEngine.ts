import axios from 'axios';
import { EventBus, PoolUpdateEvent, PriceUpdateEvent, LiquidityInflowEvent } from '../../core/EventBus';
import { AppConfig } from '../../config/AppConfig';
import { ExtendedConfig } from '../../config/schema';
import { createModuleLogger } from '../../core/Logger';
import { LiquiditySnapshot } from '../../core/types';
import LiquidityRepository from '../../db/repositories/LiquidityRepository';

import { getSolPriceUsd } from '../../core/SolPrice';

const logger = createModuleLogger('LiquidityInflowEngine');

interface TokenLiquidityState {
  mint: string;
  poolAddress: string;
  snapshots: LiquiditySnapshot[];
  solInflows: Array<{ sol: number; ts: number }>;
  buyVolumeUsd: number;
  sellVolumeUsd: number;
  lastSnapshotTs: number;
}

/**
 * LiquidityInflowEngine monitors per-token liquidity across all pools.
 *
 * On every POOL_UPDATE it:
 * 1. Records the new liquidity level
 * 2. Computes velocity (USD/min change)
 * 3. Computes net SOL inflow
 * 4. Generates bullish/bearish/neutral signal with strength 0-100
 * 5. Stores snapshot in DB
 * 6. Emits LIQUIDITY_INFLOW event
 *
 * Signal logic:
 *   strength >= bullishThreshold → bullish
 *   strength <= bearishThreshold → bearish
 *   otherwise → neutral
 */
export class LiquidityInflowEngine {
  private cfg: ExtendedConfig['liquidityInflow'];
  private states = new Map<string, TokenLiquidityState>();
  private snapshotTimer: NodeJS.Timeout;
  private readonly MAX_SNAPSHOTS_PER_TOKEN = 50;

  constructor(_baseCfg: AppConfig, extCfg: ExtendedConfig) {
    this.cfg = extCfg.liquidityInflow;

    this.snapshotTimer = setInterval(() => this._snapshotAll(), this.cfg.snapshotIntervalMs);
    this.snapshotTimer.unref();

    logger.info('LiquidityInflowEngine initialized', {
      snapshotInterval: this.cfg.snapshotIntervalMs,
      bullishThreshold: this.cfg.bullishThreshold,
    });
  }

  /** Called on POOL_UPDATE events */
  processPoolUpdate(event: PoolUpdateEvent): void {
    const { mint, liquidityUsd, liquidityDeltaUsd, poolAddress, ts } = event;
    this._ensureState(mint, poolAddress);
    const state = this.states.get(mint)!;

    // Track SOL inflow (liquidityDelta > 0 = LP added)
    if (liquidityDeltaUsd !== 0) {
      const solEquiv = liquidityDeltaUsd / getSolPriceUsd();
      state.solInflows.push({ sol: solEquiv, ts });
      // Keep last 200 inflow records per token
      if (state.solInflows.length > 200) state.solInflows.shift();
    }

    // Update LP count estimate from liquidity change
    this._takeSnapshot(state, liquidityUsd, ts);
  }

  /** Called on PRICE_UPDATE events (contains liquidityUsd from oracle) */
  processPriceUpdate(event: PriceUpdateEvent): void {
    if (event.liquidityUsd <= 0) return;
    this._ensureState(event.mint, '');
    const state = this.states.get(event.mint)!;
    this._takeSnapshot(state, event.liquidityUsd, event.ts);
  }

  private _takeSnapshot(state: TokenLiquidityState, liquidityUsd: number, ts: number): void {
    const now = Date.now();
    // Rate-limit: max 1 snapshot per 10 seconds per token
    if (now - state.lastSnapshotTs < 10000) return;
    state.lastSnapshotTs = now;

    const windowStart = now - this.cfg.velocityWindowMs;

    // Compute velocity (USD per minute)
    const windowSnapshots = state.snapshots.filter((s) => s.ts >= windowStart);
    let velocityUsdPerMin = 0;
    if (windowSnapshots.length >= 2) {
      const oldest = windowSnapshots[0]!;
      const newest = windowSnapshots[windowSnapshots.length - 1]!;
      const dtMin = (newest.ts - oldest.ts) / 60000;
      if (dtMin > 0) {
        velocityUsdPerMin = (newest.liquidityUsd - oldest.liquidityUsd) / dtMin;
      }
    }

    // Compute net SOL inflow in window
    const windowInflows = state.solInflows.filter((i) => i.ts >= windowStart);
    const netSolInflow = windowInflows.reduce((s, i) => s + i.sol, 0);

    // Buy pressure from trade events (updated separately)
    const totalVol = state.buyVolumeUsd + state.sellVolumeUsd;
    const buyPressurePct = totalVol > 0 ? (state.buyVolumeUsd / totalVol) * 100 : 50;

    // Signal strength computation
    const { signal, signalStrength } = this._computeSignal(velocityUsdPerMin, netSolInflow, buyPressurePct, liquidityUsd);

    const snapshot: LiquiditySnapshot = {
      tokenMint: state.mint,
      poolAddress: state.poolAddress,
      liquidityUsd,
      tvlUsd: liquidityUsd * 2, // approximate both sides
      netSolInflow,
      lpCount: 0,
      buyPressurePct,
      velocityUsdPerMin,
      signal,
      signalStrength,
      ts: now,
    };

    // Keep in-memory ring buffer
    state.snapshots.push(snapshot);
    if (state.snapshots.length > this.MAX_SNAPSHOTS_PER_TOKEN) state.snapshots.shift();

    // Persist to DB
    LiquidityRepository.insert(snapshot);

    // Emit event if signal is non-neutral or strength changed significantly
    if (signal !== 'neutral' || signalStrength > 50) {
      EventBus.emit('LIQUIDITY_INFLOW', {
        tokenMint: state.mint,
        signal,
        signalStrength,
        velocityUsdPerMin,
        netSolInflow,
        ts: now,
      } as LiquidityInflowEvent);
    }
  }

  private _computeSignal(
    velocityUsdPerMin: number,
    netSolInflow: number,
    buyPressurePct: number,
    liquidityUsd: number,
  ): { signal: LiquiditySnapshot['signal']; signalStrength: number } {
    // Velocity score: positive velocity = bullish (0-40 pts)
    const maxVelocity = 5000; // $5k/min = full score
    const velocityScore = Math.max(-40, Math.min(40, (velocityUsdPerMin / maxVelocity) * 40));

    // Inflow score: positive net SOL inflow (0-30 pts)
    const inflowScore = Math.max(-30, Math.min(30, (netSolInflow / 50) * 30));

    // Buy pressure score (0-30 pts, centered at 50%)
    const pressureScore = ((buyPressurePct - 50) / 50) * 30;

    const rawScore = velocityScore + inflowScore + pressureScore;
    // Map [-100, 100] to [0, 100]
    const signalStrength = Math.max(0, Math.min(100, (rawScore + 100) / 2));

    let signal: LiquiditySnapshot['signal'];
    if (signalStrength >= this.cfg.bullishThreshold) {
      signal = 'bullish';
    } else if (signalStrength <= this.cfg.bearishThreshold) {
      signal = 'bearish';
    } else {
      signal = 'neutral';
    }

    return { signal, signalStrength };
  }

  /** Update buy/sell pressure from trade events */
  recordTrade(mint: string, side: 'buy' | 'sell', volumeUsd: number): void {
    this._ensureState(mint, '');
    const state = this.states.get(mint)!;
    if (side === 'buy') {
      state.buyVolumeUsd += volumeUsd;
    } else {
      state.sellVolumeUsd += volumeUsd;
    }
    // Rolling reset after window
    const windowMs = this.cfg.velocityWindowMs;
    if (Date.now() - state.lastSnapshotTs > windowMs) {
      state.buyVolumeUsd = 0;
      state.sellVolumeUsd = 0;
    }
  }

  /**
   * Returns true if liquidity is healthy (not declining) for a token.
   * Used by the entry gate to reject trades when liquidity is collapsing.
   */
  isLiquidityHealthy(mint: string): boolean {
    if (!this.cfg.rejectOnDecline) return true;
    const latest = LiquidityRepository.getLatest(mint);
    if (!latest) return true; // no data = allow through
    if (latest.signal === 'bearish' && latest.signalStrength < this.cfg.bearishThreshold) return false;
    return true;
  }

  getLiquiditySignal(mint: string): LiquiditySnapshot | undefined {
    const state = this.states.get(mint);
    return state?.snapshots[state.snapshots.length - 1] ?? LiquidityRepository.getLatest(mint);
  }

  getNetInflowSol(mint: string, windowMs?: number): number {
    return LiquidityRepository.getNetInflow(mint, windowMs ?? this.cfg.velocityWindowMs);
  }

  private _ensureState(mint: string, poolAddress: string): void {
    if (!this.states.has(mint)) {
      this.states.set(mint, {
        mint,
        poolAddress,
        snapshots: [],
        solInflows: [],
        buyVolumeUsd: 0,
        sellVolumeUsd: 0,
        lastSnapshotTs: 0,
      });
    }
  }

  private _snapshotAll(): void {
    // Prune stale token states (no update in 30 min)
    const cutoff = Date.now() - 30 * 60 * 1000;
    for (const [mint, state] of this.states) {
      if (state.lastSnapshotTs < cutoff && state.lastSnapshotTs > 0) {
        this.states.delete(mint);
      }
    }
  }

  stop(): void {
    clearInterval(this.snapshotTimer);
  }
}

export default LiquidityInflowEngine;
