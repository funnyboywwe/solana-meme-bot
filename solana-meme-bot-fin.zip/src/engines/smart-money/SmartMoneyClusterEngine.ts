import { EventBus, WalletTxEvent, SmartMoneyClusterEvent } from '../../core/EventBus';
import { AppConfig } from '../../config/AppConfig';
import { ExtendedConfig } from '../../config/schema';
import { createModuleLogger } from '../../core/Logger';
import { SmartMoneyCluster, ClusterMember } from '../../core/types';
import WalletRepository from '../../db/repositories/WalletRepository';
import ClusterRepository from '../../db/repositories/ClusterRepository';
import { v4 as uuidv4 } from 'uuid';

const logger = createModuleLogger('SmartMoneyClusterEngine');

interface PendingEntry {
  walletAddress: string;
  amountSol: number;
  qualityScore: number;
  winRate: number;
  avgRoi: number;
  ts: number;
}

/**
 * SmartMoneyClusterEngine tracks which profitable wallets are entering
 * the same token within a rolling time window.
 *
 * When the count reaches minWalletCount, a cluster event is emitted.
 * Confidence is a weighted combination of:
 *   - wallet count vs threshold (30%)
 *   - average quality score of members (30%)
 *   - average win rate of members (20%)
 *   - average ROI of members (20%)
 */
export class SmartMoneyClusterEngine {
  private cfg: ExtendedConfig['smartMoney'];
  private baseCfg: AppConfig;
  // tokenMint → list of pending entries in the window
  private pendingEntries = new Map<string, PendingEntry[]>();
  // tokenMint → active cluster id
  private activeClusterIds = new Map<string, string>();
  private pruneInterval: NodeJS.Timeout;

  constructor(cfg: AppConfig, extCfg: ExtendedConfig) {
    this.baseCfg = cfg;
    this.cfg = extCfg.smartMoney;

    // Prune expired entries and clusters periodically
    this.pruneInterval = setInterval(() => this._prune(), 60000);
    this.pruneInterval.unref();

    logger.info('SmartMoneyClusterEngine initialized', {
      clusterWindow: this.cfg.clusterWindowMs,
      minWallets: this.cfg.minWalletCount,
      minConfidence: this.cfg.minConfidenceScore,
    });
  }

  /**
   * Process a wallet buy event. Called for every WALLET_TX (buy side).
   */
  processWalletBuy(event: WalletTxEvent): void {
    if (event.side !== 'buy') return;

    const { walletAddress, mint, amountSol, ts } = event;

    // Only cluster wallets that meet minimum quality
    const walletStats = WalletRepository.findByAddress(walletAddress);
    if (!walletStats) return;
    if (walletStats.qualityScore < this.cfg.minWalletQualityScore) return;

    // Record pending entry
    if (!this.pendingEntries.has(mint)) {
      this.pendingEntries.set(mint, []);
    }
    const entries = this.pendingEntries.get(mint)!;

    // Avoid duplicate wallet in window
    if (entries.some((e) => e.walletAddress === walletAddress)) return;

    entries.push({
      walletAddress,
      amountSol,
      qualityScore: walletStats.qualityScore,
      winRate: walletStats.winRate,
      avgRoi: walletStats.avgRoi,
      ts,
    });

    logger.debug('Smart wallet entered token', {
      wallet: walletAddress,
      mint,
      qualityScore: walletStats.qualityScore,
      clusterSize: entries.length,
    });

    // Check if cluster threshold met
    if (entries.length >= this.cfg.minWalletCount) {
      this._evaluateCluster(mint, entries);
    }
  }

  private _evaluateCluster(mint: string, entries: PendingEntry[]): void {
    const now = Date.now();
    const windowStart = now - this.cfg.clusterWindowMs;

    // Filter to only entries within the window
    const activeEntries = entries.filter((e) => e.ts >= windowStart);
    if (activeEntries.length < this.cfg.minWalletCount) return;

    // Check if we already have an active cluster for this token
    const existingId = this.activeClusterIds.get(mint);
    if (existingId) {
      this._updateCluster(existingId, activeEntries, mint);
      return;
    }

    // Compute confidence score
    const confidence = this._computeConfidence(activeEntries);
    if (confidence < this.cfg.minConfidenceScore) {
      logger.debug('Cluster below confidence threshold', { mint, confidence, required: this.cfg.minConfidenceScore });
      return;
    }

    // Create new cluster
    const cluster = ClusterRepository.insert({
      tokenMint: mint,
      walletAddresses: activeEntries.map((e) => e.walletAddress),
      walletCount: activeEntries.length,
      avgQualityScore: this._avg(activeEntries, 'qualityScore'),
      avgWinRate: this._avg(activeEntries, 'winRate'),
      avgRoi: this._avg(activeEntries, 'avgRoi'),
      totalCapitalSol: activeEntries.reduce((s, e) => s + e.amountSol, 0),
      confidenceScore: confidence,
      firstEntryTs: Math.min(...activeEntries.map((e) => e.ts)),
      lastEntryTs: Math.max(...activeEntries.map((e) => e.ts)),
      windowMs: this.cfg.clusterWindowMs,
      status: 'active',
      createdAt: now,
      updatedAt: now,
    });

    // Add members
    for (const entry of activeEntries) {
      ClusterRepository.addMember({
        clusterId: cluster.id,
        walletAddress: entry.walletAddress,
        entryTs: entry.ts,
        amountSol: entry.amountSol,
        qualityScore: entry.qualityScore,
        winRate: entry.winRate,
        avgRoi: entry.avgRoi,
      });
    }

    this.activeClusterIds.set(mint, cluster.id);

    logger.info('Smart money cluster formed', {
      clusterId: cluster.id,
      mint,
      walletCount: cluster.walletCount,
      confidenceScore: confidence.toFixed(1),
      totalCapitalSol: cluster.totalCapitalSol.toFixed(4),
    });

    EventBus.emit('SMART_MONEY_CLUSTER', {
      clusterId: cluster.id,
      tokenMint: mint,
      walletCount: cluster.walletCount,
      confidenceScore: confidence,
      totalCapitalSol: cluster.totalCapitalSol,
      ts: now,
    } as SmartMoneyClusterEvent);
  }

  private _updateCluster(clusterId: string, entries: PendingEntry[], mint: string): void {
    const confidence = this._computeConfidence(entries);
    ClusterRepository.update(clusterId, {
      walletAddresses: entries.map((e) => e.walletAddress),
      walletCount: entries.length,
      avgQualityScore: this._avg(entries, 'qualityScore'),
      avgWinRate: this._avg(entries, 'winRate'),
      avgRoi: this._avg(entries, 'avgRoi'),
      totalCapitalSol: entries.reduce((s, e) => s + e.amountSol, 0),
      confidenceScore: confidence,
      lastEntryTs: Math.max(...entries.map((e) => e.ts)),
    });

    // Add any new members
    const existing = ClusterRepository.getMembers(clusterId).map((m) => m.walletAddress);
    for (const entry of entries) {
      if (!existing.includes(entry.walletAddress)) {
        ClusterRepository.addMember({
          clusterId,
          walletAddress: entry.walletAddress,
          entryTs: entry.ts,
          amountSol: entry.amountSol,
          qualityScore: entry.qualityScore,
          winRate: entry.winRate,
          avgRoi: entry.avgRoi,
        });
      }
    }

    logger.debug('Cluster updated', { clusterId, mint, walletCount: entries.length, confidence: confidence.toFixed(1) });
  }

  private _computeConfidence(entries: PendingEntry[]): number {
    const walletCountScore = Math.min(entries.length / this.cfg.minWalletCount, 1) * 30;
    const avgQuality = this._avg(entries, 'qualityScore');
    const qualityScore = (avgQuality / 100) * 30;
    const avgWinRate = this._avg(entries, 'winRate');
    const winRateScore = avgWinRate * 20;
    const avgRoiCapped = Math.min(this._avg(entries, 'avgRoi'), 5) / 5;
    const roiScore = avgRoiCapped * 20;

    return Math.min(walletCountScore + qualityScore + winRateScore + roiScore, 100);
  }

  private _avg(entries: PendingEntry[], field: keyof PendingEntry): number {
    if (entries.length === 0) return 0;
    return entries.reduce((s, e) => s + (e[field] as number), 0) / entries.length;
  }

  private _prune(): void {
    const now = Date.now();
    const windowStart = now - this.cfg.clusterWindowMs;

    for (const [mint, entries] of this.pendingEntries) {
      const fresh = entries.filter((e) => e.ts >= windowStart);
      if (fresh.length === 0) {
        this.pendingEntries.delete(mint);
        this.activeClusterIds.delete(mint);
      } else {
        this.pendingEntries.set(mint, fresh);
      }
    }

    // Expire old DB clusters
    const expired = ClusterRepository.expireOld(this.cfg.expiryMs);
    if (expired > 0) logger.debug('Expired clusters', { count: expired });
  }

  /**
   * Get the active cluster for a token (for entry gate decisions)
   */
  getActiveCluster(mint: string): SmartMoneyCluster | undefined {
    const id = this.activeClusterIds.get(mint);
    if (!id) return undefined;
    const clusters = ClusterRepository.findByToken(mint, 'active');
    return clusters[0];
  }

  /**
   * Get confidence score for a token (0 if no active cluster)
   */
  getConfidenceScore(mint: string): number {
    return this.getActiveCluster(mint)?.confidenceScore ?? 0;
  }

  markExecuted(mint: string): void {
    const id = this.activeClusterIds.get(mint);
    if (id) {
      ClusterRepository.markExecuted(id);
      this.activeClusterIds.delete(mint);
    }
  }

  stop(): void {
    clearInterval(this.pruneInterval);
  }
}

export default SmartMoneyClusterEngine;
