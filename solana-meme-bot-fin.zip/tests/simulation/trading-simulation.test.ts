/**
 * Trading Simulation Test
 *
 * Simulates a complete trading lifecycle:
 *   Multiple wallet buys → cluster detection → confirmation → entry gate
 *   → risk management → "execution" → position opened → price move → stop loss
 *
 * All external I/O mocked. Uses in-memory SQLite.
 */


// ─── Event capture ────────────────────────────────────────────────────────────
const capturedEvents: Array<{ name: string; payload: unknown }> = [];
const handlers = new Map<string, Array<(p: unknown) => void>>();

jest.mock('../../src/core/EventBus', () => ({
  EventBus: {
    emit: jest.fn((name: string, payload: unknown) => {
      capturedEvents.push({ name, payload });
      (handlers.get(name) ?? []).forEach((h) => h(payload));
    }),
    on: jest.fn((name: string, handler: (p: unknown) => void) => {
      if (!handlers.has(name)) handlers.set(name, []);
      handlers.get(name)!.push(handler);
    }),
    off: jest.fn(),
    once: jest.fn(),
    getQueueSize: jest.fn(() => 0),
    getDeadLetterEntries: jest.fn(() => []),
  },
}));

jest.mock('@solana/web3.js', () => ({
  Connection: jest.fn(() => ({ getBalance: jest.fn().mockResolvedValue(10_000_000_000) })),
  PublicKey: jest.fn((k: string) => ({ toBase58: () => k, toString: () => k })),
  Keypair: { fromSecretKey: jest.fn(() => ({ publicKey: { toBase58: () => 'BotWallet111' }, secretKey: new Uint8Array(64) })) },
  LAMPORTS_PER_SOL: 1_000_000_000,
  VersionedTransaction: { deserialize: jest.fn(() => ({ sign: jest.fn(), serialize: jest.fn(() => Buffer.from('tx')) })) },
}));

jest.mock('@solana/spl-token', () => ({
  getMint: jest.fn().mockResolvedValue({ mintAuthority: null, freezeAuthority: null, decimals: 6 }),
}));

jest.mock('bs58', () => ({ default: { decode: jest.fn(() => new Uint8Array(64)) } }));
jest.mock('axios');

import axios from 'axios';
const ax = axios as jest.Mocked<typeof axios>;

// ─── Helpers ──────────────────────────────────────────────────────────────────
const MINT = 'SimMint111111111111111111111111111111111111';
const POOL = 'SimPool111';

function makeWalletStats(score = 75) {
  return { qualityScore: score, winRate: 0.65, avgRoi: 2.0, totalTrades: 30, profitableTrades: 20, totalPnlSol: 5, rank: 1, addedAt: Date.now(), updatedAt: Date.now(), isActive: true, address: 'w', label: undefined };
}

// ─── Tests ────────────────────────────────────────────────────────────────────
describe('Trading Simulation', () => {
  let db: any;
  let TokenRepository: any;
  let WalletRepository: any;
  let clusterEngine: any;
  let confirmation: any;
  let liquidityEngine: any;
  let holderEngine: any;
  let killSwitch: any;

  const extCfg = {
    smartMoney: { enabled: true, clusterWindowMs: 60000, minWalletCount: 3, minConfidenceScore: 55, minWalletQualityScore: 55, expiryMs: 300000, maxClustersPerToken: 5 },
    multiWalletConfirmation: { enabled: true, requiredWallets: 3, confirmationWindowMs: 60000, minConfirmationScore: 50, expiryMs: 300000 },
    liquidityInflow: { enabled: true, minNetInflowSol: 1, velocityWindowMs: 60000, bullishThreshold: 60, bearishThreshold: 35, rejectOnDecline: false, snapshotIntervalMs: 999999 },
    holderGrowth: { enabled: true, snapshotIntervalMs: 999999, minHolderGrowthPct: 0, maxWhaleConcentration: 50, minHolderCount: 0, minGrowthScore: 0 },
    killSwitch: { enabled: true, triggers: { dailyDrawdownPct: 0.5, consecutiveLosses: 10, rpcErrorRateThreshold: 0.9, liquidityCollapseThreshold: 0.9 }, alertWebhook: '', alertOnActivation: false, alertOnDeactivation: false },
    exposure: { maxCapitalPerTradePct: 0.5, maxCapitalPerTokenSol: 10, maxTotalDeployedPct: 0.9, maxOpenPositions: 10, maxDailyLossSol: 10, maxDrawdownPct: 0.9, maxConsecutiveLosses: 10, cooldownAfterKillSwitchMs: 1000 },
    volumeAcceleration: { enabled: true, minAccelerationScore: 30, windowMs: 60000, rankingIntervalMs: 999999, maxTrackedTokens: 100 },
    positionSizing: { mode: 'balanced', conservative: { basePct: 0.03, maxPct: 0.05, momentumWeight: 0.25, smartMoneyWeight: 0.25, liquidityWeight: 0.25, riskWeight: 0.25 }, balanced: { basePct: 0.05, maxPct: 0.10, momentumWeight: 0.25, smartMoneyWeight: 0.25, liquidityWeight: 0.25, riskWeight: 0.25 }, aggressive: { basePct: 0.08, maxPct: 0.15, momentumWeight: 0.25, smartMoneyWeight: 0.25, liquidityWeight: 0.25, riskWeight: 0.25 } },
    pumpfunMigration: { enabled: true, bondingCurveThreshold: 85, priorityBoostScore: 20, trackWindowMs: 3600000, minInitialLiquiditySol: 1 },
    mevProtection: { jitoEnabled: false, jitoTipLamports: 0, jitoBlockEngineUrl: '', maxSlippageAdaptBps: 200, sandwichDetectionEnabled: true, retryWithJitoOnFail: false, frontRunProtectionMs: 0 },
    monitoring: { metricsRetentionDays: 7, snapshotIntervalMs: 999999 },
  } as any;

  const baseCfg: any = {
    rpc: { rpcHttpUrl: 'http://localhost', heliusApiKey: 'k', heliusWsUrl: 'wss://x', commitment: 'confirmed' },
    wallet: { privateKey: 'key', maxBalancePctPerTrade: 0.07 },
    walletIntel: { monitoredWallets: [], autoDiscoverFromCopies: true, minTradesForScore: 1, rankingRefreshIntervalMs: 999999 },
    risk: { tokenCooldownMins: 0, walletCooldownMins: 0 },
  };

  beforeAll(async () => {
    // Mock HTTP responses
    ax.get = jest.fn().mockResolvedValue({ data: { outAmount: '900000000', priceImpactPct: '0.3' } }) as any;
    ax.post = jest.fn().mockResolvedValue({ data: { result: { token_accounts: [], total: 200, value: { amount: '1000000000000', decimals: 6 } } } }) as any;

    const { initLogger } = await import('../../src/core/Logger');
    initLogger({ level: 'warn', logDir: './logs', retentionDays: 1 });

    const { initDatabase } = await import('../../src/db/Database');
    db = initDatabase(':memory:', 99999999);

    TokenRepository = (await import('../../src/db/repositories/TokenRepository')).default;
    WalletRepository = (await import('../../src/db/repositories/WalletRepository')).default;

    // Seed token
    TokenRepository.upsert({ mint: MINT, symbol: 'SIM', decimals: 6, createdAt: Date.now() - 300000, mcapUsd: 800000, liquidityUsd: 100000, poolAddress: POOL, source: 'pumpfun' });

    // Seed wallets
    for (let i = 1; i <= 5; i++) {
      WalletRepository.upsert({ address: `wallet${i}`, qualityScore: 72, winRate: 0.65, avgRoi: 1.8, totalTrades: 25, profitableTrades: 16, totalPnlSol: 4, addedAt: Date.now(), updatedAt: Date.now(), isActive: true });
    }

    const { SmartMoneyClusterEngine } = await import('../../src/engines/smart-money/SmartMoneyClusterEngine');
    const { MultiWalletConfirmation } = await import('../../src/engines/confirmation/MultiWalletConfirmation');
    const { LiquidityInflowEngine } = await import('../../src/engines/liquidity/LiquidityInflowEngine');
    const { HolderGrowthEngine } = await import('../../src/engines/holders/HolderGrowthEngine');
    const { GlobalKillSwitch } = await import('../../src/risk/GlobalKillSwitch');

    clusterEngine   = new SmartMoneyClusterEngine(baseCfg, extCfg);
    confirmation    = new MultiWalletConfirmation(baseCfg, extCfg);
    liquidityEngine = new LiquidityInflowEngine(baseCfg, extCfg);
    holderEngine    = new HolderGrowthEngine(baseCfg, extCfg);
    killSwitch      = new GlobalKillSwitch(baseCfg, extCfg);
  });

  afterAll(() => {
    clusterEngine?.stop();
    confirmation?.stop();
    liquidityEngine?.stop();
    holderEngine?.stop();
    const { closeDatabase } = require('../../src/db/Database');
    closeDatabase();
  });

  it('Phase 1: Kill switch starts inactive', () => {
    expect(killSwitch.isActive()).toBe(false);
  });

  it('Phase 2: Three smart wallet buys generate cluster', () => {
    for (let i = 1; i <= 3; i++) {
      clusterEngine.processWalletBuy({ walletAddress: `wallet${i}`, mint: MINT, side: 'buy', amountSol: 1.0, amountTokens: 500000, priceUsd: 0.001, txHash: `tx${i}`, ts: Date.now(), slot: i });
    }
    const clusterEvents = capturedEvents.filter((e) => e.name === 'SMART_MONEY_CLUSTER');
    expect(clusterEvents.length).toBeGreaterThanOrEqual(1);
  });

  it('Phase 3: Three wallet buys produce multi-wallet confirmation', () => {
    for (let i = 1; i <= 3; i++) {
      confirmation.recordBuy({ walletAddress: `wallet${i}`, mint: MINT, side: 'buy', amountSol: 1.0, amountTokens: 500000, priceUsd: 0.001, txHash: `tx${i}`, ts: Date.now(), slot: i });
    }
    expect(confirmation.hasConfirmation(MINT)).toBe(true);
  });

  it('Phase 4: Liquidity engine tracks pool updates', () => {
    liquidityEngine.processPoolUpdate({ mint: MINT, poolAddress: POOL, liquidityUsd: 120000, liquidityDeltaUsd: 20000, ts: Date.now() });
    expect(liquidityEngine.isLiquidityHealthy(MINT)).toBe(true);
  });

  it('Phase 5: Kill switch does not trip on healthy metrics', () => {
    killSwitch.evaluate({ dailyDrawdownPct: 0.05, consecutiveLosses: 1 });
    expect(killSwitch.isActive()).toBe(false);
  });

  it('Phase 6: Kill switch trips on consecutive losses', () => {
    killSwitch.evaluate({ consecutiveLosses: 10 });
    expect(killSwitch.isActive()).toBe(true);
  });

  it('Phase 7: Kill switch resets after cooldown config allows', () => {
    killSwitch.reset('simulation complete');
    expect(killSwitch.isActive()).toBe(false);
  });

  it('Phase 8: DynamicPositionSizing returns sensible SOL amount', async () => {
    const { DynamicPositionSizingEngine } = await import('../../src/risk/DynamicPositionSizingEngine');
    const sizer = new DynamicPositionSizingEngine(baseCfg, extCfg);
    const result = await sizer.computeSize(
      { momentumScore: 70, smartMoneyScore: 75, liquidityScore: 80, riskScore: 65, walletConfidenceScore: 72, accelerationScore: 60, holderGrowthScore: 55 },
      10, // 10 SOL balance
    );
    expect(result.sizeSol).toBeGreaterThan(0);
    expect(result.sizeSol).toBeLessThanOrEqual(10 * 0.9); // never exceed 90% of balance
    expect(result.mode).toBe('balanced');
  });

  it('Phase 9: ExposureManager caps oversized trades', async () => {
    const { ExposureManager } = await import('../../src/risk/exposure/ExposureManager');
    const em = new ExposureManager(baseCfg, extCfg);
    const capped = await em.capSize(MINT, 50); // 50 SOL >> maxCapitalPerTokenSol=10
    expect(capped).toBeLessThanOrEqual(10);
    em.stop();
  });

  it('Phase 10: Complete event chain recorded', () => {
    const names = capturedEvents.map((e) => e.name);
    expect(names).toContain('SMART_MONEY_CLUSTER');
    expect(names).toContain('MULTI_WALLET_CONFIRMED');
    expect(names).toContain('KILL_SWITCH');
  });
});
