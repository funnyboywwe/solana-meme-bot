
jest.mock('axios', () => ({
  __esModule: true,
  default: { post: jest.fn().mockResolvedValue({ status: 200 }) },
}));

import axios from 'axios';
import { AlertManager, AlertConfig } from '../../../src/analytics/AlertManager';

const baseCfg: AlertConfig = {
  telegramEnabled: true,
  telegramBotToken: 'token',
  telegramChatId: 'chat',
  discordEnabled: true,
  discordWebhookUrl: 'https://discord.test/webhook',
  alertOnTrade: true,
  alertOnError: true,
};

const postMock = (axios as unknown as { post: jest.Mock }).post;

describe('AlertManager', () => {
  beforeEach(() => jest.clearAllMocks());

  it('isEnabled is true when telegram is configured', () => {
    expect(new AlertManager(baseCfg).isEnabled()).toBe(true);
  });

  it('isEnabled is false when no channel is configured', () => {
    const am = new AlertManager({ ...baseCfg, telegramEnabled: false, discordEnabled: false });
    expect(am.isEnabled()).toBe(false);
  });

  it('delivers to both Telegram and Discord', async () => {
    await new AlertManager(baseCfg).sendAlert('hello', 'info');
    expect(postMock).toHaveBeenCalledTimes(2);
  });

  it('does not deliver when disabled', async () => {
    const am = new AlertManager({ ...baseCfg, telegramEnabled: false, discordEnabled: false });
    await am.sendAlert('hello');
    expect(postMock).not.toHaveBeenCalled();
  });

  it('throttles repeated error alerts', async () => {
    const am = new AlertManager(baseCfg);
    await am.sendError('boom');
    await am.sendError('boom again');
    // First error => telegram + discord (2 posts); second is throttled.
    expect(postMock).toHaveBeenCalledTimes(2);
  });

  it('skips trade alerts when alertOnTrade is false', async () => {
    const am = new AlertManager({ ...baseCfg, alertOnTrade: false });
    await am.sendTradeAlert({ side: 'buy', mint: 'mint', sizeSol: 1, priceUsd: 0.001 });
    expect(postMock).not.toHaveBeenCalled();
  });
});
