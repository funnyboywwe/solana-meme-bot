import { describe, it, expect, beforeEach, afterEach, jest } from '@jest/globals';

jest.mock('../../../src/db/Database', () => ({
  getDb: () => ({
    prepare: () => ({ run: jest.fn(), get: jest.fn(), all: jest.fn(() => []) }),
  }),
}));

jest.mock('../../../src/db/repositories/WalletRepository', () => ({
  __esModule: true,
  default: {
    findByAddress: jest.fn(),
    exists: jest.fn(() => false),
  },
}));

jest.mock('../../../src/core/EventBus', () => ({
  EventBus: { emit: jest.fn(), on: jest.fn() },
}));

import WalletRepository from '../../../src/db/repositories/WalletRepository';
import { EventBus } from '../../../src/core/EventBus';

const mockExtCfg = {
  multiWalletConfirmation: {
    enabled: true,
    requiredWallets: 3,
    confirmationWindowMs: 300000,
    minConfirmationScore: 60,
    expiryMs: 600000,
  },
} as any;

function makeWalletTx(wallet: string, mint: string, qualityScore = 75) {
  return { walletAddress: wallet, mint, side: 'buy' as const, amountSol: 1.0, amountTokens: 1000, priceUsd: 0.001, txHash: 'tx1', ts: Date.now(), slot: 1 };
}

describe('MultiWalletConfirmation', () => {
  let engine: any;

  beforeEach(async () => {
    jest.clearAllMocks();
    (WalletRepository.findByAddress as jest.Mock).mockReturnValue({ qualityScore: 75, winRate: 0.6, avgRoi: 1.5, totalTrades: 20 });
    const { MultiWalletConfirmation } = await import('../../../src/engines/confirmation/MultiWalletConfirmation');
    engine = new MultiWalletConfirmation({} as any, mockExtCfg);
  });

  afterEach(() => engine.stop());

  it('has no confirmation initially', () => {
    expect(engine.hasConfirmation('mint1')).toBe(false);
  });

  it('does not confirm with fewer than required wallets', () => {
    engine.recordBuy(makeWalletTx('w1', 'mint1'));
    engine.recordBuy(makeWalletTx('w2', 'mint1'));
    expect(engine.hasConfirmation('mint1')).toBe(false);
  });

  it('confirms when required wallets reached', () => {
    engine.recordBuy(makeWalletTx('w1', 'mint1'));
    engine.recordBuy(makeWalletTx('w2', 'mint1'));
    engine.recordBuy(makeWalletTx('w3', 'mint1'));
    expect(engine.hasConfirmation('mint1')).toBe(true);
    expect(EventBus.emit).toHaveBeenCalledWith('MULTI_WALLET_CONFIRMED', expect.objectContaining({ tokenMint: 'mint1' }));
  });

  it('deduplicates same wallet', () => {
    engine.recordBuy(makeWalletTx('w1', 'mint1'));
    engine.recordBuy(makeWalletTx('w1', 'mint1'));
    engine.recordBuy(makeWalletTx('w1', 'mint1'));
    expect(engine.hasConfirmation('mint1')).toBe(false);
    expect(engine.getPendingCount('mint1')).toBe(1);
  });

  it('ignores low quality wallets', () => {
    (WalletRepository.findByAddress as jest.Mock).mockReturnValue({ qualityScore: 30 });
    engine.recordBuy(makeWalletTx('w1', 'mint1'));
    engine.recordBuy(makeWalletTx('w2', 'mint1'));
    engine.recordBuy(makeWalletTx('w3', 'mint1'));
    expect(engine.hasConfirmation('mint1')).toBe(false);
  });

  it('ignores sell events', () => {
    for (let i = 1; i <= 3; i++) {
      engine.recordBuy({ ...makeWalletTx(`w${i}`, 'mint1'), side: 'sell' });
    }
    expect(engine.hasConfirmation('mint1')).toBe(false);
  });

  it('markExecuted clears confirmation', () => {
    engine.recordBuy(makeWalletTx('w1', 'mint1'));
    engine.recordBuy(makeWalletTx('w2', 'mint1'));
    engine.recordBuy(makeWalletTx('w3', 'mint1'));
    expect(engine.hasConfirmation('mint1')).toBe(true);
    engine.markExecuted('mint1');
    expect(engine.hasConfirmation('mint1')).toBe(false);
  });

  it('returns true when disabled', async () => {
    const disabledCfg = { ...mockExtCfg, multiWalletConfirmation: { ...mockExtCfg.multiWalletConfirmation, enabled: false } };
    const { MultiWalletConfirmation } = await import('../../../src/engines/confirmation/MultiWalletConfirmation');
    const e2 = new MultiWalletConfirmation({} as any, disabledCfg);
    expect(e2.hasConfirmation('any-mint')).toBe(true);
    e2.stop();
  });
});
