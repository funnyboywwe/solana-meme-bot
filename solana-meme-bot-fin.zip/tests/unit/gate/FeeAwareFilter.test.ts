import { describe, expect, it } from '@jest/globals';
import { FeeAwareFilter, FeeAwareInput } from '../../../src/gate/FeeAwareFilter';

// Minimal AppConfig-shaped stub. FeeAwareFilter only reads cfg.costControl.*
// (and constructs a FeeEstimator from the same), so a partial cast is enough.
function makeCfg(feeAwareOverrides: Record<string, unknown> = {}): any {
  return {
    costControl: {
      baseTxFeeSol: 0.000005,
      dexFeePct: 0.0025,
      assumedComputeUnits: 200000,
      feeAware: {
        enabled: true,
        minExpectedProfitPct: 0.1,
        minProfitToCostRatio: 5,
        feeWarnPctOfSize: 0.05,
        referenceSizeSol: 0.03,
        ...feeAwareOverrides,
      },
    },
  };
}

const baseInput: FeeAwareInput = {
  mint: 'TestMint1111111111111111111111111111111111',
  sizeSol: 0.03,
  liquidityUsd: 50000,
  solPriceUsd: 150,
  priorityFeeMicroLamports: 10000,
  slippageBps: 100,
  expectedGainPct: 0.4,
};

describe('FeeAwareFilter', () => {
  it('approves a trade whose expected gain clears the required margin', () => {
    const filter = new FeeAwareFilter(makeCfg());
    const d = filter.evaluate(baseInput);
    expect(d.pass).toBe(true);
    // cost ~2.55% -> required = max(10%, 2.55% x 5) ~ 12.73%
    expect(d.requiredProfitPct).toBeCloseTo(0.1273, 3);
  });

  it('rejects a trade whose expected gain is below the required margin', () => {
    const filter = new FeeAwareFilter(makeCfg());
    const d = filter.evaluate({ ...baseInput, expectedGainPct: 0.05 });
    expect(d.pass).toBe(false);
    expect(d.reason).toMatch(/expected gain/);
  });

  it('rejects high-cost tiny trades and raises a fee warning', () => {
    const filter = new FeeAwareFilter(makeCfg());
    // tiny size + wide slippage -> cost dominates the trade
    const d = filter.evaluate({ ...baseInput, sizeSol: 0.01, slippageBps: 1000 });
    expect(d.feeWarning).toBe(true);
    expect(d.pass).toBe(false);
  });

  it('passes through when the filter is disabled', () => {
    const filter = new FeeAwareFilter(makeCfg({ enabled: false }));
    const d = filter.evaluate({ ...baseInput, expectedGainPct: 0 });
    expect(d.pass).toBe(true);
    expect(d.reason).toMatch(/disabled/);
  });
});
