import { RouteValidator } from '../../../../src/execution/multi-aggregator/RouteValidator';
import { PriceFallbackManager } from '../../../../src/execution/multi-aggregator/PriceFallbackManager';
import { AggregatorQuote, IAggregator } from '../../../../src/execution/multi-aggregator/types';

const MINT = 'MintAddr1111111111111111111111111111111111';

function quote(out: string): AggregatorQuote {
  return { aggregator: 'x', inputMint: 'a', outputMint: 'b', inAmount: '1', outAmount: out, priceImpactPct: 0, slippageBps: 100, estFeeSol: 0 };
}

/** Aggregator whose buy/sell route availability is individually controllable. */
function agg(name: string, opts: { buy?: boolean; sell?: boolean } = {}): IAggregator {
  return {
    name,
    getBuyQuote: async () => (opts.buy === false ? Promise.reject(new Error('no route')) : quote('1000')),
    getSellQuote: async () => (opts.sell === false ? Promise.reject(new Error('no route')) : quote('900')),
    buy: async () => ({ success: true, aggregator: name, txHash: 't', amountIn: 0, amountOut: 0, feeSol: 0, priceImpactPct: 0 }),
    sellRaw: async () => ({ success: true, aggregator: name, txHash: 't', amountIn: 0, amountOut: 0, feeSol: 0, priceImpactPct: 0 }),
  };
}

function priceMgr(liquidityUsd?: number): PriceFallbackManager {
  return new PriceFallbackManager([
    { name: 'fake', getPrice: async () => ({ mint: MINT, priceUsd: 1, liquidityUsd, source: 'fake', ts: Date.now() }) },
  ]);
}

describe('RouteValidator (pre-trade validation)', () => {
  const pass = async () => ({ pass: true });

  it('accepts when safety + liquidity + buy route + sell route all pass', async () => {
    const v = new RouteValidator([agg('jupiter')], priceMgr(50_000), pass, { minLiquidityUsd: 30_000, rejectOnUnknownLiquidity: false });
    const r = await v.validateBuy(MINT, 1, 100);
    expect(r.ok).toBe(true);
    expect(r.buyProvider).toBe('jupiter');
    expect(r.sellProvider).toBe('jupiter');
  });

  it('REJECTS when no aggregator can sell, even if buy route exists (core guarantee)', async () => {
    const v = new RouteValidator(
      [agg('jupiter', { buy: true, sell: false })],
      priceMgr(50_000),
      pass,
      { minLiquidityUsd: 30_000, rejectOnUnknownLiquidity: false },
    );
    const r = await v.validateBuy(MINT, 1, 100);
    expect(r.ok).toBe(false);
    expect(r.reasons).toContain('no_sell_route');
    expect(r.buyProvider).toBe('jupiter');
    expect(r.sellProvider).toBeUndefined();
  });

  it('finds a sell route on a fallback aggregator when the primary cannot sell', async () => {
    const v = new RouteValidator(
      [agg('jupiter', { buy: true, sell: false }), agg('raydium', { buy: true, sell: true })],
      priceMgr(50_000),
      pass,
      { minLiquidityUsd: 30_000, rejectOnUnknownLiquidity: false },
    );
    const r = await v.validateBuy(MINT, 1, 100);
    expect(r.ok).toBe(true);
    expect(r.sellProvider).toBe('raydium');
  });

  it('rejects when liquidity is below the minimum threshold', async () => {
    const v = new RouteValidator([agg('jupiter')], priceMgr(10_000), pass, { minLiquidityUsd: 30_000, rejectOnUnknownLiquidity: false });
    const r = await v.validateBuy(MINT, 1, 100);
    expect(r.ok).toBe(false);
    expect(r.reasons).toContain('liquidity_below_min');
  });

  it('rejects when the token fails safety checks', async () => {
    const fail = async () => ({ pass: false, reason: 'honeypot' });
    const v = new RouteValidator([agg('jupiter')], priceMgr(50_000), fail, { minLiquidityUsd: 30_000, rejectOnUnknownLiquidity: false });
    const r = await v.validateBuy(MINT, 1, 100);
    expect(r.ok).toBe(false);
    expect(r.reasons.some((x) => x.startsWith('safety_failed'))).toBe(true);
  });
});
