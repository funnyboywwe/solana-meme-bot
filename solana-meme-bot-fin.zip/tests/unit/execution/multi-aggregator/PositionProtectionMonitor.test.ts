import {
  PositionProtectionMonitor,
  detectEmergency,
  DEFAULT_PROTECTION_THRESHOLDS,
  PositionSnapshot,
  MonitoredPosition,
  EmergencyReason,
} from '../../../../src/execution/multi-aggregator/PositionProtectionMonitor';

const MINT = 'MintAddr1111111111111111111111111111111111';

function snap(over: Partial<PositionSnapshot> = {}): PositionSnapshot {
  return {
    priceAgeMs: 0,
    sellRouteAgeMs: 0,
    liquidityUsd: 100_000,
    baselineLiquidityUsd: 100_000,
    volumeUsd: 100_000,
    baselineVolumeUsd: 100_000,
    ...over,
  };
}

describe('detectEmergency (pure rules)', () => {
  const t = DEFAULT_PROTECTION_THRESHOLDS;

  it('returns null when the position is healthy', () => {
    expect(detectEmergency(snap(), t)).toBeNull();
  });

  it('fires no_price after 60s of stale price', () => {
    expect(detectEmergency(snap({ priceAgeMs: 60_000 }), t)).toBe('no_price');
  });

  it('fires no_sell_route after 60s with no sell route', () => {
    expect(detectEmergency(snap({ sellRouteAgeMs: 61_000 }), t)).toBe('no_sell_route');
  });

  it('fires liquidity_drop when liquidity falls >30% from baseline', () => {
    expect(detectEmergency(snap({ liquidityUsd: 69_000 }), t)).toBe('liquidity_drop');
  });

  it('fires volume_collapse when volume falls >70% from baseline', () => {
    expect(detectEmergency(snap({ volumeUsd: 29_000 }), t)).toBe('volume_collapse');
  });

  it('does not fire on a 25% liquidity dip (below threshold)', () => {
    expect(detectEmergency(snap({ liquidityUsd: 75_000 }), t)).toBeNull();
  });
});

describe('PositionProtectionMonitor.tick', () => {
  it('triggers exactly one emergency exit per position and stops re-triggering', async () => {
    let now = 1_000_000;
    const positions: MonitoredPosition[] = [{ positionId: 'p1', mint: MINT }];
    const fired: Array<{ mint: string; reason: EmergencyReason }> = [];

    const monitor = new PositionProtectionMonitor(
      {
        getOpenPositions: () => positions,
        getPriceAgeMs: () => 120_000, // stale price => no_price
        hasSellRoute: async () => true,
        getMarketStats: async () => ({ liquidityUsd: 100_000, volumeUsd: 100_000 }),
        emergencyExit: (pos, reason) => fired.push({ mint: pos.mint, reason }),
      },
      { now: () => now },
    );

    await monitor.tick();
    await monitor.tick(); // second pass must NOT re-fire
    expect(fired).toEqual([{ mint: MINT, reason: 'no_price' }]);
  });

  it('tracks peak liquidity baseline so a later collapse triggers', async () => {
    let now = 0;
    let liquidity = 100_000;
    const fired: EmergencyReason[] = [];
    const monitor = new PositionProtectionMonitor(
      {
        getOpenPositions: () => [{ positionId: 'p1', mint: MINT }],
        getPriceAgeMs: () => 0,
        hasSellRoute: async () => true,
        getMarketStats: async () => ({ liquidityUsd: liquidity, volumeUsd: 100_000 }),
        emergencyExit: (_pos, reason) => fired.push(reason),
      },
      { now: () => now },
    );

    await monitor.tick(); // baseline = 100k
    expect(fired).toHaveLength(0);
    liquidity = 50_000; // -50% from peak
    now += 5_000;
    await monitor.tick();
    expect(fired).toContain('liquidity_drop');
  });
});
