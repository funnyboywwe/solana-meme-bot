import { MultiAggregatorExecutor } from '../../../../src/execution/multi-aggregator/MultiAggregatorExecutor';
import { RouteHealthMonitor } from '../../../../src/execution/multi-aggregator/RouteHealthMonitor';
import { RouteAnalytics } from '../../../../src/execution/multi-aggregator/RouteAnalytics';
import { AggregatorQuote, IAggregator, SwapExecution } from '../../../../src/execution/multi-aggregator/types';

const MINT = 'MintAddr1111111111111111111111111111111111';

function ok(name: string, out = 0): SwapExecution {
  return { success: true, aggregator: name, txHash: `${name}-sig`, amountIn: 1, amountOut: out, feeSol: 0.001, priceImpactPct: 0 };
}
function fail(name: string, error = 'failed'): SwapExecution {
  return { success: false, aggregator: name, amountIn: 0, amountOut: 0, feeSol: 0, priceImpactPct: 0, error };
}
function quote(name: string, out: string): AggregatorQuote {
  return { aggregator: name, inputMint: 'a', outputMint: 'b', inAmount: '1', outAmount: out, priceImpactPct: 0, slippageBps: 100, estFeeSol: 0 };
}

type Behaviour = {
  buyQuote?: string | null;
  sellQuote?: string | null;
  buy?: () => SwapExecution;
  sell?: () => SwapExecution;
};

function agg(name: string, b: Behaviour): IAggregator {
  return {
    name,
    getBuyQuote: async () => (b.buyQuote == null ? Promise.reject(new Error('no route')) : quote(name, b.buyQuote)),
    getSellQuote: async () => (b.sellQuote == null ? Promise.reject(new Error('no route')) : quote(name, b.sellQuote)),
    buy: async () => (b.buy ? b.buy() : ok(name)),
    sellRaw: async () => (b.sell ? b.sell() : ok(name)),
  };
}

function build(aggs: IAggregator[], cfg = {}) {
  const health = new RouteHealthMonitor();
  const analytics = new RouteAnalytics();
  const executor = new MultiAggregatorExecutor(aggs, health, analytics, {
    config: { compareRoutes: false, maxRetries: 2, retryDelayMs: 0, ...cfg },
    sleep: async () => {},
  });
  return { executor, health, analytics };
}

describe('MultiAggregatorExecutor — buy flow', () => {
  it('fills on Jupiter (primary) when it succeeds', async () => {
    const { executor } = build([agg('jupiter', { buyQuote: '100', buy: () => ok('jupiter') }), agg('raydium', { buyQuote: '100' })]);
    const res = await executor.executeBuy(MINT, 1, 100);
    expect(res.success).toBe(true);
    expect(res.aggregator).toBe('jupiter');
  });

  it('falls back to Raydium when Jupiter buy fails', async () => {
    const { executor, analytics } = build([
      agg('jupiter', { buyQuote: '100', buy: () => fail('jupiter') }),
      agg('raydium', { buyQuote: '100', buy: () => ok('raydium') }),
    ]);
    const res = await executor.executeBuy(MINT, 1, 100);
    expect(res.success).toBe(true);
    expect(res.aggregator).toBe('raydium');
    expect(res.triedProviders).toEqual(['jupiter', 'raydium']);
    expect(analytics.getReport().routeFailures.jupiter).toBe(1);
  });

  it('aborts when both aggregators fail to buy', async () => {
    const { executor } = build([
      agg('jupiter', { buyQuote: '100', buy: () => fail('jupiter') }),
      agg('raydium', { buyQuote: '100', buy: () => fail('raydium') }),
    ]);
    const res = await executor.executeBuy(MINT, 1, 100);
    expect(res.success).toBe(false);
    expect(res.error).toBeDefined();
    expect(res.triedProviders).toEqual(['jupiter', 'raydium']);
  });

  it('route cost comparison prefers the aggregator with the most output', async () => {
    const { executor } = build(
      [agg('jupiter', { buyQuote: '100', buy: () => ok('jupiter') }), agg('raydium', { buyQuote: '500', buy: () => ok('raydium') })],
      { compareRoutes: true },
    );
    const res = await executor.executeBuy(MINT, 1, 100);
    expect(res.aggregator).toBe('raydium'); // 500 > 100
  });
});

describe('MultiAggregatorExecutor — sell flow', () => {
  it('fills on Jupiter when it succeeds', async () => {
    const { executor } = build([agg('jupiter', { sellQuote: '100', sell: () => ok('jupiter') }), agg('raydium', { sellQuote: '100' })]);
    const res = await executor.executeSell(MINT, '500000', 100);
    expect(res.success).toBe(true);
    expect(res.aggregator).toBe('jupiter');
  });

  it('falls back to Raydium when Jupiter cannot sell', async () => {
    const { executor } = build([
      agg('jupiter', { sellQuote: '100', sell: () => fail('jupiter') }),
      agg('raydium', { sellQuote: '100', sell: () => ok('raydium') }),
    ]);
    const res = await executor.executeSell(MINT, '500000', 100);
    expect(res.success).toBe(true);
    expect(res.aggregator).toBe('raydium');
  });

  it('escalates to emergency monitoring when all sell routes fail across retries', async () => {
    const onEmergency = jest.fn();
    const { executor } = build([
      agg('jupiter', { sellQuote: '100', sell: () => fail('jupiter') }),
      agg('raydium', { sellQuote: '100', sell: () => fail('raydium') }),
    ]);
    const res = await executor.executeSell(MINT, '500000', 100, undefined, onEmergency);
    expect(res.success).toBe(false);
    expect(onEmergency).toHaveBeenCalledTimes(1);
    expect(onEmergency).toHaveBeenCalledWith(expect.objectContaining({ mint: MINT, amountBaseUnits: '500000' }));
  });
});
