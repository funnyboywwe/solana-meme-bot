import { JupiterAggregatorAdapter } from '../../../../src/execution/multi-aggregator/JupiterAggregatorAdapter';
import { JupiterLike, WSOL_MINT } from '../../../../src/execution/multi-aggregator/types';

const MINT = 'MintAddr1111111111111111111111111111111111';

describe('JupiterAggregatorAdapter', () => {
  it('maps a Jupiter quote into a normalised AggregatorQuote (buy)', async () => {
    const jup: JupiterLike = {
      getQuote: async (inputMint, outputMint) => {
        expect(inputMint).toBe(WSOL_MINT);
        expect(outputMint).toBe(MINT);
        return { inAmount: '1000000000', outAmount: '777', priceImpactPct: '0.5', slippageBps: 100 };
      },
      buy: async () => ({ success: true, txHash: 'x', amountIn: 1, amountOut: 2, feeSol: 0, priceImpactPct: 0 }),
      sellRaw: async () => ({ success: true, txHash: 'x', amountIn: 1, amountOut: 2, feeSol: 0, priceImpactPct: 0 }),
    };
    const adapter = new JupiterAggregatorAdapter(jup);
    const q = await adapter.getBuyQuote(MINT, 1, 100);
    expect(q.aggregator).toBe('jupiter');
    expect(q.outAmount).toBe('777');
    expect(q.priceImpactPct).toBeCloseTo(0.5);
  });

  it('treats a swap result with no txHash as a failure', async () => {
    const jup: JupiterLike = {
      getQuote: async () => ({ inAmount: '1', outAmount: '1', priceImpactPct: '0', slippageBps: 100 }),
      buy: async () => ({ success: true, amountIn: 0, amountOut: 0, feeSol: 0, priceImpactPct: 0, error: 'no fill' }),
      sellRaw: async () => ({ success: true, txHash: 'sig', amountIn: 0, amountOut: 0, feeSol: 0.01, priceImpactPct: 0 }),
    };
    const adapter = new JupiterAggregatorAdapter(jup);
    const buy = await adapter.buy(MINT, 1, 100);
    expect(buy.success).toBe(false);
    const sell = await adapter.sellRaw(MINT, '100', 100);
    expect(sell.success).toBe(true);
    expect(sell.feeSol).toBeCloseTo(0.01);
  });
});
