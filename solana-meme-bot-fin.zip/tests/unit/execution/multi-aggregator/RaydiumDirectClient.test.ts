import { RaydiumDirectClient } from '../../../../src/execution/multi-aggregator/RaydiumDirectClient';
import { HttpClient, TxSubmitter } from '../../../../src/execution/multi-aggregator/types';

const MINT = 'MintAddr1111111111111111111111111111111111';
const WALLET = 'Wa11et1111111111111111111111111111111111111';

function makeHttp(over: Partial<HttpClient> = {}): HttpClient {
  return {
    get: async () => ({ data: { success: true, data: { inputAmount: '1000000000', outputAmount: '500000', priceImpactPct: 1.5 } } as never, status: 200 }),
    post: async () => ({ data: { success: true, data: [{ transaction: 'BASE64TX' }] } as never, status: 200 }),
    ...over,
  };
}

describe('RaydiumDirectClient', () => {
  it('produces a buy quote from the compute endpoint', async () => {
    const client = new RaydiumDirectClient(makeHttp(), WALLET, { submit: async () => 'sig' });
    const q = await client.getBuyQuote(MINT, 1, 100);
    expect(q.aggregator).toBe('raydium');
    expect(q.outAmount).toBe('500000');
    expect(q.priceImpactPct).toBeCloseTo(1.5);
  });

  it('throws when the compute endpoint reports no route', async () => {
    const http = makeHttp({ get: async () => ({ data: { success: false, msg: 'ROUTE_NOT_FOUND' } as never, status: 200 }) });
    const client = new RaydiumDirectClient(http, WALLET, { submit: async () => 'sig' });
    await expect(client.getBuyQuote(MINT, 1, 100)).rejects.toThrow(/no route/i);
  });

  it('executes a buy: builds tx, submits, and returns a tx hash', async () => {
    const submitter: TxSubmitter = { submit: jest.fn(async () => 'TXHASH123') };
    const client = new RaydiumDirectClient(makeHttp(), WALLET, submitter);
    const res = await client.buy(MINT, 1, 100, 75_000);
    expect(res.success).toBe(true);
    expect(res.txHash).toBe('TXHASH123');
    expect(res.feeSol).toBeCloseTo(75_000 / 1e9);
    expect(submitter.submit).toHaveBeenCalledWith('BASE64TX', expect.objectContaining({ priorityFeeMicroLamports: 75_000 }));
  });

  it('returns a failed execution (not a throw) when the submitter rejects', async () => {
    const client = new RaydiumDirectClient(makeHttp(), WALLET, { submit: async () => { throw new Error('blockhash expired'); } });
    const res = await client.sellRaw(MINT, '500000', 100);
    expect(res.success).toBe(false);
    expect(res.error).toMatch(/blockhash expired/);
  });

  it('fails cleanly when /transaction returns no transaction', async () => {
    const http = makeHttp({ post: async () => ({ data: { success: true, data: [] } as never, status: 200 }) });
    const client = new RaydiumDirectClient(http, WALLET, { submit: async () => 'sig' });
    const res = await client.buy(MINT, 1, 100);
    expect(res.success).toBe(false);
    expect(res.error).toMatch(/no transaction/i);
  });
});
