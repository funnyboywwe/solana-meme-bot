import { describe, expect, it } from '@jest/globals';
import {
  percentile,
  computeRecommendedFee,
  FeeBounds,
} from '../../../src/execution/PriorityFeeManager';

const bounds: FeeBounds = {
  minMicroLamports: 10000,
  maxMicroLamports: 1000000,
  congestionMultiplier: 3,
};

describe('percentile', () => {
  it('returns the value at the requested percentile', () => {
    expect(percentile([10, 20, 30, 40], 0.5)).toBe(20);
    expect(percentile([10, 20, 30, 40], 0)).toBe(10);
    expect(percentile([10, 20, 30, 40], 1)).toBe(40);
  });

  it('returns 0 for an empty array', () => {
    expect(percentile([], 0.5)).toBe(0);
  });
});

describe('computeRecommendedFee', () => {
  it('pays the floor when there are no samples', () => {
    const r = computeRecommendedFee([], bounds, 'normal');
    expect(r.recommendedMicroLamports).toBe(10000);
    expect(r.level).toBe('low');
    expect(r.sampleCount).toBe(0);
  });

  it('stays at the floor when the network is quiet (LOW)', () => {
    const r = computeRecommendedFee([8000, 9000, 10000, 11000], bounds, 'normal');
    expect(r.level).toBe('low');
    expect(r.recommendedMicroLamports).toBe(10000);
  });

  it('climbs toward the market percentile under congestion', () => {
    const r = computeRecommendedFee([40000, 50000, 60000, 70000], bounds, 'normal');
    expect(r.level).toBe('high');
    expect(r.recommendedMicroLamports).toBe(60000); // p75 of the sample
  });

  it('never exceeds the configured ceiling', () => {
    const capped: FeeBounds = { ...bounds, maxMicroLamports: 50000 };
    const r = computeRecommendedFee([100000, 200000, 300000, 400000], capped, 'normal');
    expect(r.recommendedMicroLamports).toBe(50000);
  });

  it('high urgency never drops below the floor on a quiet network', () => {
    const r = computeRecommendedFee([8000, 9000, 10000, 11000], bounds, 'high');
    expect(r.recommendedMicroLamports).toBeGreaterThanOrEqual(10000);
  });
});
