
jest.mock('../../../src/db/Database', () => ({
  getDb: () => ({ prepare: () => ({ run: jest.fn() }) }),
}));

jest.mock('../../../src/core/EventBus', () => ({
  EventBus: { emit: jest.fn(), on: jest.fn() },
}));

// Mock the RpcManager module so MEVProtection's submit() runs against a fully
// controllable connection. `mockRpc.sendBehavior` is read at call-time, so each
// test deterministically controls success/failure regardless of test order or
// the real RpcManager's connection-pooling singleton.
const mockRpc: { sendBehavior: () => Promise<string> } = {
  sendBehavior: () => Promise.resolve('txhash123'),
};
jest.mock('../../../src/core/RpcManager', () => {
  const makeConn = () => ({
    sendRawTransaction: (..._args: any[]) => mockRpc.sendBehavior(),
  });
  const fake: any = {
    getConnection: () => makeConn(),
    getReadConnection: () => makeConn(),
    getWriteConnection: () => makeConn(),
    getActiveLabel: () => 'mock',
    getActiveReadLabel: () => 'mock',
    getActiveWriteLabel: () => 'mock',
    withFailover: (fn: any) => fn(makeConn()),
    withReadFailover: (fn: any) => fn(makeConn()),
    withWriteFailover: (fn: any) => fn(makeConn()),
  };
  return {
    getRpcManager: () => fake,
    resetRpcManager: () => {},
    RpcManager: jest.fn(() => fake),
  };
});

jest.mock('@solana/web3.js', () => ({
  Connection: jest.fn().mockImplementation(() => ({
    sendRawTransaction: jest.fn().mockResolvedValue('txhash123'),
  })),
  VersionedTransaction: {
    deserialize: jest.fn().mockReturnValue({
      signatures: [new Uint8Array(64)],
      sign: jest.fn(),
      serialize: jest.fn().mockReturnValue(Buffer.from('fake-tx')),
    }),
  },
  Keypair: jest.fn().mockImplementation(() => ({})),
}));

const mockCfg = {
  rpc: { rpcHttpUrl: 'http://localhost', commitment: 'confirmed', fallbackRpcUrls: ['http://localhost'] },
} as any;

const mockExtCfg = {
  mevProtection: {
    jitoEnabled: false,
    jitoTipLamports: 10000,
    jitoBlockEngineUrl: 'https://mainnet.block-engine.jito.wtf',
    maxSlippageAdaptBps: 500,
    sandwichDetectionEnabled: true,
    retryWithJitoOnFail: false,
    frontRunProtectionMs: 0,
  },
} as any;

const mockKeypair = { publicKey: { toBase58: () => 'wallet' } } as any;

describe('MEVProtection', () => {
  let mev: any;

  beforeEach(async () => {
    jest.clearAllMocks();
    // Default: RPC submission resolves successfully.
    mockRpc.sendBehavior = () => Promise.resolve('txhash123');
    const { MEVProtection } = await import('../../../src/execution/mev/MEVProtection');
    mev = new MEVProtection(mockCfg, mockExtCfg, mockKeypair);
  });

  it('submits via RPC successfully', async () => {
    const result = await mev.submit({
      txBase64: Buffer.from('fake').toString('base64'),
      expectedOutAmount: 1000,
      slippageBps: 100,
      priorityFeeMicroLamports: 50000,
    });
    expect(result.success).toBe(true);
    expect(result.usedJito).toBe(false);
    expect(result.txHash).toBe('txhash123');
  });

  it('detects failed fill correctly', () => {
    const isFailed = mev.detectFailedFill(1000, 800, 100); // actual < expected * (1 - slippage)
    expect(isFailed).toBe(true);
  });

  it('does not flag normal fill as failed', () => {
    const isFailed = mev.detectFailedFill(1000, 995, 100); // within 1% slippage
    expect(isFailed).toBe(false);
  });

  it('computes adaptive priority fee', () => {
    const base = 50000;
    mev.consecutiveFailures = 2;
    const adapted = mev.computeAdaptivePriorityFee(base);
    expect(adapted).toBeGreaterThan(base);
  });

  it('adaptive fee resets after resetFailureCount', () => {
    mev.consecutiveFailures = 5;
    mev.resetFailureCount();
    const adapted = mev.computeAdaptivePriorityFee(50000);
    expect(adapted).toBe(50000);
  });

  it('handles RPC failure gracefully when Jito disabled', async () => {
    mockRpc.sendBehavior = () => Promise.reject(new Error('slippage tolerance exceeded'));
    const { MEVProtection } = await import('../../../src/execution/mev/MEVProtection');
    const mev2 = new MEVProtection(mockCfg, mockExtCfg, mockKeypair);
    const result = await mev2.submit({ txBase64: Buffer.from('x').toString('base64'), expectedOutAmount: 1000, slippageBps: 100, priorityFeeMicroLamports: 50000 });
    expect(result.success).toBe(false);
  });
});
