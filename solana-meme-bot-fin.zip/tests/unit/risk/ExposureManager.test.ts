
jest.mock('../../../src/db/Database', () => ({
  getDb: () => ({
    prepare: () => ({ run: jest.fn(), get: jest.fn(() => ({ total: 0 })), all: jest.fn(() => []) }),
  }),
}));

jest.mock('../../../src/db/repositories/PositionRepository', () => ({
  __esModule: true,
  default: {
    findOpenPositions: jest.fn(() => []),
    findByToken: jest.fn(() => undefined),
    getTodayRealisedPnl: jest.fn(() => 0),
    countOpen: jest.fn(() => 0),
  },
}));

jest.mock('../../../src/risk/PositionSizer', () => ({
  getPositionSizer: () => ({
    getKeypair: () => ({ publicKey: { toBase58: () => 'wallet' } }),
  }),
}));

jest.mock('../../../src/core/EventBus', () => ({
  EventBus: { emit: jest.fn(), on: jest.fn() },
}));

// Mock Connection
jest.mock('@solana/web3.js', () => ({
  Connection: jest.fn().mockImplementation(() => ({
    getBalance: jest.fn().mockResolvedValue(10 * 1e9), // 10 SOL
  })),
  LAMPORTS_PER_SOL: 1e9,
}));

import PositionRepository from '../../../src/db/repositories/PositionRepository';

const mockCfg = {
  rpc: { rpcHttpUrl: 'http://localhost', commitment: 'confirmed' },
} as any;

const mockExtCfg = {
  exposure: {
    maxCapitalPerTradePct: 0.10,    // 10% = 1 SOL
    maxCapitalPerTokenSol: 2.0,
    maxTotalDeployedPct: 0.70,
    maxOpenPositions: 3,
    maxDailyLossSol: 1.0,
    maxDrawdownPct: 0.30,
    maxConsecutiveLosses: 5,
    cooldownAfterKillSwitchMs: 3600000,
  },
} as any;

describe('ExposureManager', () => {
  let em: any;

  beforeEach(async () => {
    jest.clearAllMocks();
    (PositionRepository.findOpenPositions as jest.Mock).mockReturnValue([]);
    (PositionRepository.findByToken as jest.Mock).mockReturnValue(undefined);
    (PositionRepository.getTodayRealisedPnl as jest.Mock).mockReturnValue(0);

    const { ExposureManager } = await import('../../../src/risk/exposure/ExposureManager');
    em = new ExposureManager(mockCfg, mockExtCfg);
  });

  afterEach(() => em.stop());

  it('allows trade within all limits', async () => {
    const result = await em.checkEntry('mint1', 0.5);
    expect(result.allowed).toBe(true);
  });

  it('rejects when max positions reached', async () => {
    (PositionRepository.findOpenPositions as jest.Mock).mockReturnValue([
      { sizeSol: 1, tokenMint: 'a', unrealisedPnlSol: 0 },
      { sizeSol: 1, tokenMint: 'b', unrealisedPnlSol: 0 },
      { sizeSol: 1, tokenMint: 'c', unrealisedPnlSol: 0 },
    ]);
    const result = await em.checkEntry('mint2', 0.5);
    expect(result.allowed).toBe(false);
    expect(result.reason).toBe('max_open_positions');
  });

  it('rejects when token already held', async () => {
    (PositionRepository.findByToken as jest.Mock).mockReturnValue({ id: 'p1', tokenMint: 'mint1', status: 'open', sizeSol: 1 });
    const result = await em.checkEntry('mint1', 0.5);
    expect(result.allowed).toBe(false);
    expect(result.reason).toBe('token_already_held');
  });

  it('rejects when size exceeds per-token cap', async () => {
    const result = await em.checkEntry('mint1', 3.0); // > maxCapitalPerTokenSol=2.0
    expect(result.allowed).toBe(false);
    expect(result.reason).toBe('max_capital_per_token');
  });

  it('rejects when size exceeds per-trade percentage', async () => {
    const result = await em.checkEntry('mint1', 1.5); // > 10% of 10 SOL = 1 SOL
    expect(result.allowed).toBe(false);
    expect(result.reason).toBe('max_capital_per_trade_pct');
  });

  it('rejects when daily loss limit hit', async () => {
    (PositionRepository.getTodayRealisedPnl as jest.Mock).mockReturnValue(-1.5);
    const result = await em.checkEntry('mint1', 0.5);
    expect(result.allowed).toBe(false);
    expect(result.reason).toBe('max_daily_loss');
  });

  it('caps size to smallest applicable limit', async () => {
    const capped = await em.capSize('mint1', 5.0);
    expect(capped).toBeLessThanOrEqual(2.0); // maxCapitalPerTokenSol
  });

  it('updates consecutive losses on closed position', async () => {
    em.onPositionClosed(-0.1);
    em.onPositionClosed(-0.1);
    expect(em.getState().consecutiveLosses).toBe(2);
  });

  it('resets consecutive losses on profitable trade', async () => {
    em.onPositionClosed(-0.1);
    em.onPositionClosed(-0.1);
    em.onPositionClosed(0.5); // profit
    expect(em.getState().consecutiveLosses).toBe(0);
  });
});
