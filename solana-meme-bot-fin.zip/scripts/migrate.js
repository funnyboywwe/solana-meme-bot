"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("dotenv/config");
const AppConfig_1 = require("../src/config/AppConfig");
const Database_1 = require("../src/db/Database");
const Logger_1 = require("../src/core/Logger");
async function main() {
    const cfg = (0, AppConfig_1.loadConfig)();
    (0, Logger_1.initLogger)({
        level: cfg.analytics.logLevel,
        logDir: cfg.analytics.logDir,
        retentionDays: cfg.analytics.logRetentionDays,
    });
    const logger = (0, Logger_1.getLogger)('migrate');
    logger.info('Running database migration...');
    try {
        (0, Database_1.initDatabase)(cfg.db.path, cfg.db.walCheckpointIntervalMs);
        logger.info('Migration complete. Schema is up to date.');
    }
    catch (err) {
        logger.error('Migration failed', { error: err });
        process.exit(1);
    }
    finally {
        (0, Database_1.closeDatabase)();
    }
}
main().catch((err) => {
    console.error('Unhandled migration error:', err);
    process.exit(1);
});
//# sourceMappingURL=migrate.js.map