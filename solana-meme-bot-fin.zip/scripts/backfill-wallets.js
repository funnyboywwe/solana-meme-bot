"use strict";
/**
 * backfill-wallets.ts
 *
 * Pre-seeds known smart wallets into the DB.
 * Run once before starting the bot for the first time, or whenever
 * you want to add a curated list of wallets to track.
 *
 * Usage:
 *   ts-node scripts/backfill-wallets.ts
 *
 * Wallets can also be passed as a JSON file:
 *   WALLETS_FILE=./wallets.json ts-node scripts/backfill-wallets.ts
 *
 * wallets.json format:
 *   [
 *     { "address": "ABC123...", "label": "Alpha Trader 1" },
 *     { "address": "DEF456...", "label": "Whale 2" }
 *   ]
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
require("dotenv/config");
const fs = __importStar(require("fs"));
const AppConfig_1 = require("../src/config/AppConfig");
const Database_1 = require("../src/db/Database");
const Logger_1 = require("../src/core/Logger");
const WalletRepository_1 = __importDefault(require("../src/db/repositories/WalletRepository"));
async function main() {
    const cfg = (0, AppConfig_1.loadConfig)();
    (0, Logger_1.initLogger)({
        level: cfg.analytics.logLevel,
        logDir: cfg.analytics.logDir,
        retentionDays: cfg.analytics.logRetentionDays,
    });
    const logger = (0, Logger_1.getLogger)('backfill-wallets');
    logger.info('Starting wallet backfill...');
    (0, Database_1.initDatabase)(cfg.db.path, cfg.db.walCheckpointIntervalMs);
    // Load wallets from file or config
    let wallets = [];
    const walletsFile = process.env['WALLETS_FILE'];
    if (walletsFile && fs.existsSync(walletsFile)) {
        const raw = fs.readFileSync(walletsFile, 'utf-8');
        wallets = JSON.parse(raw);
        logger.info(`Loaded ${wallets.length} wallets from ${walletsFile}`);
    }
    else if (cfg.walletIntel.monitoredWallets.length > 0) {
        wallets = cfg.walletIntel.monitoredWallets.map((a) => ({ address: a }));
        logger.info(`Using ${wallets.length} wallets from config`);
    }
    else {
        logger.warn('No wallets to seed. Set monitoredWallets in config or provide WALLETS_FILE.');
    }
    let added = 0;
    let skipped = 0;
    for (const w of wallets) {
        if (!w.address || w.address.length < 32) {
            logger.warn('Invalid wallet address, skipping', { address: w.address });
            continue;
        }
        if (WalletRepository_1.default.exists(w.address)) {
            logger.debug('Wallet already exists, skipping', { address: w.address });
            skipped++;
            continue;
        }
        WalletRepository_1.default.upsert({
            address: w.address,
            label: w.label,
            qualityScore: 0,
            winRate: 0,
            avgRoi: 0,
            totalTrades: 0,
            profitableTrades: 0,
            totalPnlSol: 0,
            addedAt: Date.now(),
            updatedAt: Date.now(),
            isActive: true,
        });
        logger.info('Wallet seeded', { address: w.address, label: w.label });
        added++;
    }
    logger.info(`Backfill complete`, { added, skipped, total: wallets.length });
    (0, Database_1.closeDatabase)();
}
main().catch((err) => {
    console.error('Backfill failed:', err);
    process.exit(1);
});
//# sourceMappingURL=backfill-wallets.js.map