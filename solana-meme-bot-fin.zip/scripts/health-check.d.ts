/**
 * health-check.ts
 *
 * Standalone liveness probe for use with:
 *   - systemd watchdog
 *   - Docker HEALTHCHECK
 *   - External monitoring (UptimeRobot, BetterStack)
 *
 * Usage:
 *   ts-node scripts/health-check.ts
 *   node dist/scripts/health-check.js
 *
 * Exit codes:
 *   0 — bot is healthy
 *   1 — bot is down or unhealthy
 */
import 'dotenv/config';
//# sourceMappingURL=health-check.d.ts.map