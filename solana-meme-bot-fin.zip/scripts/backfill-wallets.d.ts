/**
 * backfill-wallets.ts
 *
 * Pre-seeds known smart wallets into the DB.
 * Run once before starting the bot for the first time, or whenever
 * you want to add a curated list of wallets to track.
 *
 * Usage:
 *   ts-node scripts/backfill-wallets.ts
 *
 * Wallets can also be passed as a JSON file:
 *   WALLETS_FILE=./wallets.json ts-node scripts/backfill-wallets.ts
 *
 * wallets.json format:
 *   [
 *     { "address": "ABC123...", "label": "Alpha Trader 1" },
 *     { "address": "DEF456...", "label": "Whale 2" }
 *   ]
 */
import 'dotenv/config';
//# sourceMappingURL=backfill-wallets.d.ts.map