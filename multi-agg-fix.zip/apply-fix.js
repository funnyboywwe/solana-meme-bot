#!/usr/bin/env node
'use strict';
/*
 * Multi-Aggregator integration + balance-truth buy/sell recovery fix.
 *
 * Applies precise string replacements to:
 *   - src/execution/ExecutionEngine.ts
 *   - src/index.ts
 *
 * SAFE BY DESIGN: every anchor must be found EXACTLY once, or the script
 * aborts and changes NOTHING. A .bak backup is written for each file before
 * it is edited, so you can always restore with:
 *   mv src/execution/ExecutionEngine.ts.bak src/execution/ExecutionEngine.ts
 *   mv src/index.ts.bak src/index.ts
 *
 * Usage (run from the project root, e.g. ~/solana-meme-bot):
 *   node apply-fix.js --dry-run   # verify all anchors match, write nothing
 *   node apply-fix.js             # apply edits (creates .bak files first)
 */
const fs = require('fs');
const path = require('path');

const DRY = process.argv.includes('--dry-run');
const EDITS_FILE = path.join(__dirname, 'fix-edits.txt');
const ROOT = process.cwd();

function parseEdits(text) {
  const lines = text.replace(/\r\n/g, '\n').split('\n');
  const edits = [];
  let i = 0;
  let curFile = null;
  while (i < lines.length) {
    const line = lines[i];
    if (line.indexOf('###FILE### ') === 0) {
      curFile = line.slice('###FILE### '.length).trim();
      i++;
      continue;
    }
    if (line === '###OLD###') {
      i++;
      const oldLines = [];
      while (i < lines.length && lines[i] !== '###NEW###') { oldLines.push(lines[i]); i++; }
      i++; // skip ###NEW###
      const newLines = [];
      while (i < lines.length && lines[i] !== '###END###') { newLines.push(lines[i]); i++; }
      i++; // skip ###END###
      edits.push({ file: curFile, oldStr: oldLines.join('\n'), newStr: newLines.join('\n') });
      continue;
    }
    i++;
  }
  return edits;
}

function countOccurrences(haystack, needle) {
  if (!needle) return 0;
  let n = 0, idx = 0;
  while ((idx = haystack.indexOf(needle, idx)) !== -1) { n++; idx += needle.length; }
  return n;
}

function main() {
  if (!fs.existsSync(EDITS_FILE)) {
    console.error('ERROR: fix-edits.txt not found next to this script (' + EDITS_FILE + ').');
    process.exit(1);
  }
  const edits = parseEdits(fs.readFileSync(EDITS_FILE, 'utf8'));
  console.log('Parsed ' + edits.length + ' edits.');

  const byFile = {};
  for (const e of edits) { (byFile[e.file] = byFile[e.file] || []).push(e); }

  let ok = true;
  const contents = {};
  for (const file of Object.keys(byFile)) {
    const full = path.join(ROOT, file);
    if (!fs.existsSync(full)) { console.error('MISSING FILE: ' + file + ' (run from the project root)'); ok = false; continue; }
    contents[file] = fs.readFileSync(full, 'utf8');
    for (let k = 0; k < byFile[file].length; k++) {
      const e = byFile[file][k];
      const c = countOccurrences(contents[file], e.oldStr);
      if (c !== 1) {
        ok = false;
        const preview = e.oldStr.split('\n').slice(0, 4).join('\n');
        console.error('\n[edit #' + (k + 1) + ' in ' + file + '] ANCHOR ' + (c === 0 ? 'NOT FOUND' : 'NOT UNIQUE (found ' + c + ')') + ':\n----- expected to find -----\n' + preview + '\n----------------------------');
      }
    }
  }
  if (!ok) { console.error('\nAborting: anchors did not match cleanly. No files were changed.'); process.exit(2); }
  console.log('All anchors matched exactly once.');
  if (DRY) { console.log('Dry run complete. No files written.'); return; }

  for (const file of Object.keys(byFile)) {
    let c = contents[file];
    for (const e of byFile[file]) { c = c.split(e.oldStr).join(e.newStr); }
    const full = path.join(ROOT, file);
    fs.writeFileSync(full + '.bak', contents[file], 'utf8');
    fs.writeFileSync(full, c, 'utf8');
    console.log('Patched ' + file + '  (backup: ' + file + '.bak)');
  }
  console.log('\nDone. Next steps:');
  console.log('  1) set BIRDEYE_API_KEY=... in your .env');
  console.log('  2) npm run build');
  console.log('  3) npm test');
  console.log('  4) pm2 restart solana-meme-bot --update-env');
}

main();
