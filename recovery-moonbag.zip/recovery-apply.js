#!/usr/bin/env node
/* eslint-disable no-console */
'use strict';

/**
 * recovery-apply.js
 *
 * Idempotent, self-contained patcher for the Capital Recovery + Moonbag +
 * Trailing Stop subsystem. Run it from the PROJECT ROOT after unzipping:
 *
 *     node recovery-apply.js
 *
 * It edits a small number of EXISTING files in place (a .bak backup is written
 * for each before the first change). It never touches the brand-new files that
 * the zip added under src/execution/recovery, src/db/migrations and
 * src/db/repositories. Re-running is safe: already-patched files are skipped.
 */

const fs = require('fs');
const path = require('path');

const ROOT = process.cwd();
const read = (f) => fs.readFileSync(f, 'utf8');
const write = (f, c) => fs.writeFileSync(f, c);
const backup = (f) => {
  const b = f + '.bak';
  if (!fs.existsSync(b)) fs.copyFileSync(f, b);
};

// ── New content blocks ──────────────────────────────────────────────────────

const SCHEMA_RECOVERY = `  recovery: z.object({
    enabled: z.boolean().default(true),
    capitalRecoveryTriggerPct: z.number().min(0.0001).max(100).default(0.20),
    trailingStopPct: z.number().min(0.0001).max(1).default(0.10),
    safetyBufferPct: z.number().min(0).max(1).default(0.02),
    liquidityDropExitPct: z.number().min(0).max(1).default(0.30),
    volumeDropExitPct: z.number().min(0).max(1).default(0.70),
    stalePriceSeconds: z.number().positive().default(60),
    minBuySellRatio: z.number().min(0).default(1.0),
    whaleConcentrationExitPct: z.number().min(0).max(100).default(40),
    emergencyPollMs: z.number().int().positive().default(10000),
  }).default({}),

  execution: z.object({`;

const APPCONFIG_ENV = `  merged['costControl'] = costControl;

  // \u2500\u2500 Capital Recovery + Moonbag env overrides \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
  const recovery = (merged['recovery'] as Record<string, unknown>) ?? {};
  if (process.env['RECOVERY_ENABLED']) {
    recovery['enabled'] = process.env['RECOVERY_ENABLED'] !== 'false';
  }
  if (process.env['CAPITAL_RECOVERY_TRIGGER_PERCENT']) {
    recovery['capitalRecoveryTriggerPct'] =
      parseFloat(process.env['CAPITAL_RECOVERY_TRIGGER_PERCENT'] as string) / 100;
  }
  if (process.env['TRAILING_STOP_PERCENT']) {
    recovery['trailingStopPct'] = parseFloat(process.env['TRAILING_STOP_PERCENT'] as string) / 100;
  }
  if (process.env['LIQUIDITY_DROP_EXIT_PERCENT']) {
    recovery['liquidityDropExitPct'] =
      parseFloat(process.env['LIQUIDITY_DROP_EXIT_PERCENT'] as string) / 100;
  }
  if (process.env['VOLUME_DROP_EXIT_PERCENT']) {
    recovery['volumeDropExitPct'] = parseFloat(process.env['VOLUME_DROP_EXIT_PERCENT'] as string) / 100;
  }
  if (process.env['STALE_PRICE_SECONDS']) {
    recovery['stalePriceSeconds'] = parseFloat(process.env['STALE_PRICE_SECONDS'] as string);
  }
  merged['recovery'] = recovery;

  const riskOverrides = (merged['risk'] as Record<string, unknown>) ?? {};
  if (process.env['FIXED_POSITION_SIZE_SOL']) {
    riskOverrides['fixedPositionSizeSol'] = parseFloat(process.env['FIXED_POSITION_SIZE_SOL'] as string);
  }
  if (process.env['MAX_CONCURRENT_POSITIONS']) {
    riskOverrides['maxConcurrentPositions'] = parseInt(process.env['MAX_CONCURRENT_POSITIONS'] as string, 10);
  }
  merged['risk'] = riskOverrides;

  const exposureOverrides = (merged['exposure'] as Record<string, unknown>) ?? {};
  if (process.env['MAX_OPEN_POSITIONS']) {
    exposureOverrides['maxOpenPositions'] = parseInt(process.env['MAX_OPEN_POSITIONS'] as string, 10);
  }
  merged['exposure'] = exposureOverrides;

  return merged;`;

const DB_SCHEMAFILES = `    path.join('migrations', '003_cost_tracking.sql'),
    path.join('migrations', '004_capital_recovery.sql'),
  ];`;

const DB_COLUMNS = `    'ALTER TABLE tokens ADD COLUMN lp_locked_pct REAL',
    'ALTER TABLE positions ADD COLUMN lifecycle_state TEXT DEFAULT \\'open\\'',
    'ALTER TABLE positions ADD COLUMN entry_sol_amount REAL',
    'ALTER TABLE positions ADD COLUMN buy_network_fee_sol REAL',
    'ALTER TABLE positions ADD COLUMN buy_priority_fee_sol REAL',
    'ALTER TABLE positions ADD COLUMN recovery_price_usd REAL',
    'ALTER TABLE positions ADD COLUMN capital_recovered_sol REAL',
    'ALTER TABLE positions ADD COLUMN moonbag_tokens REAL',
    'ALTER TABLE positions ADD COLUMN highest_price_usd REAL',
    'ALTER TABLE positions ADD COLUMN trailing_stop_usd REAL',
  ];`;

const SLM_RELEASE = `  /**
   * Stop managing a position (by mint) here \u2014 used when the Capital Recovery
   * subsystem takes over a position as a moonbag with its own trailing stop.
   */
  releaseManaged(mint: string): void {
    for (const [positionId, position] of this.positions) {
      if (position.tokenMint === mint) {
        this._forgetPosition(positionId);
        logger.info('Released position to Capital Recovery subsystem', { positionId, mint });
      }
    }
  }

  getOpenPositionCount(): number {`;

const INDEX_WIRE = `  stopLossManager.startStaleSweep();
  logger.info('Open positions restored');

  // \u2500\u2500 Capital Recovery + Moonbag + Trailing Stop subsystem \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
  const { RecoveryOrchestrator } = await import('./execution/recovery/RecoveryOrchestrator');
  const recoveryOrchestrator = RecoveryOrchestrator.createDefault(cfg, {
    releaseFromStopLoss: (mint: string) => stopLossManager.releaseManaged(mint),
  });
  await recoveryOrchestrator.restoreFromDb();
  recoveryOrchestrator.start();`;

const RECOVERY_YAML = `\n# \u2500\u2500 Capital Recovery + Moonbag + Trailing Stop \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\nrecovery:\n  enabled: true\n  capitalRecoveryTriggerPct: 0.20   # recover capital at +20%\n  trailingStopPct: 0.10             # 10% trailing stop on the moonbag\n  safetyBufferPct: 0.02             # extra 2% of capital held back as buffer\n  liquidityDropExitPct: 0.30        # emergency exit if liquidity falls >30% from peak\n  volumeDropExitPct: 0.70           # emergency exit if 1h volume falls >70% from peak\n  stalePriceSeconds: 60             # emergency exit if price is stale >60s\n  minBuySellRatio: 1.0              # emergency exit if buy/sell ratio < 1\n  whaleConcentrationExitPct: 40     # emergency exit if top-10 holders >40% (needs BIRDEYE_API_KEY)\n  emergencyPollMs: 10000            # emergency check cadence\n`;

// ── Patch definitions ───────────────────────────────────────────────────────

const patches = [
  {
    file: 'src/config/schema.ts',
    required: true,
    skipIf: 'recovery: z.object({',
    edits: [{ old: '  execution: z.object({', next: SCHEMA_RECOVERY }],
  },
  {
    file: 'src/config/AppConfig.ts',
    required: false,
    skipIf: 'CAPITAL_RECOVERY_TRIGGER_PERCENT',
    edits: [{ old: "  merged['costControl'] = costControl;\n\n  return merged;", next: APPCONFIG_ENV }],
  },
  {
    file: 'src/db/Database.ts',
    required: true,
    skipIf: '004_capital_recovery',
    edits: [
      { old: "    path.join('migrations', '003_cost_tracking.sql'),\n  ];", next: DB_SCHEMAFILES },
      { old: "    'ALTER TABLE tokens ADD COLUMN lp_locked_pct REAL',\n  ];", next: DB_COLUMNS },
    ],
  },
  {
    file: 'src/risk/StopLossManager.ts',
    required: true,
    skipIf: 'recoveryEnabled',
    edits: [
      {
        old: '  private trailingStopPct: number;',
        next: '  private trailingStopPct: number;\n  private recoveryEnabled: boolean;',
      },
      {
        old: '    this.trailingStopActivationPct = cfg.risk.trailingStopActivationPct;',
        next:
          '    this.trailingStopActivationPct = cfg.risk.trailingStopActivationPct;\n' +
          '    this.recoveryEnabled = cfg.recovery?.enabled ?? false;',
      },
      {
        old: '    // 2. Take profit\n    if (gainPct >= this.takeProfitPct) {',
        next:
          '    // 2. Take profit (skipped while Capital Recovery owns the exit path)\n' +
          '    if (!this.recoveryEnabled && gainPct >= this.takeProfitPct) {',
      },
      {
        old: '    // 3. Trailing stop \u2014 only active after activation threshold\n    if (gainPct >= this.trailingStopActivationPct) {',
        next:
          '    // 3. Trailing stop \u2014 only active after activation threshold (skipped while Capital Recovery owns the exit path)\n' +
          '    if (!this.recoveryEnabled && gainPct >= this.trailingStopActivationPct) {',
      },
      { old: '  getOpenPositionCount(): number {', next: SLM_RELEASE },
    ],
  },
  {
    file: 'src/index.ts',
    required: true,
    skipIf: 'RecoveryOrchestrator',
    edits: [
      { old: "  stopLossManager.startStaleSweep();\n  logger.info('Open positions restored');", next: INDEX_WIRE },
      {
        old: '    stopLossManager.stopStaleSweep();',
        next: '    stopLossManager.stopStaleSweep();\n    recoveryOrchestrator.stop();',
      },
    ],
  },
  {
    file: 'src/config/default.yaml',
    required: true,
    skipIf: 'fixedPositionSizeSol: 0.04',
    edits: [
      {
        old: '  fixedPositionSizeSol: 0.01      # LIVE TEST: force every order to exactly 0.01 SOL (~$1.5). Set to 0 for production.',
        next: '  fixedPositionSizeSol: 0.04      # Capital Recovery: 0.04 SOL per order (was 0.01)',
      },
      {
        old: '  maxConcurrentPositions: 1       # LIVE TEST: one position at a time (was 3)',
        next: '  maxConcurrentPositions: 2       # Capital Recovery: allow 2 concurrent (was 1)',
      },
      {
        old: '  maxOpenPositions: 1           # LIVE TEST: one open position (was 5)',
        next: '  maxOpenPositions: 2           # Capital Recovery: allow 2 open (was 1)',
      },
    ],
    appendIfMissing: { marker: '\nrecovery:', text: RECOVERY_YAML },
  },
];

// ── Runner ──────────────────────────────────────────────────────────────────

let failures = 0;
let applied = 0;
let skipped = 0;

for (const p of patches) {
  const abs = path.join(ROOT, p.file);
  if (!fs.existsSync(abs)) {
    console.error(`  MISSING : ${p.file} ${p.required ? '(REQUIRED)' : '(optional)'}`);
    if (p.required) failures++;
    continue;
  }
  let src = read(abs);

  if (p.skipIf && src.includes(p.skipIf)) {
    console.log(`  SKIP    : ${p.file} (already patched)`);
    skipped++;
    continue;
  }

  let working = src;
  let ok = true;
  for (const e of p.edits) {
    const parts = working.split(e.old);
    const found = parts.length - 1;
    if (found !== 1) {
      console.error(`  ANCHOR  : ${p.file} \u2014 expected exactly 1 match, found ${found} for:\n            "${e.old.slice(0, 70).replace(/\n/g, '\\n')}..."`);
      ok = false;
      break;
    }
    working = parts.join(e.next);
  }
  if (!ok) {
    if (p.required) failures++;
    continue;
  }

  if (p.appendIfMissing && !working.includes(p.appendIfMissing.marker)) {
    working = working + p.appendIfMissing.text;
  }

  backup(abs);
  write(abs, working);
  console.log(`  PATCHED : ${p.file}`);
  applied++;
}

console.log(`\nDone. patched=${applied} skipped=${skipped} failures=${failures}`);
if (failures > 0) {
  console.error('\nOne or more REQUIRED patches did not apply. Nothing partial was left in a broken');
  console.error('state for those files (each file is only written when all its anchors match).');
  console.error('Restore any *.bak if needed, then re-run after resolving the mismatch.');
  process.exit(1);
}
