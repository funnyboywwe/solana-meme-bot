#!/usr/bin/env node
'use strict';
/*
 * Follow-up fix: resolve the 2 TypeScript build errors from the multi-aggregator patch.
 *   - src/execution/ExecutionEngine.ts : strategy param typed as Position['strategy']
 *   - src/index.ts                     : PRICE_UPDATE handler returns void
 *
 * SAFE BY DESIGN: every anchor must match EXACTLY once or the script aborts and
 * changes nothing. A .bak backup is written for each file before editing.
 *
 * Usage (run from the project root, e.g. ~/solana-meme-bot):
 *   node apply-fix.js --dry-run
 *   node apply-fix.js
 */
const fs = require('fs');
const path = require('path');

const DRY = process.argv.includes('--dry-run');
const EDITS_FILE = path.join(__dirname, 'fix-edits.txt');
const ROOT = process.cwd();

function parseEdits(text) {
  const lines = text.replace(/\r\n/g, '\n').split('\n');
  const edits = [];
  let i = 0;
  let curFile = null;
  while (i < lines.length) {
    const line = lines[i];
    if (line.indexOf('###FILE### ') === 0) { curFile = line.slice('###FILE### '.length).trim(); i++; continue; }
    if (line === '###OLD###') {
      i++;
      const oldLines = [];
      while (i < lines.length && lines[i] !== '###NEW###') { oldLines.push(lines[i]); i++; }
      i++;
      const newLines = [];
      while (i < lines.length && lines[i] !== '###END###') { newLines.push(lines[i]); i++; }
      i++;
      edits.push({ file: curFile, oldStr: oldLines.join('\n'), newStr: newLines.join('\n') });
      continue;
    }
    i++;
  }
  return edits;
}

function countOccurrences(haystack, needle) {
  if (!needle) return 0;
  let n = 0, idx = 0;
  while ((idx = haystack.indexOf(needle, idx)) !== -1) { n++; idx += needle.length; }
  return n;
}

function main() {
  if (!fs.existsSync(EDITS_FILE)) { console.error('ERROR: fix-edits.txt not found next to this script.'); process.exit(1); }
  const edits = parseEdits(fs.readFileSync(EDITS_FILE, 'utf8'));
  console.log('Parsed ' + edits.length + ' edits.');
  const byFile = {};
  for (const e of edits) { (byFile[e.file] = byFile[e.file] || []).push(e); }
  let ok = true;
  const contents = {};
  for (const file of Object.keys(byFile)) {
    const full = path.join(ROOT, file);
    if (!fs.existsSync(full)) { console.error('MISSING FILE: ' + file + ' (run from the project root)'); ok = false; continue; }
    contents[file] = fs.readFileSync(full, 'utf8');
    for (let k = 0; k < byFile[file].length; k++) {
      const e = byFile[file][k];
      const c = countOccurrences(contents[file], e.oldStr);
      if (c !== 1) {
        ok = false;
        const preview = e.oldStr.split('\n').slice(0, 4).join('\n');
        console.error('\n[edit #' + (k + 1) + ' in ' + file + '] ANCHOR ' + (c === 0 ? 'NOT FOUND' : 'NOT UNIQUE (found ' + c + ')') + ':\n----- expected to find -----\n' + preview + '\n----------------------------');
      }
    }
  }
  if (!ok) { console.error('\nAborting: anchors did not match cleanly. No files were changed.'); process.exit(2); }
  console.log('All anchors matched exactly once.');
  if (DRY) { console.log('Dry run complete. No files written.'); return; }
  for (const file of Object.keys(byFile)) {
    let c = contents[file];
    for (const e of byFile[file]) { c = c.split(e.oldStr).join(e.newStr); }
    const full = path.join(ROOT, file);
    fs.writeFileSync(full + '.bak2', contents[file], 'utf8');
    fs.writeFileSync(full, c, 'utf8');
    console.log('Patched ' + file + '  (backup: ' + file + '.bak2)');
  }
  console.log('\nDone. Next steps:');
  console.log('  1) npm run build');
  console.log('  2) npm test');
  console.log('  3) pm2 restart solana-meme-bot --update-env');
}

main();
