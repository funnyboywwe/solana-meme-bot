#!/usr/bin/env node
/*
 * fix-build.js — repairs the build after sell-execution-fix.zip.
 *
 * It does TWO things, both idempotent and safe (it aborts loudly rather than
 * guessing):
 *
 *   1) src/execution/recovery/RecoveryOrchestrator.ts
 *        renames  persisted.state  ->  persisted.lifecycleState
 *        (the managed-position row field is called lifecycleState).
 *
 *   2) src/execution/ExecutionEngine.ts
 *        - if the file is missing startPositionProtection (because the previous
 *          zip overwrote your real file), it is restored from
 *          ExecutionEngine.ts.bak
 *        - then the BUG #2 sell fix is re-applied against your REAL balance API
 *          (_getOnChainTokenBalance), so a single flaky 0-balance read can no
 *          longer close a position as "stale" without selling.
 *
 * Run it from the project root:   node fix-build.js
 */
const fs = require('fs');

let hadError = false;
function fail(msg) { console.error('  \u2717 ' + msg); hadError = true; }
function ok(msg) { console.log('  \u2713 ' + msg); }
function info(msg) { console.log('  - ' + msg); }

function read(p) { return fs.readFileSync(p, 'utf8'); }
function write(p, s) { fs.writeFileSync(p, s, 'utf8'); }
function exists(p) { try { fs.accessSync(p); return true; } catch { return false; } }
function count(hay, needle) { return hay.split(needle).length - 1; }

// ---------------------------------------------------------------------------
// 1) RecoveryOrchestrator.ts : persisted.state -> persisted.lifecycleState
// ---------------------------------------------------------------------------
console.log('[1/2] RecoveryOrchestrator.ts');
const RO = 'src/execution/recovery/RecoveryOrchestrator.ts';
if (!exists(RO)) {
  fail('not found: ' + RO + ' (run this from the project root, e.g. ~/solana-meme-bot)');
} else {
  let src = read(RO);
  if (count(src, 'persisted.state') > 0) {
    const before = count(src, 'persisted.state');
    src = src.split('persisted.state').join('persisted.lifecycleState');
    write(RO, src);
    ok('renamed persisted.state -> persisted.lifecycleState (' + before + ' occurrence(s))');
  } else if (src.indexOf('Re-armed OPEN positions') !== -1) {
    ok('already patched (no persisted.state references) - nothing to do');
  } else {
    fail('this file does not look like the patched RecoveryOrchestrator.ts');
    info('Expected the capital-recovery re-arm block. Did you restore it from .bak?');
    info('If so, re-extract RecoveryOrchestrator.ts from sell-execution-fix.zip and re-run.');
  }
}

// ---------------------------------------------------------------------------
// 2) ExecutionEngine.ts : restore startPositionProtection + re-apply sell fix
// ---------------------------------------------------------------------------
console.log('[2/2] ExecutionEngine.ts');
const EE = 'src/execution/ExecutionEngine.ts';
const EE_BAK = EE + '.bak';
if (!exists(EE)) {
  fail('not found: ' + EE);
} else {
  let src = read(EE);

  // (a) restore the real file if my whole-file replacement removed the method
  if (src.indexOf('startPositionProtection') === -1) {
    if (exists(EE_BAK) && read(EE_BAK).indexOf('startPositionProtection') !== -1) {
      write(EE, read(EE_BAK));
      src = read(EE);
      ok('restored ExecutionEngine.ts from ExecutionEngine.ts.bak (recovered startPositionProtection)');
    } else {
      fail('ExecutionEngine.ts has no startPositionProtection and no usable .bak was found.');
      info('Your original file (with startPositionProtection) is needed. If you have it in git:');
      info('   git checkout -- src/execution/ExecutionEngine.ts');
      info('Then re-run this script. Otherwise send me your ExecutionEngine.ts and I will rebuild it.');
    }
  } else {
    ok('startPositionProtection present - no restore needed');
  }

  // (b) re-apply the BUG #2 sell fix against the real balance API
  if (!hadError || src.indexOf('startPositionProtection') !== -1) {
    if (src.indexOf('confirmed empty after retries') !== -1) {
      ok('sell-retry fix already present - nothing to do');
    } else {
      const ANCHOR = [
        '    const onChainBalance = await this._getOnChainTokenBalance(mint);',
        '    if (onChainBalance === 0) {',
        "      logger.warn('Wallet holds 0 of this token \u2014 closing stale position without selling', { positionId, mint });",
        '      this._closeStalePosition(position, currentPriceUsd);',
        '      return;',
        '    }',
      ].join('\n');

      const REPLACEMENT = [
        '    let onChainBalance = await this._getOnChainTokenBalance(mint);',
        '    if (onChainBalance === 0) {',
        '      // BUG #2 FIX: never trust a single balance read. A flaky/empty read-RPC',
        '      // response can report 0 even though we still hold the tokens, which made',
        '      // the bot close the position as "stale" WITHOUT selling \u2014 stranding the',
        '      // tokens in the wallet (the "stop-loss hit but sell never executed" bug).',
        '      // Re-confirm an apparent zero a few times before acting. A negative',
        '      // balance means the lookup failed, so we stop retrying and fall through',
        '      // to attempt the sell with the recorded size.',
        '      for (let i = 0; i < 3 && onChainBalance === 0; i++) {',
        '        await new Promise((resolve) => setTimeout(resolve, 800 * (i + 1)));',
        '        onChainBalance = await this._getOnChainTokenBalance(mint);',
        '      }',
        '      if (onChainBalance === 0) {',
        "        logger.warn('Wallet confirmed empty after retries \u2014 closing stale position without selling', { positionId, mint });",
        '        this._closeStalePosition(position, currentPriceUsd);',
        '        return;',
        '      }',
        "      logger.warn('Balance re-read as non-zero after retry \u2014 proceeding to sell', { positionId, mint, onChainBalance });",
        '    }',
      ].join('\n');

      const n = count(src, ANCHOR);
      if (n === 1) {
        src = src.split(ANCHOR).join(REPLACEMENT);
        write(EE, src);
        ok('applied BUG #2 sell-retry fix');
      } else {
        fail('could not apply sell fix: stale-close anchor matched ' + n + ' time(s) (expected 1).');
        info('Your sell() block differs from what I expected. Send me ExecutionEngine.ts and I will adapt the patch.');
      }
    }
  }
}

console.log('');
if (hadError) {
  console.error('FINISHED WITH ERRORS - see messages above. No build attempted.');
  process.exit(1);
} else {
  console.log('All patches applied. Now run:  npm run build');
}
