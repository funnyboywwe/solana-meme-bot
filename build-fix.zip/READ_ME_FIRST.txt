BUILD FIX — sell-execution-fix follow-up
========================================

What went wrong with the last zip
---------------------------------
The previous zip shipped two WHOLE files. That was wrong:

  * RecoveryOrchestrator.ts used  persisted.state , but the real field on the
    managed-position row is  persisted.lifecycleState  -> 2 TS2339 errors.

  * ExecutionEngine.ts was rebuilt from a baseline that did NOT contain your
    startPositionProtection() method (that method only lives in your deployed
    file, never in any zip). Overwriting the file deleted it, so src/index.ts:151
    can no longer find it -> the 3rd error.

So this time we do NOT swap whole files. We patch in place.

What this script does (idempotent + safe — it aborts rather than guessing)
------------------------------------------------------------------------
  1) RecoveryOrchestrator.ts : persisted.state -> persisted.lifecycleState
  2) ExecutionEngine.ts      : if startPositionProtection is missing, restore the
     file from ExecutionEngine.ts.bak (your real original), THEN re-apply the
     BUG #2 sell fix against your real balance API (_getOnChainTokenBalance) so a
     single flaky 0-balance read can no longer close a position as "stale"
     without selling.

How to run
----------
  cd ~/solana-meme-bot
  # put fix-build.js in this folder (project root), then:
  node fix-build.js
  npm run build
  pm2 restart solana-meme-bot --update-env

If the script says ExecutionEngine.ts.bak is missing
----------------------------------------------------
Your original ExecutionEngine.ts (with startPositionProtection) is needed.
If the repo is under git:   git checkout -- src/execution/ExecutionEngine.ts
Then re-run:                node fix-build.js
Otherwise paste me your current ExecutionEngine.ts and I will rebuild it for you.

Verify after restart (you should see these once trades run)
-----------------------------------------------------------
  pm2 logs solana-meme-bot | grep -Ei \
    "Re-armed OPEN positions|Recovery tracking armed|Capital recovered|confirmed empty after retries|Executing sell"
