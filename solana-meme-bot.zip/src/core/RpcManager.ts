import { Connection, Commitment } from '@solana/web3.js';
import { AppConfig } from '../config/AppConfig';
import { createModuleLogger } from './Logger';
import { HealthMonitor, MonitoredEndpoint } from './HealthMonitor';

const logger = createModuleLogger('RpcManager');

export type RpcRole = 'read' | 'write';

/**
 * A single configured RPC provider. Extends MonitoredEndpoint (the health
 * state) with routing metadata.
 *
 * `readPriority` / `writePriority` express *preference ordering* for each role
 * (lower = tried first). Every endpoint can technically serve either role, so a
 * high priority number just means "last resort" — this guarantees writes can
 * always fall through to *some* healthy endpoint even if OrbitFlare was never
 * configured, and reads can fall through even if Helius is down.
 */
interface RpcEndpoint extends MonitoredEndpoint {
  httpUrl: string;
  wsUrl?: string;
  readPriority: number;
  writePriority: number;
}

export interface RpcEndpointStats {
  label: string;
  healthy: boolean;
  latencyMs: number;
  consecutiveFailures: number;
  successRate: number;
  slot: number;
  /** Active for the read role. */
  active: boolean;
  /** Active for the write role. */
  activeWrite: boolean;
}

// Priority constants. Primary = 0 for its role; the cross-role "last resort"
// value is deliberately large so a role's dedicated providers are always
// preferred but nothing is ever truly excluded.
const PRIMARY = 0;
const FALLBACK = 10;
const TERTIARY = 20;
const LAST_RESORT = 90;

/**
 * RpcManager provides production-grade multi-provider RPC routing + failover
 * for a Solana meme-momentum bot.
 *
 * Role-based routing (per requirements):
 *   READS  -> Helius (primary)     / QuickNode (fallback)
 *   WRITES -> OrbitFlare (primary)  / QuickNode (fallback)
 *
 * Features:
 *   - Connection pooling: one reused web3.js Connection per endpoint.
 *   - Separate active endpoint per role (activeRead / activeWrite).
 *   - withReadFailover / withWriteFailover rotate across endpoints (in priority
 *     order, starting at the active one) and retry up to `rpcMaxRetries` times
 *     per endpoint with exponential backoff (longer on rate-limit / 429).
 *   - Health probing is delegated to HealthMonitor (every 30s by default):
 *     latency, success rate, slot freshness, 3-strikes-unhealthy, auto-recover.
 *   - Structured logging of every failover and active-endpoint switch.
 *
 * Back-compat: getConnection()/withFailover() keep working and resolve to the
 * READ pool, so existing read-side callers need no changes.
 *
 * Consumers should call getConnection()/getReadConnection()/getWriteConnection()
 * per operation (not cache them) so runtime failover takes effect.
 */
export class RpcManager {
  private endpoints: RpcEndpoint[];
  private readonly commitment: Commitment;
  private readonly checkIntervalMs: number;
  private readonly maxFailures: number;
  private readonly retryAttempts: number;
  private readonly retryBaseDelayMs: number;
  private readonly probeTimeoutMs: number;
  private readonly slotLagThreshold: number;

  // Priority-sorted endpoint indices per role.
  private readonly readOrder: number[];
  private readonly writeOrder: number[];
  private activeRead: number;
  private activeWrite: number;

  /** Round-robin pointer for read load-balancing across healthy read endpoints. */
  private rrRead = 0;

  private monitor: HealthMonitor | null = null;

  constructor(cfg: AppConfig) {
    this.commitment = cfg.rpc.commitment;
    this.checkIntervalMs = cfg.rpc.healthCheckIntervalMs;
    this.maxFailures = cfg.rpc.maxRpcFailures;
    this.retryAttempts = cfg.rpc.rpcMaxRetries;
    this.retryBaseDelayMs = cfg.rpc.rpcRetryBaseDelayMs;
    this.probeTimeoutMs = cfg.rpc.probeTimeoutMs;
    this.slotLagThreshold = cfg.rpc.slotLagThreshold;

    type Spec = {
      label: string;
      httpUrl: string;
      wsUrl?: string;
      readPriority: number;
      writePriority: number;
    };

    const specs: Spec[] = [
      // Helius: PRIMARY read, last-resort write.
      {
        label: 'helius',
        httpUrl: cfg.rpc.rpcHttpUrl,
        wsUrl: cfg.rpc.heliusWsUrl,
        readPriority: PRIMARY,
        writePriority: LAST_RESORT,
      },
    ];

    // OrbitFlare: PRIMARY write, last-resort read.
    if (cfg.rpc.orbitFlareRpcUrl) {
      specs.push({
        label: 'orbitflare',
        httpUrl: cfg.rpc.orbitFlareRpcUrl,
        wsUrl: cfg.rpc.orbitFlareWsUrl,
        readPriority: LAST_RESORT,
        writePriority: PRIMARY,
      });
    }

    // QuickNode: shared FALLBACK for both roles. If OrbitFlare is absent its
    // write priority (FALLBACK=10) beats Helius (LAST_RESORT=90), so QuickNode
    // automatically becomes the write primary — exactly the desired fallback.
    if (cfg.rpc.quickNodeRpcUrl) {
      specs.push({
        label: 'quicknode',
        httpUrl: cfg.rpc.quickNodeRpcUrl,
        wsUrl: cfg.rpc.quickNodeWsUrl,
        readPriority: FALLBACK,
        writePriority: FALLBACK,
      });
    }

    if (cfg.rpc.tritonRpcUrl) {
      specs.push({
        label: 'triton',
        httpUrl: cfg.rpc.tritonRpcUrl,
        wsUrl: cfg.rpc.tritonWsUrl,
        readPriority: TERTIARY,
        writePriority: TERTIARY,
      });
    }

    cfg.rpc.fallbackRpcUrls.forEach((url, i) => {
      specs.push({
        label: `fallback-${i + 1}`,
        httpUrl: url,
        readPriority: TERTIARY + 1 + i,
        writePriority: TERTIARY + 1 + i,
      });
    });

    this.endpoints = specs.map((s) => ({
      label: s.label,
      httpUrl: s.httpUrl,
      wsUrl: s.wsUrl,
      readPriority: s.readPriority,
      writePriority: s.writePriority,
      connection: new Connection(
        s.httpUrl,
        s.wsUrl
          ? { commitment: this.commitment, wsEndpoint: s.wsUrl }
          : { commitment: this.commitment },
      ),
      healthy: true,
      consecutiveFailures: 0,
      latencyMs: 0,
      slot: 0,
      successCount: 0,
      failureCount: 0,
      lastCheck: 0,
    }));

    // Pre-compute priority-sorted index orders per role (stable).
    const indices = this.endpoints.map((_, i) => i);
    this.readOrder = [...indices].sort(
      (a, b) => this.endpoints[a]!.readPriority - this.endpoints[b]!.readPriority,
    );
    this.writeOrder = [...indices].sort(
      (a, b) => this.endpoints[a]!.writePriority - this.endpoints[b]!.writePriority,
    );
    this.activeRead = this.readOrder[0] ?? 0;
    this.activeWrite = this.writeOrder[0] ?? 0;

    logger.info('RpcManager initialised', {
      endpoints: this.endpoints.map((e) => e.label),
      readPrimary: this.labelOf(this.readOrder[0]),
      writePrimary: this.labelOf(this.writeOrder[0]),
      count: this.endpoints.length,
    });
  }

  // ── Connection accessors ────────────────────────────────────────────────────

  /** Active READ connection (Helius unless failed over). Back-compat default. */
  getConnection(): Connection {
    return this.pickActive('read').connection;
  }

  /** Active READ connection (primary = Helius, fallback = QuickNode). */
  getReadConnection(): Connection {
    return this.pickActive('read').connection;
  }

  /** Active WRITE connection (primary = OrbitFlare, fallback = QuickNode). */
  getWriteConnection(): Connection {
    return this.pickActive('write').connection;
  }

  getActiveLabel(): string {
    return this.labelOf(this.activeRead);
  }

  getActiveReadLabel(): string {
    return this.labelOf(this.activeRead);
  }

  getActiveWriteLabel(): string {
    return this.labelOf(this.activeWrite);
  }

  // ── Failover wrappers ───────────────────────────────────────────────────────

  /** Back-compat: run an op on the READ pool with load-balanced failover. */
  withFailover<T>(fn: (c: Connection) => Promise<T>, opName = 'rpc'): Promise<T> {
    return this.withReadLoadBalanced(fn, opName);
  }

  /** Run a READ op (getAccountInfo, getProgramAccounts, blockhash, ...) load-balanced across healthy read endpoints. */
  withReadFailover<T>(fn: (c: Connection) => Promise<T>, opName = 'read'): Promise<T> {
    return this.withReadLoadBalanced(fn, opName);
  }

  /** Run a WRITE op (sendRawTransaction, simulate, confirm, ...) with failover. */
  withWriteFailover<T>(fn: (c: Connection) => Promise<T>, opName = 'write'): Promise<T> {
    return this.withFailoverForRole('write', fn, opName);
  }

  /**
   * Execute an op for a role across candidate endpoints. Endpoints are tried in
   * priority order (active first); each endpoint is retried up to
   * `rpcMaxRetries` times for transient/rate-limit errors before failing over
   * to the next provider. Every failover and active-endpoint promotion is logged.
   */
  async withFailoverForRole<T>(
    role: RpcRole,
    fn: (c: Connection) => Promise<T>,
    opName: string,
  ): Promise<T> {
    const candidates = this.candidateOrder(role);
    if (candidates.length === 0) throw new Error('RpcManager: no RPC endpoints configured');

    let lastErr: unknown;
    for (const idx of candidates) {
      const ep = this.endpoints[idx];
      if (!ep) continue;
      try {
        const result = await this.callWithRetry(ep, fn, opName, role);
        // Success: recover + promote this endpoint as the active one for the role.
        ep.consecutiveFailures = 0;
        ep.healthy = true;
        if (idx !== this.activeIndex(role)) {
          logger.warn('RPC failover: switched active endpoint', {
            role,
            op: opName,
            from: this.labelOf(this.activeIndex(role)),
            to: ep.label,
          });
          this.setActive(role, idx);
        }
        return result;
      } catch (err) {
        lastErr = err;
        ep.consecutiveFailures++;
        if (ep.consecutiveFailures >= this.maxFailures) ep.healthy = false;
        logger.warn('RPC endpoint failed, failing over', {
          role,
          op: opName,
          label: ep.label,
          consecutiveFailures: ep.consecutiveFailures,
          healthy: ep.healthy,
          error: err instanceof Error ? err.message : String(err),
        });
      }
    }
    throw lastErr instanceof Error
      ? lastErr
      : new Error(`All ${role} RPC endpoints failed for ${opName}`);
  }

  // ── Read load balancing ─────────────────────────────────────────

  /**
   * Build a round-robin candidate order for READS so traffic is spread across
   * all healthy "real" read endpoints (Helius + QuickNode + fallbacks) instead
   * of always hammering a single primary. This is what reduces HTTP 429
   * rate-limits. Last-resort (e.g. OrbitFlare) and unhealthy endpoints are
   * appended so we still fall through to them rather than hard-fail.
   */
  private readLoadBalancedOrder(): number[] {
    const realRead = this.readOrder.filter(
      (i) => this.endpoints[i] !== undefined && this.endpoints[i]!.readPriority < LAST_RESORT,
    );
    const healthyReal = realRead.filter((i) => this.endpoints[i]?.healthy);
    if (healthyReal.length <= 1) {
      // Nothing meaningful to balance — keep normal priority order (active first).
      return this.candidateOrder('read');
    }
    const rest = this.readOrder.filter((i) => !healthyReal.includes(i));
    const start = this.rrRead++ % healthyReal.length;
    if (this.rrRead >= 1_000_000_000) this.rrRead = 0; // avoid unbounded growth
    const rotated = [...healthyReal.slice(start), ...healthyReal.slice(0, start)];
    return [...rotated, ...rest];
  }

  /**
   * Execute a READ op, load-balanced round-robin across healthy read endpoints,
   * with the same per-endpoint retry/backoff + failover as writes. Unlike the
   * write path it does not log an "active endpoint switch" on every call
   * (rotation is expected), which keeps logs clean.
   */
  async withReadLoadBalanced<T>(fn: (c: Connection) => Promise<T>, opName = 'read'): Promise<T> {
    const candidates = this.readLoadBalancedOrder();
    if (candidates.length === 0) throw new Error('RpcManager: no RPC endpoints configured');

    let lastErr: unknown;
    for (const idx of candidates) {
      const ep = this.endpoints[idx];
      if (!ep) continue;
      try {
        const result = await this.callWithRetry(ep, fn, opName, 'read');
        ep.consecutiveFailures = 0;
        ep.healthy = true;
        this.activeRead = idx; // track last successful read endpoint (diagnostics only)
        return result;
      } catch (err) {
        lastErr = err;
        ep.consecutiveFailures++;
        if (ep.consecutiveFailures >= this.maxFailures) ep.healthy = false;
        logger.warn('RPC read endpoint failed, trying next', {
          op: opName,
          label: ep.label,
          consecutiveFailures: ep.consecutiveFailures,
          healthy: ep.healthy,
          error: err instanceof Error ? err.message : String(err),
        });
      }
    }
    throw lastErr instanceof Error
      ? lastErr
      : new Error(`All read RPC endpoints failed for ${opName}`);
  }

  /**
   * Retry a single endpoint up to `retryAttempts` times for transient errors.
   * Rate-limit (HTTP 429) errors get a longer exponential backoff to protect
   * the provider quota; non-retryable errors throw immediately so we fail over.
   */
  private async callWithRetry<T>(
    ep: RpcEndpoint,
    fn: (c: Connection) => Promise<T>,
    opName: string,
    role: RpcRole,
  ): Promise<T> {
    let lastErr: unknown;
    for (let attempt = 1; attempt <= this.retryAttempts; attempt++) {
      const start = Date.now();
      try {
        const result = await fn(ep.connection);
        ep.latencyMs = Date.now() - start;
        ep.successCount++;
        return result;
      } catch (err) {
        lastErr = err;
        ep.failureCount++;
        const rateLimited = isRateLimitError(err);
        const retryable = rateLimited || isRetryableError(err);
        if (!retryable || attempt === this.retryAttempts) throw err;
        const backoff = this.backoffMs(attempt, rateLimited);
        logger.warn('RPC call retrying', {
          role,
          op: opName,
          label: ep.label,
          attempt,
          maxAttempts: this.retryAttempts,
          rateLimited,
          backoffMs: backoff,
          error: err instanceof Error ? err.message : String(err),
        });
        await delay(backoff);
      }
    }
    throw lastErr instanceof Error ? lastErr : new Error(`RPC ${opName} failed on ${ep.label}`);
  }

  /** Exponential backoff with jitter; rate-limit errors back off harder. */
  private backoffMs(attempt: number, rateLimited: boolean): number {
    const base = this.retryBaseDelayMs * (rateLimited ? 4 : 1);
    const exp = base * 2 ** (attempt - 1);
    const jitter = Math.floor(Math.random() * base);
    return Math.min(exp + jitter, 10_000);
  }

  /**
   * Candidate endpoint indices for a role: priority order, but with the current
   * active endpoint first, then remaining healthy endpoints, then unhealthy ones
   * as a last resort (so we still try them rather than hard-fail).
   */
  private candidateOrder(role: RpcRole): number[] {
    const order = role === 'read' ? this.readOrder : this.writeOrder;
    const active = this.activeIndex(role);
    const healthy = order.filter((i) => this.endpoints[i]?.healthy);
    const unhealthy = order.filter((i) => !this.endpoints[i]?.healthy);
    let seq = [...healthy, ...unhealthy];
    if (seq.includes(active)) seq = [active, ...seq.filter((i) => i !== active)];
    return seq;
  }

  private pickActive(role: RpcRole): RpcEndpoint {
    const order = role === 'read' ? this.readOrder : this.writeOrder;
    for (const idx of order) {
      const ep = this.endpoints[idx];
      if (ep && ep.healthy) {
        this.setActive(role, idx);
        return ep;
      }
    }
    // All unhealthy: fall back to the top-priority endpoint for the role.
    const fallback = this.endpoints[order[0] ?? 0];
    if (!fallback) throw new Error('RpcManager: no RPC endpoints configured');
    return fallback;
  }

  private activeIndex(role: RpcRole): number {
    return role === 'read' ? this.activeRead : this.activeWrite;
  }

  private setActive(role: RpcRole, idx: number): void {
    if (role === 'read') this.activeRead = idx;
    else this.activeWrite = idx;
  }

  private labelOf(idx: number | undefined): string {
    if (idx === undefined) return 'none';
    return this.endpoints[idx]?.label ?? 'none';
  }

  // ── Health monitoring (delegated to HealthMonitor) ──────────────────────────

  /** Begin periodic health/latency/slot probing. Idempotent. */
  startHealthChecks(): void {
    if (!this.monitor) {
      this.monitor = new HealthMonitor(this.endpoints, {
        commitment: this.commitment,
        intervalMs: this.checkIntervalMs,
        maxFailures: this.maxFailures,
        probeTimeoutMs: this.probeTimeoutMs,
        slotLagThreshold: this.slotLagThreshold,
      });
    }
    this.monitor.start();
  }

  stopHealthChecks(): void {
    this.monitor?.stop();
  }

  /** Expose the monitor (mainly for tests / diagnostics). */
  getHealthMonitor(): HealthMonitor | null {
    return this.monitor;
  }

  // ── Diagnostics ─────────────────────────────────────────────────────────────

  getStats(): RpcEndpointStats[] {
    return this.endpoints.map((e, i) => {
      const total = e.successCount + e.failureCount;
      return {
        label: e.label,
        healthy: e.healthy,
        latencyMs: e.latencyMs,
        consecutiveFailures: e.consecutiveFailures,
        successRate: total === 0 ? 1 : Number((e.successCount / total).toFixed(3)),
        slot: e.slot,
        active: i === this.activeRead,
        activeWrite: i === this.activeWrite,
      };
    });
  }

  /** Fraction of configured endpoints currently unhealthy (0..1). */
  getErrorRate(): number {
    if (this.endpoints.length === 0) return 0;
    const unhealthy = this.endpoints.filter((e) => !e.healthy).length;
    return unhealthy / this.endpoints.length;
  }
}

/** True for transient errors worth retrying on the same endpoint. */
export function isRetryableError(err: unknown): boolean {
  const msg = (err instanceof Error ? err.message : String(err)).toLowerCase();
  return (
    msg.includes('timeout') ||
    msg.includes('timed out') ||
    msg.includes('econnreset') ||
    msg.includes('econnrefused') ||
    msg.includes('etimedout') ||
    msg.includes('socket hang up') ||
    msg.includes('network') ||
    msg.includes('fetch failed') ||
    msg.includes('failed to fetch') ||
    msg.includes('503') ||
    msg.includes('502') ||
    msg.includes('504') ||
    msg.includes('blockhash not found') ||
    msg.includes('node is behind')
  );
}

/** True for HTTP 429 / rate-limit errors (longer backoff). */
export function isRateLimitError(err: unknown): boolean {
  const msg = (err instanceof Error ? err.message : String(err)).toLowerCase();
  return (
    msg.includes('429') ||
    msg.includes('too many requests') ||
    msg.includes('rate limit') ||
    msg.includes('rate-limit')
  );
}

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

let _instance: RpcManager | null = null;

export function getRpcManager(cfg: AppConfig): RpcManager {
  if (!_instance) _instance = new RpcManager(cfg);
  return _instance;
}

export function resetRpcManager(): void {
  if (_instance) _instance.stopHealthChecks();
  _instance = null;
}

export default RpcManager;
