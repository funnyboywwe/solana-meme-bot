import { Connection } from '@solana/web3.js';
import { AppConfig } from '../config/AppConfig';
import { getRpcManager, RpcManager } from './RpcManager';

/**
 * WriteRpcProvider is the typed, role-aware front door for all WRITE traffic:
 * transaction broadcast (buy/sell execution) and confirmation polling.
 *
 * Every call is routed through RpcManager.withWriteFailover, which means:
 *   - Primary  = OrbitFlare (low-latency sender)
 *   - Fallback = QuickNode (then Triton / generic fallbacks)
 *   - Up to `rpcMaxRetries` retries per endpoint with rate-limit-aware backoff.
 *   - Automatic failover + structured logging on errors.
 *
 * Retrying a send is SAFE: a signed Solana transaction is idempotent by
 * signature, so re-broadcasting the same bytes can never double-spend — at
 * worst the network reports "already processed", which we treat as success at
 * the confirmation layer.
 *
 * NOTE on subscriptions: onSignature/removeSignatureListener are bound to a
 * single Connection and cannot be wrapped per-call. Callers that need a
 * signature subscription should grab getActiveConnection() once and use it for
 * both subscribe and unsubscribe, while polling confirmation via
 * getSignatureStatus (which DOES failover).
 */
export class WriteRpcProvider {
  private readonly rpc: RpcManager;

  constructor(cfg: AppConfig) {
    this.rpc = getRpcManager(cfg);
  }

  /** The currently-active WRITE connection (OrbitFlare unless failed over). */
  getActiveConnection(): Connection {
    return this.rpc.getWriteConnection();
  }

  getActiveLabel(): string {
    return this.rpc.getActiveWriteLabel();
  }

  sendRawTransaction(
    ...args: Parameters<Connection['sendRawTransaction']>
  ): ReturnType<Connection['sendRawTransaction']> {
    return this.rpc.withWriteFailover((c) => c.sendRawTransaction(...args), 'sendRawTransaction');
  }

  sendTransaction(
    ...args: Parameters<Connection['sendTransaction']>
  ): ReturnType<Connection['sendTransaction']> {
    return this.rpc.withWriteFailover((c) => c.sendTransaction(...args), 'sendTransaction');
  }

  simulateTransaction(
    ...args: Parameters<Connection['simulateTransaction']>
  ): ReturnType<Connection['simulateTransaction']> {
    return this.rpc.withWriteFailover(
      (c) => (c.simulateTransaction as (...a: unknown[]) => Promise<unknown>)(...args),
      'simulateTransaction',
    ) as ReturnType<Connection['simulateTransaction']>;
  }

  /**
   * Blockhash used immediately before a send. Routed through the WRITE pool so
   * the blockhash comes from the same provider that will broadcast the tx
   * (reduces "blockhash not found" races on the sender).
   */
  getLatestBlockhash(
    ...args: Parameters<Connection['getLatestBlockhash']>
  ): ReturnType<Connection['getLatestBlockhash']> {
    return this.rpc.withWriteFailover((c) => c.getLatestBlockhash(...args), 'getLatestBlockhash');
  }

  getSignatureStatus(
    ...args: Parameters<Connection['getSignatureStatus']>
  ): ReturnType<Connection['getSignatureStatus']> {
    return this.rpc.withWriteFailover((c) => c.getSignatureStatus(...args), 'getSignatureStatus');
  }

  getSignatureStatuses(
    ...args: Parameters<Connection['getSignatureStatuses']>
  ): ReturnType<Connection['getSignatureStatuses']> {
    return this.rpc.withWriteFailover((c) => c.getSignatureStatuses(...args), 'getSignatureStatuses');
  }

  confirmTransaction(
    ...args: Parameters<Connection['confirmTransaction']>
  ): ReturnType<Connection['confirmTransaction']> {
    return this.rpc.withWriteFailover(
      (c) => (c.confirmTransaction as (...a: unknown[]) => Promise<unknown>)(...args),
      'confirmTransaction',
    ) as ReturnType<Connection['confirmTransaction']>;
  }

  /** Escape hatch for any write not covered above; still gets failover + retries. */
  write<T>(fn: (c: Connection) => Promise<T>, opName = 'write'): Promise<T> {
    return this.rpc.withWriteFailover(fn, opName);
  }
}

let _instance: WriteRpcProvider | null = null;

export function getWriteRpcProvider(cfg: AppConfig): WriteRpcProvider {
  if (!_instance) _instance = new WriteRpcProvider(cfg);
  return _instance;
}

export function resetWriteRpcProvider(): void {
  _instance = null;
}

export default WriteRpcProvider;
