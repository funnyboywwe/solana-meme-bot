import { Connection } from '@solana/web3.js';
import { AppConfig } from '../config/AppConfig';
import { getRpcManager, RpcManager } from './RpcManager';

/**
 * ReadRpcProvider is the typed, role-aware front door for all READ traffic.
 *
 * Every call is routed through RpcManager.withReadFailover, which means:
 *   - Primary  = Helius
 *   - Fallback = QuickNode (then Triton / generic fallbacks)
 *   - Up to `rpcMaxRetries` retries per endpoint with rate-limit-aware backoff.
 *   - Automatic failover + structured logging on errors.
 *
 * Use this for: getAccountInfo, getTokenAccountsByOwner, getProgramAccounts,
 * getLatestBlockhash, pool monitoring, token monitoring, holder analysis and
 * liquidity checks.
 *
 * The wrappers preserve web3.js call signatures via Parameters<>, so call sites
 * look identical to using a raw Connection.
 */
export class ReadRpcProvider {
  private readonly rpc: RpcManager;

  constructor(cfg: AppConfig) {
    this.rpc = getRpcManager(cfg);
  }

  /**
   * The currently-active READ connection. Use ONLY for things that can't be
   * wrapped per-call (e.g. opening account/log subscriptions). Subscriptions
   * are connection-bound, so callers must re-subscribe after a reconnect.
   */
  getActiveConnection(): Connection {
    return this.rpc.getReadConnection();
  }

  getAccountInfo(
    ...args: Parameters<Connection['getAccountInfo']>
  ): ReturnType<Connection['getAccountInfo']> {
    return this.rpc.withReadFailover((c) => c.getAccountInfo(...args), 'getAccountInfo');
  }

  getParsedAccountInfo(
    ...args: Parameters<Connection['getParsedAccountInfo']>
  ): ReturnType<Connection['getParsedAccountInfo']> {
    return this.rpc.withReadFailover((c) => c.getParsedAccountInfo(...args), 'getParsedAccountInfo');
  }

  getMultipleAccountsInfo(
    ...args: Parameters<Connection['getMultipleAccountsInfo']>
  ): ReturnType<Connection['getMultipleAccountsInfo']> {
    return this.rpc.withReadFailover(
      (c) => c.getMultipleAccountsInfo(...args),
      'getMultipleAccountsInfo',
    );
  }

  getTokenAccountsByOwner(
    ...args: Parameters<Connection['getTokenAccountsByOwner']>
  ): ReturnType<Connection['getTokenAccountsByOwner']> {
    return this.rpc.withReadFailover(
      (c) => c.getTokenAccountsByOwner(...args),
      'getTokenAccountsByOwner',
    );
  }

  getParsedTokenAccountsByOwner(
    ...args: Parameters<Connection['getParsedTokenAccountsByOwner']>
  ): ReturnType<Connection['getParsedTokenAccountsByOwner']> {
    return this.rpc.withReadFailover(
      (c) => c.getParsedTokenAccountsByOwner(...args),
      'getParsedTokenAccountsByOwner',
    );
  }

  getProgramAccounts(
    ...args: Parameters<Connection['getProgramAccounts']>
  ): ReturnType<Connection['getProgramAccounts']> {
    return this.rpc.withReadFailover((c) => c.getProgramAccounts(...args), 'getProgramAccounts');
  }

  getLatestBlockhash(
    ...args: Parameters<Connection['getLatestBlockhash']>
  ): ReturnType<Connection['getLatestBlockhash']> {
    return this.rpc.withReadFailover((c) => c.getLatestBlockhash(...args), 'getLatestBlockhash');
  }

  getBalance(
    ...args: Parameters<Connection['getBalance']>
  ): ReturnType<Connection['getBalance']> {
    return this.rpc.withReadFailover((c) => c.getBalance(...args), 'getBalance');
  }

  getSlot(...args: Parameters<Connection['getSlot']>): ReturnType<Connection['getSlot']> {
    return this.rpc.withReadFailover((c) => c.getSlot(...args), 'getSlot');
  }

  getSignaturesForAddress(
    ...args: Parameters<Connection['getSignaturesForAddress']>
  ): ReturnType<Connection['getSignaturesForAddress']> {
    return this.rpc.withReadFailover(
      (c) => c.getSignaturesForAddress(...args),
      'getSignaturesForAddress',
    );
  }

  getParsedTransaction(
    ...args: Parameters<Connection['getParsedTransaction']>
  ): ReturnType<Connection['getParsedTransaction']> {
    return this.rpc.withReadFailover((c) => c.getParsedTransaction(...args), 'getParsedTransaction');
  }

  getTokenSupply(
    ...args: Parameters<Connection['getTokenSupply']>
  ): ReturnType<Connection['getTokenSupply']> {
    return this.rpc.withReadFailover((c) => c.getTokenSupply(...args), 'getTokenSupply');
  }

  getTokenAccountBalance(
    ...args: Parameters<Connection['getTokenAccountBalance']>
  ): ReturnType<Connection['getTokenAccountBalance']> {
    return this.rpc.withReadFailover(
      (c) => c.getTokenAccountBalance(...args),
      'getTokenAccountBalance',
    );
  }

  /** Escape hatch for any read not covered above; still gets failover + retries. */
  read<T>(fn: (c: Connection) => Promise<T>, opName = 'read'): Promise<T> {
    return this.rpc.withReadFailover(fn, opName);
  }
}

let _instance: ReadRpcProvider | null = null;

export function getReadRpcProvider(cfg: AppConfig): ReadRpcProvider {
  if (!_instance) _instance = new ReadRpcProvider(cfg);
  return _instance;
}

export function resetReadRpcProvider(): void {
  _instance = null;
}

export default ReadRpcProvider;
