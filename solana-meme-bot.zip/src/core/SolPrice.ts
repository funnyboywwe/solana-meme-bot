/**
 * SolPrice — shared in-memory SOL/USD price cache.
 *
 * Previously the SOL price was hardcoded to $150 in several places
 * (ExecutionEngine, LiquidityChecker, RaydiumMonitor). That made every
 * USD-denominated calculation wrong whenever SOL moved away from $150.
 *
 * The PriceOracle now tracks WSOL via Jupiter and calls setSolPriceUsd()
 * on every poll, so all consumers read a live value through getSolPriceUsd().
 * The default of 150 is only used until the first successful price poll.
 */

let _solPriceUsd = 150;
let _lastUpdatedAt = 0;

export function getSolPriceUsd(): number {
  return _solPriceUsd;
}

export function setSolPriceUsd(priceUsd: number): void {
  if (Number.isFinite(priceUsd) && priceUsd > 0) {
    _solPriceUsd = priceUsd;
    _lastUpdatedAt = Date.now();
  }
}

export function getSolPriceUpdatedAt(): number {
  return _lastUpdatedAt;
}
