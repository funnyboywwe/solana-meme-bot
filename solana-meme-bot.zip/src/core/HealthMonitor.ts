import { Commitment, Connection } from '@solana/web3.js';
import { createModuleLogger } from './Logger';

const logger = createModuleLogger('HealthMonitor');

/**
 * The minimal shape the HealthMonitor needs to probe and mutate an endpoint.
 * RpcManager's richer RpcEndpoint type is structurally compatible with this,
 * so RpcManager can hand its own endpoint array straight to the monitor and
 * both read the same live health state (no copying, no drift).
 */
export interface MonitoredEndpoint {
  /** Human-readable endpoint label, e.g. 'helius', 'orbitflare', 'quicknode'. */
  label: string;
  /** The pooled web3.js Connection used to probe this endpoint. */
  connection: Connection;
  /** Whether the endpoint is currently considered usable. */
  healthy: boolean;
  /** Consecutive failed probes; reset to 0 on any success. */
  consecutiveFailures: number;
  /** Last measured probe latency in ms (MAX_SAFE_INTEGER when failing). */
  latencyMs: number;
  /** Last observed slot height (used for slot-freshness comparison). */
  slot: number;
  /** Cumulative successful probes (for success-rate reporting). */
  successCount: number;
  /** Cumulative failed probes (for success-rate reporting). */
  failureCount: number;
  /** Timestamp (ms) of the last completed probe. */
  lastCheck: number;
}

export interface HealthMonitorOptions {
  /** Commitment level used for getSlot() probes. */
  commitment: Commitment;
  /** Probe interval in ms (requirement: every 30s). */
  intervalMs: number;
  /** Consecutive failures before an endpoint is marked unhealthy (requirement: 3). */
  maxFailures: number;
  /** Per-probe timeout in ms. */
  probeTimeoutMs: number;
  /**
   * Max slot lag (vs. the freshest endpoint) tolerated before an otherwise-
   * responsive endpoint is treated as stale/unhealthy. Catches nodes that
   * answer quickly but serve outdated state.
   */
  slotLagThreshold: number;
}

/**
 * HealthMonitor periodically probes every RPC endpoint and maintains its live
 * health state. It is intentionally transport-agnostic: it operates on a shared
 * array of MonitoredEndpoint records (owned by RpcManager) and only mutates the
 * health-related fields.
 *
 * Responsibilities (per requirements):
 *  - Check every N seconds (default 30s).
 *  - Measure latency (round-trip of getSlot).
 *  - Measure success rate (cumulative success/failure counters).
 *  - Check slot freshness (flag endpoints lagging behind the network tip).
 *  - Mark an endpoint unhealthy after `maxFailures` consecutive failures.
 *  - Automatically recover an endpoint as soon as a probe succeeds again.
 *  - Log every health-state transition (structured logging).
 */
export class HealthMonitor {
  private timer: NodeJS.Timeout | null = null;

  constructor(
    private readonly endpoints: MonitoredEndpoint[],
    private readonly opts: HealthMonitorOptions,
  ) {}

  /** Start periodic probing. Idempotent. Runs one probe immediately. */
  start(): void {
    if (this.timer) return;
    void this.checkNow();
    this.timer = setInterval(() => void this.checkNow(), this.opts.intervalMs);
    // Don't keep the event loop alive solely for health checks.
    if (typeof this.timer.unref === 'function') this.timer.unref();
    logger.info('Health monitor started', {
      intervalMs: this.opts.intervalMs,
      maxFailures: this.opts.maxFailures,
      endpoints: this.endpoints.map((e) => e.label),
    });
  }

  /** Stop periodic probing. */
  stop(): void {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
      logger.info('Health monitor stopped');
    }
  }

  /** Run a single probe cycle across all endpoints (also callable in tests). */
  async checkNow(): Promise<void> {
    await Promise.all(this.endpoints.map((ep) => this.probe(ep)));
    this.evaluateSlotFreshness();
  }

  /** Cumulative success rate (0..1) for an endpoint. */
  successRate(ep: MonitoredEndpoint): number {
    const total = ep.successCount + ep.failureCount;
    return total === 0 ? 1 : ep.successCount / total;
  }

  private async probe(ep: MonitoredEndpoint): Promise<void> {
    const start = Date.now();
    try {
      const slot = await this.withTimeout(
        ep.connection.getSlot(this.opts.commitment),
        this.opts.probeTimeoutMs,
      );
      ep.latencyMs = Date.now() - start;
      ep.slot = slot;
      ep.successCount++;
      ep.lastCheck = Date.now();
      const wasUnhealthy = !ep.healthy;
      ep.consecutiveFailures = 0;
      ep.healthy = true; // auto-recover on first success
      if (wasUnhealthy) {
        logger.info('RPC endpoint recovered', {
          label: ep.label,
          latencyMs: ep.latencyMs,
          slot: ep.slot,
          successRate: Number(this.successRate(ep).toFixed(3)),
        });
      }
    } catch (err) {
      ep.failureCount++;
      ep.consecutiveFailures++;
      ep.latencyMs = Number.MAX_SAFE_INTEGER;
      ep.lastCheck = Date.now();
      const error = err instanceof Error ? err.message : String(err);
      if (ep.healthy && ep.consecutiveFailures >= this.opts.maxFailures) {
        ep.healthy = false;
        logger.warn('RPC endpoint marked UNHEALTHY', {
          label: ep.label,
          consecutiveFailures: ep.consecutiveFailures,
          successRate: Number(this.successRate(ep).toFixed(3)),
          error,
        });
      } else {
        logger.warn('RPC health probe failed', {
          label: ep.label,
          consecutiveFailures: ep.consecutiveFailures,
          error,
        });
      }
    }
  }

  /**
   * Flag endpoints whose last observed slot lags too far behind the freshest
   * endpoint. Such a node responds but serves stale chain state, which is unsafe
   * for reads (blockhash, account state) and writes alike.
   */
  private evaluateSlotFreshness(): void {
    const slots = this.endpoints.filter((e) => e.slot > 0).map((e) => e.slot);
    if (slots.length === 0) return;
    const maxSlot = Math.max(...slots);
    for (const ep of this.endpoints) {
      if (!ep.healthy || ep.slot <= 0) continue;
      const lag = maxSlot - ep.slot;
      if (lag > this.opts.slotLagThreshold) {
        ep.healthy = false;
        logger.warn('RPC endpoint marked UNHEALTHY (stale slot)', {
          label: ep.label,
          slot: ep.slot,
          tipSlot: maxSlot,
          lag,
          slotLagThreshold: this.opts.slotLagThreshold,
        });
      }
    }
  }

  /** Resolve a promise or reject after `ms` to bound a hung RPC probe. */
  private withTimeout<T>(p: Promise<T>, ms: number): Promise<T> {
    return new Promise<T>((resolve, reject) => {
      const t = setTimeout(() => reject(new Error(`health probe timed out after ${ms}ms`)), ms);
      p.then(
        (v) => {
          clearTimeout(t);
          resolve(v);
        },
        (e) => {
          clearTimeout(t);
          reject(e);
        },
      );
    });
  }
}

export default HealthMonitor;
