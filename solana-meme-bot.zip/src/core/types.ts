// ─── Token ───────────────────────────────────────────────────────────────────

export interface TokenInfo {
  mint: string;
  symbol: string;
  decimals: number;
  createdAt: number;
  mcapUsd: number;
  liquidityUsd: number;
  poolAddress: string;
  source: 'pumpfun' | 'raydium' | 'unknown';
}

// ─── Safety ──────────────────────────────────────────────────────────────────

export interface SafetyReport {
  mint: string;
  rugScore: number;           // 0–100 (100 = definite rug)
  liquidityOk: boolean;
  mintDisabled: boolean;
  freezeDisabled: boolean;
  holderConcentrationPct: number;
  isHoneypot: boolean;
  liquidityUsd: number;
  lpLocked?: boolean;
  lpLockedPct?: number;
  checkedAt: number;
  pass: boolean;
}

// ─── Wallet ──────────────────────────────────────────────────────────────────

export interface WalletStats {
  address: string;
  label?: string;
  qualityScore: number;
  winRate: number;
  avgRoi: number;
  totalTrades: number;
  profitableTrades: number;
  totalPnlSol: number;
  rank: number;
  addedAt: number;
  updatedAt: number;
  isActive: boolean;
}

// ─── Position ────────────────────────────────────────────────────────────────

export type PositionStatus = 'open' | 'closed';

export interface Position {
  id: string;
  tokenMint: string;
  entryTradeId: string;
  sizeSol: number;
  sizeTokens?: number;        // token quantity held (base units / 10^decimals)
  entryPriceUsd: number;
  currentPriceUsd: number;
  unrealisedPnlSol: number;
  stopLossPct: number;
  takeProfitPct: number;
  trailingStopPct: number;
  trailingStopHighUsd: number;     // highest price seen since entry
  openedAt: number;
  updatedAt: number;
  status: PositionStatus;
  strategy: 'momentum' | 'copy' | 'hybrid';
}

export interface ClosedPosition {
  id: string;
  tokenMint: string;
  strategy: string;
  sizeSol: number;
  entryPriceUsd: number;
  exitPriceUsd: number;
  realisedPnlSol: number;
  holdTimeSecs: number;
  exitReason: 'stop' | 'tp' | 'trailing' | 'manual' | 'circuit';
  openedAt: number;
  closedAt: number;
}

// ─── Trade ───────────────────────────────────────────────────────────────────

export type TradeStatus = 'pending' | 'confirmed' | 'failed';
export type TradeSide = 'buy' | 'sell';
export type TradeStrategy = 'momentum' | 'copy' | 'hybrid';

export interface Trade {
  id: string;
  tokenMint: string;
  walletAddress?: string;
  strategy: TradeStrategy;
  side: TradeSide;
  amountSol: number;
  amountTokens: number;
  priceUsd?: number;
  txHash?: string;
  status: TradeStatus;
  momentumScore?: number;
  walletScore?: number;
  entryAt?: number;
  confirmedAt?: number;
  feeSol?: number;
  slippagePct?: number;
}

// ─── Order ───────────────────────────────────────────────────────────────────

export interface SwapOrder {
  mint: string;
  side: TradeSide;
  sizeSol: number;
  slippageBps: number;
  strategy: TradeStrategy;
  momentumScore?: number;
  walletScore?: number;
  walletAddress?: string;
}

export interface SwapResult {
  success: boolean;
  txHash?: string;
  amountIn: number;
  amountOut: number;
  feeSol: number;
  priceImpactPct: number;
  error?: string;
}

// ─── Risk state ───────────────────────────────────────────────────────────────

export interface DailyRiskState {
  date: string;
  startingBalanceSol: number;
  realisedPnlSol: number;
  tradeCount: number;
  circuitBroken: boolean;
  maxDrawdown: number;
}

// ─── Momentum ────────────────────────────────────────────────────────────────

export interface MomentumState {
  mint: string;
  volumeWindowUsd: number[];       // per-window buckets
  buySideVol: number;
  sellSideVol: number;
  txTimestamps: number[];          // last 200 tx timestamps for velocity
  priceHistory: Array<{ price: number; ts: number }>;
  liquidityHistory: Array<{ liquidity: number; ts: number }>;
  lastScore: number;
  lastScoreTs: number;
}

// ─── Smart money cluster ──────────────────────────────────────────────────────

export interface SmartMoneyCluster {
  id: string;
  tokenMint: string;
  walletAddresses: string[];
  walletCount: number;
  avgQualityScore: number;
  avgWinRate: number;
  avgRoi: number;
  totalCapitalSol: number;
  confidenceScore: number;    // 0-100
  firstEntryTs: number;
  lastEntryTs: number;
  windowMs: number;
  status: 'active' | 'expired' | 'executed';
  createdAt: number;
  updatedAt: number;
}

export interface ClusterMember {
  clusterId: string;
  walletAddress: string;
  entryTs: number;
  amountSol: number;
  qualityScore: number;
  winRate: number;
  avgRoi: number;
}

// ─── Liquidity inflow ─────────────────────────────────────────────────────────

export type LiquiditySignal = 'bullish' | 'bearish' | 'neutral';

export interface LiquiditySnapshot {
  tokenMint: string;
  poolAddress: string;
  liquidityUsd: number;
  tvlUsd: number;
  netSolInflow: number;
  lpCount: number;
  buyPressurePct: number;    // 0-100
  velocityUsdPerMin: number;
  signal: LiquiditySignal;
  signalStrength: number;    // 0-100
  ts: number;
}

// ─── Multi-wallet confirmation ────────────────────────────────────────────────

export interface TradeConfirmation {
  id: string;
  tokenMint: string;
  strategy: string;
  walletCount: number;
  requiredWallets: number;
  confirmationScore: number;
  wallets: string[];
  windowStartTs: number;
  windowEndTs: number;
  confirmed: boolean;
  executed: boolean;
  createdAt: number;
}

// ─── Volume acceleration ──────────────────────────────────────────────────────

export interface VolumeAccelerationData {
  tokenMint: string;
  volume1mUsd: number;
  volume5mUsd: number;
  volume15mUsd: number;
  velocityUsdPerMin: number;
  acceleration: number;         // 2nd derivative
  buySellRatio: number;
  tradeFreqPerMin: number;
  freqGrowthPct: number;
  accelerationScore: number;    // 0-100
  rank?: number;
  ts: number;
}

// ─── Holder growth ────────────────────────────────────────────────────────────

export interface HolderSnapshot {
  tokenMint: string;
  holderCount: number;
  newHolders1h: number;
  newHolders24h: number;
  uniqueBuyers: number;
  retentionRate: number;        // 0-1
  whaleConcentration: number;   // top-10 % of supply
  top10Pct: number;
  growthScore: number;          // 0-100
  healthy: boolean;
  ts: number;
}

// ─── Pump.fun migration ───────────────────────────────────────────────────────

export type MigrationStatus = 'bonding' | 'migrating' | 'migrated' | 'failed';

export interface MigrationEvent {
  id: string;
  tokenMint: string;
  pumpPoolAddress: string;
  raydiumPoolAddress: string;
  bondingCurvePct: number;      // 0-100
  completed: boolean;
  raydiumMigrated: boolean;
  initialLiquiditySol: number;
  initialLiquidityUsd: number;
  lpSolAdded: number;
  migrationTs?: number;
  detectedTs: number;
  priorityScore: number;
  status: MigrationStatus;
}

// ─── MEV ─────────────────────────────────────────────────────────────────────

export type MEVEventType = 'sandwich' | 'frontrun' | 'failed_fill' | 'retry_success' | 'jito_bundle';

export interface MEVEvent {
  txHash: string;
  eventType: MEVEventType;
  tokenMint?: string;
  costSol: number;
  slippageActualBps: number;
  slippageExpectedBps: number;
  bundleId?: string;
  tipLamports: number;
  detectedTs: number;
  resolved: boolean;
}

// ─── Exposure ─────────────────────────────────────────────────────────────────

export interface ExposureState {
  totalDeployedSol: number;
  totalPositions: number;
  largestPositionSol: number;
  largestPositionMint: string;
  dailyPnlSol: number;
  drawdownPct: number;
  consecutiveLosses: number;
  killSwitchActive: boolean;
}

// ─── Dynamic position scoring ─────────────────────────────────────────────────

export interface PositionScoreInput {
  momentumScore: number;       // 0-100
  smartMoneyScore: number;     // 0-100
  liquidityScore: number;      // 0-100
  riskScore: number;           // 0-100 (higher = lower risk)
  walletConfidenceScore: number; // 0-100
  accelerationScore: number;   // 0-100
  holderGrowthScore: number;   // 0-100
}

export interface PositionSizeResult {
  sizeSol: number;
  pct: number;
  breakdown: PositionScoreInput;
  mode: string;
  cappedBy: string;            // what capped the size
}
