import axios from 'axios';
import { createModuleLogger } from '../core/Logger';

const logger = createModuleLogger('AlertManager');

export interface AlertConfig {
  telegramEnabled: boolean;
  telegramBotToken: string;
  telegramChatId: string;
  discordEnabled: boolean;
  discordWebhookUrl: string;
  alertOnTrade: boolean;
  alertOnError: boolean;
}

export type AlertLevel = 'info' | 'success' | 'warning' | 'error';

const LEVEL_EMOJI: Record<AlertLevel, string> = {
  info: 'ℹ️',
  success: '✅',
  warning: '⚠️',
  error: '🚨',
};

export interface TradeAlert {
  side: 'buy' | 'sell';
  symbol?: string;
  mint: string;
  sizeSol: number;
  priceUsd: number;
  pnlSol?: number;
  txHash?: string;
}

/**
 * AlertManager delivers operational + trade notifications to Telegram and/or
 * Discord. Both channels are best-effort and never throw into the caller —
 * a failed alert must never break the trading loop. Error alerts are throttled
 * to avoid flooding the channel during outages.
 */
export class AlertManager {
  private cfg: AlertConfig;
  private lastErrorAt = 0;
  private static readonly ERROR_THROTTLE_MS = 30_000;

  constructor(cfg: AlertConfig) {
    this.cfg = cfg;
    logger.info('AlertManager initialized', {
      telegram: cfg.telegramEnabled,
      discord: cfg.discordEnabled,
    });
  }

  /** True when at least one delivery channel is configured + enabled. */
  isEnabled(): boolean {
    return (
      (this.cfg.telegramEnabled && !!this.cfg.telegramBotToken && !!this.cfg.telegramChatId) ||
      (this.cfg.discordEnabled && !!this.cfg.discordWebhookUrl)
    );
  }

  async sendAlert(message: string, level: AlertLevel = 'info'): Promise<void> {
    if (!this.isEnabled()) return;
    const text = `${LEVEL_EMOJI[level]} ${message}`;
    await Promise.allSettled([this._sendTelegram(text), this._sendDiscord(text)]);
  }

  async sendError(message: string): Promise<void> {
    if (!this.cfg.alertOnError) return;
    const now = Date.now();
    if (now - this.lastErrorAt < AlertManager.ERROR_THROTTLE_MS) return;
    this.lastErrorAt = now;
    await this.sendAlert(message, 'error');
  }

  async sendTradeAlert(trade: TradeAlert): Promise<void> {
    if (!this.cfg.alertOnTrade) return;
    const label = trade.symbol ?? `${trade.mint.slice(0, 8)}…`;
    const lines: string[] = [
      `${trade.side === 'buy' ? '🟢 BUY' : '🔴 SELL'} ${label}`,
      `Size: ${trade.sizeSol.toFixed(4)} SOL @ $${trade.priceUsd.toFixed(6)}`,
    ];
    if (typeof trade.pnlSol === 'number') {
      lines.push(`PnL: ${trade.pnlSol >= 0 ? '+' : ''}${trade.pnlSol.toFixed(4)} SOL`);
    }
    if (trade.txHash) lines.push(`tx: https://solscan.io/tx/${trade.txHash}`);
    const level: AlertLevel =
      typeof trade.pnlSol === 'number' && trade.pnlSol < 0 ? 'warning' : 'success';
    await this.sendAlert(lines.join('\n'), level);
  }

  /** Send a titled key/value report (used for the daily PnL summary). */
  async sendReport(title: string, fields: Record<string, string | number>): Promise<void> {
    if (!this.isEnabled()) return;
    const body = Object.entries(fields)
      .map(([k, v]) => `• ${k}: ${v}`)
      .join('\n');
    await this.sendAlert(`*${title}*\n${body}`, 'info');
  }

  private async _sendTelegram(text: string): Promise<void> {
    if (!this.cfg.telegramEnabled || !this.cfg.telegramBotToken || !this.cfg.telegramChatId) return;
    try {
      await axios.post(
        `https://api.telegram.org/bot${this.cfg.telegramBotToken}/sendMessage`,
        { chat_id: this.cfg.telegramChatId, text, disable_web_page_preview: true },
        { timeout: 5000 },
      );
    } catch (err) {
      logger.warn('Telegram alert failed', {
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }

  private async _sendDiscord(text: string): Promise<void> {
    if (!this.cfg.discordEnabled || !this.cfg.discordWebhookUrl) return;
    try {
      await axios.post(this.cfg.discordWebhookUrl, { content: text }, { timeout: 5000 });
    } catch (err) {
      logger.warn('Discord alert failed', {
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }
}

export default AlertManager;
