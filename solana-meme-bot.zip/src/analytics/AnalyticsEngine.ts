import { createModuleLogger } from '../core/Logger';
import { TradeHistory } from './TradeHistory';
import { StrategyMetrics, OverallStats } from './StrategyMetrics';
import PositionRepository from '../db/repositories/PositionRepository';
import WalletRepository from '../db/repositories/WalletRepository';
import TokenRepository from '../db/repositories/TokenRepository';
import { AppConfig } from '../config/AppConfig';

const logger = createModuleLogger('AnalyticsEngine');

export interface AnalyticsSnapshot {
  generatedAt: number;
  performance: OverallStats;
  recentTrades: ReturnType<TradeHistory['query']>;
  topWallets: Array<{
    address: string;
    label?: string;
    qualityScore: number;
    winRate: number;
    totalPnlSol: number;
    totalTrades: number;
    rank: number;
  }>;
  openPositions: Array<{
    id: string;
    tokenMint: string;
    symbol: string;
    strategy: string;
    sizeSol: number;
    entryPriceUsd: number;
    currentPriceUsd: number;
    unrealisedPnlSol: number;
    unrealisedPnlPct: number;
    openedAt: number;
    holdTimeSecs: number;
  }>;
  riskState: {
    openPositionCount: number;
    todayRealisedPnlSol: number;
    unrealisedPnlSol: number;
  };
  exitReasons: ReturnType<StrategyMetrics['getExitReasonStats']>;
  riskAnalytics: ReturnType<StrategyMetrics['getRiskAnalytics']>;
}

/**
 * AnalyticsEngine is the single point of truth for all bot statistics.
 * DashboardAPI and health endpoint both consume this.
 */
export class AnalyticsEngine {
  private tradeHistory: TradeHistory;
  private strategyMetrics: StrategyMetrics;
  private getOpenCount: () => number;
  private getOpenPositions: () => ReturnType<typeof PositionRepository.findOpenPositions>;

  constructor(
    _cfg: AppConfig,
    getOpenCount: () => number,
    getOpenPositions: () => ReturnType<typeof PositionRepository.findOpenPositions>,
  ) {
    this.tradeHistory = new TradeHistory();
    this.strategyMetrics = new StrategyMetrics();
    this.getOpenCount = getOpenCount;
    this.getOpenPositions = getOpenPositions;

    logger.info('AnalyticsEngine initialized');
  }

  /**
   * Generate a full analytics snapshot (called by dashboard endpoints)
   */
  getSnapshot(): AnalyticsSnapshot {
    const openPositions = this.getOpenPositions();
    const unrealisedPnl = openPositions.reduce((s, p) => s + p.unrealisedPnlSol, 0);
    const todayPnl = PositionRepository.getTodayRealisedPnl();

    const overall = this.strategyMetrics.getOverallStats(openPositions.length, unrealisedPnl);
    const recentTrades = this.tradeHistory.query({ limit: 50, status: 'confirmed' });
    const topWallets = WalletRepository.findTopByScore(20);
    const exitReasons = this.strategyMetrics.getExitReasonStats();
    const riskAnalytics = this.strategyMetrics.getRiskAnalytics();

    // Enrich open positions with token symbols
    const enrichedPositions = openPositions.map((p) => {
      const token = TokenRepository.findByMint(p.tokenMint);
      const holdTimeSecs = Math.floor((Date.now() - p.openedAt) / 1000);
      const unrealisedPnlPct =
        p.entryPriceUsd > 0
          ? ((p.currentPriceUsd - p.entryPriceUsd) / p.entryPriceUsd) * 100
          : 0;

      return {
        id: p.id,
        tokenMint: p.tokenMint,
        symbol: token?.symbol ?? 'UNK',
        strategy: p.strategy,
        sizeSol: p.sizeSol,
        entryPriceUsd: p.entryPriceUsd,
        currentPriceUsd: p.currentPriceUsd,
        unrealisedPnlSol: p.unrealisedPnlSol,
        unrealisedPnlPct,
        openedAt: p.openedAt,
        holdTimeSecs,
      };
    });

    return {
      generatedAt: Date.now(),
      performance: overall,
      recentTrades,
      topWallets: topWallets.map((w) => ({
        address: w.address,
        label: w.label,
        qualityScore: w.qualityScore,
        winRate: w.winRate,
        totalPnlSol: w.totalPnlSol,
        totalTrades: w.totalTrades,
        rank: w.rank,
      })),
      openPositions: enrichedPositions,
      riskState: {
        openPositionCount: openPositions.length,
        todayRealisedPnlSol: todayPnl,
        unrealisedPnlSol: unrealisedPnl,
      },
      exitReasons,
      riskAnalytics,
    };
  }

  /**
   * Lightweight stats summary (for health check endpoint)
   */
  getSummary(): {
    openPositions: number;
    todayPnlSol: number;
    totalPnlSol: number;
    winRatePct: number;
    totalTrades: number;
  } {
    const openPositions = this.getOpenPositions();
    const unrealisedPnl = openPositions.reduce((s, p) => s + p.unrealisedPnlSol, 0);
    const overall = this.strategyMetrics.getOverallStats(openPositions.length, unrealisedPnl);

    return {
      openPositions: openPositions.length,
      todayPnlSol: overall.todayRealisedPnlSol,
      totalPnlSol: overall.totalRealisedPnlSol,
      winRatePct: Math.round(overall.winRate * 1000) / 10,
      totalTrades: overall.totalTrades,
    };
  }

  /**
   * Get daily PnL chart data (last 30 days)
   */
  getDailyPnlChart(): Array<{ date: string; pnlSol: number; tradeCount: number }> {
    const openPositions = this.getOpenPositions();
    const unrealised = openPositions.reduce((s, p) => s + p.unrealisedPnlSol, 0);
    const overall = this.strategyMetrics.getOverallStats(openPositions.length, unrealised);
    return overall.dailyPnl;
  }

  getTradeHistory(): TradeHistory {
    return this.tradeHistory;
  }

  getStrategyMetrics(): StrategyMetrics {
    return this.strategyMetrics;
  }
}

export default AnalyticsEngine;
