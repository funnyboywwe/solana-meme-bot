import { TradeFilledEvent } from '../core/EventBus';
import { createModuleLogger } from '../core/Logger';
import PositionRepository from '../db/repositories/PositionRepository';
import { getDb } from '../db/Database';

const logger = createModuleLogger('PnLTracker');

/**
 * PnLTracker maintains session-level and daily P&L state.
 *
 * openPosition()  — called on TRADE_FILLED (buy side)
 * closePosition() — called on TRADE_FILLED (sell side)
 *
 * Persists daily state to daily_risk_state table.
 * Logs win/loss/rate summary after every close.
 */
export class PnLTracker {
  private sessionOpenCount = 0;
  private sessionCloseCount = 0;

  constructor() {
    logger.info('PnLTracker initialized');
  }

  openPosition(event: TradeFilledEvent): void {
    if (event.side !== 'buy') return;
    this.sessionOpenCount++;
    logger.info('Position opened', {
      mint: event.mint,
      sizeSol: event.sizeSol.toFixed(4),
      priceUsd: event.priceUsd.toFixed(6),
      txHash: event.txHash,
    });
  }

  closePosition(event: TradeFilledEvent): void {
    if (event.side !== 'sell') return;
    this.sessionCloseCount++;
    const todayPnl = PositionRepository.getTodayRealisedPnl();
    this._persistDailyState(todayPnl);
    this._logSummary(todayPnl);
  }

  private _persistDailyState(realisedPnlSol: number): void {
    const today = new Date().toISOString().slice(0, 10);
    const db = getDb();
    db.prepare(`
      INSERT INTO daily_risk_state (date, starting_balance_sol, realised_pnl_sol, trade_count, circuit_broken, max_drawdown)
      VALUES (?, 0, ?, 1, 0, 0)
      ON CONFLICT(date) DO UPDATE SET
        realised_pnl_sol = ?,
        trade_count = trade_count + 1
    `).run(today, realisedPnlSol, realisedPnlSol);
  }

  private _logSummary(todayPnlSol: number): void {
    const midnight = new Date();
    midnight.setHours(0, 0, 0, 0);
    const closed = PositionRepository.getClosedPositions(100)
      .filter((p) => p.closedAt >= midnight.getTime());

    const wins = closed.filter((p) => p.realisedPnlSol > 0).length;
    const losses = closed.filter((p) => p.realisedPnlSol <= 0).length;
    const winRate = closed.length > 0 ? (wins / closed.length) * 100 : 0;
    const avgHold = closed.length > 0
      ? closed.reduce((s, p) => s + p.holdTimeSecs, 0) / closed.length
      : 0;

    logger.info('Daily P&L summary', {
      todayPnlSol: todayPnlSol.toFixed(6),
      todayTrades: closed.length,
      wins,
      losses,
      winRatePct: winRate.toFixed(1),
      avgHoldSecs: Math.round(avgHold),
      sessionOpened: this.sessionOpenCount,
      sessionClosed: this.sessionCloseCount,
    });
  }

  getTodayPnl(): number {
    return PositionRepository.getTodayRealisedPnl();
  }
}

export default PnLTracker;
