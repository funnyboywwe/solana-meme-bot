import * as http from 'http';
import { createModuleLogger } from '../core/Logger';
import { StrategyMetrics } from './StrategyMetrics';
import { AppConfig } from '../config/AppConfig';

const logger = createModuleLogger('MetricsExporter');

/**
 * MetricsExporter exposes Prometheus-compatible metrics on /metrics
 * Only started when analytics.prometheusEnabled = true
 *
 * Metrics exposed:
 *   bot_open_positions          gauge
 *   bot_today_pnl_sol           gauge
 *   bot_total_pnl_sol           gauge
 *   bot_win_rate                gauge
 *   bot_total_trades            counter
 *   bot_confirmed_trades        counter
 *   bot_failed_trades           counter
 *   bot_unrealised_pnl_sol      gauge
 *   bot_avg_hold_time_secs      gauge
 *   bot_strategy_win_rate       gauge (label: strategy)
 *   bot_strategy_total_pnl_sol  gauge (label: strategy)
 */
export class MetricsExporter {
  private server: http.Server | null = null;
  private port: number;
  private strategyMetrics: StrategyMetrics;
  private getOpenCount: () => number;
  private getUnrealisedPnl: () => number;

  constructor(
    cfg: AppConfig,
    getOpenCount: () => number,
    getUnrealisedPnl: () => number,
  ) {
    this.port = cfg.analytics.prometheusPort;
    this.strategyMetrics = new StrategyMetrics();
    this.getOpenCount = getOpenCount;
    this.getUnrealisedPnl = getUnrealisedPnl;
  }

  start(): void {
    this.server = http.createServer((req, res) => {
      if (req.url === '/metrics' && req.method === 'GET') {
        try {
          const body = this._render();
          res.writeHead(200, { 'Content-Type': 'text/plain; version=0.0.4; charset=utf-8' });
          res.end(body);
        } catch (err) {
          logger.error('Metrics render failed', { error: String(err) });
          res.writeHead(500);
          res.end('Error rendering metrics');
        }
      } else {
        res.writeHead(404);
        res.end('Not found');
      }
    });

    this.server.listen(this.port, () => {
      logger.info(`Prometheus metrics available at http://localhost:${this.port}/metrics`);
    });

    this.server.on('error', (err) => {
      logger.error('Metrics server error', { error: String(err) });
    });
  }

  stop(): void {
    if (this.server) {
      this.server.close();
      this.server = null;
      logger.info('Metrics exporter stopped');
    }
  }

  private _render(): string {
    const openCount = this.getOpenCount();
    const unrealised = this.getUnrealisedPnl();
    const overall = this.strategyMetrics.getOverallStats(openCount, unrealised);
    const exitStats = this.strategyMetrics.getExitReasonStats();

    const lines: string[] = [];

    const gauge = (name: string, help: string, value: number, labels = '') => {
      lines.push(`# HELP ${name} ${help}`);
      lines.push(`# TYPE ${name} gauge`);
      lines.push(labels ? `${name}{${labels}} ${value}` : `${name} ${value}`);
    };

    const counter = (name: string, help: string, value: number, labels = '') => {
      lines.push(`# HELP ${name} ${help}`);
      lines.push(`# TYPE ${name} counter`);
      lines.push(labels ? `${name}{${labels}} ${value}` : `${name} ${value}`);
    };

    gauge('bot_open_positions', 'Number of currently open positions', overall.openPositions);
    gauge('bot_unrealised_pnl_sol', 'Total unrealised PnL in SOL', overall.unrealisedPnlSol);
    gauge('bot_today_pnl_sol', 'Realised PnL today in SOL', overall.todayRealisedPnlSol);
    gauge('bot_total_pnl_sol', 'Total realised PnL in SOL', overall.totalRealisedPnlSol);
    gauge('bot_win_rate', 'Overall win rate (0-1)', overall.winRate);
    gauge('bot_avg_hold_time_secs', 'Average position hold time in seconds', overall.avgHoldTimeSecs);

    counter('bot_total_trades', 'Total trade attempts', overall.totalTrades);
    counter('bot_confirmed_trades', 'Confirmed trades on-chain', overall.confirmedTrades);
    counter('bot_failed_trades', 'Failed trades', overall.failedTrades);

    // Per-strategy metrics
    for (const s of overall.byStrategy) {
      const lbl = `strategy="${s.strategy}"`;
      gauge('bot_strategy_win_rate', 'Win rate by strategy', s.winRate, lbl);
      gauge('bot_strategy_total_pnl_sol', 'Total PnL by strategy in SOL', s.totalRealisedPnlSol, lbl);
      gauge('bot_strategy_trade_count', 'Trade count by strategy', s.totalTrades, lbl);
      gauge('bot_strategy_avg_hold_secs', 'Avg hold time by strategy', s.avgHoldTimeSecs, lbl);
    }

    // Exit reason distribution
    for (const e of exitStats) {
      const lbl = `reason="${e.reason}"`;
      counter('bot_exit_count', 'Exit count by reason', e.count, lbl);
      gauge('bot_exit_avg_pnl_sol', 'Avg PnL by exit reason in SOL', e.avgPnlSol, lbl);
    }

    return lines.join('\n') + '\n';
  }
}

export default MetricsExporter;
