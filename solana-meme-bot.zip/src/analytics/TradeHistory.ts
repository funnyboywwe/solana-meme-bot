import { getDb } from '../db/Database';
import { createModuleLogger } from '../core/Logger';
import { TradeStrategy, TradeSide } from '../core/types';

const logger = createModuleLogger('TradeHistory');

export interface TradeHistoryFilter {
  strategy?: TradeStrategy;
  side?: TradeSide;
  mint?: string;
  fromTs?: number;
  toTs?: number;
  status?: 'confirmed' | 'failed' | 'pending';
  limit?: number;
  offset?: number;
}

export interface TradeHistoryResult {
  trades: TradeWithToken[];
  total: number;
  limit: number;
  offset: number;
}

export interface TradeWithToken {
  id: string;
  tokenMint: string;
  symbol: string;
  strategy: string;
  side: string;
  amountSol: number;
  amountTokens: number;
  priceUsd: number | null;
  txHash: string | null;
  status: string;
  momentumScore: number | null;
  walletScore: number | null;
  entryAt: number | null;
  confirmedAt: number | null;
  feeSol: number | null;
  slippagePct: number | null;
}

interface TradeRow {
  id: string;
  token_mint: string;
  symbol: string | null;
  strategy: string;
  side: string;
  amount_sol: number;
  amount_tokens: number;
  price_usd: number | null;
  tx_hash: string | null;
  status: string;
  momentum_score: number | null;
  wallet_score: number | null;
  entry_at: number | null;
  confirmed_at: number | null;
  fee_sol: number | null;
  slippage_pct: number | null;
}

/**
 * TradeHistory — paginated, filterable query layer.
 *
 * BUG FIXED (#18): Previous code used variadic spread to mix a dynamic
 * params array with extra limit/offset args:
 *   .all(...params, limit, offset)
 * better-sqlite3 does accept rest args, but TypeScript strict mode rejects
 * spreading an unknown[] into a typed rest param.
 *
 * FIX: Build a single params array and use named param objects (@ prefix)
 * which are both type-safe and unambiguous regardless of how many optional
 * filter conditions are active.
 */
export class TradeHistory {
  query(filter: TradeHistoryFilter = {}): TradeHistoryResult {
    const db = getDb();
    const limit = Math.min(filter.limit ?? 50, 500);
    const offset = filter.offset ?? 0;

    // FIX: named param object — no spreading dynamic arrays
    const namedParams: Record<string, string | number> = {
      p_limit: limit,
      p_offset: offset,
    };

    const conditions: string[] = [];

    if (filter.strategy) {
      conditions.push('t.strategy = @p_strategy');
      namedParams['p_strategy'] = filter.strategy;
    }
    if (filter.side) {
      conditions.push('t.side = @p_side');
      namedParams['p_side'] = filter.side;
    }
    if (filter.mint) {
      conditions.push('t.token_mint = @p_mint');
      namedParams['p_mint'] = filter.mint;
    }
    if (filter.status) {
      conditions.push('t.status = @p_status');
      namedParams['p_status'] = filter.status;
    }
    if (filter.fromTs !== undefined) {
      conditions.push('t.entry_at >= @p_from');
      namedParams['p_from'] = filter.fromTs;
    }
    if (filter.toTs !== undefined) {
      conditions.push('t.entry_at <= @p_to');
      namedParams['p_to'] = filter.toTs;
    }

    const where = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

    const countRow = db
      .prepare(`SELECT COUNT(*) as cnt FROM trades t ${where}`)
      .get(namedParams) as { cnt: number };

    const rows = db
      .prepare(
        `SELECT t.*, COALESCE(tk.symbol, 'UNK') as symbol
         FROM trades t
         LEFT JOIN tokens tk ON tk.mint = t.token_mint
         ${where}
         ORDER BY t.entry_at DESC
         LIMIT @p_limit OFFSET @p_offset`,
      )
      .all(namedParams) as TradeRow[];

    return {
      trades: rows.map(this._rowToTrade),
      total: countRow.cnt,
      limit,
      offset,
    };
  }

  getById(id: string): TradeWithToken | null {
    const db = getDb();
    const row = db
      .prepare(
        `SELECT t.*, COALESCE(tk.symbol, 'UNK') as symbol
         FROM trades t
         LEFT JOIN tokens tk ON tk.mint = t.token_mint
         WHERE t.id = @id`,
      )
      .get({ id }) as TradeRow | undefined;

    return row ? this._rowToTrade(row) : null;
  }

  getDailyVolume(days = 30): Array<{ date: string; tradeCount: number; volumeSol: number }> {
    const db = getDb();
    const since = Date.now() - days * 86400000;

    const rows = db
      .prepare(
        `SELECT
           date(entry_at / 1000, 'unixepoch') as date,
           COUNT(*) as trade_count,
           COALESCE(SUM(amount_sol), 0) as volume_sol
         FROM trades
         WHERE entry_at >= @since AND status = 'confirmed'
         GROUP BY date
         ORDER BY date DESC`,
      )
      .all({ since }) as Array<{ date: string; trade_count: number; volume_sol: number }>;

    return rows.map((r) => ({
      date: r.date,
      tradeCount: r.trade_count,
      volumeSol: r.volume_sol,
    }));
  }

  private _rowToTrade(r: TradeRow): TradeWithToken {
    return {
      id: r.id,
      tokenMint: r.token_mint,
      symbol: r.symbol ?? 'UNK',
      strategy: r.strategy,
      side: r.side,
      amountSol: r.amount_sol,
      amountTokens: r.amount_tokens,
      priceUsd: r.price_usd,
      txHash: r.tx_hash,
      status: r.status,
      momentumScore: r.momentum_score,
      walletScore: r.wallet_score,
      entryAt: r.entry_at,
      confirmedAt: r.confirmed_at,
      feeSol: r.fee_sol,
      slippagePct: r.slippage_pct,
    };
  }
}

export default TradeHistory;
