import { getDb } from '../db/Database';
import { createModuleLogger } from '../core/Logger';

const logger = createModuleLogger('StrategyMetrics');

export interface StrategyStats {
  strategy: string;
  totalTrades: number;
  winningTrades: number;
  losingTrades: number;
  winRate: number;
  totalRealisedPnlSol: number;
  avgPnlPerTradeSol: number;
  avgHoldTimeSecs: number;
  bestTradePnlSol: number;
  worstTradePnlSol: number;
  avgRoi: number;
  sharpeApprox: number;
}

export interface OverallStats {
  totalTrades: number;
  confirmedTrades: number;
  failedTrades: number;
  totalRealisedPnlSol: number;
  todayRealisedPnlSol: number;
  winRate: number;
  avgHoldTimeSecs: number;
  openPositions: number;
  unrealisedPnlSol: number;
  byStrategy: StrategyStats[];
  dailyPnl: Array<{ date: string; pnlSol: number; tradeCount: number }>;
}

interface ClosedRow {
  strategy: string;
  realised_pnl_sol: number;
  hold_time_secs: number;
  exit_reason: string;
}

interface DailyRow {
  date: string;
  pnl_sol: number;
  trade_count: number;
}

/**
 * StrategyMetrics computes comprehensive performance analytics
 * for each trading strategy and overall.
 */
export class StrategyMetrics {
  /**
   * Compute stats broken down by strategy
   */
  getStrategyBreakdown(): StrategyStats[] {
    const db = getDb();
    const strategies = ['momentum', 'copy', 'hybrid'];
    const results: StrategyStats[] = [];

    for (const strategy of strategies) {
      const rows = db
        .prepare(
          `SELECT strategy, realised_pnl_sol, hold_time_secs, exit_reason
           FROM closed_positions
           WHERE strategy = ?
           ORDER BY closed_at DESC`,
        )
        .all(strategy) as ClosedRow[];

      if (rows.length === 0) {
        results.push({
          strategy,
          totalTrades: 0,
          winningTrades: 0,
          losingTrades: 0,
          winRate: 0,
          totalRealisedPnlSol: 0,
          avgPnlPerTradeSol: 0,
          avgHoldTimeSecs: 0,
          bestTradePnlSol: 0,
          worstTradePnlSol: 0,
          avgRoi: 0,
          sharpeApprox: 0,
        });
        continue;
      }

      const totalTrades = rows.length;
      const wins = rows.filter((r) => r.realised_pnl_sol > 0);
      const losses = rows.filter((r) => r.realised_pnl_sol <= 0);
      const totalPnl = rows.reduce((s, r) => s + r.realised_pnl_sol, 0);
      const avgPnl = totalPnl / totalTrades;
      const avgHold =
        rows.reduce((s, r) => s + (r.hold_time_secs ?? 0), 0) / totalTrades;
      const best = Math.max(...rows.map((r) => r.realised_pnl_sol));
      const worst = Math.min(...rows.map((r) => r.realised_pnl_sol));

      // Sharpe approximation: avgPnl / stddev(pnl)
      const variance =
        rows.reduce((s, r) => s + Math.pow(r.realised_pnl_sol - avgPnl, 2), 0) /
        totalTrades;
      const stddev = Math.sqrt(variance);
      const sharpe = stddev > 0 ? avgPnl / stddev : 0;

      results.push({
        strategy,
        totalTrades,
        winningTrades: wins.length,
        losingTrades: losses.length,
        winRate: totalTrades > 0 ? wins.length / totalTrades : 0,
        totalRealisedPnlSol: totalPnl,
        avgPnlPerTradeSol: avgPnl,
        avgHoldTimeSecs: avgHold,
        bestTradePnlSol: best,
        worstTradePnlSol: worst,
        avgRoi: avgPnl,
        sharpeApprox: sharpe,
      });
    }

    return results;
  }

  /**
   * Get full overall performance snapshot
   */
  getOverallStats(openPositionCount: number, unrealisedPnlSol: number): OverallStats {
    const db = getDb();

    // Total confirmed trades
    const tradeStats = db
      .prepare(
        `SELECT
           COUNT(*) as total,
           SUM(CASE WHEN status='confirmed' THEN 1 ELSE 0 END) as confirmed,
           SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END) as failed
         FROM trades`,
      )
      .get() as { total: number; confirmed: number; failed: number };

    // Total realised PnL
    const pnlRow = db
      .prepare(`SELECT COALESCE(SUM(realised_pnl_sol),0) as total FROM closed_positions`)
      .get() as { total: number };

    // Today's PnL
    const midnight = new Date();
    midnight.setHours(0, 0, 0, 0);
    const todayRow = db
      .prepare(
        `SELECT COALESCE(SUM(realised_pnl_sol),0) as total
         FROM closed_positions WHERE closed_at >= ?`,
      )
      .get(midnight.getTime()) as { total: number };

    // Win rate
    const winRow = db
      .prepare(
        `SELECT
           COUNT(*) as total,
           SUM(CASE WHEN realised_pnl_sol > 0 THEN 1 ELSE 0 END) as wins
         FROM closed_positions`,
      )
      .get() as { total: number; wins: number };

    // Avg hold time
    const holdRow = db
      .prepare(`SELECT COALESCE(AVG(hold_time_secs),0) as avg FROM closed_positions`)
      .get() as { avg: number };

    // Daily PnL (last 30 days)
    const dailyRows = db
      .prepare(
        `SELECT
           date(closed_at/1000,'unixepoch') as date,
           COALESCE(SUM(realised_pnl_sol),0) as pnl_sol,
           COUNT(*) as trade_count
         FROM closed_positions
         WHERE closed_at >= ?
         GROUP BY date
         ORDER BY date DESC
         LIMIT 30`,
      )
      .all(Date.now() - 30 * 86400000) as DailyRow[];

    return {
      totalTrades: tradeStats.total ?? 0,
      confirmedTrades: tradeStats.confirmed ?? 0,
      failedTrades: tradeStats.failed ?? 0,
      totalRealisedPnlSol: pnlRow.total,
      todayRealisedPnlSol: todayRow.total,
      winRate: winRow.total > 0 ? winRow.wins / winRow.total : 0,
      avgHoldTimeSecs: holdRow.avg,
      openPositions: openPositionCount,
      unrealisedPnlSol,
      byStrategy: this.getStrategyBreakdown(),
      dailyPnl: dailyRows.map((r) => ({
        date: r.date,
        pnlSol: r.pnl_sol,
        tradeCount: r.trade_count,
      })),
    };
  }

  /**
   * Portfolio-level risk analytics computed over the realised-PnL series of all
   * closed positions (ordered chronologically):
   *   - sharpe   : mean / stddev of per-trade PnL (risk-adjusted return)
   *   - sortino  : mean / downside-deviation (penalises only losses)
   *   - maxDrawdownSol/Pct : largest peak-to-trough drop of the cumulative
   *     realised-PnL equity curve
   */
  getRiskAnalytics(): {
    trades: number;
    sharpe: number;
    sortino: number;
    volatilitySol: number;
    downsideDeviationSol: number;
    maxDrawdownSol: number;
    maxDrawdownPct: number;
    equityPeakSol: number;
  } {
    const db = getDb();
    const rows = db
      .prepare(`SELECT realised_pnl_sol FROM closed_positions ORDER BY closed_at ASC`)
      .all() as Array<{ realised_pnl_sol: number }>;
    const n = rows.length;
    if (n === 0) {
      return {
        trades: 0,
        sharpe: 0,
        sortino: 0,
        volatilitySol: 0,
        downsideDeviationSol: 0,
        maxDrawdownSol: 0,
        maxDrawdownPct: 0,
        equityPeakSol: 0,
      };
    }

    const pnls = rows.map((r) => r.realised_pnl_sol ?? 0);
    const mean = pnls.reduce((s, v) => s + v, 0) / n;
    const variance = pnls.reduce((s, v) => s + Math.pow(v - mean, 2), 0) / n;
    const stddev = Math.sqrt(variance);
    const sharpe = stddev > 0 ? mean / stddev : 0;

    const downsideSq = pnls.reduce((s, v) => (v < 0 ? s + v * v : s), 0) / n;
    const downsideDev = Math.sqrt(downsideSq);
    const sortino = downsideDev > 0 ? mean / downsideDev : 0;

    let equity = 0;
    let peak = 0;
    let maxDd = 0;
    for (const v of pnls) {
      equity += v;
      if (equity > peak) peak = equity;
      const dd = peak - equity;
      if (dd > maxDd) maxDd = dd;
    }
    const maxDdPct = peak > 0 ? (maxDd / peak) * 100 : 0;

    return {
      trades: n,
      sharpe,
      sortino,
      volatilitySol: stddev,
      downsideDeviationSol: downsideDev,
      maxDrawdownSol: maxDd,
      maxDrawdownPct: maxDdPct,
      equityPeakSol: peak,
    };
  }

  /**
   * Get exit reason distribution (stop/tp/trailing/manual/circuit)
   */
  getExitReasonStats(): Array<{ reason: string; count: number; avgPnlSol: number }> {
    const db = getDb();
    const rows = db
      .prepare(
        `SELECT
           exit_reason as reason,
           COUNT(*) as count,
           COALESCE(AVG(realised_pnl_sol),0) as avg_pnl
         FROM closed_positions
         GROUP BY exit_reason
         ORDER BY count DESC`,
      )
      .all() as Array<{ reason: string; count: number; avg_pnl: number }>;

    return rows.map((r) => ({
      reason: r.reason,
      count: r.count,
      avgPnlSol: r.avg_pnl,
    }));
  }
}

export default StrategyMetrics;
