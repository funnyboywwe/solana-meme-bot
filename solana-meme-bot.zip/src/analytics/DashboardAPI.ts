import * as http from 'http';
import * as url from 'url';
import { createModuleLogger } from '../core/Logger';
import { AnalyticsEngine } from './AnalyticsEngine';
import { AppConfig } from '../config/AppConfig';
import WalletRepository from '../db/repositories/WalletRepository';
import TokenRepository from '../db/repositories/TokenRepository';

const logger = createModuleLogger('DashboardAPI');

type RouteHandler = (
  req: http.IncomingMessage,
  res: http.ServerResponse,
  query: Record<string, string>,
) => void;

/**
 * DashboardAPI — lightweight REST API with no external framework
 *
 * Endpoints:
 *   GET /health           — liveness + WS status + quick PnL summary
 *   GET /stats            — full analytics snapshot
 *   GET /positions        — open positions with unrealised PnL
 *   GET /trades           — recent trade history (query: limit, offset, strategy, side)
 *   GET /wallets          — ranked wallet list with quality scores
 *   GET /tokens           — recently tracked tokens with safety info
 *   GET /metrics/daily    — daily PnL chart data (last 30 days)
 */
export class DashboardAPI {
  private server: http.Server | null = null;
  private analyticsEngine: AnalyticsEngine;
  private port: number;
  private wsStatusFn: () => Record<string, boolean>;

  constructor(
    cfg: AppConfig,
    analyticsEngine: AnalyticsEngine,
    wsStatusFn: () => Record<string, boolean>,
  ) {
    this.analyticsEngine = analyticsEngine;
    this.port = cfg.process.healthCheckPort;
    this.wsStatusFn = wsStatusFn;
  }

  start(): void {
    const routes: Record<string, RouteHandler> = {
      '/health':          this._handleHealth.bind(this),
      '/stats':           this._handleStats.bind(this),
      '/positions':       this._handlePositions.bind(this),
      '/trades':          this._handleTrades.bind(this),
      '/wallets':         this._handleWallets.bind(this),
      '/tokens':          this._handleTokens.bind(this),
      '/metrics/daily':   this._handleDailyMetrics.bind(this),
      '/clusters':        this._handleClusters.bind(this),
      '/acceleration':    this._handleAcceleration.bind(this),
      '/migrations':      this._handleMigrations.bind(this),
      '/exposure':        this._handleExposure.bind(this),
      '/kill-switch':     this._handleKillSwitch.bind(this),
    };

    this.server = http.createServer((req, res) => {
      const parsed = url.parse(req.url ?? '/', true);
      const pathname = parsed.pathname ?? '/';
      const query = parsed.query as Record<string, string>;

      // CORS for local dashboard
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
      res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

      if (req.method === 'OPTIONS') {
        res.writeHead(204);
        res.end();
        return;
      }

      if (req.method !== 'GET') {
        this._json(res, 405, { error: 'Method not allowed' });
        return;
      }

      const handler = routes[pathname];
      if (!handler) {
        this._json(res, 404, { error: 'Not found', availableRoutes: Object.keys(routes) });
        return;
      }

      try {
        handler(req, res, query);
      } catch (err) {
        logger.error(`Route error ${pathname}`, { error: String(err) });
        this._json(res, 500, { error: 'Internal server error' });
      }
    });

    this.server.on('error', (err) => {
      logger.error('DashboardAPI server error', { error: String(err) });
    });

    this.server.listen(this.port, () => {
      logger.info(`DashboardAPI listening on port ${this.port}`);
      logger.info('Available endpoints:', {
        routes: Object.keys(routes).map((r) => `GET http://localhost:${this.port}${r}`),
      });
    });
  }

  stop(): void {
    if (this.server) {
      this.server.close();
      this.server = null;
      logger.info('DashboardAPI stopped');
    }
  }

  // ─── Route handlers ──────────────────────────────────────────────────────────

  private _handleHealth(
    _req: http.IncomingMessage,
    res: http.ServerResponse,
    _query: Record<string, string>,
  ): void {
    const summary = this.analyticsEngine.getSummary();
    const wsStatus = this.wsStatusFn();

    this._json(res, 200, {
      status: 'ok',
      uptime: Math.floor(process.uptime()),
      wsStatus,
      ...summary,
      ts: Date.now(),
    });
  }

  private _handleStats(
    _req: http.IncomingMessage,
    res: http.ServerResponse,
    _query: Record<string, string>,
  ): void {
    const snapshot = this.analyticsEngine.getSnapshot();
    this._json(res, 200, snapshot);
  }

  private _handlePositions(
    _req: http.IncomingMessage,
    res: http.ServerResponse,
    _query: Record<string, string>,
  ): void {
    const snapshot = this.analyticsEngine.getSnapshot();
    this._json(res, 200, {
      positions: snapshot.openPositions,
      count: snapshot.openPositions.length,
      totalUnrealisedPnlSol: snapshot.riskState.unrealisedPnlSol,
      ts: Date.now(),
    });
  }

  private _handleTrades(
    _req: http.IncomingMessage,
    res: http.ServerResponse,
    query: Record<string, string>,
  ): void {
    const limit = Math.min(parseInt(query['limit'] ?? '50', 10), 500);
    const offset = parseInt(query['offset'] ?? '0', 10);

    const result = this.analyticsEngine.getTradeHistory().query({
      limit,
      offset,
      strategy: query['strategy'] as any,
      side: query['side'] as any,
      mint: query['mint'],
      status: query['status'] as any,
      fromTs: query['from'] ? parseInt(query['from'], 10) : undefined,
      toTs: query['to'] ? parseInt(query['to'], 10) : undefined,
    });

    this._json(res, 200, result);
  }

  private _handleWallets(
    _req: http.IncomingMessage,
    res: http.ServerResponse,
    query: Record<string, string>,
  ): void {
    const limit = Math.min(parseInt(query['limit'] ?? '50', 10), 200);
    const wallets = WalletRepository.findTopByScore(limit);

    this._json(res, 200, {
      wallets: wallets.map((w) => ({
        address: w.address,
        label: w.label,
        qualityScore: Math.round(w.qualityScore * 10) / 10,
        winRate: Math.round(w.winRate * 1000) / 10,
        avgRoi: Math.round(w.avgRoi * 10000) / 100,
        totalPnlSol: w.totalPnlSol,
        totalTrades: w.totalTrades,
        profitableTrades: w.profitableTrades,
        rank: w.rank,
        isActive: w.isActive,
      })),
      count: wallets.length,
      ts: Date.now(),
    });
  }

  private _handleTokens(
    _req: http.IncomingMessage,
    res: http.ServerResponse,
    query: Record<string, string>,
  ): void {
    const limitMs = parseInt(query['windowMs'] ?? String(24 * 3600000), 10);
    const maxCount = Math.min(parseInt(query['limit'] ?? '100', 10), 500);
    const tokens = TokenRepository.getRecentTokens(limitMs, maxCount);

    this._json(res, 200, {
      tokens: tokens.map((t) => ({
        mint: t.mint,
        symbol: t.symbol,
        source: t.source,
        liquidityUsd: t.liquidityUsd,
        mcapUsd: t.mcapUsd,
        createdAt: t.createdAt,
        ageMs: Date.now() - t.createdAt,
      })),
      count: tokens.length,
      ts: Date.now(),
    });
  }

  private _handleDailyMetrics(
    _req: http.IncomingMessage,
    res: http.ServerResponse,
    _query: Record<string, string>,
  ): void {
    const daily = this.analyticsEngine.getDailyPnlChart();
    const volume = this.analyticsEngine.getTradeHistory().getDailyVolume(30);

    this._json(res, 200, {
      dailyPnl: daily,
      dailyVolume: volume,
      ts: Date.now(),
    });
  }


  private _handleClusters(
    _req: http.IncomingMessage,
    res: http.ServerResponse,
    _query: Record<string, string>,
  ): void {
    const db = require('../db/Database').getDb();
    const clusters = db.prepare(
      "SELECT * FROM smart_money_clusters WHERE status = 'active' ORDER BY confidence_score DESC LIMIT 20"
    ).all();
    this._json(res, 200, { clusters, count: clusters.length, ts: Date.now() });
  }

  private _handleAcceleration(
    _req: http.IncomingMessage,
    res: http.ServerResponse,
    query: Record<string, string>,
  ): void {
    const limit = Math.min(parseInt(query['limit'] ?? '20', 10), 100);
    const db = require('../db/Database').getDb();
    const since = Date.now() - 300000;
    const rows = db.prepare(
      'SELECT * FROM volume_acceleration WHERE ts >= @since ORDER BY acceleration_score DESC LIMIT @limit'
    ).all({ since, limit });
    this._json(res, 200, { tokens: rows, count: rows.length, ts: Date.now() });
  }

  private _handleMigrations(
    _req: http.IncomingMessage,
    res: http.ServerResponse,
    query: Record<string, string>,
  ): void {
    const status = query['status'];
    const db = require('../db/Database').getDb();
    const rows = status
      ? db.prepare('SELECT * FROM migration_events WHERE status = @s ORDER BY priority_score DESC LIMIT 20').all({ s: status })
      : db.prepare('SELECT * FROM migration_events ORDER BY priority_score DESC, detected_ts DESC LIMIT 20').all();
    this._json(res, 200, { migrations: rows, count: rows.length, ts: Date.now() });
  }

  private _handleExposure(
    _req: http.IncomingMessage,
    res: http.ServerResponse,
    _query: Record<string, string>,
  ): void {
    const db = require('../db/Database').getDb();
    const latest = db.prepare(
      'SELECT * FROM exposure_snapshots ORDER BY ts DESC LIMIT 1'
    ).get();
    this._json(res, 200, { exposure: latest ?? {}, ts: Date.now() });
  }

  private _handleKillSwitch(
    _req: http.IncomingMessage,
    res: http.ServerResponse,
    _query: Record<string, string>,
  ): void {
    const db = require('../db/Database').getDb();
    const active = db.prepare("SELECT * FROM kill_switch_log WHERE active = 1 LIMIT 1").get();
    const recent = db.prepare("SELECT * FROM kill_switch_log ORDER BY activated_at DESC LIMIT 10").all();
    this._json(res, 200, { active: !!active, current: active ?? null, history: recent, ts: Date.now() });
  }

  // ─── Helpers ─────────────────────────────────────────────────────────────────

  private _json(res: http.ServerResponse, status: number, data: unknown): void {
    const body = JSON.stringify(data, null, 2);
    res.writeHead(status, {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(body),
    });
    res.end(body);
  }
}

export default DashboardAPI;
