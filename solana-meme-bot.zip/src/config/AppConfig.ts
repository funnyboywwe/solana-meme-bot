import * as fs from 'fs';
import * as path from 'path';
import * as yaml from 'yaml';
import * as dotenv from 'dotenv';
import { ConfigSchema, AppConfig } from './schema';

// Re-export shared config types so other modules can import them from here.
export type { AppConfig } from './schema';

// Load .env file if present (dev). Production uses real env vars.
dotenv.config();

function deepMerge(base: Record<string, unknown>, override: Record<string, unknown>): Record<string, unknown> {
  const result: Record<string, unknown> = { ...base };
  for (const key of Object.keys(override)) {
    const ov = override[key];
    const bv = base[key];
    if (
      ov !== null &&
      typeof ov === 'object' &&
      !Array.isArray(ov) &&
      bv !== null &&
      typeof bv === 'object' &&
      !Array.isArray(bv)
    ) {
      result[key] = deepMerge(bv as Record<string, unknown>, ov as Record<string, unknown>);
    } else {
      result[key] = ov;
    }
  }
  return result;
}

function loadYaml(filePath: string): Record<string, unknown> {
  if (!fs.existsSync(filePath)) return {};
  const raw = fs.readFileSync(filePath, 'utf-8');
  return yaml.parse(raw) as Record<string, unknown>;
}

function buildRawConfig(): Record<string, unknown> {
  const configDir = path.resolve(__dirname);
  const defaultCfg = loadYaml(path.join(configDir, 'default.yaml'));

  const env = process.env['CONFIG_ENV'] ?? process.env['NODE_ENV'] ?? 'development';
  const envCfg = loadYaml(path.join(configDir, `${env}.yaml`));

  const merged = deepMerge(defaultCfg, envCfg);

  // Inject secrets from environment — never from yaml files
  const rpc = (merged['rpc'] as Record<string, unknown>) ?? {};
  rpc['heliusApiKey'] = process.env['HELIUS_API_KEY'] ?? '';
  rpc['rpcHttpUrl'] = process.env['RPC_HTTP_URL'] ?? '';
  if (process.env['HELIUS_WS_URL']) rpc['heliusWsUrl'] = process.env['HELIUS_WS_URL'];
  // Optional multi-RPC failover endpoints (only set when provided).
  if (process.env['QUICKNODE_RPC_URL']) rpc['quickNodeRpcUrl'] = process.env['QUICKNODE_RPC_URL'];
  if (process.env['QUICKNODE_WS_URL']) rpc['quickNodeWsUrl'] = process.env['QUICKNODE_WS_URL'];
  if (process.env['TRITON_RPC_URL']) rpc['tritonRpcUrl'] = process.env['TRITON_RPC_URL'];
  if (process.env['TRITON_WS_URL']) rpc['tritonWsUrl'] = process.env['TRITON_WS_URL'];
  if (process.env['ORBITFLARE_RPC_URL']) rpc['orbitFlareRpcUrl'] = process.env['ORBITFLARE_RPC_URL'];
  if (process.env['ORBITFLARE_WS_URL']) rpc['orbitFlareWsUrl'] = process.env['ORBITFLARE_WS_URL'];
  if (process.env['FALLBACK_RPC_URLS']) {
    rpc['fallbackRpcUrls'] = process.env['FALLBACK_RPC_URLS']
      .split(',')
      .map((s) => s.trim())
      .filter((s) => s.length > 0);
  }
  merged['rpc'] = rpc;

  const wallet = (merged['wallet'] as Record<string, unknown>) ?? {};
  wallet['privateKey'] = process.env['WALLET_PRIVATE_KEY'] ?? '';
  merged['wallet'] = wallet;

  const analytics = (merged['analytics'] as Record<string, unknown>) ?? {};
  if (process.env['LOG_LEVEL']) analytics['logLevel'] = process.env['LOG_LEVEL'];
  merged['analytics'] = analytics;

  const monitoring = (merged['monitoring'] as Record<string, unknown>) ?? {};
  if (process.env['TELEGRAM_BOT_TOKEN']) monitoring['telegramBotToken'] = process.env['TELEGRAM_BOT_TOKEN'];
  if (process.env['TELEGRAM_CHAT_ID']) monitoring['telegramChatId'] = process.env['TELEGRAM_CHAT_ID'];
  if (process.env['DISCORD_WEBHOOK_URL']) monitoring['discordWebhookUrl'] = process.env['DISCORD_WEBHOOK_URL'];
  merged['monitoring'] = monitoring;

  const proc = (merged['process'] as Record<string, unknown>) ?? {};
  // FIX (#2): accept HEALTH_PORT (matches .env.example) plus legacy HEALTH_CHECK_PORT.
  const healthPortEnv = process.env['HEALTH_PORT'] ?? process.env['HEALTH_CHECK_PORT'];
  if (healthPortEnv) {
    proc['healthCheckPort'] = parseInt(healthPortEnv, 10);
  }
  merged['process'] = proc;

  // FIX (#2): DB path override from env (DATABASE_PATH in .env.example).
  const db = (merged['db'] as Record<string, unknown>) ?? {};
  if (process.env['DATABASE_PATH']) db['path'] = process.env['DATABASE_PATH'];
  merged['db'] = db;

  // FIX (#16): trading kill-switch from env. TRADING_ENABLED=false => dry run.
  const trading = (merged['trading'] as Record<string, unknown>) ?? {};
  if (process.env['TRADING_ENABLED'] !== undefined) {
    trading['enabled'] = process.env['TRADING_ENABLED'] === 'true';
  }
  merged['trading'] = trading;

  // FIX (#3): optional Jupiter API key (higher rate limits via api.jup.ag).
  const execution = (merged['execution'] as Record<string, unknown>) ?? {};
  if (process.env['JUPITER_API_KEY']) execution['jupiterApiKey'] = process.env['JUPITER_API_KEY'];
  merged['execution'] = execution;

  // FIX (#4): Jito MEV endpoint + tip overrides (extended-config section).
  const mevProtection = (merged['mevProtection'] as Record<string, unknown>) ?? {};
  if (process.env['JITO_BLOCK_ENGINE_URL']) mevProtection['jitoBlockEngineUrl'] = process.env['JITO_BLOCK_ENGINE_URL'];
  if (process.env['JITO_TIP_LAMPORTS']) mevProtection['jitoTipLamports'] = parseInt(process.env['JITO_TIP_LAMPORTS'], 10);
  merged['mevProtection'] = mevProtection;

  return merged;
}

/**
 * Returns the fully-merged raw config object (yaml + env) BEFORE it is
 * narrowed by ConfigSchema. ExtendedConfigSchema needs this so the extended
 * module sections from default.yaml are actually honoured — parsing the
 * already-narrowed AppConfig silently dropped them and always used defaults.
 */
export function loadRawConfig(): Record<string, unknown> {
  return buildRawConfig();
}

let _config: AppConfig | null = null;

export function loadConfig(): AppConfig {
  if (_config) return _config;

  const raw = buildRawConfig();
  const result = ConfigSchema.safeParse(raw);

  if (!result.success) {
    const issues = result.error.issues
      .map((i) => `  ${i.path.join('.')}: ${i.message}`)
      .join('\n');
    throw new Error(`Configuration validation failed:\n${issues}`);
  }

  _config = result.data;
  return _config;
}

export function getConfig(): AppConfig {
  if (!_config) throw new Error('Config not loaded. Call loadConfig() first.');
  return _config;
}

// Redact secrets for safe logging
export function redactedConfig(cfg: AppConfig): Record<string, unknown> {
  return {
    ...cfg,
    rpc: { ...cfg.rpc, heliusApiKey: '***', rpcHttpUrl: cfg.rpc.rpcHttpUrl.replace(/api-key=[^&]+/, 'api-key=***') },
    wallet: { ...cfg.wallet, privateKey: '***' },
  };
}
