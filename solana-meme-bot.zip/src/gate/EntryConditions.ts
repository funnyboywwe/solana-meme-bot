import { AppConfig } from '../config/AppConfig';
import { getSolPriceUsd } from '../core/SolPrice';

/**
 * EntryConditions validates each entry condition independently
 */
export class EntryConditions {
  private minLiquidityUsd: number;
  private minMarketCapUsd: number;
  private maxMarketCapUsd: number;
  private maxSlippageBps: number;
  // FIX (#12): estimate slippage against the ACTUAL configured order size
  // instead of a hardcoded $500. Uses the fixed live-test size when set,
  // otherwise a ~1 SOL production estimate.
  private orderSizeSolEstimate: number;

  constructor(cfg: AppConfig) {
    this.minLiquidityUsd = cfg.safety.minLiquidityUsd;
    this.minMarketCapUsd = cfg.filters.minMarketCapUsd;
    this.maxMarketCapUsd = cfg.filters.maxMarketCapUsd;
    this.maxSlippageBps = cfg.execution.maxSlippageBps;
    this.orderSizeSolEstimate = cfg.risk.fixedPositionSizeSol > 0 ? cfg.risk.fixedPositionSizeSol : 1;
  }

  /**
   * Check minimum liquidity
   */
  checkLiquidity(liquidityUsd: number): boolean {
    return liquidityUsd >= this.minLiquidityUsd;
  }

  /**
   * Check market cap is within range
   */
  checkMarketCap(mcapUsd: number): boolean {
    return mcapUsd >= this.minMarketCapUsd && mcapUsd <= this.maxMarketCapUsd;
  }

  /**
   * Estimate slippage based on liquidity
   * Rule: slippage ≈ (orderSize / liquidity) * 10000 bps
   * For fixed order size (assume 1 SOL = $150):
   */
  checkSlippage(liquidityUsd: number): boolean {
    if (liquidityUsd === 0) return false;

    // FIX (#12): size the slippage estimate from the real configured order size
    // (SOL) converted at the live SOL price, not a fixed $500 assumption.
    const typicalOrderUsd = this.orderSizeSolEstimate * getSolPriceUsd();
    const estimatedSlippageBps = (typicalOrderUsd / liquidityUsd) * 10000;

    return estimatedSlippageBps <= this.maxSlippageBps;
  }
}

export default EntryConditions;
