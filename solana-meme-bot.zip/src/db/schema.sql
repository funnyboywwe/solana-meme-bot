-- Performance pragmas (applied by Database.ts at connection time, not here)
-- PRAGMA journal_mode=WAL;
-- PRAGMA synchronous=NORMAL;
-- PRAGMA cache_size=-8000;
-- PRAGMA foreign_keys=ON;

-- ─── Tokens ──────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS tokens (
  mint                    TEXT PRIMARY KEY,
  symbol                  TEXT,
  decimals                INTEGER NOT NULL DEFAULT 9,
  created_at              INTEGER NOT NULL,
  mcap_usd                REAL,
  liquidity_usd           REAL,
  pool_address            TEXT,
  source                  TEXT NOT NULL DEFAULT 'unknown',
  safety_score            REAL,
  rug_score               REAL,
  mint_auth_disabled      INTEGER NOT NULL DEFAULT 0,
  freeze_auth_disabled    INTEGER NOT NULL DEFAULT 0,
  holder_concentration    REAL,
  is_honeypot             INTEGER NOT NULL DEFAULT 0,
  lp_locked               INTEGER,
  lp_locked_pct           REAL,
  safety_checked_at       INTEGER,
  updated_at              INTEGER NOT NULL
);

-- ─── Wallets ─────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS wallets (
  address                 TEXT PRIMARY KEY,
  label                   TEXT,
  quality_score           REAL NOT NULL DEFAULT 0,
  win_rate                REAL NOT NULL DEFAULT 0,
  avg_roi                 REAL NOT NULL DEFAULT 0,
  total_trades            INTEGER NOT NULL DEFAULT 0,
  profitable_trades       INTEGER NOT NULL DEFAULT 0,
  total_pnl_sol           REAL NOT NULL DEFAULT 0,
  max_drawdown            REAL NOT NULL DEFAULT 0,
  rank                    INTEGER,
  added_at                INTEGER NOT NULL,
  updated_at              INTEGER NOT NULL,
  is_active               INTEGER NOT NULL DEFAULT 1
);

-- ─── Trades ──────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS trades (
  id                      TEXT PRIMARY KEY,
  token_mint              TEXT NOT NULL REFERENCES tokens(mint),
  wallet_address          TEXT,
  strategy                TEXT NOT NULL CHECK(strategy IN ('momentum','copy','hybrid')),
  side                    TEXT NOT NULL CHECK(side IN ('buy','sell')),
  amount_sol              REAL NOT NULL,
  amount_tokens           REAL NOT NULL DEFAULT 0,
  price_usd               REAL,
  tx_hash                 TEXT UNIQUE,
  status                  TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','confirmed','failed')),
  momentum_score          REAL,
  wallet_score            REAL,
  entry_at                INTEGER,
  confirmed_at            INTEGER,
  fee_sol                 REAL,
  slippage_pct            REAL
);

-- ─── Open positions ───────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS positions (
  id                      TEXT PRIMARY KEY,
  token_mint              TEXT NOT NULL REFERENCES tokens(mint),
  entry_trade_id          TEXT REFERENCES trades(id),
  strategy                TEXT NOT NULL,
  size_sol                REAL NOT NULL,
  size_tokens             REAL NOT NULL DEFAULT 0,
  entry_price_usd         REAL NOT NULL,
  current_price_usd       REAL NOT NULL DEFAULT 0,
  unrealised_pnl_sol      REAL NOT NULL DEFAULT 0,
  stop_loss_pct           REAL NOT NULL,
  take_profit_pct         REAL NOT NULL,
  trailing_stop_pct       REAL NOT NULL,
  trailing_stop_high_usd  REAL NOT NULL DEFAULT 0,
  opened_at               INTEGER NOT NULL,
  updated_at              INTEGER NOT NULL,
  status                  TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','closed'))
);

-- ─── Closed positions ─────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS closed_positions (
  id                      TEXT PRIMARY KEY,
  token_mint              TEXT,
  strategy                TEXT,
  size_sol                REAL,
  entry_price_usd         REAL,
  exit_price_usd          REAL,
  realised_pnl_sol        REAL,
  hold_time_secs          INTEGER,
  exit_reason             TEXT CHECK(exit_reason IN ('stop','tp','trailing','manual','circuit')),
  opened_at               INTEGER,
  closed_at               INTEGER NOT NULL
);

-- ─── Daily risk state ─────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS daily_risk_state (
  date                    TEXT PRIMARY KEY,
  starting_balance_sol    REAL NOT NULL DEFAULT 0,
  realised_pnl_sol        REAL NOT NULL DEFAULT 0,
  trade_count             INTEGER NOT NULL DEFAULT 0,
  circuit_broken          INTEGER NOT NULL DEFAULT 0,
  max_drawdown            REAL NOT NULL DEFAULT 0
);

-- ─── Event log (append-only audit trail) ─────────────────────────────────────

CREATE TABLE IF NOT EXISTS event_log (
  id                      INTEGER PRIMARY KEY AUTOINCREMENT,
  event_type              TEXT NOT NULL,
  payload                 TEXT,
  ts                      INTEGER NOT NULL
);

-- ─── Indexes ──────────────────────────────────────────────────────────────────

CREATE INDEX IF NOT EXISTS idx_trades_token     ON trades(token_mint);
CREATE INDEX IF NOT EXISTS idx_trades_status    ON trades(status);
CREATE INDEX IF NOT EXISTS idx_trades_entry_at  ON trades(entry_at);
CREATE INDEX IF NOT EXISTS idx_positions_status ON positions(status);
CREATE INDEX IF NOT EXISTS idx_positions_token  ON positions(token_mint);
CREATE INDEX IF NOT EXISTS idx_event_log_ts     ON event_log(ts);
CREATE INDEX IF NOT EXISTS idx_event_log_type   ON event_log(event_type);
CREATE INDEX IF NOT EXISTS idx_closed_closed_at ON closed_positions(closed_at);
