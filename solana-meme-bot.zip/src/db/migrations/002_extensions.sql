-- ─── Migration 002: Extension tables ──────────────────────────────────────────
-- Backward-compatible additions. Run after 001_initial (schema.sql).

-- ─── Smart money clusters ─────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS smart_money_clusters (
  id                    TEXT PRIMARY KEY,
  token_mint            TEXT NOT NULL REFERENCES tokens(mint),
  wallet_addresses      TEXT NOT NULL,  -- JSON array
  wallet_count          INTEGER NOT NULL DEFAULT 0,
  avg_quality_score     REAL NOT NULL DEFAULT 0,
  avg_win_rate          REAL NOT NULL DEFAULT 0,
  avg_roi               REAL NOT NULL DEFAULT 0,
  total_capital_sol     REAL NOT NULL DEFAULT 0,
  confidence_score      REAL NOT NULL DEFAULT 0,  -- 0-100
  first_entry_ts        INTEGER NOT NULL,
  last_entry_ts         INTEGER NOT NULL,
  window_ms             INTEGER NOT NULL,
  status                TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','expired','executed')),
  created_at            INTEGER NOT NULL,
  updated_at            INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_clusters_token    ON smart_money_clusters(token_mint);
CREATE INDEX IF NOT EXISTS idx_clusters_status   ON smart_money_clusters(status);
CREATE INDEX IF NOT EXISTS idx_clusters_conf     ON smart_money_clusters(confidence_score DESC);
CREATE INDEX IF NOT EXISTS idx_clusters_created  ON smart_money_clusters(created_at);

-- ─── Wallet cluster membership ────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS cluster_members (
  cluster_id            TEXT NOT NULL REFERENCES smart_money_clusters(id),
  wallet_address        TEXT NOT NULL,
  entry_ts              INTEGER NOT NULL,
  amount_sol            REAL NOT NULL DEFAULT 0,
  quality_score         REAL NOT NULL DEFAULT 0,
  win_rate              REAL NOT NULL DEFAULT 0,
  avg_roi               REAL NOT NULL DEFAULT 0,
  PRIMARY KEY (cluster_id, wallet_address)
);

CREATE INDEX IF NOT EXISTS idx_cluster_members_wallet ON cluster_members(wallet_address);

-- ─── Liquidity inflow tracking ────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS liquidity_snapshots (
  id                    INTEGER PRIMARY KEY AUTOINCREMENT,
  token_mint            TEXT NOT NULL,
  pool_address          TEXT NOT NULL DEFAULT '',
  liquidity_usd         REAL NOT NULL DEFAULT 0,
  tvl_usd               REAL NOT NULL DEFAULT 0,
  net_sol_inflow        REAL NOT NULL DEFAULT 0,   -- positive = inflow
  lp_count              INTEGER NOT NULL DEFAULT 0,
  buy_pressure_pct      REAL NOT NULL DEFAULT 50,  -- 0-100
  velocity_usd_per_min  REAL NOT NULL DEFAULT 0,
  signal                TEXT NOT NULL DEFAULT 'neutral' CHECK(signal IN ('bullish','bearish','neutral')),
  signal_strength       REAL NOT NULL DEFAULT 0,   -- 0-100
  ts                    INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_liq_snap_mint   ON liquidity_snapshots(token_mint, ts DESC);
CREATE INDEX IF NOT EXISTS idx_liq_snap_ts     ON liquidity_snapshots(ts);
CREATE INDEX IF NOT EXISTS idx_liq_snap_signal ON liquidity_snapshots(signal, ts DESC);

-- ─── Multi-wallet confirmations ───────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS trade_confirmations (
  id                    TEXT PRIMARY KEY,
  token_mint            TEXT NOT NULL,
  strategy              TEXT NOT NULL DEFAULT 'hybrid',
  wallet_count          INTEGER NOT NULL DEFAULT 0,
  required_wallets      INTEGER NOT NULL DEFAULT 3,
  confirmation_score    REAL NOT NULL DEFAULT 0,
  wallets_json          TEXT NOT NULL DEFAULT '[]',
  window_start_ts       INTEGER NOT NULL,
  window_end_ts         INTEGER NOT NULL,
  confirmed             INTEGER NOT NULL DEFAULT 0,
  executed              INTEGER NOT NULL DEFAULT 0,
  created_at            INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_confirms_mint   ON trade_confirmations(token_mint);
CREATE INDEX IF NOT EXISTS idx_confirms_conf   ON trade_confirmations(confirmed, created_at);

-- ─── Volume acceleration ──────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS volume_acceleration (
  id                    INTEGER PRIMARY KEY AUTOINCREMENT,
  token_mint            TEXT NOT NULL,
  volume_1m_usd         REAL NOT NULL DEFAULT 0,
  volume_5m_usd         REAL NOT NULL DEFAULT 0,
  volume_15m_usd        REAL NOT NULL DEFAULT 0,
  velocity_usd_per_min  REAL NOT NULL DEFAULT 0,
  acceleration          REAL NOT NULL DEFAULT 0,   -- 2nd derivative
  buy_sell_ratio        REAL NOT NULL DEFAULT 1.0,
  trade_freq_per_min    REAL NOT NULL DEFAULT 0,
  freq_growth_pct       REAL NOT NULL DEFAULT 0,
  acceleration_score    REAL NOT NULL DEFAULT 0,   -- 0-100
  rank                  INTEGER,
  ts                    INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_vol_acc_mint   ON volume_acceleration(token_mint, ts DESC);
CREATE INDEX IF NOT EXISTS idx_vol_acc_score  ON volume_acceleration(acceleration_score DESC);
CREATE INDEX IF NOT EXISTS idx_vol_acc_ts     ON volume_acceleration(ts);

-- ─── Holder growth tracking ───────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS holder_snapshots (
  id                    INTEGER PRIMARY KEY AUTOINCREMENT,
  token_mint            TEXT NOT NULL,
  holder_count          INTEGER NOT NULL DEFAULT 0,
  new_holders_1h        INTEGER NOT NULL DEFAULT 0,
  new_holders_24h       INTEGER NOT NULL DEFAULT 0,
  unique_buyers         INTEGER NOT NULL DEFAULT 0,
  retention_rate        REAL NOT NULL DEFAULT 1.0,  -- 0-1
  whale_concentration   REAL NOT NULL DEFAULT 0,    -- top-10 % of supply
  top10_pct             REAL NOT NULL DEFAULT 0,
  growth_score          REAL NOT NULL DEFAULT 0,    -- 0-100
  healthy               INTEGER NOT NULL DEFAULT 1, -- 0=fail, 1=pass
  ts                    INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_holder_snap_mint   ON holder_snapshots(token_mint, ts DESC);
CREATE INDEX IF NOT EXISTS idx_holder_snap_ts     ON holder_snapshots(ts);
CREATE INDEX IF NOT EXISTS idx_holder_snap_score  ON holder_snapshots(growth_score DESC);

-- ─── Pump.fun migration events ────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS migration_events (
  id                    TEXT PRIMARY KEY,
  token_mint            TEXT NOT NULL,
  pump_pool_address     TEXT NOT NULL DEFAULT '',
  raydium_pool_address  TEXT NOT NULL DEFAULT '',
  bonding_curve_pct     REAL NOT NULL DEFAULT 0,   -- 0-100
  completed             INTEGER NOT NULL DEFAULT 0,
  raydium_migrated      INTEGER NOT NULL DEFAULT 0,
  initial_liquidity_sol REAL NOT NULL DEFAULT 0,
  initial_liquidity_usd REAL NOT NULL DEFAULT 0,
  lp_sol_added          REAL NOT NULL DEFAULT 0,
  migration_ts          INTEGER,
  detected_ts           INTEGER NOT NULL,
  priority_score        REAL NOT NULL DEFAULT 0,
  status                TEXT NOT NULL DEFAULT 'bonding' CHECK(status IN ('bonding','migrating','migrated','failed'))
);

CREATE INDEX IF NOT EXISTS idx_migrations_mint     ON migration_events(token_mint);
CREATE INDEX IF NOT EXISTS idx_migrations_status   ON migration_events(status);
CREATE INDEX IF NOT EXISTS idx_migrations_priority ON migration_events(priority_score DESC);
CREATE INDEX IF NOT EXISTS idx_migrations_ts       ON migration_events(detected_ts);

-- ─── MEV events ───────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS mev_events (
  id                    INTEGER PRIMARY KEY AUTOINCREMENT,
  tx_hash               TEXT NOT NULL DEFAULT '',
  event_type            TEXT NOT NULL CHECK(event_type IN ('sandwich','frontrun','failed_fill','retry_success','jito_bundle')),
  token_mint            TEXT,
  cost_sol              REAL NOT NULL DEFAULT 0,
  slippage_actual_bps   INTEGER NOT NULL DEFAULT 0,
  slippage_expected_bps INTEGER NOT NULL DEFAULT 0,
  bundle_id             TEXT,
  tip_lamports          INTEGER NOT NULL DEFAULT 0,
  detected_ts           INTEGER NOT NULL,
  resolved              INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_mev_events_type ON mev_events(event_type, detected_ts);
CREATE INDEX IF NOT EXISTS idx_mev_events_mint ON mev_events(token_mint);

-- ─── Exposure tracking ────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS exposure_snapshots (
  id                    INTEGER PRIMARY KEY AUTOINCREMENT,
  total_deployed_sol    REAL NOT NULL DEFAULT 0,
  total_positions       INTEGER NOT NULL DEFAULT 0,
  largest_position_sol  REAL NOT NULL DEFAULT 0,
  largest_position_mint TEXT NOT NULL DEFAULT '',
  daily_pnl_sol         REAL NOT NULL DEFAULT 0,
  drawdown_pct          REAL NOT NULL DEFAULT 0,
  consecutive_losses    INTEGER NOT NULL DEFAULT 0,
  kill_switch_active    INTEGER NOT NULL DEFAULT 0,
  ts                    INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_exposure_ts ON exposure_snapshots(ts DESC);

-- ─── Kill switch log ──────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS kill_switch_log (
  id                    INTEGER PRIMARY KEY AUTOINCREMENT,
  reason                TEXT NOT NULL,
  triggered_by          TEXT NOT NULL DEFAULT 'system',
  trigger_value         REAL,
  threshold             REAL,
  active                INTEGER NOT NULL DEFAULT 1,
  activated_at          INTEGER NOT NULL,
  deactivated_at        INTEGER
);

CREATE INDEX IF NOT EXISTS idx_kill_switch_active ON kill_switch_log(active, activated_at);

-- ─── Historical metrics (time-series for dashboard charts) ───────────────────

CREATE TABLE IF NOT EXISTS metrics_history (
  id                    INTEGER PRIMARY KEY AUTOINCREMENT,
  metric_name           TEXT NOT NULL,
  metric_value          REAL NOT NULL,
  tags                  TEXT,                       -- JSON key-value
  ts                    INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_metrics_name_ts ON metrics_history(metric_name, ts DESC);
CREATE INDEX IF NOT EXISTS idx_metrics_ts      ON metrics_history(ts);

-- ─── Cleanup old data (partial views) ────────────────────────────────────────

-- View: active clusters with >= 3 members
CREATE VIEW IF NOT EXISTS v_active_clusters AS
  SELECT c.*,
    (SELECT COUNT(*) FROM cluster_members m WHERE m.cluster_id = c.id) AS member_count
  FROM smart_money_clusters c
  WHERE c.status = 'active'
  ORDER BY c.confidence_score DESC;
