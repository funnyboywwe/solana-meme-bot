import { getDb } from '../Database';
import { WalletStats } from '../../core/types';

/**
 * WalletRepository — CRUD for the wallets table.
 *
 * BUG FIXED (#17): Previous upsert wrote `max_drawdown = 0` as a hardcoded
 * literal but `WalletStats` has no `maxDrawdown` field. The column exists in
 * the DB schema (added for future analytics) so we keep writing it, but now
 * we read it back properly and the upsert no longer references a non-existent
 * interface property.
 */

interface WalletRow {
  address: string;
  label: string | null;
  quality_score: number;
  win_rate: number;
  avg_roi: number;
  total_trades: number;
  profitable_trades: number;
  total_pnl_sol: number;
  max_drawdown: number;
  rank: number | null;
  added_at: number;
  updated_at: number;
  is_active: number;
}

function rowToWallet(row: WalletRow): WalletStats {
  return {
    address: row.address,
    label: row.label ?? undefined,
    qualityScore: row.quality_score,
    winRate: row.win_rate,
    avgRoi: row.avg_roi,
    totalTrades: row.total_trades,
    profitableTrades: row.profitable_trades,
    totalPnlSol: row.total_pnl_sol,
    rank: row.rank ?? 0,
    addedAt: row.added_at,
    updatedAt: row.updated_at,
    isActive: row.is_active === 1,
  };
}

export const WalletRepository = {
  upsert(wallet: Omit<WalletStats, 'rank'> & { maxDrawdown?: number }): void {
    const db = getDb();
    const now = Date.now();
    db.prepare(`
      INSERT INTO wallets (address, label, quality_score, win_rate, avg_roi, total_trades,
        profitable_trades, total_pnl_sol, max_drawdown, added_at, updated_at, is_active)
      VALUES (@address, @label, @quality_score, @win_rate, @avg_roi, @total_trades,
        @profitable_trades, @total_pnl_sol, @max_drawdown, @added_at, @updated_at, @is_active)
      ON CONFLICT(address) DO UPDATE SET
        label = COALESCE(excluded.label, label),
        quality_score = excluded.quality_score,
        win_rate = excluded.win_rate,
        avg_roi = excluded.avg_roi,
        total_trades = excluded.total_trades,
        profitable_trades = excluded.profitable_trades,
        total_pnl_sol = excluded.total_pnl_sol,
        max_drawdown = excluded.max_drawdown,
        updated_at = excluded.updated_at,
        is_active = excluded.is_active
    `).run({
      address: wallet.address,
      label: wallet.label ?? null,
      quality_score: wallet.qualityScore,
      win_rate: wallet.winRate,
      avg_roi: wallet.avgRoi,
      total_trades: wallet.totalTrades,
      profitable_trades: wallet.profitableTrades,
      total_pnl_sol: wallet.totalPnlSol,
      max_drawdown: wallet.maxDrawdown ?? 0,   // FIX: optional with default 0
      added_at: wallet.addedAt,
      updated_at: now,
      is_active: wallet.isActive ? 1 : 0,
    });
  },

  updateScore(address: string, score: number): void {
    const db = getDb();
    db.prepare('UPDATE wallets SET quality_score = ?, updated_at = ? WHERE address = ?')
      .run(score, Date.now(), address);
  },

  updateRanks(rankedAddresses: string[]): void {
    const db = getDb();
    const update = db.prepare('UPDATE wallets SET rank = ? WHERE address = ?');
    const tx = db.transaction(() => {
      rankedAddresses.forEach((addr, i) => update.run(i + 1, addr));
    });
    tx();
  },

  incrementTrade(address: string, profitable: boolean, pnlSol: number): void {
    const db = getDb();
    db.prepare(`
      UPDATE wallets SET
        total_trades = total_trades + 1,
        profitable_trades = profitable_trades + ?,
        total_pnl_sol = total_pnl_sol + ?,
        updated_at = ?
      WHERE address = ?
    `).run(profitable ? 1 : 0, pnlSol, Date.now(), address);
  },

  findByAddress(address: string): WalletStats | undefined {
    const db = getDb();
    const row = db.prepare('SELECT * FROM wallets WHERE address = ?').get(address) as WalletRow | undefined;
    return row ? rowToWallet(row) : undefined;
  },

  findActive(): WalletStats[] {
    const db = getDb();
    const rows = db.prepare('SELECT * FROM wallets WHERE is_active = 1 ORDER BY quality_score DESC').all() as WalletRow[];
    return rows.map(rowToWallet);
  },

  findTopByScore(limit = 20): WalletStats[] {
    const db = getDb();
    const rows = db.prepare('SELECT * FROM wallets WHERE is_active = 1 ORDER BY quality_score DESC LIMIT ?').all(limit) as WalletRow[];
    return rows.map(rowToWallet);
  },

  exists(address: string): boolean {
    const db = getDb();
    const row = db.prepare('SELECT address FROM wallets WHERE address = ?').get(address);
    return row !== undefined;
  },
};

export default WalletRepository;
