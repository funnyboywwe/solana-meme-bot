import { getDb } from '../Database';
import { SmartMoneyCluster, ClusterMember } from '../../core/types';
import { v4 as uuidv4 } from 'uuid';

interface ClusterRow {
  id: string;
  token_mint: string;
  wallet_addresses: string;
  wallet_count: number;
  avg_quality_score: number;
  avg_win_rate: number;
  avg_roi: number;
  total_capital_sol: number;
  confidence_score: number;
  first_entry_ts: number;
  last_entry_ts: number;
  window_ms: number;
  status: string;
  created_at: number;
  updated_at: number;
}

function rowToCluster(r: ClusterRow): SmartMoneyCluster {
  return {
    id: r.id,
    tokenMint: r.token_mint,
    walletAddresses: JSON.parse(r.wallet_addresses) as string[],
    walletCount: r.wallet_count,
    avgQualityScore: r.avg_quality_score,
    avgWinRate: r.avg_win_rate,
    avgRoi: r.avg_roi,
    totalCapitalSol: r.total_capital_sol,
    confidenceScore: r.confidence_score,
    firstEntryTs: r.first_entry_ts,
    lastEntryTs: r.last_entry_ts,
    windowMs: r.window_ms,
    status: r.status as SmartMoneyCluster['status'],
    createdAt: r.created_at,
    updatedAt: r.updated_at,
  };
}

export const ClusterRepository = {
  insert(cluster: Omit<SmartMoneyCluster, 'id'> & { id?: string }): SmartMoneyCluster {
    const db = getDb();
    const id = cluster.id ?? uuidv4();
    const now = Date.now();
    db.prepare(`
      INSERT INTO smart_money_clusters
        (id, token_mint, wallet_addresses, wallet_count, avg_quality_score, avg_win_rate,
         avg_roi, total_capital_sol, confidence_score, first_entry_ts, last_entry_ts,
         window_ms, status, created_at, updated_at)
      VALUES
        (@id, @token_mint, @wallet_addresses, @wallet_count, @avg_quality_score, @avg_win_rate,
         @avg_roi, @total_capital_sol, @confidence_score, @first_entry_ts, @last_entry_ts,
         @window_ms, @status, @created_at, @updated_at)
    `).run({
      id,
      token_mint: cluster.tokenMint,
      wallet_addresses: JSON.stringify(cluster.walletAddresses),
      wallet_count: cluster.walletCount,
      avg_quality_score: cluster.avgQualityScore,
      avg_win_rate: cluster.avgWinRate,
      avg_roi: cluster.avgRoi,
      total_capital_sol: cluster.totalCapitalSol,
      confidence_score: cluster.confidenceScore,
      first_entry_ts: cluster.firstEntryTs,
      last_entry_ts: cluster.lastEntryTs,
      window_ms: cluster.windowMs,
      status: cluster.status,
      created_at: now,
      updated_at: now,
    });
    return { ...cluster, id, createdAt: now, updatedAt: now } as SmartMoneyCluster;
  },

  update(id: string, updates: Partial<Pick<SmartMoneyCluster, 'walletAddresses' | 'walletCount' | 'avgQualityScore' | 'avgWinRate' | 'avgRoi' | 'totalCapitalSol' | 'confidenceScore' | 'lastEntryTs' | 'status'>>): void {
    const db = getDb();
    const sets: string[] = ['updated_at = @updated_at'];
    const params: Record<string, unknown> = { id, updated_at: Date.now() };

    if (updates.walletAddresses !== undefined) { sets.push('wallet_addresses = @wallet_addresses'); params['wallet_addresses'] = JSON.stringify(updates.walletAddresses); }
    if (updates.walletCount !== undefined) { sets.push('wallet_count = @wallet_count'); params['wallet_count'] = updates.walletCount; }
    if (updates.avgQualityScore !== undefined) { sets.push('avg_quality_score = @avg_quality_score'); params['avg_quality_score'] = updates.avgQualityScore; }
    if (updates.avgWinRate !== undefined) { sets.push('avg_win_rate = @avg_win_rate'); params['avg_win_rate'] = updates.avgWinRate; }
    if (updates.avgRoi !== undefined) { sets.push('avg_roi = @avg_roi'); params['avg_roi'] = updates.avgRoi; }
    if (updates.totalCapitalSol !== undefined) { sets.push('total_capital_sol = @total_capital_sol'); params['total_capital_sol'] = updates.totalCapitalSol; }
    if (updates.confidenceScore !== undefined) { sets.push('confidence_score = @confidence_score'); params['confidence_score'] = updates.confidenceScore; }
    if (updates.lastEntryTs !== undefined) { sets.push('last_entry_ts = @last_entry_ts'); params['last_entry_ts'] = updates.lastEntryTs; }
    if (updates.status !== undefined) { sets.push('status = @status'); params['status'] = updates.status; }

    db.prepare(`UPDATE smart_money_clusters SET ${sets.join(', ')} WHERE id = @id`).run(params);
  },

  addMember(member: ClusterMember): void {
    const db = getDb();
    db.prepare(`
      INSERT OR REPLACE INTO cluster_members
        (cluster_id, wallet_address, entry_ts, amount_sol, quality_score, win_rate, avg_roi)
      VALUES (@cluster_id, @wallet_address, @entry_ts, @amount_sol, @quality_score, @win_rate, @avg_roi)
    `).run({
      cluster_id: member.clusterId,
      wallet_address: member.walletAddress,
      entry_ts: member.entryTs,
      amount_sol: member.amountSol,
      quality_score: member.qualityScore,
      win_rate: member.winRate,
      avg_roi: member.avgRoi,
    });
  },

  findByToken(mint: string, status?: SmartMoneyCluster['status']): SmartMoneyCluster[] {
    const db = getDb();
    const q = status
      ? db.prepare('SELECT * FROM smart_money_clusters WHERE token_mint = @m AND status = @s ORDER BY confidence_score DESC')
          .all({ m: mint, s: status })
      : db.prepare('SELECT * FROM smart_money_clusters WHERE token_mint = @m ORDER BY confidence_score DESC')
          .all({ m: mint });
    return (q as ClusterRow[]).map(rowToCluster);
  },

  findActive(minConfidence = 0): SmartMoneyCluster[] {
    const db = getDb();
    const rows = db.prepare(`
      SELECT * FROM smart_money_clusters
      WHERE status = 'active' AND confidence_score >= @min
      ORDER BY confidence_score DESC LIMIT 50
    `).all({ min: minConfidence }) as ClusterRow[];
    return rows.map(rowToCluster);
  },

  expireOld(olderThanMs: number): number {
    const db = getDb();
    const cutoff = Date.now() - olderThanMs;
    const result = db.prepare(`
      UPDATE smart_money_clusters SET status = 'expired', updated_at = @now
      WHERE status = 'active' AND last_entry_ts < @cutoff
    `).run({ now: Date.now(), cutoff }) as { changes: number };
    return result.changes;
  },

  markExecuted(id: string): void {
    const db = getDb();
    db.prepare(`UPDATE smart_money_clusters SET status = 'executed', updated_at = @now WHERE id = @id`)
      .run({ id, now: Date.now() });
  },

  getMembers(clusterId: string): ClusterMember[] {
    const db = getDb();
    return (db.prepare('SELECT * FROM cluster_members WHERE cluster_id = @id').all({ id: clusterId }) as Array<{
      cluster_id: string; wallet_address: string; entry_ts: number; amount_sol: number;
      quality_score: number; win_rate: number; avg_roi: number;
    }>).map((r) => ({
      clusterId: r.cluster_id,
      walletAddress: r.wallet_address,
      entryTs: r.entry_ts,
      amountSol: r.amount_sol,
      qualityScore: r.quality_score,
      winRate: r.win_rate,
      avgRoi: r.avg_roi,
    }));
  },

  countActive(): number {
    const db = getDb();
    return (db.prepare("SELECT COUNT(*) as c FROM smart_money_clusters WHERE status = 'active'").get() as { c: number }).c;
  },
};

export default ClusterRepository;
