import { getDb } from '../Database';
import { Trade, TradeSide, TradeStatus, TradeStrategy } from '../../core/types';
import { createModuleLogger } from '../../core/Logger';

const logger = createModuleLogger('TradeRepository');

interface TradeRow {
  id: string;
  token_mint: string;
  wallet_address: string | null;
  strategy: string;
  side: string;
  amount_sol: number;
  amount_tokens: number;
  price_usd: number | null;
  tx_hash: string | null;
  status: string;
  momentum_score: number | null;
  wallet_score: number | null;
  entry_at: number | null;
  confirmed_at: number | null;
  fee_sol: number | null;
  slippage_pct: number | null;
}

function rowToTrade(row: TradeRow): Trade {
  return {
    id: row.id,
    tokenMint: row.token_mint,
    walletAddress: row.wallet_address ?? undefined,
    strategy: row.strategy as TradeStrategy,
    side: row.side as TradeSide,
    amountSol: row.amount_sol,
    amountTokens: row.amount_tokens,
    priceUsd: row.price_usd ?? undefined,
    txHash: row.tx_hash ?? undefined,
    status: row.status as TradeStatus,
    momentumScore: row.momentum_score ?? undefined,
    walletScore: row.wallet_score ?? undefined,
    entryAt: row.entry_at ?? undefined,
    confirmedAt: row.confirmed_at ?? undefined,
    feeSol: row.fee_sol ?? undefined,
    slippagePct: row.slippage_pct ?? undefined,
  };
}

export const TradeRepository = {
  insert(trade: Trade): void {
    const db = getDb();
    db.prepare(`
      INSERT INTO trades (id, token_mint, wallet_address, strategy, side, amount_sol, amount_tokens,
        price_usd, tx_hash, status, momentum_score, wallet_score, entry_at, confirmed_at, fee_sol, slippage_pct)
      VALUES (@id, @token_mint, @wallet_address, @strategy, @side, @amount_sol, @amount_tokens,
        @price_usd, @tx_hash, @status, @momentum_score, @wallet_score, @entry_at, @confirmed_at, @fee_sol, @slippage_pct)
    `).run({
      id: trade.id,
      token_mint: trade.tokenMint,
      wallet_address: trade.walletAddress ?? null,
      strategy: trade.strategy,
      side: trade.side,
      amount_sol: trade.amountSol,
      amount_tokens: trade.amountTokens,
      price_usd: trade.priceUsd ?? null,
      tx_hash: trade.txHash ?? null,
      status: trade.status,
      momentum_score: trade.momentumScore ?? null,
      wallet_score: trade.walletScore ?? null,
      entry_at: trade.entryAt ?? null,
      confirmed_at: trade.confirmedAt ?? null,
      fee_sol: trade.feeSol ?? null,
      slippage_pct: trade.slippagePct ?? null,
    });
  },

  updateStatus(id: string, status: TradeStatus, updates: Partial<Pick<Trade, 'txHash' | 'confirmedAt' | 'feeSol' | 'amountTokens' | 'priceUsd' | 'slippagePct'>> = {}): void {
    const db = getDb();
    db.prepare(`
      UPDATE trades SET
        status = @status,
        tx_hash = COALESCE(@tx_hash, tx_hash),
        confirmed_at = COALESCE(@confirmed_at, confirmed_at),
        fee_sol = COALESCE(@fee_sol, fee_sol),
        amount_tokens = COALESCE(@amount_tokens, amount_tokens),
        price_usd = COALESCE(@price_usd, price_usd),
        slippage_pct = COALESCE(@slippage_pct, slippage_pct)
      WHERE id = @id
    `).run({
      id,
      status,
      tx_hash: updates.txHash ?? null,
      confirmed_at: updates.confirmedAt ?? null,
      fee_sol: updates.feeSol ?? null,
      amount_tokens: updates.amountTokens ?? null,
      price_usd: updates.priceUsd ?? null,
      slippage_pct: updates.slippagePct ?? null,
    });
  },

  findById(id: string): Trade | undefined {
    const db = getDb();
    const row = db.prepare('SELECT * FROM trades WHERE id = ?').get(id) as TradeRow | undefined;
    return row ? rowToTrade(row) : undefined;
  },

  findByTxHash(txHash: string): Trade | undefined {
    const db = getDb();
    const row = db.prepare('SELECT * FROM trades WHERE tx_hash = ?').get(txHash) as TradeRow | undefined;
    return row ? rowToTrade(row) : undefined;
  },

  findPending(): Trade[] {
    const db = getDb();
    const rows = db.prepare("SELECT * FROM trades WHERE status = 'pending' ORDER BY entry_at ASC").all() as TradeRow[];
    return rows.map(rowToTrade);
  },

  findByToken(mint: string, limit = 50): Trade[] {
    const db = getDb();
    const rows = db.prepare('SELECT * FROM trades WHERE token_mint = ? ORDER BY entry_at DESC LIMIT ?').all(mint, limit) as TradeRow[];
    return rows.map(rowToTrade);
  },

  getRecentTrades(limitMs: number, limit = 100): Trade[] {
    const db = getDb();
    const since = Date.now() - limitMs;
    const rows = db.prepare('SELECT * FROM trades WHERE entry_at >= ? ORDER BY entry_at DESC LIMIT ?').all(since, limit) as TradeRow[];
    return rows.map(rowToTrade);
  },

  getTodayStats(): { tradeCount: number; confirmedCount: number; failedCount: number } {
    const db = getDb();
    const midnight = new Date();
    midnight.setHours(0, 0, 0, 0);
    const since = midnight.getTime();

    const row = db.prepare(`
      SELECT
        COUNT(*) as trade_count,
        SUM(CASE WHEN status = 'confirmed' THEN 1 ELSE 0 END) as confirmed_count,
        SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed_count
      FROM trades WHERE entry_at >= ?
    `).get(since) as { trade_count: number; confirmed_count: number; failed_count: number };

    return {
      tradeCount: row.trade_count ?? 0,
      confirmedCount: row.confirmed_count ?? 0,
      failedCount: row.failed_count ?? 0,
    };
  },
};

export default TradeRepository;
