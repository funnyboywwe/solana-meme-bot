import { getDb } from '../Database';
import { LiquiditySnapshot } from '../../core/types';

interface LiqSnapshotRow {
  id: number;
  token_mint: string;
  pool_address: string;
  liquidity_usd: number;
  tvl_usd: number;
  net_sol_inflow: number;
  lp_count: number;
  buy_pressure_pct: number;
  velocity_usd_per_min: number;
  signal: string;
  signal_strength: number;
  ts: number;
}

function rowToSnapshot(r: LiqSnapshotRow): LiquiditySnapshot {
  return {
    tokenMint: r.token_mint,
    poolAddress: r.pool_address,
    liquidityUsd: r.liquidity_usd,
    tvlUsd: r.tvl_usd,
    netSolInflow: r.net_sol_inflow,
    lpCount: r.lp_count,
    buyPressurePct: r.buy_pressure_pct,
    velocityUsdPerMin: r.velocity_usd_per_min,
    signal: r.signal as LiquiditySnapshot['signal'],
    signalStrength: r.signal_strength,
    ts: r.ts,
  };
}

export const LiquidityRepository = {
  insert(snap: LiquiditySnapshot): void {
    const db = getDb();
    db.prepare(`
      INSERT INTO liquidity_snapshots
        (token_mint, pool_address, liquidity_usd, tvl_usd, net_sol_inflow, lp_count,
         buy_pressure_pct, velocity_usd_per_min, signal, signal_strength, ts)
      VALUES (@token_mint, @pool_address, @liquidity_usd, @tvl_usd, @net_sol_inflow, @lp_count,
              @buy_pressure_pct, @velocity_usd_per_min, @signal, @signal_strength, @ts)
    `).run({
      token_mint: snap.tokenMint,
      pool_address: snap.poolAddress,
      liquidity_usd: snap.liquidityUsd,
      tvl_usd: snap.tvlUsd,
      net_sol_inflow: snap.netSolInflow,
      lp_count: snap.lpCount,
      buy_pressure_pct: snap.buyPressurePct,
      velocity_usd_per_min: snap.velocityUsdPerMin,
      signal: snap.signal,
      signal_strength: snap.signalStrength,
      ts: snap.ts,
    });
  },

  getLatest(mint: string): LiquiditySnapshot | undefined {
    const db = getDb();
    const row = db.prepare(`
      SELECT * FROM liquidity_snapshots WHERE token_mint = @m ORDER BY ts DESC LIMIT 1
    `).get({ m: mint }) as LiqSnapshotRow | undefined;
    return row ? rowToSnapshot(row) : undefined;
  },

  getHistory(mint: string, windowMs: number, limit = 20): LiquiditySnapshot[] {
    const db = getDb();
    const since = Date.now() - windowMs;
    const rows = db.prepare(`
      SELECT * FROM liquidity_snapshots WHERE token_mint = @m AND ts >= @s ORDER BY ts DESC LIMIT @l
    `).all({ m: mint, s: since, l: limit }) as LiqSnapshotRow[];
    return rows.map(rowToSnapshot);
  },

  /** Net inflow over a window — positive = bullish */
  getNetInflow(mint: string, windowMs: number): number {
    const db = getDb();
    const since = Date.now() - windowMs;
    const row = db.prepare(`
      SELECT COALESCE(SUM(net_sol_inflow), 0) as total
      FROM liquidity_snapshots WHERE token_mint = @m AND ts >= @s
    `).get({ m: mint, s: since }) as { total: number };
    return row.total;
  },

  getBullishTokens(minStrength = 60, limit = 20): string[] {
    const db = getDb();
    const since = Date.now() - 300000; // last 5 min
    const rows = db.prepare(`
      SELECT DISTINCT token_mint FROM liquidity_snapshots
      WHERE signal = 'bullish' AND signal_strength >= @s AND ts >= @t
      ORDER BY signal_strength DESC LIMIT @l
    `).all({ s: minStrength, t: since, l: limit }) as Array<{ token_mint: string }>;
    return rows.map((r) => r.token_mint);
  },

  pruneOld(retentionDays: number): number {
    const db = getDb();
    const cutoff = Date.now() - retentionDays * 86400000;
    const r = db.prepare('DELETE FROM liquidity_snapshots WHERE ts < @c').run({ c: cutoff }) as { changes: number };
    return r.changes;
  },
};

export default LiquidityRepository;
