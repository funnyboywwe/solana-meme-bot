import { LRUCache } from 'lru-cache';
import { getDb } from '../Database';
import { TokenInfo } from '../../core/types';
import { createModuleLogger } from '../../core/Logger';

const logger = createModuleLogger('TokenRepository');

// Cache up to 500 tokens in memory
const cache = new LRUCache<string, TokenInfo>({ max: 500 });

interface TokenRow {
  mint: string;
  symbol: string | null;
  decimals: number;
  created_at: number;
  mcap_usd: number | null;
  liquidity_usd: number | null;
  pool_address: string | null;
  source: string;
  rug_score: number | null;
  mint_auth_disabled: number;
  freeze_auth_disabled: number;
  holder_concentration: number | null;
  is_honeypot: number;
  lp_locked: number | null;
  lp_locked_pct: number | null;
  safety_checked_at: number | null;
  updated_at: number;
}

function rowToToken(row: TokenRow): TokenInfo {
  return {
    mint: row.mint,
    symbol: row.symbol ?? '',
    decimals: row.decimals,
    createdAt: row.created_at,
    mcapUsd: row.mcap_usd ?? 0,
    liquidityUsd: row.liquidity_usd ?? 0,
    poolAddress: row.pool_address ?? '',
    source: row.source as TokenInfo['source'],
  };
}

export const TokenRepository = {
  upsert(token: TokenInfo): void {
    const db = getDb();
    const now = Date.now();
    db.prepare(`
      INSERT INTO tokens (mint, symbol, decimals, created_at, mcap_usd, liquidity_usd, pool_address, source, updated_at)
      VALUES (@mint, @symbol, @decimals, @created_at, @mcap_usd, @liquidity_usd, @pool_address, @source, @updated_at)
      ON CONFLICT(mint) DO UPDATE SET
        symbol = excluded.symbol,
        mcap_usd = excluded.mcap_usd,
        liquidity_usd = excluded.liquidity_usd,
        updated_at = excluded.updated_at
    `).run({
      mint: token.mint,
      symbol: token.symbol,
      decimals: token.decimals,
      created_at: token.createdAt,
      mcap_usd: token.mcapUsd,
      liquidity_usd: token.liquidityUsd,
      pool_address: token.poolAddress,
      source: token.source,
      updated_at: now,
    });
    cache.set(token.mint, token);
  },

  updateLiquidity(mint: string, liquidityUsd: number): void {
    const db = getDb();
    db.prepare(`
      UPDATE tokens SET liquidity_usd = ?, updated_at = ? WHERE mint = ?
    `).run(liquidityUsd, Date.now(), mint);
    const cached = cache.get(mint);
    if (cached) cache.set(mint, { ...cached, liquidityUsd });
  },

  updateSafety(mint: string, report: {
    rugScore: number;
    mintDisabled: boolean;
    freezeDisabled: boolean;
    holderConcentration: number;
    isHoneypot: boolean;
    lpLocked?: boolean;
    lpLockedPct?: number;
  }): void {
    const db = getDb();
    db.prepare(`
      UPDATE tokens SET
        rug_score = ?,
        mint_auth_disabled = ?,
        freeze_auth_disabled = ?,
        holder_concentration = ?,
        is_honeypot = ?,
        lp_locked = ?,
        lp_locked_pct = ?,
        safety_checked_at = ?,
        updated_at = ?
      WHERE mint = ?
    `).run(
      report.rugScore,
      report.mintDisabled ? 1 : 0,
      report.freezeDisabled ? 1 : 0,
      report.holderConcentration,
      report.isHoneypot ? 1 : 0,
      report.lpLocked === undefined ? null : report.lpLocked ? 1 : 0,
      report.lpLockedPct ?? null,
      Date.now(),
      Date.now(),
      mint,
    );
    cache.delete(mint);
  },

  /**
   * Read persisted safety fields for a mint. Returns null when the token has
   * not been safety-checked yet (rug_score is null).
   */
  getSafety(mint: string): {
    rugScore: number;
    mintDisabled: boolean;
    freezeDisabled: boolean;
    holderConcentration: number | null;
    isHoneypot: boolean;
    lpLocked: boolean | null;
    lpLockedPct: number | null;
    checkedAt: number | null;
  } | null {
    const db = getDb();
    const row = db.prepare(
      'SELECT rug_score, mint_auth_disabled, freeze_auth_disabled, holder_concentration, is_honeypot, lp_locked, lp_locked_pct, safety_checked_at FROM tokens WHERE mint = ?',
    ).get(mint) as
      | {
          rug_score: number | null;
          mint_auth_disabled: number;
          freeze_auth_disabled: number;
          holder_concentration: number | null;
          is_honeypot: number;
          lp_locked: number | null;
          lp_locked_pct: number | null;
          safety_checked_at: number | null;
        }
      | undefined;
    if (!row || row.rug_score === null) return null;
    return {
      rugScore: row.rug_score,
      mintDisabled: row.mint_auth_disabled === 1,
      freezeDisabled: row.freeze_auth_disabled === 1,
      holderConcentration: row.holder_concentration,
      isHoneypot: row.is_honeypot === 1,
      lpLocked: row.lp_locked === null ? null : row.lp_locked === 1,
      lpLockedPct: row.lp_locked_pct,
      checkedAt: row.safety_checked_at,
    };
  },

  findByMint(mint: string): TokenInfo | undefined {
    const cached = cache.get(mint);
    if (cached) return cached;

    const db = getDb();
    const row = db.prepare('SELECT * FROM tokens WHERE mint = ?').get(mint) as TokenRow | undefined;
    if (!row) return undefined;
    const token = rowToToken(row);
    cache.set(mint, token);
    return token;
  },

  exists(mint: string): boolean {
    if (cache.has(mint)) return true;
    const db = getDb();
    const row = db.prepare('SELECT mint FROM tokens WHERE mint = ?').get(mint);
    return row !== undefined;
  },

  getRecentTokens(limitMs: number, maxCount: number): TokenInfo[] {
    const db = getDb();
    const since = Date.now() - limitMs;
    const rows = db.prepare(`
      SELECT * FROM tokens WHERE created_at >= ? ORDER BY created_at DESC LIMIT ?
    `).all(since, maxCount) as TokenRow[];
    return rows.map(rowToToken);
  },

  updateMcap(mint: string, mcapUsd: number): void {
    const db = getDb();
    db.prepare('UPDATE tokens SET mcap_usd = ?, updated_at = ? WHERE mint = ?')
      .run(mcapUsd, Date.now(), mint);
    const cached = cache.get(mint);
    if (cached) cache.set(mint, { ...cached, mcapUsd });
  },
};

export default TokenRepository;
