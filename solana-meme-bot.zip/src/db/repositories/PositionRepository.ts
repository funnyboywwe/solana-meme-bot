import { getDb, runInTransaction } from '../Database';
import { Position, ClosedPosition, PositionStatus } from '../../core/types';

interface PositionRow {
  id: string;
  token_mint: string;
  entry_trade_id: string | null;
  strategy: string;
  size_sol: number;
  size_tokens: number | null;
  entry_price_usd: number;
  current_price_usd: number;
  unrealised_pnl_sol: number;
  stop_loss_pct: number;
  take_profit_pct: number;
  trailing_stop_pct: number;
  trailing_stop_high_usd: number;
  opened_at: number;
  updated_at: number;
  status: string;
}

interface ClosedPositionRow {
  id: string;
  token_mint: string | null;
  strategy: string | null;
  size_sol: number | null;
  entry_price_usd: number | null;
  exit_price_usd: number | null;
  realised_pnl_sol: number | null;
  hold_time_secs: number | null;
  exit_reason: string | null;
  opened_at: number | null;
  closed_at: number;
}

function rowToPosition(row: PositionRow): Position {
  return {
    id: row.id,
    tokenMint: row.token_mint,
    entryTradeId: row.entry_trade_id ?? '',
    strategy: row.strategy as Position['strategy'],
    sizeSol: row.size_sol,
    sizeTokens: row.size_tokens ?? 0,
    entryPriceUsd: row.entry_price_usd,
    currentPriceUsd: row.current_price_usd,
    unrealisedPnlSol: row.unrealised_pnl_sol,
    stopLossPct: row.stop_loss_pct,
    takeProfitPct: row.take_profit_pct,
    trailingStopPct: row.trailing_stop_pct,
    trailingStopHighUsd: row.trailing_stop_high_usd,
    openedAt: row.opened_at,
    updatedAt: row.updated_at,
    status: row.status as PositionStatus,
  };
}

export const PositionRepository = {
  open(position: Position): void {
    const db = getDb();
    db.prepare(`
      INSERT INTO positions (id, token_mint, entry_trade_id, strategy, size_sol, size_tokens, entry_price_usd,
        current_price_usd, unrealised_pnl_sol, stop_loss_pct, take_profit_pct, trailing_stop_pct,
        trailing_stop_high_usd, opened_at, updated_at, status)
      VALUES (@id, @token_mint, @entry_trade_id, @strategy, @size_sol, @size_tokens, @entry_price_usd,
        @current_price_usd, @unrealised_pnl_sol, @stop_loss_pct, @take_profit_pct, @trailing_stop_pct,
        @trailing_stop_high_usd, @opened_at, @updated_at, @status)
    `).run({
      id: position.id,
      token_mint: position.tokenMint,
      entry_trade_id: position.entryTradeId || null,
      strategy: position.strategy,
      size_sol: position.sizeSol,
      size_tokens: position.sizeTokens ?? 0,
      entry_price_usd: position.entryPriceUsd,
      current_price_usd: position.currentPriceUsd,
      unrealised_pnl_sol: position.unrealisedPnlSol,
      stop_loss_pct: position.stopLossPct,
      take_profit_pct: position.takeProfitPct,
      trailing_stop_pct: position.trailingStopPct,
      trailing_stop_high_usd: position.trailingStopHighUsd,
      opened_at: position.openedAt,
      updated_at: position.updatedAt,
      status: position.status,
    });
  },

  updatePrice(id: string, currentPriceUsd: number, unrealisedPnlSol: number, trailingHighUsd?: number): void {
    const db = getDb();
    db.prepare(`
      UPDATE positions SET
        current_price_usd = ?,
        unrealised_pnl_sol = ?,
        trailing_stop_high_usd = CASE WHEN ? > trailing_stop_high_usd THEN ? ELSE trailing_stop_high_usd END,
        updated_at = ?
      WHERE id = ?
    `).run(currentPriceUsd, unrealisedPnlSol, trailingHighUsd ?? 0, trailingHighUsd ?? 0, Date.now(), id);
  },

  close(id: string, closedPosition: ClosedPosition): void {
    runInTransaction((db) => {
      db.prepare("UPDATE positions SET status = 'closed', updated_at = ? WHERE id = ?")
        .run(Date.now(), id);
      db.prepare(`
        INSERT INTO closed_positions (id, token_mint, strategy, size_sol, entry_price_usd, exit_price_usd,
          realised_pnl_sol, hold_time_secs, exit_reason, opened_at, closed_at)
        VALUES (@id, @token_mint, @strategy, @size_sol, @entry_price_usd, @exit_price_usd,
          @realised_pnl_sol, @hold_time_secs, @exit_reason, @opened_at, @closed_at)
      `).run({
        id: closedPosition.id,
        token_mint: closedPosition.tokenMint,
        strategy: closedPosition.strategy,
        size_sol: closedPosition.sizeSol,
        entry_price_usd: closedPosition.entryPriceUsd,
        exit_price_usd: closedPosition.exitPriceUsd,
        realised_pnl_sol: closedPosition.realisedPnlSol,
        hold_time_secs: closedPosition.holdTimeSecs,
        exit_reason: closedPosition.exitReason,
        opened_at: closedPosition.openedAt,
        closed_at: closedPosition.closedAt,
      });
    });
  },

  findOpenPositions(): Position[] {
    const db = getDb();
    const rows = db.prepare("SELECT * FROM positions WHERE status = 'open'").all() as PositionRow[];
    return rows.map(rowToPosition);
  },

  findById(id: string): Position | undefined {
    const db = getDb();
    const row = db.prepare('SELECT * FROM positions WHERE id = ?').get(id) as PositionRow | undefined;
    return row ? rowToPosition(row) : undefined;
  },

  findByToken(mint: string): Position | undefined {
    const db = getDb();
    const row = db.prepare("SELECT * FROM positions WHERE token_mint = ? AND status = 'open' LIMIT 1").get(mint) as PositionRow | undefined;
    return row ? rowToPosition(row) : undefined;
  },

  countOpen(): number {
    const db = getDb();
    const row = db.prepare("SELECT COUNT(*) as cnt FROM positions WHERE status = 'open'").get() as { cnt: number };
    return row.cnt;
  },

  getClosedPositions(limit = 100): ClosedPosition[] {
    const db = getDb();
    const rows = db.prepare('SELECT * FROM closed_positions ORDER BY closed_at DESC LIMIT ?').all(limit) as ClosedPositionRow[];
    return rows.map((r) => ({
      id: r.id,
      tokenMint: r.token_mint ?? '',
      strategy: r.strategy ?? '',
      sizeSol: r.size_sol ?? 0,
      entryPriceUsd: r.entry_price_usd ?? 0,
      exitPriceUsd: r.exit_price_usd ?? 0,
      realisedPnlSol: r.realised_pnl_sol ?? 0,
      holdTimeSecs: r.hold_time_secs ?? 0,
      exitReason: (r.exit_reason ?? 'manual') as ClosedPosition['exitReason'],
      openedAt: r.opened_at ?? 0,
      closedAt: r.closed_at,
    }));
  },

  getTodayRealisedPnl(): number {
    const db = getDb();
    const midnight = new Date();
    midnight.setHours(0, 0, 0, 0);
    const row = db.prepare(`
      SELECT COALESCE(SUM(realised_pnl_sol), 0) as total FROM closed_positions WHERE closed_at >= ?
    `).get(midnight.getTime()) as { total: number };
    return row.total;
  },
};

export default PositionRepository;
