import { getDb } from '../Database';
import { MigrationEvent } from '../../core/types';
import { v4 as uuidv4 } from 'uuid';

interface MigrationRow {
  id: string;
  token_mint: string;
  pump_pool_address: string;
  raydium_pool_address: string;
  bonding_curve_pct: number;
  completed: number;
  raydium_migrated: number;
  initial_liquidity_sol: number;
  initial_liquidity_usd: number;
  lp_sol_added: number;
  migration_ts: number | null;
  detected_ts: number;
  priority_score: number;
  status: string;
}

function rowToEvent(r: MigrationRow): MigrationEvent {
  return {
    id: r.id,
    tokenMint: r.token_mint,
    pumpPoolAddress: r.pump_pool_address,
    raydiumPoolAddress: r.raydium_pool_address,
    bondingCurvePct: r.bonding_curve_pct,
    completed: r.completed === 1,
    raydiumMigrated: r.raydium_migrated === 1,
    initialLiquiditySol: r.initial_liquidity_sol,
    initialLiquidityUsd: r.initial_liquidity_usd,
    lpSolAdded: r.lp_sol_added,
    migrationTs: r.migration_ts ?? undefined,
    detectedTs: r.detected_ts,
    priorityScore: r.priority_score,
    status: r.status as MigrationEvent['status'],
  };
}

export const MigrationRepository = {
  upsert(event: Omit<MigrationEvent, 'id'> & { id?: string }): MigrationEvent {
    const db = getDb();
    const id = event.id ?? uuidv4();
    db.prepare(`
      INSERT INTO migration_events
        (id, token_mint, pump_pool_address, raydium_pool_address, bonding_curve_pct,
         completed, raydium_migrated, initial_liquidity_sol, initial_liquidity_usd,
         lp_sol_added, migration_ts, detected_ts, priority_score, status)
      VALUES
        (@id, @token_mint, @pump_pool_address, @raydium_pool_address, @bonding_curve_pct,
         @completed, @raydium_migrated, @initial_liquidity_sol, @initial_liquidity_usd,
         @lp_sol_added, @migration_ts, @detected_ts, @priority_score, @status)
      ON CONFLICT(id) DO UPDATE SET
        bonding_curve_pct = excluded.bonding_curve_pct,
        completed = excluded.completed,
        raydium_migrated = excluded.raydium_migrated,
        raydium_pool_address = excluded.raydium_pool_address,
        lp_sol_added = excluded.lp_sol_added,
        migration_ts = excluded.migration_ts,
        priority_score = excluded.priority_score,
        status = excluded.status
    `).run({
      id,
      token_mint: event.tokenMint,
      pump_pool_address: event.pumpPoolAddress,
      raydium_pool_address: event.raydiumPoolAddress,
      bonding_curve_pct: event.bondingCurvePct,
      completed: event.completed ? 1 : 0,
      raydium_migrated: event.raydiumMigrated ? 1 : 0,
      initial_liquidity_sol: event.initialLiquiditySol,
      initial_liquidity_usd: event.initialLiquidityUsd,
      lp_sol_added: event.lpSolAdded,
      migration_ts: event.migrationTs ?? null,
      detected_ts: event.detectedTs,
      priority_score: event.priorityScore,
      status: event.status,
    });
    return { ...event, id } as MigrationEvent;
  },

  findByToken(mint: string): MigrationEvent | undefined {
    const db = getDb();
    const row = db.prepare('SELECT * FROM migration_events WHERE token_mint = @m ORDER BY detected_ts DESC LIMIT 1')
      .get({ m: mint }) as MigrationRow | undefined;
    return row ? rowToEvent(row) : undefined;
  },

  findRecent(status?: MigrationEvent['status'], limit = 20): MigrationEvent[] {
    const db = getDb();
    const rows = status
      ? db.prepare('SELECT * FROM migration_events WHERE status = @s ORDER BY priority_score DESC, detected_ts DESC LIMIT @l').all({ s: status, l: limit })
      : db.prepare('SELECT * FROM migration_events ORDER BY priority_score DESC, detected_ts DESC LIMIT @l').all({ l: limit });
    return (rows as MigrationRow[]).map(rowToEvent);
  },

  exists(mint: string): boolean {
    const db = getDb();
    return !!db.prepare('SELECT id FROM migration_events WHERE token_mint = @m').get({ m: mint });
  },
};

export default MigrationRepository;
