import { EventBus, EntryApprovedEvent, OrderReadyEvent } from '../core/EventBus';
import { AppConfig } from '../config/AppConfig';
import { createModuleLogger } from '../core/Logger';
import PositionRepository from '../db/repositories/PositionRepository';
import { PendingPositions } from './exposure/PendingPositions';
import { getPositionSizer } from './PositionSizer';
import { CircuitBreaker } from './CircuitBreaker';
import { CooldownTracker } from './CooldownTracker';
import type { ExposureManager } from './exposure/ExposureManager';
import type { DynamicPositionSizingEngine } from './DynamicPositionSizingEngine';
import type { PositionScoreInput } from '../core/types';

const logger = createModuleLogger('RiskManager');

/**
 * RiskManager gates trade execution through 4 sequential checks.
 *
 * BUG FIXED (#16): Uses getPositionSizer() singleton instead of
 * creating a new PositionSizer (and therefore a new Connection +
 * Keypair decode) on construction.
 */
export class RiskManager {
  private circuitBreaker: CircuitBreaker;
  private cooldownTracker: CooldownTracker;
  private maxConcurrentPositions: number;
  private maxSlippageBps: number;
  private fixedPositionSizeSol: number;
  private cfg: AppConfig;
  private exposureManager: ExposureManager | null = null;
  private dynamicSizer: DynamicPositionSizingEngine | null = null;

  constructor(cfg: AppConfig) {
    this.cfg = cfg;
    this.circuitBreaker = new CircuitBreaker(cfg);
    this.cooldownTracker = new CooldownTracker(cfg);
    this.maxConcurrentPositions = cfg.risk.maxConcurrentPositions;
    this.maxSlippageBps = cfg.execution.maxSlippageBps;
    this.fixedPositionSizeSol = cfg.risk.fixedPositionSizeSol ?? 0;

    // FIX: initialise singleton here so it is created exactly once
    getPositionSizer(cfg);

    logger.info('RiskManager initialized', {
      maxConcurrentPositions: this.maxConcurrentPositions,
      maxDailyLossSol: cfg.risk.maxDailyLossSol,
    });
  }

  /**
   * Wire in portfolio-level exposure controls and the dynamic position sizing
   * engine. These are constructed after RiskManager in bootstrap, so they are
   * injected here rather than via the constructor.
   */
  wireRisk(opts: { exposureManager?: ExposureManager; dynamicSizer?: DynamicPositionSizingEngine }): void {
    this.exposureManager = opts.exposureManager ?? null;
    this.dynamicSizer = opts.dynamicSizer ?? null;
    logger.info('RiskManager wired', {
      exposure: !!this.exposureManager,
      dynamicSizing: !!this.dynamicSizer,
    });
  }

  async evaluate(event: EntryApprovedEvent): Promise<void> {
    const { mint, strategy } = event;

    // 1. Circuit breaker
    if (this.circuitBreaker.isBroken()) {
      logger.info('Circuit breaker active — trade rejected', { mint, reason: this.circuitBreaker.getBreakReason() });
      return;
    }

    // 2. Atomic slot reservation (CONCURRENCY FIX).
    // ENTRY_APPROVED handlers run concurrently and the position row only lands
    // in the DB AFTER the buy confirms (seconds later). Without a synchronous
    // reservation taken BEFORE any `await`, several approvals all observe the
    // same open-position count and fire simultaneous buys, blowing past
    // maxConcurrentPositions (observed: 2-3 trades in one burst). Everything
    // from here to PendingPositions.reserve() is synchronous, so concurrent
    // evaluations serialise on it: the first claims the slot, the rest bail.
    const openCount = PositionRepository.countOpen();
    if (PositionRepository.findByToken(mint) || PendingPositions.has(mint)) {
      logger.info('Already holding or buying this token — trade rejected', { mint });
      return;
    }
    if (openCount + PendingPositions.size() >= this.maxConcurrentPositions) {
      logger.info('Max concurrent positions reached (incl. in-flight) — trade rejected', {
        mint, openCount, inFlight: PendingPositions.size(), limit: this.maxConcurrentPositions,
      });
      return;
    }
    PendingPositions.reserve(mint);

    let committed = false;
    try {
      // 3. Token cooldown
      if (this.cooldownTracker.isInCooldown(mint)) {
        logger.debug('Token in cooldown — trade rejected', {
          mint,
          remainingMs: this.cooldownTracker.remainingCooldownMs(mint),
        });
        return;
      }

      // 4. Position size — base sizing from the singleton sizer
      const sizer = getPositionSizer(); // use singleton, no cfg needed
      let sizeSol = await sizer.calculateSize(event);

      // 4b. Multi-factor dynamic sizing (if wired)
      if (this.dynamicSizer) {
        try {
          const scores: PositionScoreInput = {
            momentumScore: event.momentumScore ?? 50,
            smartMoneyScore: 50,
            liquidityScore: 50,
            riskScore: 50,
            walletConfidenceScore: event.walletScore ?? 0,
            accelerationScore: 0,
            holderGrowthScore: 0,
          };
          const dyn = await this.dynamicSizer.computeSize(scores);
          if (dyn.sizeSol > 0) sizeSol = dyn.sizeSol;
        } catch (err) {
          logger.warn('Dynamic sizing failed — falling back to base size', { mint, error: String(err) });
        }
      }

      // LIVE TEST OVERRIDE: when risk.fixedPositionSizeSol > 0, force every order
      // to this exact tiny SOL amount regardless of balance/percentage sizing.
      if (this.fixedPositionSizeSol > 0) {
        sizeSol = this.fixedPositionSizeSol;
        logger.info('Fixed position size override applied', { mint, sizeSol: sizeSol.toFixed(4) });
      }

      if (sizeSol <= 0) {
        logger.warn('Position size zero — trade rejected', { mint });
        return;
      }

      // 4c. Portfolio exposure limits (if wired)
      if (this.exposureManager) {
        const check = await this.exposureManager.checkEntry(mint, sizeSol);
        if (!check.allowed) {
          logger.info('Exposure limit — trade rejected', { mint, reason: check.reason });
          return;
        }
        sizeSol = await this.exposureManager.capSize(mint, sizeSol);
        if (sizeSol <= 0) {
          logger.warn('Exposure capped size to zero — trade rejected', { mint });
          return;
        }
      }

      logger.info('Risk checks passed → ORDER_READY', { mint, strategy, sizeSol: sizeSol.toFixed(4) });

      // Hand the reserved slot to execution. ExecutionEngine releases the
      // reservation in its finally block (fill, fail, or timeout); a confirmed
      // position then occupies the slot via PositionRepository.
      committed = true;
      EventBus.emit('ORDER_READY', {
        mint,
        strategy,
        sizeSol,
        maxSlippageBps: this.maxSlippageBps,
        ts: Date.now(),
      } as OrderReadyEvent);
    } catch (err) {
      logger.error('Risk evaluation error', { error: String(err) });
    } finally {
      // If we did not hand the slot to execution, free it immediately.
      if (!committed) PendingPositions.release(mint);
    }
  }

  getCooldownTracker(): CooldownTracker {
    return this.cooldownTracker;
  }

  getCircuitBreaker(): CircuitBreaker {
    return this.circuitBreaker;
  }
}

export default RiskManager;
