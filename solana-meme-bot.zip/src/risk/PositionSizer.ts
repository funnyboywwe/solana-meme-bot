import { Connection, Keypair, LAMPORTS_PER_SOL } from '@solana/web3.js';
import bs58 from 'bs58';
import { AppConfig } from '../config/AppConfig';
import { createModuleLogger } from '../core/Logger';
import { EntryApprovedEvent } from '../core/EventBus';

const logger = createModuleLogger('PositionSizer');

/**
 * PositionSizer computes order size and manages the bot keypair.
 *
 * BUG FIXED (#16): PositionSizer was instantiated independently in BOTH
 * RiskManager AND ExecutionEngine, creating two Connections and two
 * Keypair objects from the same private key — doubling RAM usage.
 *
 * FIX: PositionSizer is now a singleton (module-level instance created
 * once). Both RiskManager and ExecutionEngine call getPositionSizer()
 * which returns the shared instance. The Connection is also shared.
 */
let _instance: PositionSizer | null = null;

export class PositionSizer {
  private connection: Connection;
  private keypair: Keypair;
  private positionSizePct: number;
  private readonly minSizeSol = 0.01;

  constructor(cfg: AppConfig) {
    this.connection = new Connection(cfg.rpc.rpcHttpUrl, cfg.rpc.commitment);
    const secretKey = bs58.decode(cfg.wallet.privateKey);
    this.keypair = Keypair.fromSecretKey(secretKey);
    this.positionSizePct = cfg.wallet.maxBalancePctPerTrade;

    logger.info('PositionSizer initialized', {
      wallet: this.keypair.publicKey.toBase58(),
      positionSizePct: this.positionSizePct,
    });
  }

  async calculateSize(event: EntryApprovedEvent): Promise<number> {
    try {
      const lamports = await this.connection.getBalance(this.keypair.publicKey);
      const balanceSol = lamports / LAMPORTS_PER_SOL;

      if (balanceSol < this.minSizeSol * 2) {
        logger.warn('Wallet balance too low for trade', { balanceSol });
        return 0;
      }

      const rawSize = balanceSol * this.positionSizePct;
      // Keep at least 10% of balance for fees and gas
      const maxAllowable = balanceSol * 0.9;
      const sizeSol = Math.min(rawSize, maxAllowable);

      logger.debug('Position size calculated', {
        balanceSol: balanceSol.toFixed(4),
        sizeSol: sizeSol.toFixed(4),
        strategy: event.strategy,
      });

      return Math.max(sizeSol, 0);
    } catch (err) {
      logger.error('Failed to calculate position size', { error: String(err) });
      return 0;
    }
  }

  getWalletPublicKey(): string {
    return this.keypair.publicKey.toBase58();
  }

  getKeypair(): Keypair {
    return this.keypair;
  }

  getConnection(): Connection {
    return this.connection;
  }
}

/** Singleton factory — call this instead of new PositionSizer() */
export function getPositionSizer(cfg?: AppConfig): PositionSizer {
  if (!_instance) {
    if (!cfg) throw new Error('PositionSizer not yet initialized — pass cfg on first call');
    _instance = new PositionSizer(cfg);
  }
  return _instance;
}

export default PositionSizer;
