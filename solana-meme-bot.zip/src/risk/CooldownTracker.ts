import { AppConfig } from '../config/AppConfig';
import { createModuleLogger } from '../core/Logger';

const logger = createModuleLogger('CooldownTracker');

/**
 * CooldownTracker enforces:
 * 1. Per-token cooldown: after exiting a token, don't re-enter for N minutes
 * 2. Per-wallet cooldown: after copying a wallet, pause before copying again
 *
 * All stored in-memory (LRU would be overkill for a few hundred entries)
 */
export class CooldownTracker {
  private tokenCooldowns = new Map<string, number>(); // mint → expiry timestamp
  private walletCooldowns = new Map<string, number>(); // wallet → expiry timestamp
  private tokenCooldownMs: number;
  private walletCooldownMs: number;

  constructor(cfg: AppConfig) {
    this.tokenCooldownMs = cfg.risk.tokenCooldownMins * 60 * 1000;
    this.walletCooldownMs = cfg.risk.walletCooldownMins * 60 * 1000;

    // Prune expired entries every 10 minutes
    const pruner = setInterval(() => this._prune(), 600000);
    pruner.unref();

    logger.info('CooldownTracker initialized', {
      tokenCooldownMins: cfg.risk.tokenCooldownMins,
      walletCooldownMins: cfg.risk.walletCooldownMins,
    });
  }

  /**
   * Start cooldown for a token (call after position close)
   */
  startTokenCooldown(mint: string): void {
    const expiry = Date.now() + this.tokenCooldownMs;
    this.tokenCooldowns.set(mint, expiry);
    logger.debug('Token cooldown started', {
      mint,
      expiresIn: `${this.tokenCooldownMs / 60000}m`,
    });
  }

  /**
   * Start cooldown for a wallet (call after copy trade)
   */
  startWalletCooldown(walletAddress: string): void {
    const expiry = Date.now() + this.walletCooldownMs;
    this.walletCooldowns.set(walletAddress, expiry);
    logger.debug('Wallet cooldown started', {
      wallet: walletAddress,
      expiresIn: `${this.walletCooldownMs / 60000}m`,
    });
  }

  /**
   * Check if token is in cooldown
   */
  isInCooldown(mint: string): boolean {
    const expiry = this.tokenCooldowns.get(mint);
    if (!expiry) return false;
    if (Date.now() >= expiry) {
      this.tokenCooldowns.delete(mint);
      return false;
    }
    return true;
  }

  /**
   * Check if wallet is in cooldown
   */
  isWalletInCooldown(walletAddress: string): boolean {
    const expiry = this.walletCooldowns.get(walletAddress);
    if (!expiry) return false;
    if (Date.now() >= expiry) {
      this.walletCooldowns.delete(walletAddress);
      return false;
    }
    return true;
  }

  /**
   * Remaining cooldown in milliseconds for a token (0 if none)
   */
  remainingCooldownMs(mint: string): number {
    const expiry = this.tokenCooldowns.get(mint);
    if (!expiry) return 0;
    return Math.max(0, expiry - Date.now());
  }

  private _prune(): void {
    const now = Date.now();
    for (const [key, expiry] of this.tokenCooldowns) {
      if (expiry <= now) this.tokenCooldowns.delete(key);
    }
    for (const [key, expiry] of this.walletCooldowns) {
      if (expiry <= now) this.walletCooldowns.delete(key);
    }
  }
}

export default CooldownTracker;
