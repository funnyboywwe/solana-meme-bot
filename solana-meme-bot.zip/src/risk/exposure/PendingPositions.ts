/**
 * PendingPositions — synchronous, in-memory reservation registry.
 *
 * WHY: ENTRY_APPROVED → ORDER_READY → buy → (confirm) → PositionRepository.open
 * is asynchronous, and the position row only appears in the DB AFTER the buy
 * confirms (seconds later). The EventBus delivers ENTRY_APPROVED handlers
 * concurrently, so without a guard several approvals all read the same
 * open-position count (0), all pass the maxConcurrentPositions check, and fire
 * simultaneous buys — opening 2-3 positions when the limit is 1.
 *
 * This registry lets RiskManager claim a slot SYNCHRONOUSLY (before any await)
 * the instant it decides to proceed. Concurrent evaluations serialise on it:
 * the first claims the slot, the rest see it and back off. ExecutionEngine
 * releases the reservation when the trade reaches a terminal state (filled,
 * failed, or timed out); a confirmed position then occupies the slot via the
 * DB. A time-based prune frees any reservation orphaned by an unexpected crash.
 */

const reservations = new Map<string, number>(); // mint -> reservedAt (ms)

// Safety net: drop reservations older than this in case a release is ever
// missed (e.g. process killed mid-buy). Generous enough to outlast buy retries
// + confirmation timeouts, short enough to self-heal.
let pruneMs = 180_000;

function prune(): void {
  const now = Date.now();
  for (const [mint, ts] of reservations) {
    if (now - ts > pruneMs) reservations.delete(mint);
  }
}

export const PendingPositions = {
  /** Optionally tune the orphan-prune window (ms). */
  configure(opts: { pruneMs?: number }): void {
    if (opts.pruneMs && opts.pruneMs > 0) pruneMs = opts.pruneMs;
  },

  /** Number of in-flight (reserved-but-not-yet-open) positions. */
  size(): number {
    prune();
    return reservations.size;
  },

  /** True if a buy for this mint is already in flight. */
  has(mint: string): boolean {
    prune();
    return reservations.has(mint);
  },

  /** Claim a slot for this mint. Caller must have checked capacity first. */
  reserve(mint: string): void {
    reservations.set(mint, Date.now());
  },

  /** Release a slot once the trade reaches a terminal state. Idempotent. */
  release(mint: string): void {
    reservations.delete(mint);
  },

  /** Clear all reservations (test/shutdown helper). */
  clear(): void {
    reservations.clear();
  },
};

export default PendingPositions;
