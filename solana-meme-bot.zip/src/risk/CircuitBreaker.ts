import { AppConfig } from '../config/AppConfig';
import { createModuleLogger } from '../core/Logger';
import PositionRepository from '../db/repositories/PositionRepository';
import { getDb } from '../db/Database';

const logger = createModuleLogger('CircuitBreaker');

/**
 * CircuitBreaker halts all trading when:
 * 1. Daily realised PnL drops below maxDailyLossSol
 * 2. Session drawdown exceeds circuitBreakerDrawdownPct
 *
 * Resets at UTC midnight for (1), manual reset for (2)
 */
export class CircuitBreaker {
  private maxDailyLossSol: number;
  private circuitBreakerDrawdownPct: number;
  private broken = false;
  private breakReason = '';
  private sessionHighSol = 0;
  private lastDateStr = '';

  constructor(cfg: AppConfig) {
    this.maxDailyLossSol = cfg.risk.maxDailyLossSol;
    this.circuitBreakerDrawdownPct = cfg.risk.circuitBreakerDrawdownPct;
    this._initDailyState();
  }

  private _initDailyState(): void {
    const today = this._todayStr();
    const db = getDb();
    const row = db
      .prepare('SELECT * FROM daily_risk_state WHERE date = ?')
      .get(today) as { circuit_broken: number } | undefined;

    if (row) {
      this.broken = row.circuit_broken === 1;
    } else {
      db.prepare(`
        INSERT OR IGNORE INTO daily_risk_state (date, starting_balance_sol, realised_pnl_sol, trade_count, circuit_broken, max_drawdown)
        VALUES (?, 0, 0, 0, 0, 0)
      `).run(today);
    }

    if (this.broken) {
      logger.warn('Circuit breaker already tripped for today, trading halted');
    }
  }

  /**
   * Update daily PnL and check if circuit should trip
   */
  update(realisedPnlSolDelta: number, currentBalanceSol: number): void {
    this._maybeResetDay();

    // Track session high
    if (currentBalanceSol > this.sessionHighSol) {
      this.sessionHighSol = currentBalanceSol;
    }

    // Check daily loss
    const todayPnl = PositionRepository.getTodayRealisedPnl();
    if (todayPnl <= -Math.abs(this.maxDailyLossSol)) {
      this._trip(`Daily loss limit reached: ${todayPnl.toFixed(4)} SOL`);
      return;
    }

    // Check drawdown from session high
    if (this.sessionHighSol > 0) {
      const drawdown = (this.sessionHighSol - currentBalanceSol) / this.sessionHighSol;
      if (drawdown >= this.circuitBreakerDrawdownPct) {
        this._trip(`Drawdown limit reached: ${(drawdown * 100).toFixed(1)}%`);
        return;
      }
    }
  }

  private _trip(reason: string): void {
    if (this.broken) return;
    this.broken = true;
    this.breakReason = reason;

    const today = this._todayStr();
    const db = getDb();
    db.prepare('UPDATE daily_risk_state SET circuit_broken = 1 WHERE date = ?').run(today);

    logger.warn('CIRCUIT BREAKER TRIPPED', { reason });
  }

  isBroken(): boolean {
    this._maybeResetDay();
    return this.broken;
  }

  getBreakReason(): string {
    return this.breakReason;
  }

  /**
   * Manual reset — use with caution
   */
  reset(): void {
    this.broken = false;
    this.breakReason = '';
    const today = this._todayStr();
    getDb()
      .prepare('UPDATE daily_risk_state SET circuit_broken = 0 WHERE date = ?')
      .run(today);
    logger.info('Circuit breaker manually reset');
  }

  private _maybeResetDay(): void {
    const today = this._todayStr();
    if (today !== this.lastDateStr) {
      this.lastDateStr = today;
      this.broken = false;
      this.breakReason = '';
      this.sessionHighSol = 0;
      this._initDailyState();
      logger.info('CircuitBreaker daily reset', { date: today });
    }
  }

  private _todayStr(): string {
    return new Date().toISOString().slice(0, 10);
  }
}

export default CircuitBreaker;
