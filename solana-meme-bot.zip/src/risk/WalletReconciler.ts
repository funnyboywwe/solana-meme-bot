import { PublicKey } from '@solana/web3.js';
import { AppConfig } from '../config/AppConfig';
import { createModuleLogger } from '../core/Logger';
import { ReadRpcProvider } from '../core/ReadRpcProvider';
import { getPositionSizer } from './PositionSizer';
import PositionRepository from '../db/repositories/PositionRepository';
import { Position } from '../core/types';

const logger = createModuleLogger('WalletReconciler');

/**
 * On startup the positions table can contain rows still marked `open` that no
 * longer exist on-chain — most commonly because the operator sold the tokens
 * manually outside the bot. Those ghost positions:
 *   - permanently consume open-position slots (ExposureManager counts them), so
 *     the bot stops opening any new trades, and
 *   - trigger endless failing sell attempts when StopLoss fires on them.
 *
 * WalletReconciler compares each open DB position against the actual SPL token
 * balance in the trading wallet and closes (exit_reason 'manual') any position
 * whose on-chain balance is effectively zero. A failed balance lookup is left
 * untouched so a transient RPC error can never wrongly abandon a real position.
 */
export class WalletReconciler {
  private readRpc: ReadRpcProvider;

  constructor(cfg: AppConfig) {
    this.readRpc = new ReadRpcProvider(cfg);
  }

  async reconcileOpenPositions(): Promise<void> {
    const open = PositionRepository.findOpenPositions();
    if (open.length === 0) {
      logger.info('Wallet reconciliation: no open positions to check');
      return;
    }

    const owner = getPositionSizer().getKeypair().publicKey;
    let closed = 0;

    for (const position of open) {
      const balance = await this._getTokenBalance(owner, position.tokenMint);
      // balance < 0 means the lookup failed — skip rather than wrongly abandon.
      if (balance < 0) continue;
      if (balance === 0) {
        this._closeGhost(position);
        closed++;
      }
    }

    logger.info('Wallet reconciliation complete', {
      checked: open.length,
      closedGhostPositions: closed,
      stillOpen: open.length - closed,
    });
  }

  private async _getTokenBalance(owner: PublicKey, mint: string): Promise<number> {
    try {
      const res = await this.readRpc.getParsedTokenAccountsByOwner(owner, {
        mint: new PublicKey(mint),
      });
      let total = 0;
      for (const acc of res.value) {
        const ui = (acc.account.data as any)?.parsed?.info?.tokenAmount?.uiAmount;
        if (typeof ui === 'number') total += ui;
      }
      return total;
    } catch (err) {
      logger.warn('Token balance lookup failed during reconciliation', {
        mint,
        error: err instanceof Error ? err.message : String(err),
      });
      return -1;
    }
  }

  private _closeGhost(position: Position): void {
    const now = Date.now();
    const holdTimeSecs = Math.max(0, Math.floor((now - position.openedAt) / 1000));
    logger.warn('Closing ghost position (0 on-chain balance — likely sold manually)', {
      positionId: position.id,
      mint: position.tokenMint,
      sizeSol: position.sizeSol,
    });
    try {
      PositionRepository.close(position.id, {
        id: position.id,
        tokenMint: position.tokenMint,
        strategy: position.strategy,
        sizeSol: position.sizeSol,
        entryPriceUsd: position.entryPriceUsd,
        exitPriceUsd: position.currentPriceUsd,
        realisedPnlSol: 0,
        holdTimeSecs,
        exitReason: 'manual',
        openedAt: position.openedAt,
        closedAt: now,
      });
    } catch (err) {
      logger.error('Failed to close ghost position', {
        positionId: position.id,
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }
}

export default WalletReconciler;
