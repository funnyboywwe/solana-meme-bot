import axios from 'axios';
import { AppConfig } from '../config/AppConfig';
import { ExtendedConfig } from '../config/schema';
import { createModuleLogger } from '../core/Logger';
import { EventBus, KillSwitchEvent } from '../core/EventBus';
import { getDb } from '../db/Database';

const logger = createModuleLogger('GlobalKillSwitch');

export type KillReason =
  | 'daily_drawdown'
  | 'consecutive_losses'
  | 'rpc_instability'
  | 'liquidity_collapse'
  | 'manual';

/**
 * GlobalKillSwitch halts all trading when dangerous conditions are detected.
 *
 * Triggers:
 *   daily_drawdown       — daily P&L drops below threshold
 *   consecutive_losses   — N losses in a row
 *   rpc_instability      — RPC error rate exceeds threshold
 *   liquidity_collapse   — token liquidity drops > 50% suddenly
 *   manual               — operator calls kill() directly
 *
 * After activation:
 *   - All isActive() checks return true → no new trades
 *   - Alert sent to webhook (if configured)
 *   - Logged to kill_switch_log table
 *   - Auto-reset after cooldownMs (optional)
 */
export class GlobalKillSwitch {
  private cfg: ExtendedConfig['killSwitch'];
  private active = false;
  private activeReason: KillReason | null = null;
  private activatedAt: number | null = null;
  private cooldownMs: number;
  private rpcCallCount = 0;
  private rpcErrorCount = 0;
  private rpcWindowStart = Date.now();
  private readonly RPC_WINDOW_MS = 60000; // 1 minute window for error rate

  constructor(_baseCfg: AppConfig, extCfg: ExtendedConfig) {
    this.cfg = extCfg.killSwitch;
    this.cooldownMs = extCfg.exposure.cooldownAfterKillSwitchMs;

    logger.info('GlobalKillSwitch initialized', {
      enabled: this.cfg.enabled,
      triggers: this.cfg.triggers,
    });
  }

  /** Check if trading should be halted */
  isActive(): boolean {
    if (!this.cfg.enabled) return false;
    if (!this.active) return false;

    // Auto-reset after cooldown
    if (this.activatedAt && Date.now() - this.activatedAt > this.cooldownMs) {
      this._reset('Cooldown period elapsed');
    }

    return this.active;
  }

  /** Evaluate current metrics and trip if thresholds breached */
  evaluate(metrics: {
    dailyDrawdownPct?: number;
    consecutiveLosses?: number;
    liquidityDropPct?: number;
  }): void {
    if (!this.cfg.enabled) return;
    if (this.active) return; // already tripped

    const t = this.cfg.triggers;

    if (metrics.dailyDrawdownPct !== undefined && metrics.dailyDrawdownPct >= t.dailyDrawdownPct) {
      this.trip('daily_drawdown', metrics.dailyDrawdownPct, t.dailyDrawdownPct);
      return;
    }

    if (metrics.consecutiveLosses !== undefined && metrics.consecutiveLosses >= t.consecutiveLosses) {
      this.trip('consecutive_losses', metrics.consecutiveLosses, t.consecutiveLosses);
      return;
    }

    if (metrics.liquidityDropPct !== undefined && metrics.liquidityDropPct >= t.liquidityCollapseThreshold) {
      this.trip('liquidity_collapse', metrics.liquidityDropPct, t.liquidityCollapseThreshold);
      return;
    }
  }

  /** Record an RPC call result and trip if error rate is too high */
  recordRPCCall(success: boolean): void {
    const now = Date.now();

    // Reset window if expired
    if (now - this.rpcWindowStart > this.RPC_WINDOW_MS) {
      this.rpcCallCount = 0;
      this.rpcErrorCount = 0;
      this.rpcWindowStart = now;
    }

    this.rpcCallCount++;
    if (!success) this.rpcErrorCount++;

    if (this.rpcCallCount >= 10) {
      const errorRate = this.rpcErrorCount / this.rpcCallCount;
      if (errorRate >= this.cfg.triggers.rpcErrorRateThreshold) {
        this.trip('rpc_instability', errorRate, this.cfg.triggers.rpcErrorRateThreshold);
      }
    }
  }

  /** Manually activate the kill switch */
  kill(reason = 'Manual operator halt'): void {
    this.trip('manual', 1, 0, reason);
  }

  /** Manually reset the kill switch */
  reset(reason = 'Manual operator reset'): void {
    this._reset(reason);
  }

  private trip(reason: KillReason, triggerValue: number, threshold: number, message?: string): void {
    this.active = true;
    this.activeReason = reason;
    this.activatedAt = Date.now();

    const msg = message ?? `${reason}: value=${triggerValue.toFixed(3)} threshold=${threshold.toFixed(3)}`;
    logger.warn('KILL SWITCH ACTIVATED', { reason, triggerValue, threshold, message: msg });

    this._persist(reason, triggerValue, threshold);

    EventBus.emit('KILL_SWITCH', {
      active: true,
      reason: msg,
      triggerValue,
      threshold,
      ts: Date.now(),
    } as KillSwitchEvent);

    if (this.cfg.alertOnActivation && this.cfg.alertWebhook) {
      void this._sendAlert(`🚨 Bot Kill Switch ACTIVATED\nReason: ${msg}\nTime: ${new Date().toISOString()}`);
    }
  }

  private _reset(reason: string): void {
    if (!this.active) return;
    this.active = false;
    this.activeReason = null;
    this.rpcCallCount = 0;
    this.rpcErrorCount = 0;

    // Update DB record
    try {
      getDb().prepare(`
        UPDATE kill_switch_log SET active = 0, deactivated_at = @now
        WHERE active = 1
      `).run({ now: Date.now() });
    } catch { /* non-critical */ }

    logger.info('Kill switch deactivated', { reason });

    EventBus.emit('KILL_SWITCH', { active: false, reason, ts: Date.now() } as KillSwitchEvent);

    if (this.cfg.alertOnDeactivation && this.cfg.alertWebhook) {
      void this._sendAlert(`✅ Bot Kill Switch DEACTIVATED\nReason: ${reason}\nTime: ${new Date().toISOString()}`);
    }
  }

  private _persist(reason: string, triggerValue: number, threshold: number): void {
    try {
      getDb().prepare(`
        INSERT INTO kill_switch_log (reason, triggered_by, trigger_value, threshold, active, activated_at)
        VALUES (@reason, @triggered_by, @trigger_value, @threshold, 1, @activated_at)
      `).run({
        reason,
        triggered_by: 'system',
        trigger_value: triggerValue,
        threshold,
        activated_at: Date.now(),
      });
    } catch { /* non-critical */ }
  }

  private async _sendAlert(message: string): Promise<void> {
    if (!this.cfg.alertWebhook) return;
    try {
      await axios.post(this.cfg.alertWebhook, { text: message, content: message }, { timeout: 5000 });
      logger.info('Kill switch alert sent');
    } catch (err) {
      logger.warn('Failed to send kill switch alert', { error: String(err) });
    }
  }

  getStatus(): { active: boolean; reason: KillReason | null; activatedAt: number | null } {
    return { active: this.active, reason: this.activeReason, activatedAt: this.activatedAt };
  }
}

export default GlobalKillSwitch;
