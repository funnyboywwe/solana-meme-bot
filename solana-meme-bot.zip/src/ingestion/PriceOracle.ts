import axios from 'axios';
import { EventBus } from '../core/EventBus';
import { createModuleLogger } from '../core/Logger';
import { AppConfig } from '../config/AppConfig';
import { setSolPriceUsd } from '../core/SolPrice';

const WSOL_MINT = 'So11111111111111111111111111111111111111112';

const logger = createModuleLogger('PriceOracle');

// Jupiter Price API V3 returns a FLAT map keyed by mint (no `data` wrapper).
// Each entry exposes `usdPrice` (number). Some mints may be missing/undefined.
type JupiterPriceV3Response = Record<
  string,
  { usdPrice: number; blockId?: number; decimals?: number; priceChange24h?: number } | undefined
>;

/**
 * PriceOracle polls Jupiter Price API v6 every 5 seconds.
 *
 * BUG FIXED (#5 / PriceOracle): Jupiter's price endpoint is on a
 * completely different host: https://price.jup.ag/v6/price
 * NOT on quote-api.jup.ag which only handles quote/swap.
 *
 * Old (broken): `${jupiterApiUrl}/price`  → 404
 * New (correct): `https://price.jup.ag/v6/price`
 */
const JUPITER_PRICE_URL = 'https://lite-api.jup.ag/price/v3';
const BATCH_SIZE = 100; // Jupiter price API max IDs per request

// DexScreener price fallback. Jupiter does NOT index many fresh / migrated /
// dumping pump.fun tokens and returns no price for them, which left open
// positions un-priced so StopLossManager never evaluated SL/TP. DexScreener's
// tokens endpoint returns live USD price + liquidity for up to 30 addresses per
// request (rate-limit 300/min); we only ever query the mints Jupiter missed.
const DEXSCREENER_TOKENS_URL = 'https://api.dexscreener.com/tokens/v1/solana';
const DEXSCREENER_BATCH_SIZE = 30;

// Minimal DexScreener pair shape (only the fields the price fallback consumes).
interface DexScreenerPair {
  baseToken?: { address?: string };
  priceUsd?: string;
  liquidity?: { usd?: number };
}

export class PriceOracle {
  private pollInterval: NodeJS.Timeout | null = null;
  private trackedMints = new Set<string>();
  private readonly maxTrackedMints = 250;
  private readonly pollIntervalMs = 5000;
  // In-memory price cache — accessed by other components synchronously
  private priceCache = new Map<string, number>();

  constructor(_cfg: AppConfig) {
    // Always track WSOL so the shared SOL/USD price stays fresh.
    this.trackedMints.add(WSOL_MINT);
  }

  trackToken(mint: string): void {
    this.trackedMints.add(mint);
    // LIVE TEST: candidate tokens are now tracked too, so bound the set to avoid
    // unbounded growth. Evict the oldest non-WSOL mint when over the cap.
    if (this.trackedMints.size > this.maxTrackedMints) {
      for (const m of this.trackedMints) {
        if (m !== WSOL_MINT) { this.trackedMints.delete(m); break; }
      }
    }
  }

  untrackToken(mint: string): void {
    this.trackedMints.delete(mint);
    this.priceCache.delete(mint);
  }

  getCachedPrice(mint: string): number {
    return this.priceCache.get(mint) ?? 0;
  }

  start(): void {
    if (this.pollInterval) return;
    logger.info('PriceOracle starting', { endpoint: JUPITER_PRICE_URL });
    void this._poll();
    this.pollInterval = setInterval(() => void this._poll(), this.pollIntervalMs);
    this.pollInterval.unref();
  }

  stop(): void {
    if (this.pollInterval) {
      clearInterval(this.pollInterval);
      this.pollInterval = null;
    }
    logger.info('PriceOracle stopped');
  }

  private async _poll(): Promise<void> {
    if (this.trackedMints.size === 0) return;

    const mints = Array.from(this.trackedMints);

    // 1. Primary source: Jupiter Price API (batch max 100 IDs).
    const pricedMints = new Set<string>();
    for (let i = 0; i < mints.length; i += BATCH_SIZE) {
      const batch = mints.slice(i, i + BATCH_SIZE);
      await this._fetchBatch(batch, pricedMints);
    }

    // 2. Fallback source: DexScreener for any tracked mint Jupiter did not
    //    price. This is what lets stop-loss / take-profit keep firing on tokens
    //    Jupiter doesn't index (observed previously as tracked=9, priced=8 — the
    //    missing token was an open position the bot had gone blind to).
    const unpriced = mints.filter((m) => m !== WSOL_MINT && !pricedMints.has(m));
    let fallbackPriced = 0;
    if (unpriced.length > 0) {
      fallbackPriced = await this._fetchBatchDexScreener(unpriced);
    }

    logger.info('PriceOracle poll complete', {
      tracked: this.trackedMints.size,
      priced: pricedMints.size,
      fallbackPriced,
      unpriced: unpriced.length,
    });
  }

  private async _fetchBatch(mints: string[], pricedMints: Set<string>): Promise<void> {
    try {
      const ids = mints.join(',');
      const response = await axios.get<JupiterPriceV3Response>(JUPITER_PRICE_URL, {
        params: { ids },
        timeout: 5000,
      });

      const data = response.data ?? {};

      for (const mint of mints) {
        const entry = data[mint];
        if (!entry) continue;

        const priceUsd = typeof entry.usdPrice === 'number'
          ? entry.usdPrice
          : parseFloat(String(entry.usdPrice));
        if (!(priceUsd > 0)) continue;

        // Keep the shared SOL price fresh; don't emit PRICE_UPDATE for WSOL.
        if (mint === WSOL_MINT) {
          setSolPriceUsd(priceUsd);
          pricedMints.add(mint);
          continue;
        }

        this.priceCache.set(mint, priceUsd);
        EventBus.emit('PRICE_UPDATE', {
          mint,
          priceUsd,
          liquidityUsd: 0,
          ts: Date.now(),
        });
        pricedMints.add(mint);
      }
    } catch (err) {
      logger.warn('PriceOracle batch fetch failed', { error: String(err) });
    }
  }

  /**
   * DexScreener price fallback for mints Jupiter does not index.
   *
   * GET https://api.dexscreener.com/tokens/v1/solana/{addrs}
   *   - up to 30 comma-separated addresses per request
   *   - rate-limit 300 req/min (we poll every 5s and only query the gap)
   * Returns an array of pairs; we keep the most-liquid pair per base mint and
   * emit PRICE_UPDATE with its USD price + liquidity so SL/TP can evaluate.
   */
  private async _fetchBatchDexScreener(mints: string[]): Promise<number> {
    let emitted = 0;
    for (let i = 0; i < mints.length; i += DEXSCREENER_BATCH_SIZE) {
      const batch = mints.slice(i, i + DEXSCREENER_BATCH_SIZE);
      try {
        const url = `${DEXSCREENER_TOKENS_URL}/${batch.join(',')}`;
        const response = await axios.get<DexScreenerPair[]>(url, { timeout: 5000 });
        const pairs = Array.isArray(response.data) ? response.data : [];

        // Keep the most-liquid pair per base mint.
        const bestByMint = new Map<string, { priceUsd: number; liquidityUsd: number }>();
        for (const p of pairs) {
          const mint = p?.baseToken?.address;
          if (!mint) continue;
          const priceUsd = parseFloat(String(p?.priceUsd ?? ''));
          if (!(priceUsd > 0)) continue;
          const liquidityUsd = p?.liquidity?.usd ?? 0;
          const current = bestByMint.get(mint);
          if (!current || liquidityUsd > current.liquidityUsd) {
            bestByMint.set(mint, { priceUsd, liquidityUsd });
          }
        }

        for (const [mint, info] of bestByMint) {
          if (mint === WSOL_MINT) {
            setSolPriceUsd(info.priceUsd);
            continue;
          }
          this.priceCache.set(mint, info.priceUsd);
          EventBus.emit('PRICE_UPDATE', {
            mint,
            priceUsd: info.priceUsd,
            liquidityUsd: info.liquidityUsd,
            ts: Date.now(),
          });
          emitted++;
        }
      } catch (err) {
        logger.warn('PriceOracle DexScreener fallback failed', { error: String(err) });
      }
    }
    return emitted;
  }

  getTrackedCount(): number {
    return this.trackedMints.size;
  }
}

export default PriceOracle;
