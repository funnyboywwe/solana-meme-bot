import { BaseWebSocketClient } from './BaseWebSocketClient';
import { EventBus, TokenCreatedEvent, PoolUpdateEvent } from '../core/EventBus';
import { createModuleLogger } from '../core/Logger';
import { AppConfig } from '../config/AppConfig';
import axios from 'axios';

const logger = createModuleLogger('RaydiumMonitor');

// The Raydium V2 API (api.mainnet.raydium.io/v2/main/pairs) has been
// decommissioned — its hostname no longer resolves (getaddrinfo ENOTFOUND).
// The current API is V3 at api-v3.raydium.io. The pool-list endpoint returns a
// paginated, enveloped response and exposes `tvl` (USD liquidity) directly, so
// we no longer need to derive liquidity from reserves * SOL price.
const RAYDIUM_POOLS_URL = 'https://api-v3.raydium.io/pools/info/list';
const WSOL = 'So11111111111111111111111111111111111111112';
const MIN_LIQUIDITY_USD = 5000;

interface V3Mint {
  address: string;
  symbol?: string;
  name?: string;
  decimals: number;
}

interface V3Pool {
  type: string;
  programId: string;
  id: string;
  mintA: V3Mint;
  mintB: V3Mint;
  price: number;
  mintAmountA: number;
  mintAmountB: number;
  feeRate: number;
  openTime: string;
  tvl: number;
  lpMint?: { address: string; decimals: number };
}

interface V3PoolListResponse {
  id: string;
  success: boolean;
  data: {
    count: number;
    data: V3Pool[];
    hasNextPage: boolean;
  };
}

/**
 * RaydiumMonitor polls the Raydium V3 pool-list API every 10 seconds.
 *
 * MIGRATION (Pass 14): switched from the dead V2 endpoint
 * (https://api.mainnet.raydium.io/v2/main/pairs) to the V3 endpoint
 * (https://api-v3.raydium.io/pools/info/list). V3 is paginated, wraps results
 * in a { success, data: { data: [...] } } envelope, and provides `tvl`
 * directly. Mint metadata (symbol/decimals) now comes from mintA/mintB objects.
 */
export class RaydiumMonitor extends BaseWebSocketClient {
  private pollTimer: NodeJS.Timeout | null = null;
  private seenPoolIds = new Set<string>();
  private liquidityCache = new Map<string, number>();
  private firstPoll = true;
  private maxTokenAgeMs: number;

  constructor(cfg: AppConfig) {
    super('wss://api-v3.raydium.io/ws', 'RaydiumMonitor');
    this.maxTokenAgeMs = cfg.filters.maxTokenAgeMs;
  }

  override async connect(): Promise<void> {
    logger.info('RaydiumMonitor starting (REST polling, V3 API)');
    this.connected = true;
    EventBus.emit('WS_STATUS', { client: 'RaydiumMonitor', status: 'connected', ts: Date.now() });
    await this._poll(); // immediate first poll
    this.pollTimer = setInterval(() => void this._poll(), 10000);
    this.pollTimer.unref();
  }

  private async _poll(): Promise<void> {
    try {
      const response = await axios.get<V3PoolListResponse>(RAYDIUM_POOLS_URL, {
        timeout: 15000,
        params: {
          poolType: 'standard',
          poolSortField: 'volume24h',
          sortType: 'desc',
          pageSize: 1000,
          page: 1,
        },
      });

      const body = response.data;
      if (!body?.success || !Array.isArray(body.data?.data)) {
        logger.warn('Raydium poll: unexpected response shape');
        return;
      }
      const pools = body.data.data;

      for (const pool of pools) {
        const aIsWsol = pool.mintA?.address === WSOL;
        const bIsWsol = pool.mintB?.address === WSOL;
        // Only track SOL-paired pools
        if (!aIsWsol && !bIsWsol) continue;

        const tokenMint = aIsWsol ? pool.mintB : pool.mintA;
        const mint = tokenMint?.address;
        if (!mint) continue;

        const liquidityUsd = pool.tvl ?? 0; // V3 provides TVL directly
        if (liquidityUsd < MIN_LIQUIDITY_USD) continue; // skip dust pools

        // REAL on-chain pool open time. Raydium V3 `openTime` is a unix SECONDS
        // string. This is the AUTHORITATIVE token/pool age. The pool list is
        // sorted by volume24h, so it is dominated by OLD, established pools;
        // previously we stamped createdAt = Date.now() on first sight, so a
        // year-old token looked brand new and could be bought. We now compute
        // the true age and only treat sufficiently fresh pools as new launches.
        const openTimeSec = Number(pool.openTime);
        const poolOpenedMs =
          Number.isFinite(openTimeSec) && openTimeSec > 0 ? openTimeSec * 1000 : 0;
        // Unknown/zero openTime => treat as old (Infinity age) and skip.
        const poolAgeMs = poolOpenedMs > 0 ? Date.now() - poolOpenedMs : Infinity;
        const isFreshLaunch = poolAgeMs <= this.maxTokenAgeMs;

        if (!this.seenPoolIds.has(pool.id)) {
          this.seenPoolIds.add(pool.id);
          this.liquidityCache.set(pool.id, liquidityUsd);

          // On the very first poll every existing pool looks "new". Seed the
          // seen-set silently instead of emitting a flood of TOKEN_CREATED
          // events for pools that already existed.
          if (this.firstPoll) continue;

          // Only act on brand-new launches; ignore aged pools entirely so the
          // bot never buys old tokens that merely have high 24h volume.
          if (!isFreshLaunch) {
            logger.debug('Skipping aged Raydium pool', { poolId: pool.id, mint, poolAgeMs });
            continue;
          }

          logger.info('New Raydium pool detected', { poolId: pool.id, mint, poolAgeMs });

          EventBus.emit('TOKEN_CREATED', {
            mint,
            symbol: tokenMint.symbol ?? 'UNK',
            decimals: tokenMint.decimals ?? 9,
            initialLiquidityUsd: liquidityUsd,
            poolAddress: pool.id,
            // Use the REAL pool open time so every downstream age check is accurate.
            createdAt: poolOpenedMs > 0 ? poolOpenedMs : Date.now(),
            source: 'raydium',
          } as TokenCreatedEvent);
        } else {
          // Check for significant liquidity change
          const prev = this.liquidityCache.get(pool.id) ?? liquidityUsd;
          const delta = liquidityUsd - prev;

          if (Math.abs(delta) > MIN_LIQUIDITY_USD) {
            this.liquidityCache.set(pool.id, liquidityUsd);
            EventBus.emit('POOL_UPDATE', {
              poolAddress: pool.id,
              mint,
              liquidityUsd,
              liquidityDeltaUsd: delta,
              ts: Date.now(),
            } as PoolUpdateEvent);
          }
        }
      }
      this.firstPoll = false;
    } catch (err) {
      logger.warn('Raydium poll failed', { error: String(err) });
    }
  }

  protected onMessage(_message: unknown): void {}
  protected resubscribe(_key: string, _state: unknown): void {}

  override disconnect(): void {
    if (this.pollTimer) {
      clearInterval(this.pollTimer);
      this.pollTimer = null;
    }
    this.connected = false;
    logger.info('RaydiumMonitor disconnected');
  }
}

export default RaydiumMonitor;
