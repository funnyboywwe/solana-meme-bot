import WebSocket from 'ws';
import { EventBus } from '../core/EventBus';
import { createModuleLogger } from '../core/Logger';

const logger = createModuleLogger('BaseWebSocketClient');

export interface SubscriptionState {
  [key: string]: unknown;
}

/**
 * BaseWebSocketClient manages:
 * - Auto-reconnect with exponential backoff (1s → 60s) + jitter
 * - Ping/pong heartbeat (20s interval, 45s stale timeout)
 * - Message ring buffer (2000 capacity, drop oldest on overflow)
 * - Subscription state snapshot (restore after reconnect)
 * - Intentional-disconnect guard (no reconnect on explicit .disconnect())
 *
 * BUG FIXED: Added _intentionalClose flag so disconnect() does NOT
 * trigger the reconnect loop that _onClose() previously started.
 */
export abstract class BaseWebSocketClient {
  protected ws: WebSocket | null = null;
  protected connected = false;
  protected subscriptions: SubscriptionState = {};

  private heartbeatInterval: NodeJS.Timeout | null = null;
  private lastPongAt = Date.now();
  private reconnectAttempt = 0;
  private readonly maxReconnectAttempts = 10;
  private readonly baseDelayMs = 1000;
  private readonly maxDelayMs = 60000;
  private ringBuffer: unknown[] = [];
  private readonly RING_BUFFER_SIZE = 2000;
  private draining = false;
  // FIX: guard against reconnecting after intentional disconnect
  private _intentionalClose = false;

  constructor(
    protected wsUrl: string,
    protected name: string,
  ) {}

  /**
   * Connect with manual exponential backoff retry loop
   * (replaces p-retry which is ESM-only in v6)
   */
  async connect(): Promise<void> {
    this._intentionalClose = false;
    for (let attempt = 1; attempt <= this.maxReconnectAttempts; attempt++) {
      try {
        await this._connect();
        return; // success
      } catch (err) {
        if (this._intentionalClose) return;
        if (attempt >= this.maxReconnectAttempts) {
          logger.error(`${this.name} failed after ${attempt} attempts`, { error: String(err) });
          throw err;
        }
        const delay = Math.min(this.baseDelayMs * Math.pow(1.5, attempt - 1), this.maxDelayMs);
        const jitter = Math.random() * 0.3 * delay;
        logger.warn(`${this.name} connection failed, attempt ${attempt}/${this.maxReconnectAttempts}, retrying in ${Math.round(delay + jitter)}ms`, { error: String(err) });
        await this._sleep(delay + jitter);
      }
    }
  }

  private _connect(): Promise<void> {
    return new Promise((resolve, reject) => {
      try {
        this.ws = new WebSocket(this.wsUrl);

        const onOpen = () => {
          logger.info(`${this.name} connected`);
          this.connected = true;
          this.reconnectAttempt = 0;
          this._restoreSubscriptions();
          this._startHeartbeat();
          EventBus.emit('WS_STATUS', { client: this.name, status: 'connected', ts: Date.now() });
          resolve();
        };

        this.ws.once('open', onOpen);

        this.ws.on('message', (data: WebSocket.Data) => {
          this._onMessage(data);
        });

        this.ws.on('pong', () => {
          this.lastPongAt = Date.now();
        });

        this.ws.on('close', () => {
          this._onClose();
        });

        this.ws.once('error', (err) => {
          // Only reject on the initial connection error (before open fires)
          if (!this.connected) {
            reject(err);
          } else {
            logger.error(`${this.name} WS error`, { error: String(err) });
          }
        });
      } catch (err) {
        reject(err);
      }
    });
  }

  private _onMessage(data: WebSocket.Data): void {
    try {
      const parsed = typeof data === 'string' ? JSON.parse(data) : data;
      this.ringBuffer.push(parsed);
      if (this.ringBuffer.length > this.RING_BUFFER_SIZE) {
        this.ringBuffer.shift();
      }
      if (!this.draining) {
        setImmediate(() => this._drain());
      }
    } catch (err) {
      logger.error(`${this.name} message parsing failed`, { error: String(err) });
    }
  }

  private _drain(): void {
    this.draining = true;
    let processed = 0;
    const MAX_PER_TICK = 30;

    while (this.ringBuffer.length > 0 && processed < MAX_PER_TICK) {
      const msg = this.ringBuffer.shift();
      if (msg !== undefined) {
        try {
          this.onMessage(msg);
        } catch (err) {
          logger.error(`${this.name} message handler error`, { error: String(err) });
        }
      }
      processed++;
    }

    this.draining = false;
    if (this.ringBuffer.length > 0) {
      setImmediate(() => this._drain());
    }
  }

  private _startHeartbeat(): void {
    if (this.heartbeatInterval) clearInterval(this.heartbeatInterval);

    this.lastPongAt = Date.now(); // reset on new connection
    this.heartbeatInterval = setInterval(() => {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        const staleness = Date.now() - this.lastPongAt;
        if (staleness > 45000) {
          logger.warn(`${this.name} heartbeat timeout (${staleness}ms), reconnecting`);
          this._closeAndReconnect();
          return;
        }
        this.ws.ping();
      }
    }, 20000);
    this.heartbeatInterval.unref();
  }

  private _onClose(): void {
    this.connected = false;
    this._clearHeartbeat();
    // FIX: only reconnect if this was NOT an intentional close
    if (!this._intentionalClose) {
      logger.warn(`${this.name} unexpectedly disconnected`);
      EventBus.emit('WS_STATUS', { client: this.name, status: 'disconnected', ts: Date.now() });
      this._scheduleReconnect();
    }
  }

  private _closeAndReconnect(): void {
    if (this.ws) {
      this.ws.terminate();
      this.ws = null;
    }
    this.connected = false;
    this._clearHeartbeat();
    if (!this._intentionalClose) {
      this._scheduleReconnect();
    }
  }

  private _scheduleReconnect(): void {
    this.reconnectAttempt++;
    const delay = Math.min(
      this.baseDelayMs * Math.pow(1.5, this.reconnectAttempt - 1),
      this.maxDelayMs,
    );
    const jitter = Math.random() * 0.3 * delay;
    EventBus.emit('WS_STATUS', { client: this.name, status: 'reconnecting', ts: Date.now() });
    setTimeout(() => {
      if (!this._intentionalClose) {
        void this.connect();
      }
    }, delay + jitter);
  }

  private _clearHeartbeat(): void {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
      this.heartbeatInterval = null;
    }
  }

  private _restoreSubscriptions(): void {
    for (const [key, state] of Object.entries(this.subscriptions)) {
      try {
        this.resubscribe(key, state);
      } catch (err) {
        logger.error(`${this.name} resubscribe failed for ${key}`, { error: String(err) });
      }
    }
  }

  // FIX: set intentional flag before closing to prevent reconnect loop
  disconnect(): void {
    this._intentionalClose = true;
    this._clearHeartbeat();
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    this.connected = false;
    logger.info(`${this.name} disconnected`);
  }

  isConnected(): boolean {
    return this.connected && this.ws?.readyState === WebSocket.OPEN;
  }

  protected send(message: unknown): void {
    if (!this.isConnected()) {
      logger.warn(`${this.name} not connected, cannot send`);
      return;
    }
    try {
      this.ws!.send(JSON.stringify(message));
    } catch (err) {
      logger.error(`${this.name} send failed`, { error: String(err) });
    }
  }

  protected abstract onMessage(message: unknown): void;
  protected abstract resubscribe(key: string, state: unknown): void;

  protected getBufferSize(): number {
    return this.ringBuffer.length;
  }

  private _sleep(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
}
