import axios from 'axios';
import {
  VersionedTransaction,
  Keypair,
  PublicKey,
  SystemProgram,
  TransactionMessage,
} from '@solana/web3.js';
import bs58 from 'bs58';
import { createModuleLogger } from '../../core/Logger';
import { AppConfig } from '../../config/AppConfig';
import { ExtendedConfig } from '../../config/schema';
import { EventBus, MEVDetectedEvent } from '../../core/EventBus';
import { getDb } from '../../db/Database';
import { getRpcManager, RpcManager } from '../../core/RpcManager';
import { getWriteRpcProvider, WriteRpcProvider } from '../../core/WriteRpcProvider';

const logger = createModuleLogger('MEVProtection');

// Jito tip accounts (mainnet). A tip transfer to one of these is REQUIRED for a
// bundle to be accepted/landed by the Jito block engine. Pick one at random to
// spread load. Source: Jito docs (getTipAccounts).
const JITO_TIP_ACCOUNTS = [
  '96gYZGLnJYVFmbjzopPSU6QiEV5fGqZNyN9nmNhvrZU5',
  'HFqU5x63VTqvQss8hp11i4wVV8bD44PvwucfZ2bU7gRe',
  'Cw8CFyM9FkoMi7K7Crf6HNQqf4uEMzpKw6QNghXLvLkY',
  'ADaUMid9yfUytqMBgopwjb2DTLSokTSzL1zt6iGPaS49',
  'DfXygSm4jCyNCybVYYK6DwvWqjKee8pbDmJGcLWNDXjh',
  'ADuUkR4vqLUMWXxW9gh6D6L8pMSawimctcNZ5pGwDcEt',
  'DttWaMuVvTiduZRnguLF7jNxTgiMBZ1hyAumKUiL2KRL',
  '3AVi9Tg9Uo68tJfuvoKvqKNWKkC5wPdSSdeBnizKZ6jT',
];

export interface MEVSubmitOptions {
  txBase64: string;
  mint?: string;
  expectedOutAmount: number;
  slippageBps: number;
  priorityFeeMicroLamports: number;
}

export interface MEVSubmitResult {
  success: boolean;
  txHash?: string;
  bundleId?: string;
  usedJito: boolean;
  tipLamports: number;
  error?: string;
}

/**
 * MEVProtection handles:
 * 1. Sandwich attack detection (price moved before/after quote)
 * 2. Front-run protection (delay between quote and submit)
 * 3. Jito bundle submission (bypasses mempool, prevents sandwiching)
 * 4. Dynamic priority fee adaptation (higher fee under congestion)
 * 5. Failed-fill detection (actual out < expected - slippage)
 * 6. Automatic retry with Jito if normal submit fails
 */
export class MEVProtection {
  private cfg: ExtendedConfig['mevProtection'];
  private rpc: RpcManager;
  // FIX (#4): broadcasts must go through the WRITE pool (OrbitFlare primary,
  // QuickNode fallback) — the READ pool getConnection() must not send txs.
  private write: WriteRpcProvider;
  private keypair: Keypair;
  private rpcUrl: string;
  private jitoUrl: string;
  private consecutiveFailures = 0;
  private readonly MAX_CONSECUTIVE_FAILURES = 3;

  constructor(baseCfg: AppConfig, extCfg: ExtendedConfig, keypair: Keypair) {
    this.cfg = extCfg.mevProtection;
    this.rpc = getRpcManager(baseCfg);
    this.write = getWriteRpcProvider(baseCfg);
    this.keypair = keypair;
    this.rpcUrl = baseCfg.rpc.rpcHttpUrl;
    this.jitoUrl = this.cfg.jitoBlockEngineUrl;
  }

  /**
   * Submit transaction with MEV protection.
   * Tries normal RPC first; falls back to Jito if enabled and fails.
   */
  async submit(opts: MEVSubmitOptions): Promise<MEVSubmitResult> {
    const { txBase64, mint } = opts;

    // Front-run protection: small delay between quote and submit
    if (this.cfg.frontRunProtectionMs > 0) {
      await this._sleep(this.cfg.frontRunProtectionMs);
    }

    // FIX (#5): the caller (JupiterClient) already signed this transaction. Only
    // sign if it is still unsigned, so we never produce a redundant signature pass.
    const tx = VersionedTransaction.deserialize(Buffer.from(txBase64, 'base64'));
    const isSigned = tx.signatures.length > 0 && tx.signatures.some((s) => s.some((b) => b !== 0));
    if (!isSigned) tx.sign([this.keypair]);
    const signedBytes = tx.serialize();
    // Real on-chain signature — used as txHash for confirmation regardless of
    // whether we land via direct RPC or a Jito bundle.
    const signature = bs58.encode(tx.signatures[0]);

    // FIX (#4): when Jito is enabled, submit the bundle FIRST (with a real tip),
    // because Jito bundles bypass the public mempool and actually prevent the
    // sandwich attacks this module defends against. Fall back to a direct RPC
    // broadcast if the bundle is rejected.
    if (this.cfg.jitoEnabled) {
      const jitoRes = await this._submitViaJito(tx, signature, mint);
      if (jitoRes.success) {
        this.consecutiveFailures = 0;
        return jitoRes;
      }
      logger.warn('Jito bundle failed — falling back to direct RPC', { mint, error: jitoRes.error });
    }

    // Direct RPC submission via the WRITE pool.
    try {
      const txHash = await this.write.sendRawTransaction(signedBytes, {
        skipPreflight: false,
        maxRetries: 0,
        preflightCommitment: 'confirmed',
      });

      this.consecutiveFailures = 0;
      logger.info('Transaction submitted via RPC', { txHash, mint });
      return { success: true, txHash, usedJito: false, tipLamports: 0 };
    } catch (rpcErr) {
      const errMsg = rpcErr instanceof Error ? rpcErr.message : String(rpcErr);
      this.consecutiveFailures++;

      // Detect sandwich / front-run patterns
      if (this.cfg.sandwichDetectionEnabled && this._isSandwichError(errMsg)) {
        logger.warn('Potential sandwich attack detected', { mint, error: errMsg });
        this._logMEVEvent({ eventType: 'sandwich', mint, txHash: '', costSol: 0, slippageActualBps: opts.slippageBps * 2, slippageExpectedBps: opts.slippageBps });
        EventBus.emit('MEV_DETECTED', { eventType: 'sandwich', tokenMint: mint, txHash: '', estimatedCostSol: 0.001, ts: Date.now() } as MEVDetectedEvent);
      }

      return { success: false, usedJito: false, tipLamports: 0, error: errMsg };
    }
  }

  /**
   * Submit transaction as a Jito bundle to bypass the public mempool.
   * FIX (#4): a Jito bundle is only accepted/landed if it contains a tip to a
   * Jito tip account. We append a dedicated tip-transfer transaction to the
   * bundle and return the REAL swap signature as txHash (plus the bundleId) so
   * downstream confirmation can poll the signature directly.
   */
  private async _submitViaJito(tx: VersionedTransaction, signature: string, mint?: string): Promise<MEVSubmitResult> {
    if (!this.cfg.jitoEnabled) {
      return { success: false, usedJito: false, tipLamports: 0, error: 'Jito disabled' };
    }

    // Jito requires a minimum tip of 1000 lamports.
    const tipLamports = Math.max(1000, this.cfg.jitoTipLamports);

    try {
      const tipTx = await this._buildTipTx(tipLamports);
      const swapBase64 = Buffer.from(tx.serialize()).toString('base64');
      const tipBase64 = Buffer.from(tipTx.serialize()).toString('base64');

      // Jito bundles API — send the swap tx + tip tx as one atomic bundle.
      const response = await axios.post<{ result: string }>(
        `${this.jitoUrl}/api/v1/bundles`,
        {
          jsonrpc: '2.0',
          id: 1,
          method: 'sendBundle',
          params: [[swapBase64, tipBase64]],
        },
        {
          headers: { 'Content-Type': 'application/json' },
          timeout: 15000,
        },
      );

      const bundleId = response.data?.result;
      if (!bundleId) throw new Error('No bundle ID returned from Jito');

      this._logMEVEvent({ eventType: 'jito_bundle', mint, txHash: signature, costSol: tipLamports / 1e9, slippageActualBps: 0, slippageExpectedBps: 0, bundleId, tipLamports });
      logger.info('Jito bundle submitted', { bundleId, signature, mint, tipLamports });

      return { success: true, txHash: signature, bundleId, usedJito: true, tipLamports };
    } catch (err) {
      const errMsg = err instanceof Error ? err.message : String(err);
      logger.error('Jito bundle submission failed', { error: errMsg });
      return { success: false, usedJito: true, tipLamports, error: errMsg };
    }
  }

  /** Build and sign a standalone Jito tip-transfer transaction. */
  private async _buildTipTx(tipLamports: number): Promise<VersionedTransaction> {
    const tipAccount = new PublicKey(
      JITO_TIP_ACCOUNTS[Math.floor(Math.random() * JITO_TIP_ACCOUNTS.length)],
    );
    const { blockhash } = await this.write.getLatestBlockhash('confirmed');
    const message = new TransactionMessage({
      payerKey: this.keypair.publicKey,
      recentBlockhash: blockhash,
      instructions: [
        SystemProgram.transfer({
          fromPubkey: this.keypair.publicKey,
          toPubkey: tipAccount,
          lamports: tipLamports,
        }),
      ],
    }).compileToV0Message();
    const tipTx = new VersionedTransaction(message);
    tipTx.sign([this.keypair]);
    return tipTx;
  }

  /**
   * Compute adaptive priority fee based on network congestion.
   * Under heavy load (many consecutive failures), increase fee.
   */
  computeAdaptivePriorityFee(baseFee: number): number {
    const multiplier = Math.min(1 + this.consecutiveFailures * 0.5, 3.0);
    const adapted = Math.round(baseFee * multiplier);
    const capped = Math.min(adapted, baseFee + this.cfg.maxSlippageAdaptBps * 100);
    if (multiplier > 1) {
      logger.debug('Adaptive priority fee', { baseFee, adapted, multiplier });
    }
    return capped;
  }

  /**
   * Detect if actual output is below the expected threshold (failed fill / sandwich).
   */
  /** sandwichDetectionEnabled guards both attack-pattern and failed-fill detection */
  detectFailedFill(expectedOut: number, actualOut: number, slippageBps: number, mint?: string): boolean {
    if (!this.cfg.sandwichDetectionEnabled) return false;
    const minAcceptable = expectedOut * (1 - slippageBps / 10000);
    if (actualOut < minAcceptable) {
      const lossRatio = (expectedOut - actualOut) / expectedOut;
      logger.warn('Failed fill detected', { expectedOut, actualOut, lossRatio: (lossRatio * 100).toFixed(2) + '%', mint });
      this._logMEVEvent({
        eventType: 'failed_fill',
        mint,
        txHash: '',
        costSol: (expectedOut - actualOut) / 1e9,
        slippageActualBps: Math.round(lossRatio * 10000),
        slippageExpectedBps: slippageBps,
      });
      EventBus.emit('MEV_DETECTED', { eventType: 'failed_fill', tokenMint: mint, txHash: '', estimatedCostSol: (expectedOut - actualOut) / 1e9, ts: Date.now() } as MEVDetectedEvent);
      return true;
    }
    return false;
  }

  private _isSandwichError(errMsg: string): boolean {
    const sandwichPatterns = ['slippage tolerance exceeded', 'custom program error: 0x1771', 'AmountOutBelowMinimum', 'slippage'];
    return sandwichPatterns.some((p) => errMsg.toLowerCase().includes(p.toLowerCase()));
  }

  private _logMEVEvent(event: { eventType: string; mint?: string; txHash: string; costSol: number; slippageActualBps: number; slippageExpectedBps: number; bundleId?: string; tipLamports?: number }): void {
    try {
      getDb().prepare(`
        INSERT INTO mev_events (tx_hash, event_type, token_mint, cost_sol, slippage_actual_bps, slippage_expected_bps, bundle_id, tip_lamports, detected_ts, resolved)
        VALUES (@tx_hash, @event_type, @token_mint, @cost_sol, @slippage_actual_bps, @slippage_expected_bps, @bundle_id, @tip_lamports, @detected_ts, 0)
      `).run({
        tx_hash: event.txHash,
        event_type: event.eventType,
        token_mint: event.mint ?? null,
        cost_sol: event.costSol,
        slippage_actual_bps: event.slippageActualBps,
        slippage_expected_bps: event.slippageExpectedBps,
        bundle_id: event.bundleId ?? null,
        tip_lamports: event.tipLamports ?? 0,
        detected_ts: Date.now(),
      });
    } catch { /* non-critical */ }
  }

  resetFailureCount(): void {
    this.consecutiveFailures = 0;
  }

  private _sleep(ms: number): Promise<void> {
    return new Promise((r) => setTimeout(r, ms));
  }
}

export default MEVProtection;
