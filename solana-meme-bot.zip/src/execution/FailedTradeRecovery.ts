import { Connection } from '@solana/web3.js';
import { createModuleLogger } from '../core/Logger';
import { AppConfig } from '../config/AppConfig';
import TradeRepository from '../db/repositories/TradeRepository';
import { getRpcManager, RpcManager } from '../core/RpcManager';

const logger = createModuleLogger('FailedTradeRecovery');

/**
 * FailedTradeRecovery handles ambiguous trade outcomes:
 * - Timeout: tx may have landed but confirmation timed out
 * - Failure: on-chain error, DB should mark as failed
 *
 * On timeout: checks chain one final time before marking failed.
 * Prevents double-sends when tx was actually confirmed.
 */
export class FailedTradeRecovery {
  private rpc: RpcManager;
  private get connection(): Connection { return this.rpc.getConnection(); }

  constructor(cfg: AppConfig) {
    this.rpc = getRpcManager(cfg);
  }

  /**
   * Check if a timed-out transaction actually confirmed
   * Returns true if confirmed, false if safe to retry
   */
  async resolveTimeout(tradeId: string, txHash: string): Promise<boolean> {
    try {
      logger.info('Resolving timed-out transaction', { tradeId, txHash });

      const sigStatus = await this.connection.getSignatureStatus(txHash, {
        searchTransactionHistory: true,
      });

      const status = sigStatus?.value;
      if (!status) {
        // Transaction not found — safe to retry or mark failed
        logger.info('Timed-out tx not found on chain, marking failed', { txHash });
        TradeRepository.updateStatus(tradeId, 'failed');
        return false;
      }

      if (status.err) {
        logger.warn('Timed-out tx found on chain with error', { txHash, err: JSON.stringify(status.err) });
        TradeRepository.updateStatus(tradeId, 'failed');
        return false;
      }

      if (status.confirmationStatus === 'confirmed' || status.confirmationStatus === 'finalized') {
        logger.info('Timed-out tx actually confirmed', { txHash, slot: status.slot });
        TradeRepository.updateStatus(tradeId, 'confirmed', {
          txHash,
          confirmedAt: Date.now(),
        });
        return true;
      }

      // Still processing — mark as failed conservatively
      logger.warn('Timed-out tx status uncertain, marking failed', { txHash });
      TradeRepository.updateStatus(tradeId, 'failed');
      return false;
    } catch (err) {
      logger.error('Failed to resolve timed-out transaction', { txHash, error: String(err) });
      TradeRepository.updateStatus(tradeId, 'failed');
      return false;
    }
  }

  /**
   * Scan and reconcile any pending trades in DB
   * (Run on startup to catch trades from previous session)
   */
  async reconcilePendingTrades(): Promise<void> {
    const pending = TradeRepository.findPending();
    if (pending.length === 0) return;

    logger.info(`Reconciling ${pending.length} pending trade(s) from previous session`);

    for (const trade of pending) {
      if (!trade.txHash) {
        // Never submitted — mark failed
        TradeRepository.updateStatus(trade.id, 'failed');
        continue;
      }

      const confirmed = await this.resolveTimeout(trade.id, trade.txHash);
      logger.info('Pending trade reconciled', { tradeId: trade.id, confirmed });
    }
  }
}

export default FailedTradeRecovery;
