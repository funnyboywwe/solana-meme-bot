import { Connection } from '@solana/web3.js';
import { createModuleLogger } from '../core/Logger';
import { AppConfig } from '../config/AppConfig';
import { getRpcManager, RpcManager } from '../core/RpcManager';

const logger = createModuleLogger('PriorityFeeManager');

/**
 * PriorityFeeManager computes optimal priority fee
 * based on recent network congestion levels
 *
 * Strategy:
 * - Poll recent priority fees from RPC
 * - Use P75 (75th percentile) to avoid overpaying
 * - Cap at configuredMax (prevent runaway fees)
 * - Floor at configuredBase (ensure inclusion)
 */
export class PriorityFeeManager {
  private rpc: RpcManager;
  private get connection(): Connection { return this.rpc.getConnection(); }
  private baseFee: number;
  private cachedFee: number;
  private lastFetchedAt = 0;
  private cacheMs = 30000; // Refresh every 30s

  constructor(cfg: AppConfig) {
    this.rpc = getRpcManager(cfg);
    this.baseFee = cfg.execution.priorityFeeMicroLamports;
    this.cachedFee = this.baseFee;
  }

  /**
   * Get recommended priority fee in microLamports
   */
  async getRecommendedFee(): Promise<number> {
    const now = Date.now();
    if (now - this.lastFetchedAt < this.cacheMs) {
      return this.cachedFee;
    }

    try {
      // Fetch recent priority fee samples from RPC
      const response = await this.connection.getRecentPrioritizationFees();

      if (!response || response.length === 0) {
        return this.baseFee;
      }

      // Sort and take P75
      const fees = response
        .map((f) => f.prioritizationFee)
        .filter((f) => f > 0)
        .sort((a, b) => a - b);

      if (fees.length === 0) return this.baseFee;

      const p75Index = Math.floor(fees.length * 0.75);
      const p75Fee = fees[p75Index] ?? this.baseFee;

      // Apply bounds: floor at baseFee, cap at 3x baseFee
      this.cachedFee = Math.max(this.baseFee, Math.min(p75Fee, this.baseFee * 3));
      this.lastFetchedAt = now;

      logger.debug('Priority fee updated', { cachedFee: this.cachedFee, p75Fee });

      return this.cachedFee;
    } catch (err) {
      logger.warn('Failed to fetch priority fees, using base', { error: String(err) });
      return this.baseFee;
    }
  }
}

export default PriorityFeeManager;
