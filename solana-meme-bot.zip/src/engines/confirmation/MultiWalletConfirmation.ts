import { EventBus, WalletTxEvent, MultiWalletConfirmedEvent } from '../../core/EventBus';
import { AppConfig } from '../../config/AppConfig';
import { ExtendedConfig } from '../../config/schema';
import { createModuleLogger } from '../../core/Logger';
import { TradeConfirmation } from '../../core/types';
import WalletRepository from '../../db/repositories/WalletRepository';
import { getDb } from '../../db/Database';
import { v4 as uuidv4 } from 'uuid';

const logger = createModuleLogger('MultiWalletConfirmation');

interface PendingConfirmation {
  tokenMint: string;
  wallets: Map<string, { ts: number; qualityScore: number; amountSol: number }>;
  windowStartTs: number;
  id: string;
}

/**
 * MultiWalletConfirmation is a pre-execution gate that collects
 * WALLET_TX buy events for the same token across multiple high-quality
 * wallets within a configurable time window.
 *
 * Only when `requiredWallets` distinct wallets have bought does it:
 * 1. Compute a confirmation score
 * 2. Persist the confirmation record
 * 3. Emit MULTI_WALLET_CONFIRMED
 *
 * The entry gate checks for an active confirmation before approving.
 */
export class MultiWalletConfirmation {
  private cfg: ExtendedConfig['multiWalletConfirmation'];
  private baseCfg: AppConfig;
  private pending = new Map<string, PendingConfirmation>();
  private confirmed = new Map<string, TradeConfirmation>(); // tokenMint → latest confirmation
  private pruneInterval: NodeJS.Timeout;

  constructor(baseCfg: AppConfig, extCfg: ExtendedConfig) {
    this.baseCfg = baseCfg;
    this.cfg = extCfg.multiWalletConfirmation;

    this.pruneInterval = setInterval(() => this._pruneExpired(), 60000);
    this.pruneInterval.unref();

    logger.info('MultiWalletConfirmation initialized', {
      requiredWallets: this.cfg.requiredWallets,
      windowMs: this.cfg.confirmationWindowMs,
      minScore: this.cfg.minConfirmationScore,
    });
  }

  /**
   * Record a wallet buy event. Returns true if confirmation achieved.
   */
  recordBuy(event: WalletTxEvent): boolean {
    if (!this.cfg.enabled) return true; // disabled = always pass
    if (event.side !== 'buy') return false;

    const walletStats = WalletRepository.findByAddress(event.walletAddress);
    if (!walletStats || walletStats.qualityScore < 50) return false;

    const now = Date.now();
    const mint = event.mint;

    if (!this.pending.has(mint)) {
      this.pending.set(mint, {
        tokenMint: mint,
        wallets: new Map(),
        windowStartTs: now,
        id: uuidv4(),
      });
    }

    const conf = this.pending.get(mint)!;

    // Reset window if expired
    if (now - conf.windowStartTs > this.cfg.confirmationWindowMs) {
      conf.wallets.clear();
      conf.windowStartTs = now;
      conf.id = uuidv4();
    }

    // Add wallet (dedup by address)
    if (!conf.wallets.has(event.walletAddress)) {
      conf.wallets.set(event.walletAddress, {
        ts: now,
        qualityScore: walletStats.qualityScore,
        amountSol: event.amountSol,
      });
    }

    const walletCount = conf.wallets.size;
    logger.debug('Wallet buy recorded for confirmation', { mint, walletCount, required: this.cfg.requiredWallets });

    if (walletCount >= this.cfg.requiredWallets) {
      return this._tryConfirm(mint, conf);
    }
    return false;
  }

  private _tryConfirm(mint: string, conf: PendingConfirmation): boolean {
    const now = Date.now();
    const walletEntries = Array.from(conf.wallets.entries());
    const score = this._computeScore(walletEntries.map(([, v]) => v));

    if (score < this.cfg.minConfirmationScore) {
      logger.debug('Confirmation score below threshold', { mint, score, required: this.cfg.minConfirmationScore });
      return false;
    }

    const confirmation: TradeConfirmation = {
      id: conf.id,
      tokenMint: mint,
      strategy: 'hybrid',
      walletCount: conf.wallets.size,
      requiredWallets: this.cfg.requiredWallets,
      confirmationScore: score,
      wallets: walletEntries.map(([addr]) => addr),
      windowStartTs: conf.windowStartTs,
      windowEndTs: now,
      confirmed: true,
      executed: false,
      createdAt: now,
    };

    this.confirmed.set(mint, confirmation);
    this._persist(confirmation);

    logger.info('Multi-wallet confirmation achieved', {
      mint,
      walletCount: confirmation.walletCount,
      score: score.toFixed(1),
    });

    EventBus.emit('MULTI_WALLET_CONFIRMED', {
      confirmationId: conf.id,
      tokenMint: mint,
      walletCount: confirmation.walletCount,
      confirmationScore: score,
      strategy: 'hybrid',
      ts: now,
    } as MultiWalletConfirmedEvent);

    return true;
  }

  private _computeScore(wallets: Array<{ qualityScore: number; amountSol: number }>): number {
    if (wallets.length === 0) return 0;
    const countScore = Math.min(wallets.length / (this.cfg.requiredWallets * 2), 1) * 40;
    const avgQuality = wallets.reduce((s, w) => s + w.qualityScore, 0) / wallets.length;
    const qualityScore = (avgQuality / 100) * 40;
    const capitalScore = Math.min(wallets.reduce((s, w) => s + w.amountSol, 0) / 10, 1) * 20;
    return Math.min(countScore + qualityScore + capitalScore, 100);
  }

  /**
   * Check if a token has an active, unexpired confirmation.
   */
  hasConfirmation(mint: string): boolean {
    if (!this.cfg.enabled) return true;
    const conf = this.confirmed.get(mint);
    if (!conf) return false;
    const age = Date.now() - conf.createdAt;
    return age < this.cfg.expiryMs && !conf.executed;
  }

  getConfirmation(mint: string): TradeConfirmation | undefined {
    return this.confirmed.get(mint);
  }

  markExecuted(mint: string): void {
    const conf = this.confirmed.get(mint);
    if (conf) {
      this.confirmed.set(mint, { ...conf, executed: true });
      getDb().prepare('UPDATE trade_confirmations SET executed = 1 WHERE id = @id').run({ id: conf.id });
    }
  }

  private _persist(conf: TradeConfirmation): void {
    const db = getDb();
    db.prepare(`
      INSERT OR REPLACE INTO trade_confirmations
        (id, token_mint, strategy, wallet_count, required_wallets, confirmation_score,
         wallets_json, window_start_ts, window_end_ts, confirmed, executed, created_at)
      VALUES (@id, @token_mint, @strategy, @wallet_count, @required_wallets, @confirmation_score,
              @wallets_json, @window_start_ts, @window_end_ts, @confirmed, @executed, @created_at)
    `).run({
      id: conf.id,
      token_mint: conf.tokenMint,
      strategy: conf.strategy,
      wallet_count: conf.walletCount,
      required_wallets: conf.requiredWallets,
      confirmation_score: conf.confirmationScore,
      wallets_json: JSON.stringify(conf.wallets),
      window_start_ts: conf.windowStartTs,
      window_end_ts: conf.windowEndTs,
      confirmed: conf.confirmed ? 1 : 0,
      executed: conf.executed ? 1 : 0,
      created_at: conf.createdAt,
    });
  }

  private _pruneExpired(): void {
    const now = Date.now();
    for (const [mint, conf] of this.confirmed) {
      if (now - conf.createdAt > this.cfg.expiryMs) {
        this.confirmed.delete(mint);
      }
    }
    for (const [mint, pend] of this.pending) {
      if (now - pend.windowStartTs > this.cfg.confirmationWindowMs * 2) {
        this.pending.delete(mint);
      }
    }
  }

  getPendingCount(mint: string): number {
    return this.pending.get(mint)?.wallets.size ?? 0;
  }

  stop(): void {
    clearInterval(this.pruneInterval);
  }
}

export default MultiWalletConfirmation;
