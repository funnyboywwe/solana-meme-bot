import { EventBus, TokenCreatedEvent, PoolUpdateEvent, MigrationDetectedEvent } from '../../core/EventBus';
import { AppConfig } from '../../config/AppConfig';
import { ExtendedConfig } from '../../config/schema';
import { createModuleLogger } from '../../core/Logger';
import { MigrationEvent } from '../../core/types';
import MigrationRepository from '../../db/repositories/MigrationRepository';
import { getSolPriceUsd } from '../../core/SolPrice';
import { v4 as uuidv4 } from 'uuid';

const logger = createModuleLogger('PumpfunMigrationEngine');

/**
 * PumpfunMigrationEngine detects Pump.fun bonding curve completion
 * and subsequent Raydium migration.
 *
 * Detection logic:
 * 1. New token from 'pumpfun' source → start tracking
 * 2. Monitor liquidity growth on the bonding curve
 * 3. When bondingCurvePct >= bondingCurveThreshold → flag as near-complete
 * 4. When Raydium pool detected for same token → migration confirmed
 *
 * Priority boost: newly migrated tokens get a score bonus to prioritize them
 * in the entry gate scoring.
 *
 * Pump.fun tokenomics:
 * - Bonding curve fills when ~$69k of SOL is purchased
 * - At completion, LP is auto-created on Raydium
 * - ~$12k of LP is burned
 */
export class PumpfunMigrationEngine {
  private cfg: ExtendedConfig['pumpfunMigration'];
  private baseCfg: AppConfig;
  // Track pump.fun tokens and their bonding curve progress
  private pumpTokens = new Map<string, { mint: string; poolAddress: string; liquidityUsd: number; detectedTs: number }>();
  private readonly BONDING_CURVE_TARGET_USD = 69000; // ~$69k fills the curve
  private cleanupTimer: NodeJS.Timeout;

  constructor(baseCfg: AppConfig, extCfg: ExtendedConfig) {
    this.baseCfg = baseCfg;
    this.cfg = extCfg.pumpfunMigration;

    this.cleanupTimer = setInterval(() => this._cleanup(), 600000); // 10 min
    this.cleanupTimer.unref();

    logger.info('PumpfunMigrationEngine initialized', {
      bondingCurveThreshold: this.cfg.bondingCurveThreshold,
      priorityBoost: this.cfg.priorityBoostScore,
    });
  }

  /** Track all Pump.fun token creations */
  processTokenCreated(event: TokenCreatedEvent): void {
    if (!this.cfg.enabled) return;
    if (event.source !== 'pumpfun') return;

    this.pumpTokens.set(event.mint, {
      mint: event.mint,
      poolAddress: event.poolAddress,
      liquidityUsd: event.initialLiquidityUsd,
      detectedTs: event.createdAt,
    });

    // Create migration tracking record
    if (!MigrationRepository.exists(event.mint)) {
      const bondingPct = this._estimateBondingPct(event.initialLiquidityUsd);
      MigrationRepository.upsert({
        tokenMint: event.mint,
        pumpPoolAddress: event.poolAddress,
        raydiumPoolAddress: '',
        bondingCurvePct: bondingPct,
        completed: false,
        raydiumMigrated: false,
        initialLiquiditySol: event.initialLiquidityUsd / getSolPriceUsd(),
        initialLiquidityUsd: event.initialLiquidityUsd,
        lpSolAdded: 0,
        detectedTs: Date.now(),
        priorityScore: 0,
        status: 'bonding',
      });
    }
  }

  /** Monitor liquidity changes to detect bonding curve progress */
  processPoolUpdate(event: PoolUpdateEvent): void {
    if (!this.cfg.enabled) return;
    const pumpToken = this.pumpTokens.get(event.mint);
    if (!pumpToken) return;

    pumpToken.liquidityUsd = event.liquidityUsd;
    const bondingPct = this._estimateBondingPct(event.liquidityUsd);

    const existing = MigrationRepository.findByToken(event.mint);
    if (!existing || existing.status === 'migrated') return;

    // Update bonding progress
    MigrationRepository.upsert({
      ...existing,
      bondingCurvePct: bondingPct,
      status: bondingPct >= 100 ? 'migrating' : 'bonding',
    });

    if (bondingPct >= this.cfg.bondingCurveThreshold) {
      logger.info('Pump.fun bonding curve near complete', {
        mint: event.mint,
        bondingPct: bondingPct.toFixed(1),
        liquidityUsd: event.liquidityUsd.toFixed(0),
      });

      EventBus.emit('MIGRATION_DETECTED', {
        tokenMint: event.mint,
        migrationId: existing.id,
        status: 'bonding',
        bondingCurvePct: bondingPct,
        initialLiquiditySol: pumpToken.liquidityUsd / getSolPriceUsd(),
        priorityScore: this._computePriorityScore(bondingPct, event.liquidityUsd),
        ts: Date.now(),
      } as MigrationDetectedEvent);
    }
  }

  /** Called when Raydium pool detected for a previously-pump token */
  processRaydiumMigration(mint: string, raydiumPoolAddress: string, liquidityUsd: number): void {
    if (!this.cfg.enabled) return;
    const pumpToken = this.pumpTokens.get(mint);
    if (!pumpToken) return;

    const existing = MigrationRepository.findByToken(mint);
    const lpSolAdded = liquidityUsd / getSolPriceUsd(); // FIX (#9): live SOL price

    const priorityScore = this._computePriorityScore(100, liquidityUsd) + this.cfg.priorityBoostScore;

    MigrationRepository.upsert({
      ...(existing ?? {
        id: uuidv4(),
        tokenMint: mint,
        pumpPoolAddress: pumpToken.poolAddress,
        bondingCurvePct: 100,
        completed: true,
        initialLiquiditySol: pumpToken.liquidityUsd / getSolPriceUsd(),
        initialLiquidityUsd: pumpToken.liquidityUsd,
        detectedTs: pumpToken.detectedTs,
        status: 'migrated' as const,
      }),
      raydiumPoolAddress,
      raydiumMigrated: true,
      completed: true,
      bondingCurvePct: 100,
      lpSolAdded,
      migrationTs: Date.now(),
      priorityScore,
      status: 'migrated',
    });

    logger.info('Pump.fun → Raydium migration confirmed', {
      mint,
      raydiumPool: raydiumPoolAddress,
      liquidityUsd: liquidityUsd.toFixed(0),
      priorityScore: priorityScore.toFixed(1),
    });

    EventBus.emit('MIGRATION_DETECTED', {
      tokenMint: mint,
      migrationId: existing?.id ?? mint,
      status: 'migrated',
      bondingCurvePct: 100,
      initialLiquiditySol: lpSolAdded,
      priorityScore,
      ts: Date.now(),
    } as MigrationDetectedEvent);
  }

  private _estimateBondingPct(liquidityUsd: number): number {
    return Math.min((liquidityUsd / this.BONDING_CURVE_TARGET_USD) * 100, 100);
  }

  private _computePriorityScore(bondingPct: number, liquidityUsd: number): number {
    const bondingScore = (bondingPct / 100) * 50;
    const liquidityScore = Math.min(liquidityUsd / this.BONDING_CURVE_TARGET_USD, 1) * 30;
    const solCheck = liquidityUsd / getSolPriceUsd() >= this.cfg.minInitialLiquiditySol ? 20 : 0;
    return Math.min(bondingScore + liquidityScore + solCheck, 100);
  }

  isMigrated(mint: string): boolean {
    return MigrationRepository.findByToken(mint)?.status === 'migrated';
  }

  getPriorityScore(mint: string): number {
    return MigrationRepository.findByToken(mint)?.priorityScore ?? 0;
  }

  getMigrationEvent(mint: string): MigrationEvent | undefined {
    return MigrationRepository.findByToken(mint);
  }

  private _cleanup(): void {
    const cutoff = Date.now() - this.cfg.trackWindowMs;
    for (const [mint, token] of this.pumpTokens) {
      if (token.detectedTs < cutoff) {
        this.pumpTokens.delete(mint);
      }
    }
  }

  stop(): void {
    clearInterval(this.cleanupTimer);
  }
}

export default PumpfunMigrationEngine;
