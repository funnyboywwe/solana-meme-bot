import { WalletTxEvent, CopySignalEvent } from '../../core/EventBus';
import { createModuleLogger } from '../../core/Logger';
import { AppConfig } from '../../config/AppConfig';
import { Connection, Keypair, LAMPORTS_PER_SOL } from '@solana/web3.js';
import bs58 from 'bs58';

const logger = createModuleLogger('TradeReplicator');

export interface ReplicatedOrder {
  mint: string;
  walletAddress: string;
  walletScore: number;
  suggestedSizeSol: number;
  originTxHash: string;
}

/**
 * TradeReplicator converts a wallet buy event into a scaled bot order.
 *
 * Sizing strategy:
 *   baseSize = botBalance * positionSizePct
 *   walletFraction = walletBuyAmountSol / walletBalanceSol (approximated)
 *   scaledSize = baseSize * min(walletFraction, 1.0)
 *   finalSize = clamp(scaledSize, minSizeSol, maxSizeSol)
 *
 * Score-weighted sizing:
 *   finalSize *= (walletScore / 100)  — higher score → larger fraction
 *   but capped at baseSize
 */
export class TradeReplicator {
  private connection: Connection;
  private keypair: Keypair;
  private positionSizePct: number;
  private minSizeSol: number;
  private maxSizeSol: number;

  constructor(cfg: AppConfig) {
    this.connection = new Connection(cfg.rpc.rpcHttpUrl, cfg.rpc.commitment);
    this.keypair = Keypair.fromSecretKey(bs58.decode(cfg.wallet.privateKey));
    this.positionSizePct = cfg.wallet.maxBalancePctPerTrade;
    this.minSizeSol = 0.01;
    this.maxSizeSol = 5.0; // hard cap regardless of balance
  }

  /**
   * Compute the bot order size for a given wallet buy event
   */
  async computeOrder(
    event: WalletTxEvent,
    walletScore: number,
  ): Promise<ReplicatedOrder | null> {
    try {
      // 1. Fetch bot wallet balance
      const lamports = await this.connection.getBalance(this.keypair.publicKey);
      const botBalanceSol = lamports / LAMPORTS_PER_SOL;

      if (botBalanceSol < this.minSizeSol * 2) {
        logger.warn('Bot wallet balance too low for copy trade', { botBalanceSol });
        return null;
      }

      // 2. Base size from fixed fraction
      const baseSize = botBalanceSol * this.positionSizePct;

      // 3. Scale by wallet quality score (0–100 → 0.0–1.0 multiplier)
      //    A wallet with score 65 → 0.65× of base size
      //    A wallet with score 90 → 0.90× of base size
      const scoreMultiplier = walletScore / 100;
      const scoredSize = baseSize * scoreMultiplier;

      // 4. Proportional to wallet's own trade size relative to 1 SOL baseline
      //    If the wallet bought 5 SOL worth and we scale relative to 1 SOL → cap at 1×
      const walletBuyRef = event.amountSol > 0 ? Math.min(event.amountSol, 10) : 1;
      const proportionFactor = Math.min(walletBuyRef / 1.0, 1.0);
      const proportionalSize = scoredSize * proportionFactor;

      // 5. Clamp to [min, max]
      const finalSize = Math.max(
        this.minSizeSol,
        Math.min(this.maxSizeSol, proportionalSize),
      );

      logger.debug('Copy order computed', {
        wallet: event.walletAddress,
        mint: event.mint,
        botBalance: botBalanceSol.toFixed(4),
        baseSize: baseSize.toFixed(4),
        scoreMultiplier: scoreMultiplier.toFixed(2),
        finalSize: finalSize.toFixed(4),
      });

      return {
        mint: event.mint,
        walletAddress: event.walletAddress,
        walletScore,
        suggestedSizeSol: finalSize,
        originTxHash: event.txHash,
      };
    } catch (err) {
      logger.error('Failed to compute copy order', { error: String(err) });
      return null;
    }
  }
}

export default TradeReplicator;
