import { WalletTxEvent, CopySignalEvent, EventBus } from '../../core/EventBus';
import { AppConfig } from '../../config/AppConfig';
import { createModuleLogger } from '../../core/Logger';
import { WalletIntelEngine } from '../wallet-intel/WalletIntelEngine';
import { WalletScorer } from './WalletScorer';
import { SignalFilter } from './SignalFilter';
import { TradeReplicator } from './TradeReplicator';

const logger = createModuleLogger('CopyTradingEngine');

/**
 * CopyTradingEngine is the full Phase 4 implementation.
 *
 * Flow for every WALLET_TX event:
 *   1. Early-exit if copy trading disabled
 *   2. SignalFilter: reject sells, stale, duplicates, post-pump, mcap
 *   3. WalletScorer: reject if wallet score below threshold
 *   4. WalletScorer: reject if insufficient trade history
 *   5. TradeReplicator: compute scaled order size
 *   6. Emit COPY_SIGNAL to EventBus
 *
 * COPY_SIGNAL is consumed by HybridEntryGate (Phase 3),
 * which applies additional safety + liquidity checks before
 * emitting ENTRY_APPROVED.
 */
export class CopyTradingEngine {
  private enabled: boolean;
  private walletScorer: WalletScorer;
  private signalFilter: SignalFilter;
  private tradeReplicator: TradeReplicator;
  private walletIntel: WalletIntelEngine;
  private minTradesForScore: number;
  private walletScoreThreshold: number;

  constructor(cfg: AppConfig, walletIntel: WalletIntelEngine) {
    this.enabled = cfg.trading.strategies.copy.enabled;
    this.walletIntel = walletIntel;
    this.minTradesForScore = cfg.walletIntel.minTradesForScore;
    this.walletScoreThreshold = cfg.trading.strategies.copy.walletScoreThreshold;

    this.walletScorer = new WalletScorer(this.walletScoreThreshold);
    this.signalFilter = new SignalFilter(cfg);
    this.tradeReplicator = new TradeReplicator(cfg);

    logger.info('CopyTradingEngine initialized', {
      enabled: this.enabled,
      walletScoreThreshold: this.walletScoreThreshold,
      minTradesForScore: this.minTradesForScore,
    });
  }

  /**
   * Process a WALLET_TX event — main entry point
   */
  async processTx(event: WalletTxEvent): Promise<void> {
    if (!this.enabled) return;

    const { walletAddress, mint } = event;

    // Step 1: Signal filter (fast synchronous checks)
    const filterResult = this.signalFilter.evaluate(event);
    if (!filterResult.pass) {
      logger.debug('Signal filtered', {
        wallet: walletAddress,
        mint,
        reason: filterResult.reason,
      });
      return;
    }

    // Step 2: Wallet score threshold
    if (!this.walletScorer.meetsThreshold(walletAddress)) {
      return; // Already logged inside meetsThreshold
    }

    // Step 3: Minimum trade history
    if (!this.walletScorer.hasSufficientHistory(walletAddress, this.minTradesForScore)) {
      logger.debug('Wallet lacks sufficient history', {
        wallet: walletAddress,
        required: this.minTradesForScore,
      });
      return;
    }

    // Step 4: Compute copy order size
    const walletScore = this.walletScorer.getScore(walletAddress);
    const order = await this.tradeReplicator.computeOrder(event, walletScore);
    if (!order) {
      logger.warn('TradeReplicator returned null order', { wallet: walletAddress, mint });
      return;
    }

    // Step 5: Log score breakdown for observability
    const breakdown = this.walletScorer.getBreakdown(walletAddress);
    logger.info('Copy signal generated', {
      wallet: walletAddress,
      mint,
      walletScore: walletScore.toFixed(1),
      suggestedSizeSol: order.suggestedSizeSol.toFixed(4),
      breakdown,
    });

    // Step 6: Emit COPY_SIGNAL
    EventBus.emit('COPY_SIGNAL', {
      mint,
      walletAddress,
      walletScore,
      suggestedSizeSol: order.suggestedSizeSol,
      originTxHash: event.txHash,
      ts: Date.now(),
    } as CopySignalEvent);
  }
}

export default CopyTradingEngine;
