import { createModuleLogger } from '../../core/Logger';
import WalletRepository from '../../db/repositories/WalletRepository';
import { WalletStats } from '../../core/types';

const logger = createModuleLogger('WalletScorer');

export interface WalletScoreBreakdown {
  winRateScore: number;
  roiScore: number;
  recentAccuracyScore: number;
  maturityScore: number;
  drawdownPenalty: number;
  total: number;
}

/**
 * WalletScorer computes the real-time quality score for a wallet.
 *
 * Used by CopyTradingEngine before deciding to copy a trade.
 * Score is read from DB (maintained live by WalletIntelEngine).
 * This class provides scoring explanation and threshold checking.
 *
 * Formula:
 *   winRateScore     = winRate   * 30   (0–30)
 *   roiScore         = min(avgRoi,5)/5 * 30  (0–30)
 *   recentScore      = recentWinRate * 20   (0–20)
 *   maturityScore    = min(trades,200)/200 * 10 (0–10)
 *   drawdownPenalty  = min(maxDrawdown,1) * 10  (0–10, subtracted)
 *   ──────────────────────────────────────────
 *   total            = clamped [0, 100]
 */
export class WalletScorer {
  private threshold: number;

  constructor(threshold: number) {
    this.threshold = threshold;
  }

  /**
   * Get score from DB (persisted by WalletIntelEngine)
   */
  getScore(walletAddress: string): number {
    return WalletRepository.findByAddress(walletAddress)?.qualityScore ?? 0;
  }

  /**
   * Get full breakdown for debugging/logging
   */
  getBreakdown(walletAddress: string): WalletScoreBreakdown | null {
    const stats = WalletRepository.findByAddress(walletAddress);
    if (!stats) return null;

    const winRateScore = stats.winRate * 30;
    const roiCapped = Math.min(Math.max(stats.avgRoi, 0), 5);
    const roiScore = (roiCapped / 5) * 30;
    const recentAccuracyScore = 0; // Stored in WalletIntelEngine in-memory; use qualityScore as proxy
    const maturityScore = (Math.min(stats.totalTrades, 200) / 200) * 10;
    const drawdownPenalty = 0; // Drawn from ProfitabilityTracker, use approximation here

    const total = Math.max(
      0,
      Math.min(100, winRateScore + roiScore + recentAccuracyScore + maturityScore - drawdownPenalty),
    );

    return { winRateScore, roiScore, recentAccuracyScore, maturityScore, drawdownPenalty, total };
  }

  /**
   * Does this wallet pass the minimum quality threshold?
   */
  meetsThreshold(walletAddress: string): boolean {
    const score = this.getScore(walletAddress);
    const passes = score >= this.threshold;
    if (!passes) {
      logger.debug('Wallet below threshold', {
        wallet: walletAddress,
        score: score.toFixed(1),
        threshold: this.threshold,
      });
    }
    return passes;
  }

  /**
   * Minimum trades requirement (wallet needs enough history to trust)
   */
  hasSufficientHistory(walletAddress: string, minTrades: number): boolean {
    const stats = WalletRepository.findByAddress(walletAddress);
    return (stats?.totalTrades ?? 0) >= minTrades;
  }

  getThreshold(): number {
    return this.threshold;
  }
}

export default WalletScorer;
