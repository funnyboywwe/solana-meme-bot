import { WalletTxEvent } from '../../core/EventBus';
import { createModuleLogger } from '../../core/Logger';
import { AppConfig } from '../../config/AppConfig';
import PositionRepository from '../../db/repositories/PositionRepository';
import TokenRepository from '../../db/repositories/TokenRepository';

const logger = createModuleLogger('SignalFilter');

export interface FilterResult {
  pass: boolean;
  reason?: string;
}

/**
 * SignalFilter applies a chain of rules to a WALLET_TX buy event.
 *
 * Rejects if ANY of the following:
 * 1. Side is 'sell' (never copy exits)
 * 2. Signal is stale (arrived > maxCopyDelayMs after the tx timestamp)
 * 3. We already hold this token (avoid doubling up)
 * 4. Token is too new (below minTokenAgeMs)
 * 5. Token is in post-pump zone (price > 3× the 1-hour low — copied too late)
 * 6. Token failed safety check (rugScore stored in DB)
 * 7. Token market cap is outside allowed range
 */
export class SignalFilter {
  private maxCopyDelayMs: number;
  private minTokenAgeMs: number;
  private minMarketCapUsd: number;
  private maxMarketCapUsd: number;
  private maxRugScore: number;
  private postPumpMultiplier = 3.0; // price > 3× 1h low → skip

  constructor(cfg: AppConfig) {
    this.maxCopyDelayMs = cfg.trading.strategies.copy.maxCopyDelayMs;
    this.minTokenAgeMs = cfg.filters.minTokenAgeMs;
    this.minMarketCapUsd = cfg.filters.minMarketCapUsd;
    this.maxMarketCapUsd = cfg.filters.maxMarketCapUsd;
    this.maxRugScore = cfg.safety.maxRugScore;
  }

  /**
   * Evaluate whether a wallet buy event should generate a copy signal
   */
  evaluate(event: WalletTxEvent): FilterResult {
    // Rule 1: Only copy buys
    if (event.side !== 'buy') {
      return { pass: false, reason: 'sell_event' };
    }

    // Rule 2: Staleness — signal must be fresh
    const signalAge = Date.now() - event.ts;
    if (signalAge > this.maxCopyDelayMs) {
      return {
        pass: false,
        reason: `stale_signal_${signalAge}ms`,
      };
    }

    // Rule 3: Already holding this token
    const existingPosition = PositionRepository.findByToken(event.mint);
    if (existingPosition) {
      return { pass: false, reason: 'already_holding' };
    }

    // Rule 4: Token age
    const tokenInfo = TokenRepository.findByMint(event.mint);
    if (!tokenInfo) {
      return { pass: false, reason: 'token_not_found' };
    }

    const tokenAge = Date.now() - tokenInfo.createdAt;
    if (tokenAge < this.minTokenAgeMs) {
      return { pass: false, reason: `token_too_new_${tokenAge}ms` };
    }

    // Rule 5: Market cap range
    if (tokenInfo.mcapUsd > 0) {
      if (tokenInfo.mcapUsd < this.minMarketCapUsd) {
        return { pass: false, reason: 'mcap_too_low' };
      }
      if (tokenInfo.mcapUsd > this.maxMarketCapUsd) {
        return { pass: false, reason: 'mcap_too_high' };
      }
    }

    // Rule 6: Rug score (if safety check has run)
    const rugScore = this._getRugScore(event.mint);
    if (rugScore !== null && rugScore > this.maxRugScore) {
      return { pass: false, reason: `rug_score_${rugScore}` };
    }

    // Rule 7: Post-pump zone — if current price is far above recent low, skip
    if (event.priceUsd > 0 && tokenInfo.mcapUsd > 0) {
      if (this._isPostPump(event)) {
        return { pass: false, reason: 'post_pump_zone' };
      }
    }

    return { pass: true };
  }

  private _getRugScore(mint: string): number | null {
    // Rug score is persisted to tokens.rug_score by SafetyEngine.
    // getSafety() returns null when the token has not been safety-checked yet.
    const safety = TokenRepository.getSafety(mint);
    if (!safety) return null;
    return safety.rugScore;
  }

  private _isPostPump(event: WalletTxEvent): boolean {
    // Heuristic: if amountSol per token is very high relative to what we'd
    // expect from a fresh token, it may be post-pump.
    // A more accurate check would compare to 1h OHLC from a price oracle.
    // For now: if priceUsd indicates mcap > 3× the min threshold, flag it.
    const tokenInfo = TokenRepository.findByMint(event.mint);
    if (!tokenInfo) return false;

    // If market cap has grown more than postPumpMultiplier × the min cap
    // since the token was created, treat as post-pump
    const mcapGrowthFactor =
      tokenInfo.mcapUsd > 0 && this.minMarketCapUsd > 0
        ? tokenInfo.mcapUsd / this.minMarketCapUsd
        : 1;

    return mcapGrowthFactor > this.postPumpMultiplier * 10;
  }
}

export default SignalFilter;
