import { MomentumState } from '../../core/types';
import { AppConfig } from '../../config/AppConfig';

/**
 * VolumeDetector tracks rolling 5-minute volume in time-bucketed windows.
 *
 * BUG FIXED (#14): Previous implementation used modular bucket indexing
 * (now % windowMs / bucketSize) which overwrote old data but never reset
 * totals — volumes accumulated monotonically, making the spike multiplier
 * meaningless after the first few minutes.
 *
 * FIX: Each entry is timestamped. On every update we evict entries older
 * than windowMs before computing the score. Score compares the last-bucket
 * volume against the average of all prior buckets within the window.
 */
export class VolumeDetector {
  private readonly windowMs: number;
  private readonly bucketMs: number; // 1-minute buckets
  private readonly spikeMultiplier: number;

  constructor(cfg: AppConfig) {
    this.windowMs = cfg.momentum.windowMs; // default 300_000 ms = 5 min
    this.bucketMs = Math.floor(this.windowMs / 5);
    this.spikeMultiplier = cfg.momentum.volumeSpikeMultiplier;
  }

  /**
   * Record a trade volume observation.
   * Stores (bucket_start_ts, volumeUsd) pairs per token state.
   */
  update(state: MomentumState, volumeUsd: number): void {
    const now = Date.now();
    const bucketStart = Math.floor(now / this.bucketMs) * this.bucketMs;

    // Find or create current bucket
    const last = state.volumeWindowUsd[state.volumeWindowUsd.length - 1] as unknown as { ts: number; vol: number } | undefined;
    if (last && last.ts === bucketStart) {
      last.vol += volumeUsd;
    } else {
      // Push new bucket entry { ts, vol }
      (state.volumeWindowUsd as unknown as Array<{ ts: number; vol: number }>).push({ ts: bucketStart, vol: volumeUsd });
    }

    // FIX: evict buckets older than windowMs
    const cutoff = now - this.windowMs;
    const buckets = state.volumeWindowUsd as unknown as Array<{ ts: number; vol: number }>;
    while (buckets.length > 0 && buckets[0]!.ts < cutoff) {
      buckets.shift();
    }
  }

  /**
   * Compute volume score (0–25 points).
   * spike = current_bucket_vol / avg(older_buckets_vol)
   */
  getScore(state: MomentumState): number {
    const buckets = state.volumeWindowUsd as unknown as Array<{ ts: number; vol: number }>;
    if (buckets.length < 2) return 0;

    const current = buckets[buckets.length - 1]!.vol;
    const prior = buckets.slice(0, -1);
    const avgPrior = prior.reduce((s, b) => s + b.vol, 0) / prior.length;

    if (avgPrior === 0) return 0;

    const spike = current / avgPrior;
    return Math.min((spike / this.spikeMultiplier) * 25, 25);
  }
}

export default VolumeDetector;
