import { EventBus, TokenCreatedEvent, TradeDetectedEvent, PoolUpdateEvent, PriceUpdateEvent, MomentumSignalEvent } from '../../core/EventBus';
import { AppConfig } from '../../config/AppConfig';
import { createModuleLogger } from '../../core/Logger';
import { MomentumState } from '../../core/types';
import { VolumeDetector } from './VolumeDetector';
import { BuyPressure } from './BuyPressure';
import { VelocityDetector } from './VelocityDetector';
import { LiquidityTracker } from './LiquidityTracker';
import { PriceAccel } from './PriceAccel';
import { MomentumScorer } from './MomentumScorer';

const logger = createModuleLogger('MomentumEngine');

const SCORE_EMIT_INTERVAL_MS = 2000;  // max one signal per 2s per token
const EVICT_AFTER_IDLE_MS = 30 * 60 * 1000; // evict state after 30 min idle

/**
 * MomentumEngine coordinates all 5 detectors.
 *
 * BUG FIXED (#7): Threshold was hardcoded at 65 in _maybeEmitSignal.
 * Now reads from scorer.getThreshold() which reads from config — so
 * changing trading.strategies.momentum.scoreThreshold in config
 * actually takes effect.
 */
export class MomentumEngine {
  private states = new Map<string, MomentumState>();
  private volumeDetector: VolumeDetector;
  private buyPressure: BuyPressure;
  private velocityDetector: VelocityDetector;
  private liquidityTracker: LiquidityTracker;
  private priceAccel: PriceAccel;
  private scorer: MomentumScorer;
  private evictTimer: NodeJS.Timeout;

  constructor(cfg: AppConfig) {
    this.volumeDetector = new VolumeDetector(cfg);
    this.buyPressure = new BuyPressure(cfg);
    this.velocityDetector = new VelocityDetector(cfg);
    this.liquidityTracker = new LiquidityTracker(cfg);
    this.priceAccel = new PriceAccel(cfg);
    this.scorer = new MomentumScorer(cfg);

    // Evict idle token states to prevent unbounded memory growth
    this.evictTimer = setInterval(() => this._evictIdleStates(), 5 * 60 * 1000);
    this.evictTimer.unref();

    logger.info('MomentumEngine initialized', {
      threshold: this.scorer.getThreshold(),
    });
  }

  registerToken(event: TokenCreatedEvent): void {
    if (this.states.has(event.mint)) return;

    const state: MomentumState = {
      mint: event.mint,
      volumeWindowUsd: [],
      buySideVol: 0,
      sellSideVol: 0,
      txTimestamps: [],
      priceHistory: [],
      liquidityHistory: [{ liquidity: event.initialLiquidityUsd, ts: Date.now() }],
      lastScore: 0,
      lastScoreTs: 0,
    };

    this.states.set(event.mint, state);
    logger.debug('Token registered for momentum', { mint: event.mint });
  }

  processTrade(event: TradeDetectedEvent): void {
    let state = this.states.get(event.mint);
    if (!state) {
      this.registerToken({
        mint: event.mint,
        symbol: 'UNK',
        decimals: 6,
        initialLiquidityUsd: 0,
        poolAddress: event.poolAddress,
        createdAt: Date.now(),
        source: 'unknown',
      });
      state = this.states.get(event.mint)!;
    }

    this.volumeDetector.update(state, event.amountUsd);
    this.buyPressure.update(state, event.side, event.amountUsd);
    this.velocityDetector.update(state, event.ts);
    this.priceAccel.update(state, event.priceUsd, event.ts);

    this._maybeEmitSignal(state);
  }

  processPoolUpdate(event: PoolUpdateEvent): void {
    const state = this.states.get(event.mint);
    if (!state) return;
    this.liquidityTracker.update(state, event.liquidityUsd, event.ts);
    this._maybeEmitSignal(state);
  }

  processPriceUpdate(event: PriceUpdateEvent): void {
    // LIVE TEST: lazily register a momentum state if we don't have one yet.
    // Tokens discovered in PRIOR sessions are price-tracked via the startup
    // backfill but never re-fire TOKEN_CREATED, so they had NO momentum state and
    // every price tick was dropped here (no scoring => no signal => no trade).
    // Mirror processTrade()'s lazy registration so ANY price-tracked token gets scored.
    let state = this.states.get(event.mint);
    if (!state) {
      this.registerToken({
        mint: event.mint,
        symbol: 'UNK',
        decimals: 6,
        initialLiquidityUsd: event.liquidityUsd > 0 ? event.liquidityUsd : 0,
        poolAddress: '',
        createdAt: Date.now(),
        source: 'unknown',
      });
      state = this.states.get(event.mint)!;
    }
    this.priceAccel.update(state, event.priceUsd, event.ts);
    if (event.liquidityUsd > 0) {
      this.liquidityTracker.update(state, event.liquidityUsd, event.ts);
    }
    // re-score on each price tick so price-driven momentum can emit a MOMENTUM_SIGNAL
    // (previously only trade/pool updates triggered scoring).
    this._maybeEmitSignal(state);
  }

  private _maybeEmitSignal(state: MomentumState): void {
    const now = Date.now();
    if (now - state.lastScoreTs < SCORE_EMIT_INTERVAL_MS) return;

    const breakdown = {
      volumeScore: this.volumeDetector.getScore(state),
      buyScore: this.buyPressure.getScore(state),
      velocityScore: this.velocityDetector.getScore(state),
      liquidityScore: this.liquidityTracker.getScore(state),
      accelScore: this.priceAccel.getScore(state),
    };

    const totalScore = this.scorer.computeTotal(breakdown);
    state.lastScore = totalScore;
    state.lastScoreTs = now;

    logger.debug('Momentum score', { mint: state.mint, score: totalScore.toFixed(1), breakdown });

    // LIVE TEST diagnostic: surface momentum scoring at info level for EVERY
    // tracked token each cycle (even score 0) so we can confirm the
    // price->accel scoring path is actually running on backlog tokens and see
    // how close each one is to the threshold. A score of 0 means the token is
    // flat / not rising; a trade only fires once a token climbs >= threshold.
    if (totalScore < this.scorer.getThreshold()) {
      logger.info('Momentum below threshold', {
        mint: state.mint,
        score: totalScore.toFixed(1),
        accel: breakdown.accelScore.toFixed(1),
        liquidity: breakdown.liquidityScore.toFixed(1),
        threshold: this.scorer.getThreshold(),
      });
    }

    // FIX: use scorer.getThreshold() instead of hardcoded 65
    if (totalScore >= this.scorer.getThreshold()) {
      logger.info('Momentum signal', { mint: state.mint, score: totalScore.toFixed(1) });
      EventBus.emit('MOMENTUM_SIGNAL', {
        mint: state.mint,
        score: totalScore,
        breakdown,
        ts: now,
      } as MomentumSignalEvent);
    }
  }

  private _evictIdleStates(): void {
    const now = Date.now();
    let evicted = 0;
    for (const [mint, state] of this.states) {
      if (now - state.lastScoreTs > EVICT_AFTER_IDLE_MS) {
        this.states.delete(mint);
        evicted++;
      }
    }
    if (evicted > 0) {
      logger.debug('Evicted idle momentum states', { evicted, remaining: this.states.size });
    }
  }

  getState(mint: string): MomentumState | undefined {
    return this.states.get(mint);
  }

  getTokenCount(): number {
    return this.states.size;
  }
}

export default MomentumEngine;
