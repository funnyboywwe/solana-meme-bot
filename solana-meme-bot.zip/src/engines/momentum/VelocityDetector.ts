import { MomentumState } from '../../core/types';
import { AppConfig } from '../../config/AppConfig';

/**
 * VelocityDetector tracks:
 * - Transaction timestamps (last 200)
 * - Transactions per minute (rolling 60s window)
 * - Normalises to 0–20 points
 *
 * High velocity = sudden uptick in trading activity
 */
export class VelocityDetector {
  private txPerMinThreshold: number;
  private maxTxHistory = 200;

  constructor(cfg: AppConfig) {
    this.txPerMinThreshold = cfg.momentum.txPerMinThreshold; // 20 tx/min threshold
  }

  /**
   * Record transaction timestamp
   */
  update(state: MomentumState, ts: number): void {
    state.txTimestamps.push(ts);

    // Keep only last 200 for memory efficiency
    if (state.txTimestamps.length > this.maxTxHistory) {
      state.txTimestamps.shift();
    }
  }

  /**
   * Compute velocity score (0–20 points)
   * Based on tx/minute in rolling 60-second window
   */
  getScore(state: MomentumState): number {
    if (state.txTimestamps.length === 0) return 0;

    const now = Date.now();
    const windowStart = now - 60000; // 60 second window

    // Count tx in window
    const txInWindow = state.txTimestamps.filter((ts) => ts >= windowStart).length;

    if (txInWindow < this.txPerMinThreshold) {
      return 0;
    }

    // Map [threshold, 5x threshold] to [0, 20]
    const normalized = Math.min((txInWindow / this.txPerMinThreshold) * 10, 20);
    return normalized;
  }
}

export default VelocityDetector;
