import { MomentumState } from '../../core/types';
import { AppConfig } from '../../config/AppConfig';

/**
 * BuyPressure tracks the buy-vs-sell volume ratio over a rolling window.
 *
 * BUG FIXED (#15 companion): Previous version accumulated buySideVol and
 * sellSideVol monotonically with no time windowing. After a few hours all
 * tokens converge toward 50/50 as volumes accumulate equally, making the
 * score useless.
 *
 * FIX: Use a timestamped circular buffer of (ts, side, vol) entries.
 * Only events within the last windowMs are counted.
 */

interface VolumeEntry {
  ts: number;
  buy: boolean;
  vol: number;
}

const MAX_ENTRIES = 500; // per token cap

export class BuyPressure {
  private readonly windowMs: number;
  private readonly buyPressureMin: number;
  // Per-mint event log
  private readonly entries = new Map<string, VolumeEntry[]>();

  constructor(cfg: AppConfig) {
    this.windowMs = cfg.momentum.windowMs;
    this.buyPressureMin = cfg.momentum.buyPressureMin;
  }

  /**
   * Record a trade event on the token's rolling log.
   */
  update(state: MomentumState, side: 'buy' | 'sell', volumeUsd: number): void {
    const mint = state.mint;
    if (!this.entries.has(mint)) this.entries.set(mint, []);
    const log = this.entries.get(mint)!;

    log.push({ ts: Date.now(), buy: side === 'buy', vol: volumeUsd });

    // Evict oldest beyond MAX_ENTRIES (memory cap)
    if (log.length > MAX_ENTRIES) log.shift();

    // Also keep state fields in sync for legacy compatibility
    const now = Date.now();
    const cutoff = now - this.windowMs;
    const active = log.filter((e) => e.ts >= cutoff);

    state.buySideVol = active.filter((e) => e.buy).reduce((s, e) => s + e.vol, 0);
    state.sellSideVol = active.filter((e) => !e.buy).reduce((s, e) => s + e.vol, 0);
  }

  /**
   * Compute buy pressure score (0–20 points) using only the rolling window.
   */
  getScore(state: MomentumState): number {
    const total = state.buySideVol + state.sellSideVol;
    if (total === 0) return 0;

    const buyRatio = state.buySideVol / total;
    if (buyRatio < this.buyPressureMin) return 0;

    return Math.min(((buyRatio - this.buyPressureMin) / (1 - this.buyPressureMin)) * 20, 20);
  }
}

export default BuyPressure;
