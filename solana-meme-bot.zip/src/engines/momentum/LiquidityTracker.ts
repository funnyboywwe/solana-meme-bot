import { MomentumState } from '../../core/types';
import { AppConfig } from '../../config/AppConfig';

/**
 * LiquidityTracker monitors:
 * - Liquidity USD amount (rolling history)
 * - Growth rate = (current - previous) / previous
 * - Normalises to 0–15 points
 *
 * High growth = strong buying pressure, increasing tvl
 */
export class LiquidityTracker {
  private windowMs: number;
  private liquidityGrowthThreshold: number;
  private maxHistoryPoints = 50;

  constructor(cfg: AppConfig) {
    this.windowMs = cfg.momentum.windowMs; // 300000 ms = 5 min
    this.liquidityGrowthThreshold = cfg.momentum.liquidityGrowthPct; // 0.15 = 15%
  }

  /**
   * Record liquidity observation
   */
  update(state: MomentumState, liquidityUsd: number, ts: number): void {
    state.liquidityHistory.push({ liquidity: liquidityUsd, ts });

    // Keep only last 50 for memory
    if (state.liquidityHistory.length > this.maxHistoryPoints) {
      state.liquidityHistory.shift();
    }
  }

  /**
   * Compute liquidity score (0–15 points)
   */
  getScore(state: MomentumState): number {
    if (state.liquidityHistory.length < 2) return 0;

    const now = Date.now();
    const windowStart = now - this.windowMs;

    // Find oldest point in window
    const hist = state.liquidityHistory;
    let oldestIdx = 0;
    for (let i = 0; i < hist.length; i++) {
      const point = hist[i];
      if (point && point.ts >= windowStart) {
        oldestIdx = i;
        break;
      }
    }

    const lastPoint = hist[hist.length - 1];
    const basePoint = oldestIdx > 0 ? hist[oldestIdx - 1] : hist[0];
    if (!lastPoint || !basePoint) return 0;
    const current = lastPoint.liquidity;
    const previous = basePoint.liquidity;

    if (previous === 0) return 0;

    const growth = (current - previous) / previous;

    if (growth < 0) return 0; // Only reward liquidity growth, not decline

    // Map [0, 3x threshold] to [0, 15]
    const normalized = Math.min((growth / (this.liquidityGrowthThreshold * 3)) * 15, 15);
    return normalized;
  }
}

export default LiquidityTracker;
