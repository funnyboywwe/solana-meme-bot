import { AppConfig } from '../../config/AppConfig';

/**
 * MomentumScorer aggregates all detector scores
 *
 * Weights:
 * - Volume spike:     25 points (40%)
 * - Buy pressure:     20 points (32%)
 * - Velocity:         20 points (32%)
 * - Liquidity growth: 15 points (24%)
 * - Price accel:      20 points (32%)
 * ─────────────────────────────────
 * Total max:         100 points
 *
 * Strategy:
 * - Multiple indicators must align
 * - No single detector dominates
 * - Threshold: 65 points triggers MOMENTUM_SIGNAL
 */
export class MomentumScorer {
  private threshold: number;

  constructor(cfg: AppConfig) {
    this.threshold = cfg.trading.strategies.momentum.scoreThreshold; // 65
  }

  /**
   * Compute weighted total score
   * Breakdown is { volumeScore, buyScore, velocityScore, liquidityScore, accelScore }
   */
  computeTotal(breakdown: {
    volumeScore: number;
    buyScore: number;
    velocityScore: number;
    liquidityScore: number;
    accelScore: number;
  }): number {
    // All components sum to 100 if all detectors max out
    const total = breakdown.volumeScore + breakdown.buyScore + breakdown.velocityScore + breakdown.liquidityScore + breakdown.accelScore;

    // Clamp to [0, 100]
    return Math.min(total, 100);
  }

  getThreshold(): number {
    return this.threshold;
  }
}

export default MomentumScorer;
