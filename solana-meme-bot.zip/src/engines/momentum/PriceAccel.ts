import { MomentumState } from '../../core/types';
import { AppConfig } from '../../config/AppConfig';

/**
 * PriceAccel tracks:
 * - Price history (last 10 ticks)
 * - Velocity = rate of price change
 * - Acceleration = rate of velocity change (2nd derivative)
 * - Normalises to 0–20 points
 *
 * High acceleration = price is speeding upward (early pump indicator)
 */
export class PriceAccel {
  private priceAccelThreshold: number;
  private maxPriceHistory = 10;

  constructor(cfg: AppConfig) {
    this.priceAccelThreshold = cfg.momentum.priceAccelThreshold; // 0.02 = 2% accel
  }

  /**
   * Record price tick
   */
  update(state: MomentumState, priceUsd: number, ts: number): void {
    state.priceHistory.push({ price: priceUsd, ts });

    if (state.priceHistory.length > this.maxPriceHistory) {
      state.priceHistory.shift();
    }
  }

  /**
   * Compute price-momentum score (0–20 points).
   *
   * Returns the STRONGER of two upward signals:
   *   A) Sustained upward RETURN over the recent window (1st order). This is the
   *      primary live signal when only Jupiter price data is available — with no
   *      trade stream the volume/buy/velocity detectors stay at 0, so a token that
   *      simply trends up must still be able to score. The old acceleration-only
   *      logic returned 0 for steadily-rising tokens, so no signal ever fired.
   *   B) Upward ACCELERATION (2nd derivative) — the original early-pump indicator,
   *      kept so sharp curve-ups still get rewarded.
   */
  getScore(state: MomentumState): number {
    const hist = state.priceHistory;
    if (hist.length < 3) return 0;

    // ── Score A: upward price return over the window ──
    let returnScore = 0;
    const first = hist[0];
    const last = hist[hist.length - 1];
    if (first && last && first.price > 0) {
      const ret = (last.price - first.price) / first.price; // fractional gain
      if (ret > 0) {
        // priceAccelThreshold reused as the return threshold (0.02 = 2%).
        // 2% over the window => 15 pts (crosses momentum threshold); ~2.7% => 20 (max).
        returnScore = Math.min((ret / this.priceAccelThreshold) * 15, 20);
      }
    }

    // ── Score B: upward acceleration (original 2nd-derivative logic) ──
    let accelScore = 0;
    if (hist.length >= 4) {
      const p1n = hist[hist.length - 1];
      const p0n = hist[hist.length - 2];
      const p2n = hist[hist.length - 3];
      if (p1n && p0n && p2n && p0n.price !== 0) {
        const dt1 = (p1n.ts - p0n.ts) / 1000;
        const v1 = dt1 > 0 ? (p1n.price - p0n.price) / dt1 : 0;
        const dt2 = (p0n.ts - p2n.ts) / 1000;
        const v0 = dt2 > 0 ? (p0n.price - p2n.price) / dt2 : 0;
        const dtMid = (p1n.ts - p2n.ts) / 2000;
        const accel = dtMid > 0 ? (v1 - v0) / dtMid : 0;
        const accelNorm = Math.abs(accel / p0n.price);
        if (accel > 0 && accelNorm >= this.priceAccelThreshold) {
          accelScore = Math.min((accelNorm / this.priceAccelThreshold) * 10, 20);
        }
      }
    }

    // Reward whichever upward signal is stronger; cap at the 20-pt detector weight.
    return Math.min(Math.max(returnScore, accelScore), 20);
  }
}

export default PriceAccel;
