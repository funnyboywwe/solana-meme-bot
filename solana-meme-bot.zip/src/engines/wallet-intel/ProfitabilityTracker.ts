import { createModuleLogger } from '../../core/Logger';

const logger = createModuleLogger('ProfitabilityTracker');

const MAX_TRADE_HISTORY = 200; // per wallet, memory cap

export interface TradeRecord {
  mint: string;
  side: 'buy' | 'sell';
  amountSol: number;
  priceUsd: number;
  ts: number;
}

export interface WalletProfitability {
  totalPnlSol: number;
  avgRoi: number; // average return per closed trade (as fraction)
  maxDrawdown: number; // worst peak-to-trough drawdown
  recentPnlSol: number; // last 30 trades
}

interface OpenLeg {
  mint: string;
  amountSol: number;
  entryPriceUsd: number;
  ts: number;
}

/**
 * ProfitabilityTracker maintains per-wallet:
 * - Open legs (buy side of a trade, waiting for sell)
 * - Closed P&L per round-trip (buy → sell)
 * - Rolling drawdown computation
 * - Recent 30-trade P&L
 */
export class ProfitabilityTracker {
  // walletAddress → list of completed trade PnL values
  private closedPnls = new Map<string, number[]>();
  // walletAddress → open buy legs keyed by mint
  private openLegs = new Map<string, Map<string, OpenLeg>>();

  /**
   * Record a buy event for a wallet
   */
  recordBuy(walletAddress: string, mint: string, amountSol: number, priceUsd: number): void {
    if (!this.openLegs.has(walletAddress)) {
      this.openLegs.set(walletAddress, new Map());
    }
    this.openLegs.get(walletAddress)!.set(mint, {
      mint,
      amountSol,
      entryPriceUsd: priceUsd,
      ts: Date.now(),
    });
  }

  /**
   * Record a sell event, close the matching buy leg and compute PnL
   * Returns the realised PnL in SOL (or undefined if no matching buy)
   */
  recordSell(
    walletAddress: string,
    mint: string,
    exitPriceUsd: number,
  ): number | undefined {
    const legs = this.openLegs.get(walletAddress);
    const leg = legs?.get(mint);
    if (!leg) return undefined;

    legs!.delete(mint);

    // ROI = (exit - entry) / entry
    const roi =
      leg.entryPriceUsd > 0
        ? (exitPriceUsd - leg.entryPriceUsd) / leg.entryPriceUsd
        : 0;

    // PnL in SOL terms
    const pnlSol = leg.amountSol * roi;

    if (!this.closedPnls.has(walletAddress)) {
      this.closedPnls.set(walletAddress, []);
    }
    const history = this.closedPnls.get(walletAddress)!;
    history.push(pnlSol);

    // Keep capped at MAX_TRADE_HISTORY
    if (history.length > MAX_TRADE_HISTORY) {
      history.shift();
    }

    logger.debug('Wallet trade closed', {
      wallet: walletAddress,
      mint,
      roi: (roi * 100).toFixed(2) + '%',
      pnlSol: pnlSol.toFixed(6),
    });

    return pnlSol;
  }

  /**
   * Compute full profitability summary for a wallet
   */
  getSummary(walletAddress: string): WalletProfitability {
    const history = this.closedPnls.get(walletAddress) ?? [];

    const totalPnlSol = history.reduce((s, v) => s + v, 0);

    // Average ROI (as fraction, not %)
    const avgRoi =
      history.length > 0
        ? history.reduce((s, v) => s + v, 0) / history.length
        : 0;

    // Recent 30
    const recent30 = history.slice(-30);
    const recentPnlSol = recent30.reduce((s, v) => s + v, 0);

    // Max drawdown: worst peak-to-trough in cumulative PnL curve
    let peak = 0;
    let cumulative = 0;
    let maxDrawdown = 0;
    for (const pnl of history) {
      cumulative += pnl;
      if (cumulative > peak) peak = cumulative;
      const drawdown = peak > 0 ? (peak - cumulative) / peak : 0;
      if (drawdown > maxDrawdown) maxDrawdown = drawdown;
    }

    return { totalPnlSol, avgRoi, maxDrawdown, recentPnlSol };
  }

  getTradeCount(walletAddress: string): number {
    return this.closedPnls.get(walletAddress)?.length ?? 0;
  }

  hasOpenLeg(walletAddress: string, mint: string): boolean {
    return this.openLegs.get(walletAddress)?.has(mint) ?? false;
  }
}

export default ProfitabilityTracker;
