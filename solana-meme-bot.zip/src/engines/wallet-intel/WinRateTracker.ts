import { createModuleLogger } from '../../core/Logger';

const logger = createModuleLogger('WinRateTracker');

const RECENT_WINDOW = 30;
const MAX_HISTORY = 200;

/**
 * WinRateTracker maintains:
 * - Lifetime win/loss counts per wallet
 * - Rolling 30-trade win rate ("recent accuracy")
 * - Streak tracking (current win/loss streak)
 */
export class WinRateTracker {
  // walletAddress → boolean[] (true = win, false = loss)
  private outcomes = new Map<string, boolean[]>();

  /**
   * Record outcome of a closed trade
   */
  record(walletAddress: string, profitableTrade: boolean): void {
    if (!this.outcomes.has(walletAddress)) {
      this.outcomes.set(walletAddress, []);
    }
    const hist = this.outcomes.get(walletAddress)!;
    hist.push(profitableTrade);
    if (hist.length > MAX_HISTORY) hist.shift();

    logger.debug('Win/loss recorded', {
      wallet: walletAddress,
      win: profitableTrade,
      lifetimeWinRate: (this.getLifetimeWinRate(walletAddress) * 100).toFixed(1) + '%',
    });
  }

  /**
   * Lifetime win rate (0–1)
   */
  getLifetimeWinRate(walletAddress: string): number {
    const hist = this.outcomes.get(walletAddress) ?? [];
    if (hist.length === 0) return 0;
    const wins = hist.filter(Boolean).length;
    return wins / hist.length;
  }

  /**
   * Rolling 30-trade win rate (0–1)
   */
  getRecentWinRate(walletAddress: string): number {
    const hist = this.outcomes.get(walletAddress) ?? [];
    const recent = hist.slice(-RECENT_WINDOW);
    if (recent.length === 0) return 0;
    const wins = recent.filter(Boolean).length;
    return wins / recent.length;
  }

  /**
   * Total trades recorded
   */
  getTotalTrades(walletAddress: string): number {
    return this.outcomes.get(walletAddress)?.length ?? 0;
  }

  /**
   * Profitable trade count
   */
  getProfitableCount(walletAddress: string): number {
    return this.outcomes.get(walletAddress)?.filter(Boolean).length ?? 0;
  }

  /**
   * Current streak (positive = win streak, negative = loss streak)
   */
  getCurrentStreak(walletAddress: string): number {
    const hist = this.outcomes.get(walletAddress) ?? [];
    if (hist.length === 0) return 0;

    const lastOutcome = hist[hist.length - 1]!;
    let streak = 0;
    for (let i = hist.length - 1; i >= 0; i--) {
      if (hist[i] === lastOutcome) {
        streak++;
      } else {
        break;
      }
    }
    return lastOutcome ? streak : -streak;
  }
}

export default WinRateTracker;
