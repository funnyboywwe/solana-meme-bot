import { createModuleLogger } from '../../core/Logger';
import WalletRepository from '../../db/repositories/WalletRepository';
import { WalletStats } from '../../core/types';

const logger = createModuleLogger('WalletRanker');

/**
 * WalletRanker runs on a schedule (default 1 hour) and:
 * 1. Fetches all active wallets
 * 2. Sorts by quality_score DESC
 * 3. Writes ranks back to DB
 * 4. Promotes inactive wallets that have improved their score
 * 5. Demotes wallets with persistently low scores
 *
 * Quality score formula (used by WalletScorer, consumed here):
 *   score = (winRate * 30)
 *         + (min(avgRoi, 5) / 5 * 30)
 *         + (recentWinRate * 20)
 *         + (min(tradeCount, 200) / 200 * 10)
 *         - (maxDrawdown * 10)
 *   clamped [0, 100]
 */
export class WalletRanker {
  private refreshIntervalMs: number;
  private timer: NodeJS.Timeout | null = null;
  private DEMOTION_THRESHOLD = 30; // score below this → deactivate
  private PROMOTION_THRESHOLD = 50; // inactive wallet above this → reactivate
  private MIN_TRADES_TO_RANK = 10;

  constructor(refreshIntervalMs: number) {
    this.refreshIntervalMs = refreshIntervalMs;
  }

  /**
   * Start periodic ranking
   */
  start(): void {
    this.rank(); // immediate
    this.timer = setInterval(() => this.rank(), this.refreshIntervalMs);
    this.timer.unref();
    logger.info('WalletRanker started', { intervalMs: this.refreshIntervalMs });
  }

  stop(): void {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }

  /**
   * Run one ranking cycle
   */
  rank(): void {
    try {
      const allWallets = WalletRepository.findActive();
      const eligible = allWallets.filter(
        (w) => w.totalTrades >= this.MIN_TRADES_TO_RANK,
      );

      // Sort by quality score descending
      eligible.sort((a, b) => b.qualityScore - a.qualityScore);

      // Write ranks to DB
      const rankedAddresses = eligible.map((w) => w.address);
      if (rankedAddresses.length > 0) {
        WalletRepository.updateRanks(rankedAddresses);
      }

      // Demotion: deactivate wallets with consistently low score
      for (const wallet of eligible) {
        if (
          wallet.qualityScore < this.DEMOTION_THRESHOLD &&
          wallet.totalTrades >= this.MIN_TRADES_TO_RANK * 2
        ) {
          this._demote(wallet);
        }
      }

      logger.info('Wallet ranking complete', {
        ranked: eligible.length,
        top3: eligible.slice(0, 3).map((w) => ({
          addr: w.address.slice(0, 8) + '...',
          score: w.qualityScore.toFixed(1),
        })),
      });
    } catch (err) {
      logger.error('Wallet ranking failed', { error: String(err) });
    }
  }

  private _demote(wallet: WalletStats): void {
    logger.info('Demoting low-performing wallet', {
      address: wallet.address,
      score: wallet.qualityScore,
    });
    WalletRepository.upsert({
      ...wallet,
      isActive: false,
      updatedAt: Date.now(),
    });
  }

  getTopWallets(limit: number): WalletStats[] {
    return WalletRepository.findTopByScore(limit);
  }
}

export default WalletRanker;
