import { WalletTxEvent } from '../../core/EventBus';
import { AppConfig } from '../../config/AppConfig';
import { createModuleLogger } from '../../core/Logger';
import WalletRepository from '../../db/repositories/WalletRepository';
import { ProfitabilityTracker } from './ProfitabilityTracker';
import { WinRateTracker } from './WinRateTracker';
import { WalletRanker } from './WalletRanker';

const logger = createModuleLogger('WalletIntelEngine');

/**
 * WalletIntelEngine is the central coordinator for wallet quality tracking.
 *
 * On every WALLET_TX:
 *   1. Auto-discover new wallets (if enabled)
 *   2. Record buy/sell in ProfitabilityTracker
 *   3. On sell: compute PnL, record win/loss in WinRateTracker
 *   4. Recompute quality score, persist to DB
 *
 * WalletRanker runs hourly, sorts by score, writes ranks.
 *
 * Quality score formula (0-100):
 *   winRate            x 30  pts
 *   avgRoi (capped 5x) x 30  pts
 *   recentWinRate      x 20  pts
 *   tradeCount ratio   x 10  pts
 *   maxDrawdown penalty x 10  pts (negative)
 */
export class WalletIntelEngine {
  private profitabilityTracker: ProfitabilityTracker;
  private winRateTracker: WinRateTracker;
  private walletRanker: WalletRanker;
  private cfg: AppConfig;
  private autoDiscover: boolean;
  private minTradesForScore: number;

  constructor(cfg: AppConfig) {
    this.cfg = cfg;
    this.autoDiscover = cfg.walletIntel.autoDiscoverFromCopies;
    this.minTradesForScore = cfg.walletIntel.minTradesForScore;

    this.profitabilityTracker = new ProfitabilityTracker();
    this.winRateTracker = new WinRateTracker();
    this.walletRanker = new WalletRanker(cfg.walletIntel.rankingRefreshIntervalMs);

    for (const address of cfg.walletIntel.monitoredWallets) {
      this._ensureWalletExists(address);
    }

    this.walletRanker.start();

    logger.info('WalletIntelEngine initialized', {
      seededWallets: cfg.walletIntel.monitoredWallets.length,
      autoDiscover: this.autoDiscover,
    });
  }

  processWalletTx(event: WalletTxEvent): void {
    const { walletAddress, mint, side, amountSol, priceUsd } = event;

    if (this.autoDiscover) {
      this._ensureWalletExists(walletAddress);
    } else if (!WalletRepository.exists(walletAddress)) {
      return;
    }

    if (side === 'buy') {
      this.profitabilityTracker.recordBuy(walletAddress, mint, amountSol, priceUsd);
      logger.debug('Wallet buy recorded', { wallet: walletAddress, mint });
    } else {
      const pnlSol = this.profitabilityTracker.recordSell(walletAddress, mint, priceUsd);
      if (pnlSol !== undefined) {
        const profitable = pnlSol > 0;
        this.winRateTracker.record(walletAddress, profitable);
        WalletRepository.incrementTrade(walletAddress, profitable, pnlSol);
        this._recomputeScore(walletAddress);
        logger.info('Wallet sell processed', {
          wallet: walletAddress,
          mint,
          pnlSol: pnlSol.toFixed(6),
          profitable,
        });
      }
    }
  }

  private _recomputeScore(walletAddress: string): void {
    const stats = WalletRepository.findByAddress(walletAddress);
    if (!stats) return;

    const profSummary = this.profitabilityTracker.getSummary(walletAddress);
    const recentWinRate = this.winRateTracker.getRecentWinRate(walletAddress);
    const tradeCount = this.winRateTracker.getTotalTrades(walletAddress);

    const score = this._computeScore({
      winRate: stats.winRate,
      avgRoi: profSummary.avgRoi,
      recentWinRate,
      tradeCount,
      maxDrawdown: profSummary.maxDrawdown,
    });

    WalletRepository.upsert({
      ...stats,
      qualityScore: score,
      winRate: this.winRateTracker.getLifetimeWinRate(walletAddress),
      avgRoi: profSummary.avgRoi,
      totalTrades: tradeCount,
      profitableTrades: this.winRateTracker.getProfitableCount(walletAddress),
      totalPnlSol: profSummary.totalPnlSol,
      updatedAt: Date.now(),
    });

    logger.debug('Wallet score updated', { wallet: walletAddress, score: score.toFixed(1) });
  }

  private _computeScore(params: {
    winRate: number;
    avgRoi: number;
    recentWinRate: number;
    tradeCount: number;
    maxDrawdown: number;
  }): number {
    const { winRate, avgRoi, recentWinRate, tradeCount, maxDrawdown } = params;
    const winRateScore = winRate * 30;
    const roiCapped = Math.min(Math.max(avgRoi, 0), 5);
    const roiScore = (roiCapped / 5) * 30;
    const recentScore = recentWinRate * 20;
    const maturityScore = (Math.min(tradeCount, 200) / 200) * 10;
    const drawdownPenalty = Math.min(maxDrawdown, 1) * 10;
    const total = winRateScore + roiScore + recentScore + maturityScore - drawdownPenalty;
    return Math.max(0, Math.min(100, total));
  }

  getWalletScore(walletAddress: string): number {
    return WalletRepository.findByAddress(walletAddress)?.qualityScore ?? 0;
  }

  getMonitoredWallets(): string[] {
    return WalletRepository.findActive().map((w) => w.address);
  }

  addWallet(address: string, label?: string): void {
    this._ensureWalletExists(address, label);
    logger.info('Wallet manually added', { address, label });
  }

  private _ensureWalletExists(address: string, label?: string): void {
    if (!WalletRepository.exists(address)) {
      WalletRepository.upsert({
        address,
        label,
        qualityScore: 0,
        winRate: 0,
        avgRoi: 0,
        totalTrades: 0,
        profitableTrades: 0,
        totalPnlSol: 0,
        addedAt: Date.now(),
        updatedAt: Date.now(),
        isActive: true,
      });
    }
  }

  stop(): void {
    this.walletRanker.stop();
  }
}

export default WalletIntelEngine;
