import { EventBus, TradeDetectedEvent, VolumeAccelerationEvent } from '../../core/EventBus';
import { AppConfig } from '../../config/AppConfig';
import { ExtendedConfig } from '../../config/schema';
import { createModuleLogger } from '../../core/Logger';
import { VolumeAccelerationData } from '../../core/types';
import { getDb } from '../../db/Database';

const logger = createModuleLogger('VolumeAccelerationEngine');

interface TradeEntry {
  ts: number;
  side: 'buy' | 'sell';
  usd: number;
}

interface TokenVolumeState {
  mint: string;
  trades: TradeEntry[];
  lastRankTs: number;
  lastScore: number;
}

/**
 * VolumeAccelerationEngine measures:
 * - Volume velocity (USD/min over rolling window)
 * - Volume acceleration (rate of change of velocity)
 * - Buy/sell ratio
 * - Trade frequency growth
 *
 * Ranks all tracked tokens by acceleration score every `rankingIntervalMs`.
 * Emits VOLUME_ACCELERATION for any token crossing minAccelerationScore.
 */
export class VolumeAccelerationEngine {
  private cfg: ExtendedConfig['volumeAcceleration'];
  private states = new Map<string, TokenVolumeState>();
  private rankings: VolumeAccelerationData[] = [];
  private rankingTimer: NodeJS.Timeout;
  private readonly MAX_TRADES_PER_TOKEN = 500;

  constructor(_baseCfg: AppConfig, extCfg: ExtendedConfig) {
    this.cfg = extCfg.volumeAcceleration;

    this.rankingTimer = setInterval(() => this._rankAll(), this.cfg.rankingIntervalMs);
    this.rankingTimer.unref();

    logger.info('VolumeAccelerationEngine initialized', {
      minScore: this.cfg.minAccelerationScore,
      window: this.cfg.windowMs,
    });
  }

  processTrade(event: TradeDetectedEvent): void {
    if (!this.cfg.enabled) return;
    const { mint, side, amountUsd, ts } = event;

    if (!this.states.has(mint)) {
      this.states.set(mint, { mint, trades: [], lastRankTs: 0, lastScore: 0 });
    }

    // Evict oldest tokens if over limit
    if (this.states.size > this.cfg.maxTrackedTokens) {
      this._evictColdest();
    }

    const state = this.states.get(mint)!;
    state.trades.push({ ts, side, usd: amountUsd });

    // Keep bounded
    if (state.trades.length > this.MAX_TRADES_PER_TOKEN) state.trades.shift();

    // Compute score on the fly; emit if above threshold
    const data = this._computeScore(state);
    if (data && data.accelerationScore >= this.cfg.minAccelerationScore) {
      if (data.accelerationScore > state.lastScore + 5) {
        state.lastScore = data.accelerationScore;
        this._persistAndEmit(data);
      }
    }
  }

  private _computeScore(state: TokenVolumeState): VolumeAccelerationData | null {
    const now = Date.now();
    const windowMs = this.cfg.windowMs;

    const recent = state.trades.filter((t) => t.ts >= now - windowMs);
    if (recent.length < 3) return null;

    const recent1m = state.trades.filter((t) => t.ts >= now - 60_000);
    const recent5m = state.trades.filter((t) => t.ts >= now - 300_000);
    const recent15m = state.trades.filter((t) => t.ts >= now - 900_000);

    const vol1m = recent1m.reduce((s, t) => s + t.usd, 0);
    const vol5m = recent5m.reduce((s, t) => s + t.usd, 0);
    const vol15m = recent15m.reduce((s, t) => s + t.usd, 0);

    // Velocity: USD per minute over last 5 min
    const vel5m = vol5m / 5;
    const vel1m = vol1m;

    // Acceleration: change in velocity (1m vs 5m rate)
    const acceleration = vel5m > 0 ? (vel1m - vel5m) / vel5m : 0;

    // Buy/sell ratio
    const buyVol = recent.filter((t) => t.side === 'buy').reduce((s, t) => s + t.usd, 0);
    const sellVol = recent.filter((t) => t.side === 'sell').reduce((s, t) => s + t.usd, 0);
    const buySellRatio = sellVol > 0 ? buyVol / sellVol : buyVol > 0 ? 3 : 1;

    // Trade frequency growth (compare last 1m vs avg of 5m window)
    const freqNow = recent1m.length;
    const freqAvg = recent5m.length / 5;
    const freqGrowthPct = freqAvg > 0 ? ((freqNow - freqAvg) / freqAvg) * 100 : 0;

    // Composite score (0-100)
    const accelScore = Math.min(Math.max(acceleration * 40, 0), 35);
    const bsScore = Math.min(((buySellRatio - 1) / 3) * 25, 25);
    const freqScore = Math.min((freqGrowthPct / 200) * 20, 20);
    const volScore = Math.min((vol1m / 10000) * 20, 20);

    const accelerationScore = Math.min(accelScore + bsScore + freqScore + volScore, 100);

    return {
      tokenMint: state.mint,
      volume1mUsd: vol1m,
      volume5mUsd: vol5m,
      volume15mUsd: vol15m,
      velocityUsdPerMin: vel5m,
      acceleration,
      buySellRatio,
      tradeFreqPerMin: freqNow,
      freqGrowthPct,
      accelerationScore,
      ts: now,
    };
  }

  private _rankAll(): void {
    const now = Date.now();
    const results: VolumeAccelerationData[] = [];

    for (const state of this.states.values()) {
      const data = this._computeScore(state);
      if (data) results.push(data);
    }

    // Sort descending by score
    results.sort((a, b) => b.accelerationScore - a.accelerationScore);
    results.forEach((r, i) => { r.rank = i + 1; });
    this.rankings = results;

    // Persist top 20 to DB
    const db = getDb();
    const insert = db.prepare(`
      INSERT INTO volume_acceleration
        (token_mint, volume_1m_usd, volume_5m_usd, volume_15m_usd, velocity_usd_per_min,
         acceleration, buy_sell_ratio, trade_freq_per_min, freq_growth_pct, acceleration_score, rank, ts)
      VALUES (@token_mint, @volume_1m_usd, @volume_5m_usd, @volume_15m_usd, @velocity_usd_per_min,
              @acceleration, @buy_sell_ratio, @trade_freq_per_min, @freq_growth_pct, @acceleration_score, @rank, @ts)
    `);

    const tx = db.transaction(() => {
      for (const r of results.slice(0, 20)) {
        insert.run({
          token_mint: r.tokenMint,
          volume_1m_usd: r.volume1mUsd,
          volume_5m_usd: r.volume5mUsd,
          volume_15m_usd: r.volume15mUsd,
          velocity_usd_per_min: r.velocityUsdPerMin,
          acceleration: r.acceleration,
          buy_sell_ratio: r.buySellRatio,
          trade_freq_per_min: r.tradeFreqPerMin,
          freq_growth_pct: r.freqGrowthPct,
          acceleration_score: r.accelerationScore,
          rank: r.rank ?? 0,
          ts: now,
        });
      }
    });
    tx();

    logger.debug('Volume ranking complete', {
      tracked: this.states.size,
      top3: results.slice(0, 3).map((r) => ({ mint: r.tokenMint.slice(0, 8), score: r.accelerationScore.toFixed(1) })),
    });
  }

  private _persistAndEmit(data: VolumeAccelerationData): void {
    EventBus.emit('VOLUME_ACCELERATION', {
      tokenMint: data.tokenMint,
      accelerationScore: data.accelerationScore,
      rank: data.rank ?? 0,
      velocity: data.velocityUsdPerMin,
      buySellRatio: data.buySellRatio,
      ts: data.ts,
    } as VolumeAccelerationEvent);
  }

  private _evictColdest(): void {
    let oldestMint = '';
    let oldestTs = Infinity;
    for (const [mint, state] of this.states) {
      const lastTrade = state.trades[state.trades.length - 1]?.ts ?? 0;
      if (lastTrade < oldestTs) {
        oldestTs = lastTrade;
        oldestMint = mint;
      }
    }
    if (oldestMint) this.states.delete(oldestMint);
  }

  getTopTokens(limit = 10): VolumeAccelerationData[] {
    return this.rankings.slice(0, limit);
  }

  getScore(mint: string): number {
    const state = this.states.get(mint);
    if (!state) return 0;
    return this._computeScore(state)?.accelerationScore ?? 0;
  }

  stop(): void {
    clearInterval(this.rankingTimer);
  }
}

export default VolumeAccelerationEngine;
