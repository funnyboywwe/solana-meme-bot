import { AppConfig } from '../../config/AppConfig';
import { createModuleLogger } from '../../core/Logger';
import axios from 'axios';

const logger = createModuleLogger('LiquidityChecker');

const WSOL = 'So11111111111111111111111111111111111111112';
const RAYDIUM_V3_MINT_POOLS = 'https://api-v3.raydium.io/pools/info/mint';

export interface LiquidityResult {
  pass: boolean;
  liquidityUsd: number;
}

interface V3Mint {
  address: string;
  symbol?: string;
  decimals?: number;
}

interface V3Pool {
  id: string;
  mintA: V3Mint;
  mintB: V3Mint;
  /** Total value locked in USD, provided directly by the V3 API. */
  tvl?: number;
  lpMint?: V3Mint;
}

interface V3MintPoolsResponse {
  id?: string;
  success?: boolean;
  data?: {
    count?: number;
    data?: V3Pool[];
    hasNextPage?: boolean;
  };
}

/**
 * LiquidityChecker verifies a token has adequate liquidity.
 *
 * MIGRATION (Pass 15): The previous code hit the deprecated Raydium V2 host
 * `https://api.mainnet.raydium.io/v2/main/pairs`, which no longer resolves
 * (getaddrinfo ENOTFOUND). It is replaced by the Raydium V3 per-mint endpoint
 * `https://api-v3.raydium.io/pools/info/mint`, which returns the SOL-paired
 * pool's TVL directly in USD. This removes the old reserve x SOL-price
 * estimation (and the getSolPriceUsd dependency), which was both fragile and a
 * single point of failure.
 */
export class LiquidityChecker {
  private minLiquidityUsd: number;

  constructor(cfg: AppConfig) {
    this.minLiquidityUsd = cfg.safety.minLiquidityUsd;
  }

  async check(mint: string): Promise<LiquidityResult> {
    try {
      // Query Raydium V3 for every pool that contains this mint.
      const response = await axios.get<V3MintPoolsResponse>(RAYDIUM_V3_MINT_POOLS, {
        timeout: 5000,
        params: {
          mint1: mint,
          poolType: 'all',
          poolSortField: 'liquidity',
          sortType: 'desc',
          pageSize: 100,
          page: 1,
        },
      });

      const pools: V3Pool[] = response.data?.data?.data ?? [];

      // Keep only SOL-paired pools for this mint (either side may be WSOL).
      const solPools = pools.filter(
        (p) =>
          (p.mintA?.address === mint && p.mintB?.address === WSOL) ||
          (p.mintB?.address === mint && p.mintA?.address === WSOL),
      );

      if (solPools.length === 0) {
        // Not on Raydium — many trending tokens trade on PumpSwap / Meteora /
        // Orca, which this Raydium-only check can't see. Fall back to the
        // liquidity DexScreener reports so these tokens aren't auto-rejected.
        const dsLiquidityUsd = await this._dexScreenerLiquidity(mint);
        logger.debug('No Raydium SOL pool; using DexScreener liquidity', { mint, dsLiquidityUsd });
        return { pass: dsLiquidityUsd >= this.minLiquidityUsd, liquidityUsd: dsLiquidityUsd };
      }

      // Use the deepest pool's TVL (already denominated in USD by the V3 API).
      const liquidityUsd = solPools.reduce(
        (max, p) => Math.max(max, Number(p.tvl ?? 0)),
        0,
      );

      return { pass: liquidityUsd >= this.minLiquidityUsd, liquidityUsd };
    } catch (err) {
      logger.warn('Liquidity check failed', { mint, error: String(err) });
      return { pass: false, liquidityUsd: 0 };
    }
  }

  /** Fallback: read the deepest pair's USD liquidity from DexScreener. */
  private async _dexScreenerLiquidity(mint: string): Promise<number> {
    try {
      const resp = await axios.get<Array<{ liquidity?: { usd?: number } }>>(
        "https://api.dexscreener.com/tokens/v1/solana/" + mint,
        { timeout: 5000 },
      );
      const pairs = Array.isArray(resp.data) ? resp.data : [];
      return pairs.reduce((max, p) => Math.max(max, Number(p.liquidity?.usd ?? 0)), 0);
    } catch (err) {
      logger.warn('DexScreener liquidity fallback failed', { mint, error: String(err) });
      return 0;
    }
  }
}

export default LiquidityChecker;
