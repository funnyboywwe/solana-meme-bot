import { AppConfig } from '../../config/AppConfig';
import { createModuleLogger } from '../../core/Logger';
import axios from 'axios';

const logger = createModuleLogger('HoneypotDetector');

export interface HoneypotDetectionResult {
  isHoneypot: boolean;
  sellTaxPct?: number;
  reason?: string;
}

/**
 * HoneypotDetector simulates a sell to detect tokens that cannot be sold.
 *
 * BUG FIXED (#12): Previous version returned isHoneypot:true on ANY
 * network/API error, including Jupiter being rate-limited or temporarily
 * unavailable. This caused ALL tokens to fail safety whenever Jupiter
 * had a blip.
 *
 * FIX: On network error return isHoneypot:false (allow through) with a
 * log warning. Only return isHoneypot:true when we CONFIRM the swap is
 * unavailable (404 from Jupiter quote, explicit no-route error) or the
 * computed sell tax exceeds 50%.
 *
 * Honeypot signals (true positives):
 * - Jupiter /quote returns no route for the sell direction
 * - Sell tax > 50% (price impact is extreme)
 *
 * Non-honeypot signals (false positives to avoid):
 * - Network timeout
 * - Jupiter 429 rate limit
 * - Any non-route-specific error
 */
export class HoneypotDetector {
  private jupiterApiUrl: string;
  private jupiterApiKey: string;
  private readonly HIGH_SELL_TAX_PCT = 50;

  constructor(cfg: AppConfig) {
    // FIX (#10): mirror JupiterClient — use the keyed host + x-api-key header
    // when a Jupiter API key is configured (higher rate limits, fewer 429s).
    this.jupiterApiKey = cfg.execution.jupiterApiKey ?? '';
    this.jupiterApiUrl = this.jupiterApiKey
      ? cfg.execution.jupiterApiUrl.replace('lite-api.jup.ag', 'api.jup.ag')
      : cfg.execution.jupiterApiUrl;
  }

  // FIX (#10): `decimals` defaults to 6 (the pump.fun/Solana meme default the
  // rest of the codebase assumes). Callers that know the real mint decimals
  // should pass them so the sell probe is exactly ~1 token.
  async detect(mint: string, decimals = 6): Promise<HoneypotDetectionResult> {
    const wsolMint = 'So11111111111111111111111111111111111111112';

    try {
      const response = await axios.get<{
        outAmount: string;
        inAmount: string;
        priceImpactPct: string;
      }>(
        `${this.jupiterApiUrl}/quote`,
        {
          params: {
            inputMint: mint,
            outputMint: wsolMint,
            // FIX (#10): probe with ~1 whole token in the token's own base units
            // instead of a hardcoded 1e9 (= 1000 tokens for a 6-decimal meme
            // token), which produced false extreme-price-impact honeypot hits.
            amount: Math.pow(10, decimals).toString(),
            slippageBps: 1000,
          },
          headers: this.jupiterApiKey ? { 'x-api-key': this.jupiterApiKey } : undefined,
          timeout: 5000,
        },
      );

      const data = response.data;
      if (!data?.outAmount) {
        // Explicit empty response = no route = likely honeypot
        logger.warn('Honeypot suspected: no sell route from Jupiter', { mint });
        return { isHoneypot: true, reason: 'no_sell_route' };
      }

      // Check effective sell tax from price impact
      const priceImpact = parseFloat(data.priceImpactPct ?? '0');
      if (priceImpact > this.HIGH_SELL_TAX_PCT) {
        logger.warn('Honeypot suspected: extreme sell tax', { mint, sellTaxPct: priceImpact });
        return { isHoneypot: true, sellTaxPct: priceImpact, reason: 'extreme_sell_tax' };
      }

      return { isHoneypot: false, sellTaxPct: priceImpact };
    } catch (err: unknown) {
      // FIX: distinguish "no route" (404/specific error) from network issues
      if (axios.isAxiosError(err)) {
        const status = err.response?.status;
        const errorData = err.response?.data as Record<string, unknown> | undefined;

        // Jupiter returns 400 with specific error messages for no-route scenarios
        if (status === 400) {
          const errMsg = String(errorData?.error ?? '');
          if (errMsg.includes('Could not find any route') || errMsg.includes('No routes')) {
            logger.warn('Honeypot confirmed: Jupiter explicitly says no route', { mint });
            return { isHoneypot: true, reason: 'no_route_400' };
          }
        }

        // Rate limit or server error = network issue, not a honeypot signal
        if (status === 429 || (status !== undefined && status >= 500)) {
          logger.warn('Honeypot check skipped: Jupiter API error (not a honeypot signal)', { mint, status });
          return { isHoneypot: false, reason: 'api_unavailable' };
        }
      }

      // Unknown error — log and allow through (do not block on uncertainty)
      logger.warn('Honeypot detection error, allowing token through', { mint, error: String(err) });
      return { isHoneypot: false, reason: 'detection_error' };
    }
  }
}
