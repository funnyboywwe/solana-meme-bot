import { PublicKey } from '@solana/web3.js';
import axios from 'axios';
import { AppConfig } from '../../config/AppConfig';
import { createModuleLogger } from '../../core/Logger';
import { getRpcManager, RpcManager } from '../../core/RpcManager';

const logger = createModuleLogger('LpLockChecker');

const WSOL = 'So11111111111111111111111111111111111111112';

/**
 * Owners that indicate burned / unrecoverable LP. If the LP tokens live in a
 * token account owned by one of these, the liquidity can no longer be pulled
 * by the deployer (the #1 meme-coin rug vector).
 */
const BURN_OWNERS = new Set<string>([
  '1nc1nerator11111111111111111111111111111111', // SPL incinerator
  '11111111111111111111111111111111', // System program / null owner
]);

// Raydium V3 pool shape (api-v3.raydium.io). The deprecated V2 host
// (api.mainnet.raydium.io) no longer resolves, so lpMint resolution now uses
// the V3 per-mint endpoint below.
interface V3Mint {
  address: string;
  symbol?: string;
  decimals?: number;
}

interface V3Pool {
  id: string;
  mintA: V3Mint;
  mintB: V3Mint;
  tvl?: number;
  lpMint?: V3Mint;
}

interface V3MintPoolsResponse {
  id?: string;
  success?: boolean;
  data?: {
    count?: number;
    data?: V3Pool[];
    hasNextPage?: boolean;
  };
}

export interface LpLockResult {
  /** false when we could not determine (no pool indexed yet / RPC error). */
  checked: boolean;
  /** true when burned/locked pct >= configured threshold. */
  locked: boolean;
  /** Percentage of LP supply held by burn/null owners (0..100). */
  burnedPct: number;
  lpMint?: string;
  reason?: string;
}

/**
 * LpLockChecker verifies that the LP tokens for a token's SOL pool have been
 * burned (or sent to a null/locker owner), which prevents a "liquidity pull"
 * rug. Strategy:
 *   1. Resolve the Raydium SOL-paired pool's lpMint.
 *   2. Read total LP supply (getTokenSupply).
 *   3. Read the largest LP holders (getTokenLargestAccounts) and resolve each
 *      account's owner (getParsedAccountInfo).
 *   4. Sum LP held by burn/null owners; if supply is zero, treat as fully
 *      burned.
 */
export class LpLockChecker {
  private rpc: RpcManager;
  private minLockedPct: number;

  constructor(cfg: AppConfig) {
    this.rpc = getRpcManager(cfg);
    this.minLockedPct = cfg.safety.minLpLockedPct;
  }

  async check(mint: string): Promise<LpLockResult> {
    try {
      const lpMint = await this._findLpMint(mint);
      if (!lpMint) {
        return { checked: false, locked: false, burnedPct: 0, reason: 'no Raydium pool / lpMint found' };
      }

      const conn = this.rpc.getConnection();
      const lpKey = new PublicKey(lpMint);

      const supplyResp = await conn.getTokenSupply(lpKey);
      const totalSupply = BigInt(supplyResp.value.amount);
      if (totalSupply === 0n) {
        return { checked: true, locked: true, burnedPct: 100, lpMint, reason: 'LP supply is zero (fully burned)' };
      }

      const largest = await conn.getTokenLargestAccounts(lpKey);
      let burned = 0n;
      for (const acct of largest.value) {
        const info = await conn.getParsedAccountInfo(acct.address);
        const data = info.value?.data;
        let owner: string | undefined;
        if (data && typeof data === 'object' && 'parsed' in data) {
          const parsed = (data as { parsed?: { info?: { owner?: string } } }).parsed;
          owner = parsed?.info?.owner;
        }
        if (owner && BURN_OWNERS.has(owner)) {
          burned += BigInt(acct.amount);
        }
      }

      const burnedPct = Number((burned * 10000n) / totalSupply) / 100;
      const locked = burnedPct >= this.minLockedPct;
      logger.info('LP lock check', { mint, lpMint, burnedPct: burnedPct.toFixed(2), locked });
      return { checked: true, locked, burnedPct, lpMint };
    } catch (err) {
      logger.warn('LP lock check failed', { mint, error: err instanceof Error ? err.message : String(err) });
      return { checked: false, locked: false, burnedPct: 0, reason: 'rpc error' };
    }
  }

  private async _findLpMint(mint: string): Promise<string | null> {
    try {
      // Raydium V3 per-mint pools endpoint. Restrict to 'standard' AMM pools,
      // which expose an lpMint (CLMM concentrated pools have no LP token).
      const response = await axios.get<V3MintPoolsResponse>(
        'https://api-v3.raydium.io/pools/info/mint',
        {
          timeout: 5000,
          params: {
            mint1: mint,
            poolType: 'standard',
            poolSortField: 'liquidity',
            sortType: 'desc',
            pageSize: 100,
            page: 1,
          },
        },
      );
      const pools: V3Pool[] = response.data?.data?.data ?? [];
      const pool = pools.find(
        (p) =>
          (p.mintA?.address === mint && p.mintB?.address === WSOL) ||
          (p.mintB?.address === mint && p.mintA?.address === WSOL),
      );
      return pool?.lpMint?.address ?? null;
    } catch {
      return null;
    }
  }
}

export default LpLockChecker;
