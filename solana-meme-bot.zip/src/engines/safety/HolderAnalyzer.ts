import { AppConfig } from '../../config/AppConfig';
import { createModuleLogger } from '../../core/Logger';
import axios from 'axios';

const logger = createModuleLogger('HolderAnalyzer');

export interface HolderAnalysisResult {
  concentration: number; // % of supply held by top 10 wallets
  holderCount: number;
}

interface HeliusTokenHolder {
  owner: string;
  amount: number;
  decimals: number;
  uiAmount: number;
  uiAmountString: string;
}

interface HeliusHoldersResponse {
  result: HeliusTokenHolder[];
}

/**
 * HolderAnalyzer checks token holder distribution.
 *
 * BUG FIXED (#13): Previous URL was api.helius.xyz/v0/tokens/{mint}/holders
 * which does not exist. The correct Helius endpoint for token holders uses
 * the DAS (Digital Asset Standard) API:
 * POST https://mainnet.helius-rpc.com/?api-key=KEY
 * with method: "getTokenAccounts" and params.mint
 *
 * Alternatively use the Helius /v1/addresses/{mint}/balances endpoint
 * which is the correct REST endpoint for SPL token holders.
 */
export class HolderAnalyzer {
  private maxHolderConcentration: number;
  private rpcUrl: string;
  private apiKey: string;

  constructor(cfg: AppConfig) {
    this.maxHolderConcentration = cfg.safety.maxHolderConcentrationPct;
    this.rpcUrl = cfg.rpc.rpcHttpUrl;
    this.apiKey = cfg.rpc.heliusApiKey;
  }

  async analyze(mint: string): Promise<HolderAnalysisResult> {
    try {
      // getTokenLargestAccounts is a STANDARD Solana JSON-RPC method supported by
      // every RPC provider (QuickNode, Helius, etc.). The previous Helius-only DAS
      // method `getTokenAccounts` is rejected by non-Helius RPCs (e.g. QuickNode),
      // which made this check throw and fall back to a blocking 50% on every token.
      const largestResp = await axios.post<{
        result: { value: Array<{ amount: string; uiAmount: number | null }> };
      }>(
        this.rpcUrl,
        {
          jsonrpc: '2.0',
          id: 'holder-largest',
          method: 'getTokenLargestAccounts',
          params: [mint],
        },
        { timeout: 5000 },
      );

      const largest = largestResp.data?.result?.value ?? [];
      if (largest.length === 0) {
        // No holder data available — treat as unknown (non-blocking) rather than
        // rejecting the token outright.
        return { concentration: 0, holderCount: 0 };
      }

      // Sum the top-10 token-account balances.
      const topHolderTotal = largest
        .slice(0, 10)
        .reduce((sum, a) => sum + parseFloat(a.amount), 0);

      // Get total supply via the standard getTokenSupply RPC.
      const supplyResponse = await axios.post<{
        result: { value: { amount: string; decimals: number } };
      }>(
        this.rpcUrl,
        {
          jsonrpc: '2.0',
          id: 'supply-check',
          method: 'getTokenSupply',
          params: [mint],
        },
        { timeout: 5000 },
      );

      const totalSupplyRaw = parseFloat(
        supplyResponse.data?.result?.value?.amount ?? '0',
      );

      if (totalSupplyRaw === 0) {
        return { concentration: 0, holderCount: largest.length };
      }

      const concentration = Math.min((topHolderTotal / totalSupplyRaw) * 100, 100);
      return { concentration, holderCount: largest.length };
    } catch (err) {
      logger.warn('Holder analysis failed', { mint, error: String(err) });
      // Non-blocking: unknown holder data must not reject every token.
      return { concentration: 0, holderCount: 0 };
    }
  }
}
