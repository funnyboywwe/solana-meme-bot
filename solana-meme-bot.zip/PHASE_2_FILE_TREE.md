# Phase 2 — Complete File Tree

```
solana-meme-bot/
│
├── 📂 src/
│   │
│   ├── 📂 config/                                   [Phase 1 ✅]
│   │   ├── schema.ts
│   │   ├── AppConfig.ts
│   │   ├── default.yaml
│   │   └── production.yaml
│   │
│   ├── 📂 core/                                     [Phase 1 ✅]
│   │   ├── Logger.ts
│   │   ├── EventBus.ts
│   │   └── types.ts
│   │
│   ├── 📂 db/                                       [Phase 1 ✅]
│   │   ├── schema.sql
│   │   ├── Database.ts
│   │   └── 📂 repositories/
│   │       ├── TokenRepository.ts
│   │       ├── TradeRepository.ts
│   │       ├── WalletRepository.ts
│   │       └── PositionRepository.ts
│   │
│   ├── 📂 ingestion/                                [Phase 2 ✅]
│   │   ├── BaseWebSocketClient.ts                   ✅ abstract base (reconnect, heartbeat, ring buffer)
│   │   ├── HeliusWebSocket.ts                       ✅ Helius Enhanced TX stream
│   │   ├── PumpFunMonitor.ts                        ✅ Pump.fun new tokens + trades
│   │   ├── RaydiumMonitor.ts                        ✅ Raydium pool events (REST polling)
│   │   └── WalletMonitor.ts                         ✅ Wallet account changes (REST polling)
│   │
│   ├── 📂 engines/
│   │   │
│   │   ├── 📂 momentum/                             [Phase 2 ✅]
│   │   │   ├── MomentumEngine.ts                    ✅ orchestrates all detectors
│   │   │   ├── VolumeDetector.ts                    ✅ 5-min rolling volume spike (0–25 pts)
│   │   │   ├── BuyPressure.ts                       ✅ buy/sell ratio (0–20 pts)
│   │   │   ├── VelocityDetector.ts                  ✅ tx/minute (0–20 pts)
│   │   │   ├── LiquidityTracker.ts                  ✅ liquidity growth (0–15 pts)
│   │   │   ├── PriceAccel.ts                        ✅ price acceleration (0–20 pts)
│   │   │   └── MomentumScorer.ts                    ✅ aggregates to 0–100 total
│   │   │
│   │   ├── 📂 safety/                               [Phase 3 — NOT YET]
│   │   │   ├── SafetyEngine.ts
│   │   │   ├── LiquidityChecker.ts
│   │   │   ├── MintAuthChecker.ts
│   │   │   ├── FreezeAuthChecker.ts
│   │   │   ├── HolderAnalyzer.ts
│   │   │   └── HoneypotDetector.ts
│   │   │
│   │   ├── 📂 copytrading/                          [Phase 4 — NOT YET]
│   │   │   ├── CopyTradingEngine.ts
│   │   │   ├── WalletScorer.ts
│   │   │   ├── SignalFilter.ts
│   │   │   └── TradeReplicator.ts
│   │   │
│   │   └── 📂 wallet-intel/                         [Phase 4 — NOT YET]
│   │       ├── WalletIntelEngine.ts
│   │       ├── ProfitabilityTracker.ts
│   │       ├── WinRateTracker.ts
│   │       └── WalletRanker.ts
│   │
│   ├── 📂 gate/                                     [Phase 3 — NOT YET]
│   │   ├── HybridEntryGate.ts
│   │   └── EntryConditions.ts
│   │
│   ├── 📂 risk/                                     [Phase 3 — NOT YET]
│   │   ├── RiskManager.ts
│   │   ├── PositionSizer.ts
│   │   ├── StopLossManager.ts
│   │   ├── CircuitBreaker.ts
│   │   └── CooldownTracker.ts
│   │
│   ├── 📂 execution/                                [Phase 3 — NOT YET]
│   │   ├── ExecutionEngine.ts
│   │   ├── JupiterClient.ts
│   │   ├── PriorityFeeManager.ts
│   │   ├── TxConfirmation.ts
│   │   └── FailedTradeRecovery.ts
│   │
│   ├── 📂 analytics/                                [Phase 5 — NOT YET]
│   │   ├── PnLTracker.ts
│   │   ├── TradeHistory.ts
│   │   ├── StrategyMetrics.ts
│   │   └── MetricsExporter.ts
│   │
│   └── index.ts                                     ✅ (updated bootstrap with Phase 2)
│
├── 📂 scripts/
│   └── migrate.ts                                   [Phase 1 ✅]
│
├── 📂 tests/
│   ├── unit/
│   └── integration/
│
├── 📂 logs/
├── 📂 data/
│
├── 📄 package.json                                  ✅
├── 📄 tsconfig.json                                 ✅
├── 📄 ecosystem.config.js                           ✅
├── 📄 .env.example                                  ✅
├── 📄 .gitignore                                    ✅
├── 📄 README.md                                     ✅
├── 📄 PHASE_1_SUMMARY.md                            ✅
├── 📄 PHASE_1_FILE_TREE.md                          ✅
└── 📄 PHASE_2_SUMMARY.md                            ✅
```

## Phase 2 Files (12 new)

### ✅ WebSocket Services (5 files)
```
✅ src/ingestion/BaseWebSocketClient.ts       — abstract WS base class
✅ src/ingestion/HeliusWebSocket.ts           — Solana mainnet tx stream
✅ src/ingestion/PumpFunMonitor.ts            — Pump.fun event stream
✅ src/ingestion/RaydiumMonitor.ts            — Raydium pool REST polling
✅ src/ingestion/WalletMonitor.ts             — Wallet account REST polling
```

### ✅ Momentum Detectors (7 files)
```
✅ src/engines/momentum/MomentumEngine.ts      — orchestrator
✅ src/engines/momentum/VolumeDetector.ts      — volume spike (25 pts)
✅ src/engines/momentum/BuyPressure.ts         — buy/sell ratio (20 pts)
✅ src/engines/momentum/VelocityDetector.ts    — tx velocity (20 pts)
✅ src/engines/momentum/LiquidityTracker.ts    — liquidity growth (15 pts)
✅ src/engines/momentum/PriceAccel.ts          — price acceleration (20 pts)
✅ src/engines/momentum/MomentumScorer.ts      — aggregator (0–100)
```

---

## Project Status

| Phase | Status | Files | Lines | Dependencies |
|-------|--------|-------|-------|---|
| 1 | ✅ Complete | 21 | 1,500 | Config, logging, DB, event bus |
| 2 | ✅ Complete | 12 | 1,200 | WS clients, momentum detectors |
| 3 | ⏳ Next | – | – | Risk mgmt, safety, execution |
| 4 | ⏳ Later | – | – | Copy trading, wallet intel |
| 5 | ⏳ Later | – | – | Analytics, dashboard |

**Total: 33 files, 2,700 lines (after Phase 2)**

---

## Compilation & Deployment

```bash
# Build Phase 1 + 2
npm run build

# Expected output:
# ✓ Compiled successfully (33 source files, 0 errors)

# Run locally (dev)
npm run dev

# Or production
npm run build && npm start

# Or with PM2
npm run build && pm2 start ecosystem.config.js --env production
```

---

## Next Phase (Phase 3)

Phase 3 will implement:
1. **PriceOracle** — Jupiter REST polling for current USD prices
2. **SafetyEngine** — rug/mint/freeze/liquidity/honeypot checks
3. **HybridEntryGate** — AND-gate: momentum + safety + conditions
4. **RiskManager** — position sizing, daily loss, circuit breaker
5. **StopLossManager** — per-position stop/tp/trailing
6. **ExecutionEngine** — Jupiter swaps, retry, confirmation

These will consume MOMENTUM_SIGNAL events from Phase 2.
