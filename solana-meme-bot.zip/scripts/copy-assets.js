/**
 * Copy non-TypeScript runtime assets (YAML config, SQL schema/migrations) from
 * src/ into dist/, preserving directory structure. `tsc` only emits compiled
 * .js/.d.ts files, so without this step `node dist/index.js` cannot find
 * default.yaml / production.yaml / schema.sql / migrations/*.sql at runtime.
 *
 * Cross-platform (pure Node, no shell tools required).
 */
const fs = require('fs');
const path = require('path');

const SRC = path.join(__dirname, '..', 'src');
const DIST = path.join(__dirname, '..', 'dist');
const COPY_EXTENSIONS = new Set(['.yaml', '.yml', '.sql']);

let copied = 0;

function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      walk(full);
    } else if (COPY_EXTENSIONS.has(path.extname(entry.name).toLowerCase())) {
      const rel = path.relative(SRC, full);
      const dest = path.join(DIST, rel);
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      fs.copyFileSync(full, dest);
      copied++;
      console.log(`[copy-assets] ${rel}`);
    }
  }
}

if (!fs.existsSync(SRC)) {
  console.error('[copy-assets] src/ directory not found');
  process.exit(1);
}
if (!fs.existsSync(DIST)) {
  console.error('[copy-assets] dist/ not found — run `tsc` first');
  process.exit(1);
}

walk(SRC);
console.log(`[copy-assets] done (${copied} file${copied === 1 ? '' : 's'})`);
