/**
 * backfill-wallets.ts
 *
 * Pre-seeds known smart wallets into the DB.
 * Run once before starting the bot for the first time, or whenever
 * you want to add a curated list of wallets to track.
 *
 * Usage:
 *   ts-node scripts/backfill-wallets.ts
 *
 * Wallets can also be passed as a JSON file:
 *   WALLETS_FILE=./wallets.json ts-node scripts/backfill-wallets.ts
 *
 * wallets.json format:
 *   [
 *     { "address": "ABC123...", "label": "Alpha Trader 1" },
 *     { "address": "DEF456...", "label": "Whale 2" }
 *   ]
 */

import 'dotenv/config';
import * as fs from 'fs';
import { loadConfig } from '../src/config/AppConfig';
import { initDatabase, closeDatabase } from '../src/db/Database';
import { initLogger, getLogger } from '../src/core/Logger';
import WalletRepository from '../src/db/repositories/WalletRepository';

interface WalletEntry {
  address: string;
  label?: string;
}

async function main(): Promise<void> {
  const cfg = loadConfig();

  initLogger({
    level: cfg.analytics.logLevel,
    logDir: cfg.analytics.logDir,
    retentionDays: cfg.analytics.logRetentionDays,
  });

  const logger = getLogger('backfill-wallets');
  logger.info('Starting wallet backfill...');

  initDatabase(cfg.db.path, cfg.db.walCheckpointIntervalMs);

  // Load wallets from file or config
  let wallets: WalletEntry[] = [];

  const walletsFile = process.env['WALLETS_FILE'];
  if (walletsFile && fs.existsSync(walletsFile)) {
    const raw = fs.readFileSync(walletsFile, 'utf-8');
    wallets = JSON.parse(raw) as WalletEntry[];
    logger.info(`Loaded ${wallets.length} wallets from ${walletsFile}`);
  } else if (cfg.walletIntel.monitoredWallets.length > 0) {
    wallets = cfg.walletIntel.monitoredWallets.map((a) => ({ address: a }));
    logger.info(`Using ${wallets.length} wallets from config`);
  } else {
    logger.warn('No wallets to seed. Set monitoredWallets in config or provide WALLETS_FILE.');
  }

  let added = 0;
  let skipped = 0;

  for (const w of wallets) {
    if (!w.address || w.address.length < 32) {
      logger.warn('Invalid wallet address, skipping', { address: w.address });
      continue;
    }

    if (WalletRepository.exists(w.address)) {
      logger.debug('Wallet already exists, skipping', { address: w.address });
      skipped++;
      continue;
    }

    WalletRepository.upsert({
      address: w.address,
      label: w.label,
      qualityScore: 0,
      winRate: 0,
      avgRoi: 0,
      totalTrades: 0,
      profitableTrades: 0,
      totalPnlSol: 0,
      addedAt: Date.now(),
      updatedAt: Date.now(),
      isActive: true,
    });

    logger.info('Wallet seeded', { address: w.address, label: w.label });
    added++;
  }

  logger.info(`Backfill complete`, { added, skipped, total: wallets.length });
  closeDatabase();
}

main().catch((err) => {
  console.error('Backfill failed:', err);
  process.exit(1);
});
