import 'dotenv/config';
import { loadConfig } from '../src/config/AppConfig';
import { initDatabase, closeDatabase } from '../src/db/Database';
import { initLogger, getLogger } from '../src/core/Logger';

async function main(): Promise<void> {
  const cfg = loadConfig();

  initLogger({
    level: cfg.analytics.logLevel,
    logDir: cfg.analytics.logDir,
    retentionDays: cfg.analytics.logRetentionDays,
  });

  const logger = getLogger('migrate');
  logger.info('Running database migration...');

  try {
    initDatabase(cfg.db.path, cfg.db.walCheckpointIntervalMs);
    logger.info('Migration complete. Schema is up to date.');
  } catch (err) {
    logger.error('Migration failed', { error: err });
    process.exit(1);
  } finally {
    closeDatabase();
  }
}

main().catch((err) => {
  console.error('Unhandled migration error:', err);
  process.exit(1);
});
