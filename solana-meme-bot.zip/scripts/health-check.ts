/**
 * health-check.ts
 *
 * Standalone liveness probe for use with:
 *   - systemd watchdog
 *   - Docker HEALTHCHECK
 *   - External monitoring (UptimeRobot, BetterStack)
 *
 * Usage:
 *   ts-node scripts/health-check.ts
 *   node dist/scripts/health-check.js
 *
 * Exit codes:
 *   0 — bot is healthy
 *   1 — bot is down or unhealthy
 */

import 'dotenv/config';
import * as http from 'http';
import { loadConfig } from '../src/config/AppConfig';

interface HealthPayload {
  status: string;
  uptime: number;
  openPositions: number;
  wsStatus: Record<string, boolean>;
  eventQueueSize: number;
  todayPnlSol?: number;
  winRatePct?: number;
  ts: number;
}

async function check(): Promise<void> {
  const cfg = loadConfig();
  const port = cfg.process.healthCheckPort;

  return new Promise((resolve, reject) => {
    const req = http.get(
      `http://localhost:${port}/health`,
      { timeout: 5000 },
      (res) => {
        let raw = '';
        res.on('data', (chunk: string) => { raw += chunk; });
        res.on('end', () => {
          if (res.statusCode !== 200) {
            console.error(`Health check returned HTTP ${res.statusCode}`);
            process.exit(1);
          }

          try {
            const payload = JSON.parse(raw) as HealthPayload;
            const wsDown = Object.entries(payload.wsStatus ?? {}).filter(([, v]) => !v);
            const queueSize = payload.eventQueueSize ?? 0;

            console.log('=== Bot Health ===');
            console.log('Status:         ', payload.status);
            console.log('Uptime:         ', `${Math.floor(payload.uptime / 60)}m ${payload.uptime % 60}s`);
            console.log('Open positions: ', payload.openPositions);
            console.log('Today PnL:      ', payload.todayPnlSol !== undefined ? `${payload.todayPnlSol.toFixed(4)} SOL` : 'N/A');
            console.log('Win rate:       ', payload.winRatePct !== undefined ? `${payload.winRatePct}%` : 'N/A');
            console.log('Event queue:    ', queueSize);
            console.log('WS connections:');
            for (const [name, up] of Object.entries(payload.wsStatus ?? {})) {
              console.log(`  ${name.padEnd(15)} ${up ? '✓ connected' : '✗ disconnected'}`);
            }

            if (payload.status !== 'ok') {
              console.error('\nUnhealthy: status is not ok');
              process.exit(1);
            }

            if (wsDown.length > 0) {
              console.warn(`\nWarning: ${wsDown.length} WebSocket(s) disconnected: ${wsDown.map(([n]) => n).join(', ')}`);
            }

            if (queueSize > 1000) {
              console.warn(`\nWarning: event queue backed up (${queueSize} events)`);
            }

            console.log('\nHealth check: PASSED ✓');
            process.exit(0);
          } catch (parseErr) {
            console.error('Failed to parse health response:', parseErr);
            process.exit(1);
          }
        });
      },
    );

    req.on('error', (err) => {
      console.error(`Health check failed: ${err.message}`);
      console.error('Bot may be down or not yet started.');
      process.exit(1);
    });

    req.on('timeout', () => {
      console.error('Health check timed out');
      req.destroy();
      process.exit(1);
    });
  });
}

check().catch((err) => {
  console.error('Unexpected error:', err);
  process.exit(1);
});
