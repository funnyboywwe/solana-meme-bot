#!/usr/bin/env bash
# =============================================================================
# Solana Meme Bot — VPS Deployment Script
# Target: Ubuntu 20.04/22.04, 1 vCPU, 1 GB RAM
#
# Usage:
#   chmod +x scripts/deploy.sh
#   ./scripts/deploy.sh
#
# Run as non-root user with sudo access.
# Requires: HELIUS_API_KEY, RPC_HTTP_URL, WALLET_PRIVATE_KEY set in .env
# =============================================================================

set -euo pipefail

REPO_DIR="$HOME/solana-meme-bot"
NODE_VERSION="20"
LOG_FILE="$HOME/deploy.log"

log() { echo "[$(date +'%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOG_FILE"; }
die() { log "ERROR: $*"; exit 1; }

log "=== Solana Meme Bot Deployment Starting ==="

# ─── 1. System packages ───────────────────────────────────────────────────────
log "Installing system packages..."
sudo apt-get update -qq
sudo apt-get install -y -qq \
  curl git build-essential ufw fail2ban \
  htop iotop sysstat unzip jq

# ─── 2. Swap file (prevents OOM on 1 GB RAM) ─────────────────────────────────
if ! swapon --show | grep -q /swapfile; then
  log "Creating 512 MB swap file..."
  sudo fallocate -l 512M /swapfile
  sudo chmod 600 /swapfile
  sudo mkswap /swapfile
  sudo swapon /swapfile
  echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
  sudo sysctl vm.swappiness=10
  echo 'vm.swappiness=10' | sudo tee -a /etc/sysctl.conf
  log "Swap created"
else
  log "Swap already configured"
fi

# ─── 3. Node.js via nvm ───────────────────────────────────────────────────────
if ! command -v node &>/dev/null || [[ "$(node -e 'process.stdout.write(process.version.split(\".\")[0].slice(1))')" -lt "$NODE_VERSION" ]]; then
  log "Installing Node.js $NODE_VERSION via nvm..."
  curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
  # shellcheck source=/dev/null
  export NVM_DIR="$HOME/.nvm"
  # shellcheck source=/dev/null
  source "$NVM_DIR/nvm.sh"
  nvm install "$NODE_VERSION"
  nvm use "$NODE_VERSION"
  nvm alias default "$NODE_VERSION"
  log "Node.js $(node --version) installed"
else
  log "Node.js $(node --version) already installed"
fi

# Ensure nvm is sourced in subsequent steps
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && source "$NVM_DIR/nvm.sh"

# ─── 4. PM2 ───────────────────────────────────────────────────────────────────
if ! command -v pm2 &>/dev/null; then
  log "Installing PM2..."
  npm install -g pm2
fi
log "PM2 $(pm2 --version) ready"

# ─── 5. Firewall ──────────────────────────────────────────────────────────────
log "Configuring UFW firewall..."
sudo ufw --force reset
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow OpenSSH
sudo ufw allow 3001/tcp comment 'Bot health/dashboard API'
sudo ufw --force enable
log "Firewall configured"

# ─── 6. fail2ban ─────────────────────────────────────────────────────────────
log "Enabling fail2ban..."
sudo systemctl enable fail2ban --now
log "fail2ban active"

# ─── 7. Clone or update repo ──────────────────────────────────────────────────
if [ -d "$REPO_DIR/.git" ]; then
  log "Pulling latest changes..."
  cd "$REPO_DIR"
  git pull origin main
else
  log "Cloning repository..."
  git clone https://github.com/yourorg/solana-meme-bot.git "$REPO_DIR"
  cd "$REPO_DIR"
fi

# ─── 8. Environment setup ─────────────────────────────────────────────────────
if [ ! -f "$REPO_DIR/.env" ]; then
  log "Creating .env from .env.example..."
  cp "$REPO_DIR/.env.example" "$REPO_DIR/.env"
  log "ACTION REQUIRED: Edit $REPO_DIR/.env with your API keys before continuing"
  log "  nano $REPO_DIR/.env"
  exit 0
fi

# Verify required env vars are set
source "$REPO_DIR/.env"
[[ -z "${HELIUS_API_KEY:-}" ]] && die "HELIUS_API_KEY not set in .env"
[[ -z "${RPC_HTTP_URL:-}" ]] && die "RPC_HTTP_URL not set in .env"
[[ -z "${WALLET_PRIVATE_KEY:-}" ]] && die "WALLET_PRIVATE_KEY not set in .env"
log "Environment variables verified"

# ─── 9. Install dependencies and build ───────────────────────────────────────
log "Installing npm dependencies..."
cd "$REPO_DIR"
npm ci --production=false

log "Building TypeScript..."
npm run build
log "Build complete"

# ─── 10. Database migration ───────────────────────────────────────────────────
log "Running database migration..."
mkdir -p "$REPO_DIR/data" "$REPO_DIR/logs"
npm run migrate
log "Migration complete"

# ─── 11. Start with PM2 ───────────────────────────────────────────────────────
log "Starting bot with PM2..."
pm2 delete solana-meme-bot 2>/dev/null || true
pm2 start "$REPO_DIR/ecosystem.config.js" --env production
pm2 save

# Setup PM2 startup (run the printed command manually if needed)
STARTUP_CMD=$(pm2 startup | grep "sudo env" || true)
if [[ -n "$STARTUP_CMD" ]]; then
  log "Running PM2 startup command..."
  eval "$STARTUP_CMD" || log "PM2 startup: run manually if this failed"
fi

# ─── 12. Verify ───────────────────────────────────────────────────────────────
sleep 5
log "Checking bot health..."
if curl -sf "http://localhost:3001/health" | jq '.status' | grep -q '"ok"'; then
  log "=== Bot is HEALTHY ==="
else
  log "WARNING: Health check did not return ok. Check logs:"
  log "  pm2 logs solana-meme-bot --lines 50"
fi

log ""
log "=== Deployment Complete ==="
log ""
log "Useful commands:"
log "  pm2 status                         — process status"
log "  pm2 logs solana-meme-bot           — live logs"
log "  pm2 restart solana-meme-bot        — restart bot"
log "  curl http://localhost:3001/health  — health check"
log "  curl http://localhost:3001/stats   — full analytics"
log "  curl http://localhost:3001/trades  — recent trades"
log "  npm run health                     — detailed health report"
log ""
log "Log file: $LOG_FILE"
