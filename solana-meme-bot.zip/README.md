# Solana Meme Momentum + Copy Trading Bot

Production-ready Solana trading bot combining momentum detection with smart wallet copy trading. Optimized for 1 vCPU / 1 GB RAM VPS deployment.

## Architecture Overview

```
Data Ingestion (Helius, Pump.fun, Raydium)
    ↓
Event Bus (typed pub/sub with back-pressure)
    ↓
Processing Engines:
  - Momentum detector (volume, velocity, price accel, liquidity)
  - Copy trading engine (wallet scoring, signal filtering)
  - Safety checker (rug, mint, freeze, holders, honeypot)
  - Wallet intelligence (profitability tracking, ranking)
    ↓
Hybrid Entry Gate (AND-gate requiring all conditions)
    ↓
Risk Manager (position sizing, circuit breaker, daily loss)
    ↓
Execution Engine (Jupiter, priority fees, retries)
    ↓
Stop-Loss Manager (per-position watchers)
    ↓
SQLite (persists all state)
    ↓
Analytics & Metrics
```

## Quick Start

### 1. Prerequisites
- Node.js 20+
- Solana devnet/mainnet RPC (Helius recommended)
- Keypair with SOL for trading

### 2. Setup
```bash
git clone https://github.com/yourorg/solana-meme-bot
cd solana-meme-bot
npm install
cp .env.example .env
# Edit .env with your keys
npm run migrate
```

### 3. Run
**Development:**
```bash
npm run dev
```

**Production:**
```bash
npm run build
npm start
```

**With PM2:**
```bash
npm run build
pm2 start ecosystem.config.js --env production
pm2 save
pm2 startup
```

### 4. Monitor
```bash
curl http://localhost:3001
pm2 logs solana-meme-bot
```

## Configuration

All settings in `src/config/default.yaml`, overridden by `src/config/production.yaml` and environment variables.

Key parameters:
- `risk.maxDailyLossSol` – daily loss circuit breaker
- `risk.maxConcurrentPositions` – max open trades
- `momentum.scoreThreshold` – min momentum score to trigger
- `safety.maxRugScore` – max acceptable rug risk (0–100)

## Memory Profile

Target: < 200 MB RSS on 1 GB VPS

| Component | MB |
|---|---|
| Node.js baseline | ~60 |
| WebSocket clients | ~30 |
| SQLite cache | ~20 |
| Event bus buffers | ~15 |
| Engine state (tokens) | ~40 |
| Analytics & logs | ~15 |
| **Total** | **~180** |

## Database

SQLite with WAL mode for fast writes. Auto-checkpointing every 60 seconds.

Schema:
- `tokens` – on-chain token metadata
- `trades` – all buy/sell records
- `positions` – open and closed trades
- `wallets` – monitored wallet stats
- `daily_risk_state` – daily PnL snapshot
- `event_log` – audit trail

## Security

- Private keys in env vars only (never logged)
- All external data validated via Zod schemas
- Rate-limit backoff for RPC/Jupiter calls
- Firewall: SSH + health check only
- No web dashboard exposed (read via SSH tunnel)

## Deployment (VPS)

```bash
# Ubuntu 20.04, 1 vCPU, 1 GB RAM
sudo apt update && sudo apt upgrade -y
sudo apt install -y curl git build-essential ufw fail2ban

# Node.js
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
source ~/.bashrc
nvm install 20 && nvm use 20

# PM2
npm install -g pm2

# Clone and start
git clone https://github.com/yourorg/solana-meme-bot.git
cd solana-meme-bot
npm install && npm run build
cp .env.example .env && nano .env
npm run migrate
pm2 start ecosystem.config.js --env production
pm2 startup && pm2 save
```

## Troubleshooting

**Memory leak:** Check `EventBus.getQueueSize()` – if > 1000, event processing is backing up. Lower `execution.maxRetries` or `maxConcurrentPositions`.

**Trades not filling:** Verify RPC endpoint with `getRecentBlockhash()`. Increase `execution.priorityFeeMicroLamports` on congested networks.

**No signals:** Review momentum thresholds. Enable `debug` log level and check raw scores in logs.

## Performance Tuning

Node.js flags in `ecosystem.config.js`:
```
--max-old-space-size=384         # 384 MB heap limit
--max-semi-space-size=16         # Small nursery for low-memory systems
--gc-interval=100                # Force GC every 100 ms
```

SQLite pragmas applied in `Database.ts`:
- `journal_mode = WAL` – write-ahead logging
- `synchronous = NORMAL` – fast but safe
- `cache_size = -8000` – ~8 MB page cache
- `mmap_size = 67108864` – 64 MB memory mapping

## Roadmap

- [ ] Phase 2: WebSocket ingestion + momentum scanner
- [ ] Phase 3: Risk engine + execution
- [ ] Phase 4: Copy trading + wallet scoring
- [ ] Phase 5: Analytics dashboard
- [ ] Multi-chain support (Ethereum, Base)
- [ ] Horizontal scaling (worker threads)

## License

MIT
