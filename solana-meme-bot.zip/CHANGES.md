# Bug Fixes & Changes

This document summarizes the fixes applied to the Solana meme-coin momentum + copy-trading bot.

## Critical bugs fixed

1. **Extended config was silently ignored** (`src/index.ts`, `src/config/AppConfig.ts`)
   - `ExtendedConfigSchema.safeParse(cfg)` parsed the already-narrowed `AppConfig`, which strips unknown keys, so every extended-module section fell back to schema defaults.
   - Added `loadRawConfig()` and now parse the raw merged YAML+env config.

2. **Tokens were never persisted on creation** (`src/index.ts`)
   - SafetyEngine / HybridEntryGate use `UPDATE ... WHERE mint=?` and `findByMint()`. With no existing row their writes silently no-op and entries never qualified.
   - Added a `TOKEN_CREATED` handler that upserts the token row FIRST (handlers run in registration order).

3. **EventBus.off() never removed listeners** (`src/core/EventBus.ts`)
   - `on()` registered a wrapped async closure but `off()` passed the original handler, which never matched. Listeners leaked forever.
   - Now tracks each handler→wrapped mapping so `off()` removes the correct listener.

4. **Hardcoded SOL price ($150)** (`src/core/SolPrice.ts` [new], `ExecutionEngine`, `LiquidityChecker`, `RaydiumMonitor`)
   - Introduced a shared `SolPrice` helper kept fresh by the PriceOracle (WSOL). All `* 150` sites now use `getSolPriceUsd()`.

5. **PriceOracle used a dead endpoint & wrong response shape** (`src/ingestion/PriceOracle.ts`)
   - Migrated to Jupiter Price API V3 (`https://lite-api.jup.ag/price/v3`), which returns a flat map keyed by mint with `usdPrice`.
   - Oracle now also feeds the shared SOL price from WSOL.

6. **PriceOracle was never wired to positions** (`src/index.ts`)
   - Prices were never polled, so stop-loss / take-profit (driven by `PRICE_UPDATE`) never fired.
   - Now `trackToken` on buy, `untrackToken` on sell, and re-track restored open positions on startup.

7. **Jupiter swap endpoint updated** (`src/config/schema.ts`, `src/config/default.yaml`)
   - Default `jupiterApiUrl` moved to `https://lite-api.jup.ag/swap/v1` (keyless quote + swap).

8. **Priority fee was static** (`src/execution/JupiterClient.ts`, `ExecutionEngine`)
   - Buy/sell now accept a dynamic `priorityFeeMicroLamports` from `PriorityFeeManager.getRecommendedFee()`.

9. **Raydium liquidity response parsed incorrectly** (`src/engines/safety/LiquidityChecker.ts`)
   - The pairs endpoint returns a FLAT array, not `{ data: [...] }`. Now handles both shapes.

10. **Sell sold an estimated token amount** (`src/execution/ExecutionEngine.ts`, `src/core/types.ts`, DB)
    - Positions now record `sizeTokens` (added to `Position`, `schema.sql`, `PositionRepository`). Sells use the real recorded quantity, falling back to the price estimate only for legacy rows.

11. **Hardcoded entry risk parameters** (`src/execution/ExecutionEngine.ts`)
    - Stop-loss / take-profit / trailing-stop now come from `cfg.risk` instead of hardcoded `0.15 / 0.40 / 0.10`.

12. **RaydiumMonitor flooded TOKEN_CREATED on first poll** (`src/ingestion/RaydiumMonitor.ts`)
    - On startup every existing pool looked "new". Added a `firstPoll` guard that seeds the seen-set silently.

13. **RiskManager ignored exposure limits & dynamic sizing** (`src/risk/RiskManager.ts`, `ExposureManager`, `src/index.ts`)
    - Added `wireRisk({ exposureManager, dynamicSizer })`. `evaluate()` now applies multi-factor dynamic sizing and portfolio exposure checks/caps. Added `ExposureManager.getBalanceSol()`.

14. **Closed-position bookkeeping missing** (`src/index.ts`, `src/core/EventBus.ts`)
    - `TradeFilledEvent` now carries `realisedPnlSol`. On each sell fill we update the exposure loss-streak, circuit breaker (with live balance), and kill switch. Also start a token cooldown on `CLOSE_SIGNAL`.

15. **Logger did not redact secrets on the console transport** (`src/core/Logger.ts`)
    - The redact format was applied only to file transports; added it to the console format too.

16. **tsconfig** (`tsconfig.json`)
    - Removed `scripts/**/*` from `include` (was causing rootDir errors) and set `"ignoreDeprecations": "6.0"` for the `moduleResolution` deprecation warning.

## Deferred (documented, not changed)

- **MEV / Jito tip submission** is present (`MEVProtection`) but NOT wired into the swap submission path. Wiring it requires refactoring `JupiterClient` to expose the unsigned transaction so it can be bundled with a tip. Left as-is to avoid destabilizing execution.
- **Raydium host** kept on the legacy `api.mainnet.raydium.io/v2/main/pairs` endpoint rather than migrating to api-v3, to avoid blind breakage without live testing.
- **PnL fee subtraction** and **HolderAnalyzer owner-aggregation** refinements were left for a follow-up pass.
- Items requiring live API keys / on-chain testing (RPC, Helius, wallet keypair) cannot be validated in this environment.

## Build / verification note

The sandbox's `node_modules` was cleared between sessions, so a full `tsc` typecheck could not be completed here without reinstalling dependencies (`npm install`). All fixes are source-level and self-contained. After `npm install`, build with `npm run build` (`tsc --project tsconfig.json`).

---

# Pass 2 — critical fix + deployment infrastructure

17. **Critical: wrong SPL Token program ID** (`src/ingestion/WalletMonitor.ts`)
    - `getTokenAccountsByOwner` used `TokenkegQfeZyiNwAJsyFbPVwwQQUWVLMgiyckPJsLJC` (invalid). Smart-money wallet token-account scans would never match.
    - Corrected to the canonical `TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA`.

18. **Deployment infrastructure added**
    - `Dockerfile` — multi-stage build (compiles native `better-sqlite3`), non-root runtime, `dumb-init` for clean signal handling, runtime YAML/SQL assets copied in.
    - `.dockerignore`, `docker-compose.yml` (persistent `data`/`logs` volumes, healthcheck, 30s graceful stop, log rotation, 1G memory cap).
    - `ecosystem.config.js` — PM2 single-instance fork mode (intentionally NOT clustered; the bot is stateful and would double-trade).
    - `.env.example` — documented secrets (wallet key, Helius/QuickNode/Triton RPCs, Jito, Telegram/Discord).
    - `DEPLOYMENT.md` — architecture + trade-lifecycle Mermaid diagrams, local/Docker/PM2 run steps, AWS EC2 and ECS Fargate guides (secrets via SSM/Secrets Manager, EFS for the DB), and an operational runbook.

## Still outstanding (next passes — require your RPC/API keys + live testing to verify)

- Full Jito **bundle submission** wired into the live swap path + **pre-flight `simulateTransaction`** on every trade.
- **Multi-RPC failover** manager (QuickNode/Triton) with latency monitoring + health checks.
- **Telegram/Discord** alert delivery and the **Sharpe/drawdown** analytics dashboard endpoints.
- **LP-lock verification** and **HolderAnalyzer** owner-aggregation.
- **Unit/integration test** suite and CI.

These are real, sizeable implementations. They must be built against your live credentials and validated on devnet + small-size mainnet before trading real funds.


---

## Pass 3 — MEV protection + pre-flight transaction simulation (fund safety)

Goal: stop spending fees/tips on transactions that will revert, and route live
swaps through the existing MEV defense layer (which was previously never called).

### What changed
1. **`src/config/schema.ts`** — added `execution.simulateBeforeSend` (boolean,
   default `true`). Controls the new pre-flight simulation gate.
2. **`src/execution/JupiterClient.ts`**
   - New optional `mevProtection` dependency + `setMevProtection()` injector.
   - `_executeSwap()` now, after building & signing the Jupiter swap tx:
     a. **Simulates the transaction** via `connection.simulateTransaction()`
        (`replaceRecentBlockhash`, `sigVerify:false`). If `value.err` is set, it
        **aborts before broadcasting** and returns a failed `SwapResult` with the
        simulation error + last log lines. No SOL/tips are spent on a doomed tx.
     b. **Routes submission through `MEVProtection.submit()`** when wired —
        front-run delay, RPC submit, sandwich-pattern detection, and Jito-bundle
        fallback. Falls back to direct `sendRawTransaction` when MEV is not wired
        (with `skipPreflight` set since we already simulated).
   - Derives the traded mint from the quote for MEV bookkeeping/logging.
3. **`src/execution/ExecutionEngine.ts`** — constructor now accepts the
   `ExtendedConfig` and constructs `MEVProtection(cfg, extCfg, keypair)` (reusing
   the singleton keypair), injecting it into `JupiterClient`.
4. **`src/index.ts`** — passes `extCfg` into `new ExecutionEngine(cfg, extCfg)`.

### Behavior / config notes
- Pre-flight simulation is **on by default** (`execution.simulateBeforeSend`).
- MEV protection activates automatically now that it is wired; Jito itself stays
  **off by default** (`mevProtection.jitoEnabled=false`) — enable in config.
- `mevProtection.frontRunProtectionMs` defaults to 2000ms (a 2s delay before each
  submit). For latency-sensitive momentum entries, lower or zero this.

### Known limitation (be aware before live trading)
- In the current `MEVProtection` design, **Jito is a fallback** (tried only when
  the normal RPC submit throws). True mempool-bypass would submit via Jito
  *first*. Also, a Jito bundle returns a `bundleId`, not a tx signature, so
  `TxConfirmation` (which watches a signature) cannot confirm bundle-only
  submissions — those need bundle-status polling. Making Jito the primary path
  with proper bundle confirmation is a further step that must be validated on
  devnet/mainnet with your own keys.

### Still NOT verified by a compiler
- `node_modules` is wiped in this sandbox and the registry is unreachable, so a
  full `tsc` build could not be run here. Run `npm install && npx tsc --noEmit`
  locally to confirm before deploying.


## Pass 4 — Multi-RPC failover, LP-lock rug check, Telegram/Discord alerts & risk analytics

### Multi-RPC failover
- Added `src/core/RpcManager.ts`: health-checked, latency-ranked connection pool over Helius (primary), optional QuickNode/Triton, and arbitrary `FALLBACK_RPC_URLS`. Exposes `getConnection()`, `withFailover()`, `getStats()`, `getErrorRate()`, and periodic `startHealthChecks()`.
- Routed the trading hot path (JupiterClient, MEVProtection, PriorityFeeManager, FailedTradeRecovery, TxConfirmation) through `RpcManager` via a delegating `connection` getter so failover is transparent to existing call sites.
- `schema.ts`: new optional rpc fields (`quickNodeRpcUrl/WsUrl`, `tritonRpcUrl/WsUrl`, `fallbackRpcUrls`, `healthCheckIntervalMs`, `maxRpcFailures`).
- `AppConfig.ts`: injects `HELIUS_WS_URL`, `QUICKNODE_RPC_URL`, `QUICKNODE_WS_URL`, `TRITON_RPC_URL`, `TRITON_WS_URL`, and comma-separated `FALLBACK_RPC_URLS` from env (only when non-empty).
- `index.ts`: starts RPC health checks at bootstrap (after risk wiring).
- `.env.example`: aligned + documented the new RPC env vars.
- NOTE: read/analytics-only paths (position sizing, exposure, mint/freeze auth, replicator) still use a primary-only connection and can be migrated identically later.

### LP-lock / burn rug detection
- Added `src/engines/safety/LpLockChecker.ts`: resolves the Raydium SOL-pool lpMint, reads total LP supply + largest holders, and computes the % of LP held by burn/null owners (incinerator / system program). Zero supply = fully burned.
- `SafetyEngine` now runs this as a 6th check: adds `lpLockRugScoreWeight` to the rug score when LP is not locked, and hard-blocks entry when `safety.requireLpLock` is enabled.
- `schema.ts`: new safety fields `requireLpLock` (default false), `minLpLockedPct` (default 80), `lpLockRugScoreWeight` (default 15).
- `types.ts`: `SafetyReport` gains optional `lpLocked` / `lpLockedPct`.

### Telegram / Discord alerts + PnL / Sharpe / drawdown analytics
- Added `src/analytics/AlertManager.ts`: best-effort Telegram (Bot API) + Discord (webhook) delivery with error throttling; `sendAlert`, `sendError`, `sendTradeAlert`, `sendReport`.
- `StrategyMetrics.getRiskAnalytics()`: portfolio Sharpe, Sortino, volatility, downside deviation, and max drawdown (SOL + %) computed over the realised-PnL equity curve; surfaced in `AnalyticsSnapshot.riskAnalytics`.
- `index.ts`: emits trade alerts on every fill, forwards KILL_SWITCH / EXPOSURE_LIMIT / MEV_DETECTED events to the alert channels, sends a startup ping, and schedules a daily PnL+risk report.
- `schema.ts` monitoring block: `telegramEnabled/BotToken/ChatId`, `discordEnabled/WebhookUrl`, `alertOnTrade`, `alertOnError`, `dailyReportEnabled`, `dailyReportHourUtc`. Secrets injected from env (`TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`, `DISCORD_WEBHOOK_URL`).

### Tests
- `tests/unit/analytics/AlertManager.test.ts`: enable/disable, dual-channel delivery, error throttling, trade-alert gating.
- `tests/unit/analytics/StrategyMetrics.test.ts`: max-drawdown / equity-peak / risk-ratio math.

### Still requires your validation before real funds
- `node_modules` is empty in this build environment, so `tsc` and `jest` could not be executed here. Run `npm install`, then `npm run build` and `npm test` locally, and validate on devnet + small mainnet sizes with your own API keys before trading real funds.


---

## Pass 4 — Multi-RPC, LP-lock, Alerts/Analytics, and a real export bug fix

### Critical bug fixed (found via full `tsc` run)
- **`AppConfig` type was never re-exported.** `src/config/schema.ts` defines `export type AppConfig = z.infer<typeof ConfigSchema>`, and `src/config/AppConfig.ts` imported it locally but did **not** re-export it. Yet **51 files** import `AppConfig` from `../config/AppConfig`. Every one failed to type-check (`TS2459: declares 'AppConfig' locally, but it is not exported`). This was invisible until a full type-check could run.
  - Fix: added `export type { AppConfig } from './schema';` to `src/config/AppConfig.ts`.

### Multi-RPC failover
- New `src/core/RpcManager.ts`: health-checked, failover-aware connection manager (`getConnection`, `withFailover`, `startHealthChecks`, `getStats`, `getErrorRate`; singleton `getRpcManager(cfg)` / `resetRpcManager()`).
- `schema.ts` gained an `rpc` block (helius/quicknode/triton HTTP+WS URLs, `fallbackRpcUrls`, `healthCheckIntervalMs`, `maxRpcFailures`).
- `AppConfig.ts` wires the new RPC env vars (`HELIUS_WS_URL`, `QUICKNODE_RPC_URL`, `QUICKNODE_WS_URL`, `TRITON_RPC_URL`, `TRITON_WS_URL`, `FALLBACK_RPC_URLS`).
- Trading hot-path execution classes use a delegating `get connection()` so swaps/sends transparently fail over. Health checks start at bootstrap in `index.ts`.

### Rug / LP-lock verification
- New `src/engines/safety/LpLockChecker.ts`: checks LP burn/lock percentage (incinerator + system burn owners) against `minLpLockedPct`.
- `SafetyEngine` now runs this as a 6th safety check; pass requires `(!requireLpLock || lpLocked === true)`.
- `types.ts` `SafetyReport` gained `lpLocked?` / `lpLockedPct?`. `schema.ts` `safety` block gained `requireLpLock`, `minLpLockedPct`, `lpLockRugScoreWeight`.

### Telegram / Discord alerts + risk analytics
- New `src/analytics/AlertManager.ts`: Telegram + Discord delivery (best-effort, never throws), error throttling (30s), trade alerts, and report sending.
- `StrategyMetrics.getRiskAnalytics()` computes Sharpe, Sortino, volatility, downside deviation, and max drawdown (SOL + %) over closed positions. Surfaced via `AnalyticsEngine` snapshot.
- `index.ts` sends a startup alert, per-trade alerts (`TRADE_FILLED`), risk alerts (kill switch / exposure / MEV), and an optional daily PnL report.
- `schema.ts` `monitoring` block gained `telegramEnabled/telegramBotToken/telegramChatId/discordEnabled/discordWebhookUrl/alertOnTrade/alertOnError/dailyReportEnabled/dailyReportHourUtc`; `.env.example` updated.

### Tests added
- `tests/unit/analytics/AlertManager.test.ts`
- `tests/unit/analytics/StrategyMetrics.test.ts`

### Build verification status (honest)
- The sandbox could not reliably populate `node_modules` (npm install repeatedly timed out), so a clean end-to-end `tsc` build could not be completed here. The full type-check that *did* run surfaced the `AppConfig` export bug (now fixed) plus the expected "cannot find module" errors that are purely missing-dependency noise. You must run `npm install && npm run build` in your own environment to confirm a clean compile before trading.


---

## Pass 5 — Static-analysis bug fixes (compile-blockers + correctness)

### Compile-blocking fixes (strict `tsconfig`: `noUncheckedIndexedAccess`)
- **`momentum/PriceAccel.ts`** — indexed price-history access (`hist[i].price` / `.ts`) now goes through guarded locals (`const last = hist[...]; if (!last) return 0;`) so it compiles under `noUncheckedIndexedAccess`.
- **`momentum/LiquidityTracker.ts`** — same fix for `liquidityHistory` indexing; baseline/last points are guarded before use.
- **`engines/holders/HolderGrowthEngine.ts`** — typed the `topAccounts.reduce(...)` callback (`s: number, a: { amount: string | number }`) and made it `parseFloat(String(a.amount))` to avoid implicit-any and string/number coercion issues.

### Correctness / removed the last placeholder
- **`engines/copytrading/SignalFilter.ts`** — `_getRugScore()` previously always `return null` (a placeholder), silently disabling the copy-trade rug-score gate. It now reads the persisted rug score via the new `TokenRepository.getSafety(mint)` and returns it (null only when the token hasn't been safety-checked yet).

### LP-lock results now persisted (closes the gap from Pass 4)
- **`db/schema.sql`** — added `lp_locked INTEGER` and `lp_locked_pct REAL` to the `tokens` table.
- **`db/Database.ts`** — added idempotent, guarded `ALTER TABLE tokens ADD COLUMN ...` so existing databases upgrade without crashing.
- **`db/repositories/TokenRepository.ts`** — `updateSafety()` now writes `lpLocked` / `lpLockedPct`; added `getSafety(mint)` to read back all persisted safety fields (rug score, auth flags, holder concentration, LP lock).
- **`engines/safety/SafetyEngine.ts`** — passes `lpLocked` / `lpLockedPct` into `updateSafety()`.

### Verified-not-a-bug (left intact)
- `core/types.ts` already includes `'unknown'` in `TokenInfo.source`, so the earlier `MomentumEngine` source assignment is fine.
- Holder concentration units are consistent: Helius `getTokenAccounts` `amount` and `getTokenSupply` `value.amount` are both raw base units.
- `core/Logger.ts` / `core/RpcManager.ts` implicit-any warnings were cascades from missing dependency type defs (winston / @solana types); they resolve once `npm install` runs.

### Still recommended (not done — needs a verified build loop; see audit list)
- Route the ~6 read/analytics `new Connection(...)` sites through `getRpcManager()` for full failover.
- Align the daily report to `dailyReportHourUtc` instead of a fixed 24h interval.
- Add stale-price protection to the SOL price oracle so a failed fetch blocks trading instead of passing 0.
- Confirm Jito bundle landing via `getBundleStatuses`; adopt Jupiter `dynamicSlippage` + `priceImpactPct` cap; migrate Raydium reads to `api-v3`.

> Build status unchanged: this sandbox has no network to npmjs.org, so a clean `tsc` could not be run here. All Pass 5 edits were made against the verified current source; run `npm install && npm run build` locally to confirm.


---

## Pass 6 — Fixes from the first real `tsc` build (9 errors, 5 files)

These were caught by running `npm run build` on the deployment VPS (no network in the dev sandbox, so this was the first true compile).

- **`core/EventBus.ts`** — `TokenCreatedEvent.source` was `'pumpfun' | 'raydium'`; added `'unknown'`. This is the type that actually constrained `MomentumEngine.ts:81` (the earlier `core/types.ts` union was already correct, but this event type was the real source of the TS2322 error).
- **`ingestion/HeliusWebSocket.ts`**, **`PumpFunMonitor.ts`**, **`RaydiumMonitor.ts`**, **`WalletMonitor.ts`** — added the `override` keyword to `connect()` / `disconnect()` methods that override `BaseWebSocketClient` (required by `noImplicitOverride`). 6 methods total (TS4114).
- **`ingestion/WalletMonitor.ts:185`** — real bug: the token-disposal loop read `for (const prev of prev)`, a self-referential typo (TS7022 + TS2448) that would never iterate the previous-balance list. Renamed the loop variable to `prevItem` and updated its uses, so sell/disposal detection for copy-traded wallets now works.
- **`tsconfig.json`** — set `ignoreDeprecations` to `"5.0"` (correct value for TypeScript 5.3.3; `"6.0"` is only valid on TS 5.5+).

> Status: build verified to reach these 9 errors and no others; all are now fixed at the source. Re-run `npm run build` to confirm a clean compile.


---

## Pass 7 — Logger crash on startup/migrate (`colors[...] is not a function`)

- **`core/Logger.ts`** — the secret-redaction format (`redactFormat`) rebuilt the log `info` object with `Object.entries(...)`, which dropped winston's non-enumerable internal symbols (`Symbol(level)`, `Symbol(message)`, `Symbol(splat)`). With `Symbol(level)` gone, `winston.format.colorize()` looked up an undefined level color and crashed with `TypeError: colors[Colorizer.allColors[lookup]] is not a function` on the first log line (seen during `npm run migrate`). The same symbol loss also broke the error-only log transport's level filtering.
- Fix: redact secrets **in place** (mutate the existing `info` object's own enumerable keys) instead of returning a fresh object, so winston's internal symbols are preserved. Colorized console output and the error-log filtering now work.


---

## Pass 8 — Migration runner silently dropped most CREATE statements

- **`db/Database.ts`** — the schema runner split the `.sql` file on `;`, then filtered out any chunk that `startsWith('--')`. Because each section in `schema.sql` has a `-- ─── Section ───` comment header, the comment landed in the same chunk as the statement beneath it, so the filter discarded the **entire** statement. Result: most tables/indexes (including `trades`) were never created, and migration failed at `CREATE INDEX ... ON trades(status)` (`SQLITE_ERROR`) — the first surviving statement that referenced a table that had been dropped.
- Fix: strip full-line `--` comments **before** splitting on `;`, then split. All `CREATE TABLE` / `CREATE INDEX` statements now run. Inline/trailing comments and statements are unaffected.
- **Action for existing installs:** delete any partially-created dev database (`rm -f ./data/bot.db*`) and re-run `npm run migrate` so the full schema is built cleanly.


---

## Pass 9 — Compiled app couldn't find config/SQL assets (`Configuration validation failed`)

- **Symptom:** `npm start` (which runs the compiled `dist/index.js`) threw `Configuration validation failed: trading/momentum/safety/risk/... Required`. `npm run migrate` worked only because it runs via `ts-node` from `src/`.
- **Cause:** `tsc` compiles `.ts` → `.js` but does **not** copy non-code assets. The runtime config (`src/config/default.yaml`, `production.yaml`) and DB DDL (`src/db/schema.sql`, `src/db/migrations/002_extensions.sql`) were never placed in `dist/`, so at runtime `__dirname` (= `dist/config`, `dist/db`) had no YAML/SQL and the config parsed to `{}`.
- **Fix:**
  - Added `scripts/copy-assets.js` — a pure-Node, cross-platform step that recursively copies every `.yaml` / `.yml` / `.sql` file from `src/` into `dist/`, preserving directory structure.
  - Wired it into the build: `"build": "tsc --project tsconfig.json && node scripts/copy-assets.js"`, and added a standalone `"copy-assets"` script.
- After rebuilding, `dist/config/*.yaml` and `dist/db/*.sql` exist, so `node dist/index.js` loads the full config and schema. (This also makes the DB schema available when the app boots in compiled mode, not just under `ts-node`.)


---

## Pass 10 — `Cannot find module 'rpc-websockets/dist/lib/client'` (dependency conflict)

- **Symptom:** After config + DB init succeeded, boot crashed when `@solana/web3.js@1.91.8` loaded: `Cannot find module 'rpc-websockets/dist/lib/client'`.
- **Cause:** `@solana/web3.js` 1.91.x imports `rpc-websockets/dist/lib/client`. npm resolved a newer `rpc-websockets` (8.x/9.x) which restructured its build and removed that path, so the require failed. Not a code bug — a transitive-dependency version drift.
- **Fix:** Pinned the dependency via an npm `overrides` block in `package.json`:
  ```json
  "overrides": { "rpc-websockets": "^7.11.0" }
  ```
  The 7.x line still ships `dist/lib/client`, which is what web3.js 1.91.8 expects.
- **Action for existing installs:** the override only takes effect on a fresh dependency resolution, so delete and reinstall:
  ```bash
  rm -rf node_modules package-lock.json && npm install
  ```


---

## Pass 11 — `ERESOLVE` peer conflict between spl-token and web3.js

- **Symptom:** Fresh `npm install` failed: `@solana/spl-token@0.4.8` declares peer `@solana/web3.js@^1.94.0`, but the project pins `@solana/web3.js@1.91.8`. (Previously masked by an old lockfile / pre-existing node_modules.)
- **Decision:** Keep web3.js on `1.91.8` (paired with the `rpc-websockets@^7.11.0` override from Pass 10, a known-good combination) and **downgrade `@solana/spl-token` `0.4.8` → `0.4.6`**, whose peer range `^1.91.6` is satisfied by `1.91.8`. The spl-token APIs used by the bot (e.g. `getMint`) are stable across 0.4.x, so this is a no-code-change alignment.
- **Why not the alternatives:** `--legacy-peer-deps` would install spl-token 0.4.8 against an unsupported web3.js and risk runtime breakage; bumping web3.js to 1.95.x would require dropping the rpc-websockets override and re-validating the whole stack. Downgrading spl-token is the minimal, safe change.
- **Action for existing installs:**
  ```bash
  rm -rf node_modules package-lock.json && npm install
  ```


---

## Pass 12 — rpc-websockets override corrected to exact `7.5.1`

- **Symptom:** Even after the Pass 10 override (`^7.11.0`), boot still failed with `Cannot find module 'rpc-websockets/dist/lib/client'`.
- **Cause:** `^7.11.0` resolves to `7.11.0` (the highest 7.x). rpc-websockets `7.6.0`–`7.11.x` added a restrictive `"exports"` map to their package.json that blocks the deep subpath import `dist/lib/client` that `@solana/web3.js@1.91.8` relies on — so the deep import throws `MODULE_NOT_FOUND` even though it's a 7.x version. web3.js's own caret range (`^7.5.1`) inadvertently allows these broken releases, which is why this error is so widespread.
- **Fix:** Pinned the override to the **exact** version web3.js 1.91.8 was built against and which still permits the deep import:
  ```json
  "overrides": { "rpc-websockets": "7.5.1" }
  ```
- **Action for existing installs:**
  ```bash
  rm -rf node_modules package-lock.json && npm install
  npm ls rpc-websockets   # must show 7.5.1
  ```


---

## Pass 13 — Helius WebSocket 401 (double api-key in URL)

- **Symptom:** Bot booted fully and all engines initialized, but `HeliusWebSocket` looped on `connection failed ... Unexpected server response: 401`.
- **Cause:** `HeliusWebSocketClient` built the URL as `${heliusWsUrl}?api-key=${heliusApiKey}`. But `HELIUS_WS_URL` in `.env` already includes `?api-key=...`, so the result had **two** query strings (`...?api-key=KEY?api-key=KEY`). The server parsed a garbage key value and rejected the handshake with 401.
- **Fix (`src/ingestion/HeliusWebSocket.ts`):** build the URL robustly — if the configured URL already contains `api-key=`, use it as-is; otherwise append with the correct `?`/`&` separator. Handles both "full URL in env" and "base URL + separate key" setups.
- **Note on `transactionSubscribe`:** that method is a Helius enhanced stream served by the **Atlas** endpoint (`wss://atlas-mainnet.helius-rpc.com`) and requires a paid Helius plan. The standard `wss://mainnet.helius-rpc.com` endpoint does not support it. If after this fix the socket connects (101) but the subscription is rejected, switch `HELIUS_WS_URL` to the Atlas endpoint on a qualifying plan.


---

## Pass 14 — Raydium API migration (V2 dead host → V3)

- **Symptom:** Bot ran fully (Helius WS connected, transactionSubscribe sent, PumpFun connected, dashboard on :3001), but `RaydiumMonitor` logged `Raydium poll failed: getaddrinfo ENOTFOUND api.mainnet.raydium.io` every 10s.
- **Cause:** Raydium decommissioned the V2 API. The host `api.mainnet.raydium.io` no longer has a DNS record, so the lookup fails outright (not a 404 — the hostname is gone). Confirmed via web research: current API is **V3 at `https://api-v3.raydium.io`**.
- **Fix (`src/ingestion/RaydiumMonitor.ts`, full rewrite of the fetch/parse path):**
  - Endpoint → `https://api-v3.raydium.io/pools/info/list` with params `poolType=standard&poolSortField=volume24h&sortType=desc&pageSize=1000&page=1`.
  - V3 wraps results in `{ success, data: { count, data: [...], hasNextPage } }` — parse `body.data.data`.
  - V3 pool objects use `mintA`/`mintB` objects (with `address`/`symbol`/`decimals`) instead of flat `baseMint`/`quoteMint`, and the pool id is `pool.id` (was `ammId`).
  - V3 provides `tvl` (USD) directly, so the old `solReserve * 2 * getSolPriceUsd()` estimate (and the `SolPrice` import) was removed — liquidity is now exact.
  - Same downstream behavior preserved: SOL-paired filter, dust filter (<$5k), first-poll silent seeding, `TOKEN_CREATED` / `POOL_UPDATE` emissions, graceful poll-failure handling.

## Pass 15 — Raydium safety-checker migration (V2 dead host → V3)

- **Symptom:** After Pass 14 fixed the monitor, the run log showed `[LiquidityChecker] Liquidity check failed ... getaddrinfo ENOTFOUND api.mainnet.raydium.io` during per-token safety checks.
- **Cause:** Two more callers still used the decommissioned V2 host `api.mainnet.raydium.io/v2/main/pairs` (the monitor was only one of three Raydium consumers).
- **Fix:**
  - `src/engines/safety/LiquidityChecker.ts` — migrated to V3 `https://api-v3.raydium.io/pools/info/mint?mint1=<mint>&poolType=all&poolSortField=liquidity&sortType=desc&pageSize=100&page=1`; parses `data.data`, filters SOL-paired pools, returns max `tvl` as `liquidityUsd` and `pass = tvl >= minLiquidityUsd`.
  - `src/engines/safety/LpLockChecker.ts` — `_findLpMint` now resolves the pool's `lpMint.address` from V3 (`poolType=standard`), then checks burn/lock owners.
- **Confirmed by user run log:** ENOTFOUND gone; `[LpLockChecker] LP lock check` now succeeds.

## Pass 16 — LIVE TEST MODE (tiny fixed-size real trading)

> ⚠️ **This pass intentionally enables REAL on-chain buys with REAL SOL.** Sizes are hard-capped to a tiny absolute amount. Revert instructions are at the bottom.

**Goal:** make the entry → sizing → execution path actually fire (it was emitting 0 trades) while keeping every order tiny and capped.

### New deterministic tiny-size control
- `src/config/schema.ts` — added `risk.fixedPositionSizeSol` (default `0` = off, so production is unchanged).
- `src/risk/RiskManager.ts` — when `fixedPositionSizeSol > 0`, the computed size is overridden to that exact SOL amount (after both PositionSizer and the dynamic sizer), so every order is a fixed tiny size regardless of wallet balance or percentages.

### Config changes (`src/config/default.yaml`) — all tagged `# LIVE TEST`
- `risk.fixedPositionSizeSol: 0.01` — every buy is exactly **0.01 SOL (~$1.5)**.
- `risk.maxConcurrentPositions: 3 → 1`, `risk.maxDailyLossSol: 0.5 → 0.05`.
- `exposure.maxOpenPositions: 5 → 1`, `exposure.maxCapitalPerTokenSol: 2.0 → 0.05`, `exposure.maxDailyLossSol: 1.0 → 0.05`, `exposure.maxCapitalPerTradePct: 0.10 → 0.50` (gating only; absolute size stays fixed at 0.01 SOL).
- **Unblocked the entry gate** (these were the real reasons 0 trades fired):
  - `filters.minMarketCapUsd: 50000 → 0` — Raydium tokens report mcap `0`, which hard-failed every entry.
  - `safety.minLiquidityUsd: 30000 → 20000` — still passes the ~$500 order slippage check (≤ maxSlippageBps 300).
  - `trading.strategies.momentum.scoreThreshold: 65 → 45`.
  - `multiWalletConfirmation.enabled: true → false` — otherwise the gate required 3 co-buying wallets (with 0 monitored wallets it could never pass).
  - `liquidityInflow.rejectOnDecline: true → false`.
- **Kept ON (core rug protection):** `requireMintDisabled`, `requireFreezeDisabled`, `maxRugScore: 30`, `minTokenAgeMs: 300000`.

### Wallet requirement
- The trading wallet needs roughly **≥ 0.02 SOL** for a 0.01 SOL order to clear sizing + exposure checks (plus a little for fees/priority). ~0.05 SOL is a comfortable minimum.

### To revert to production (paper-safe) sizing
- Set `risk.fixedPositionSizeSol: 0` (or delete the key), and restore: `momentum.scoreThreshold: 65`, `safety.minLiquidityUsd: 30000`, `filters.minMarketCapUsd: 50000`, `multiWalletConfirmation.enabled: true`, `liquidityInflow.rejectOnDecline: true`, and the `risk.*` / `exposure.*` caps to their prior values. `production.yaml` still carries the stricter overrides for `NODE_ENV=production`.

## Pass 17 — Feed live prices to candidates so momentum can actually score (the real “0 trades” cause)

**Symptom:** Even after Pass 16 unblocked the entry gate, still 0 trades. `/tokens` showed 24 tracked tokens but every `liquidityUsd` was identical across polls and `mcapUsd` was always 0 — i.e. tokens were seeded once and received no live updates.

**Root cause (traced through the whole chain):** The entry gate only runs on a `MOMENTUM_SIGNAL`. That signal is only emitted when a token's momentum score crosses the threshold. The score is built from live trade + price data, but:
- The tracked tokens come from the **Raydium REST poller**, which only emits `TOKEN_CREATED` + `POOL_UPDATE` (a static snapshot) — no live trades.
- `TRADE_DETECTED` only comes from the Helius WS (configured with `accountInclude: []`, so no usable per-token trades) and PumpFun.
- `PRICE_UPDATE` only comes from the `PriceOracle`, which **only polled tokens already held** (`trackToken` was called on buy). Candidate tokens were never price-polled.
- Result: for every candidate, all 5 detectors scored ~0 → no signal → gate never invoked → no trade. (My Pass 16 gate changes were necessary but never reached.)

**Fix (quick path — get it trading via price-driven momentum):**
1. `src/index.ts` — on `TOKEN_CREATED`, also `priceOracle.trackToken(mint)`, so candidate tokens get a `PRICE_UPDATE` every 5s (not just held positions).
2. `src/ingestion/PriceOracle.ts` — bounded the tracked set with `maxTrackedMints = 250` (evicts oldest non-WSOL mint) so candidate tracking can't grow unbounded.
3. `src/engines/momentum/MomentumEngine.ts` — `processPriceUpdate` now calls `_maybeEmitSignal`, so a price tick can emit a signal (previously only trade/pool updates triggered scoring).
4. `src/config/default.yaml` — `momentum.scoreThreshold: 45 → 15`. With price-only data only **PriceAccel** can score (max ~20 pts; volume/buy-pressure/velocity need a real trade stream, and liquidity is flat), so 15 lets a genuine upward price acceleration fire a buy.

**Honest limitation:** This trades on **price acceleration only**. Full-quality momentum (volume spike, buy/sell pressure, tx velocity) still needs a real trade stream — i.e. narrowing the Helius `transactionSubscribe` to the Raydium/Pump AMM program IDs (a larger change, not done here).

**To revert:** set `momentum.scoreThreshold` back to 65 and remove the `TOKEN_CREATED → trackToken` line (the PriceOracle cap and the `_maybeEmitSignal` call are safe to keep).

## Pass 18 — Diagnostics so we can SEE the price→score path (info-level)

Pass 17 is confirmed compiled into `dist/` (verified `maxTrackedMints` present). Tokens pass safety but no momentum signal fires yet. At `info` log level we can't tell whether prices are even coming back for these brand-new pools, or what scores tokens get. Added two lightweight `info` logs:

1. `src/ingestion/PriceOracle.ts` — each 5s poll now logs `PriceOracle poll complete { tracked, priced }`. `priced` = how many tracked tokens Jupiter actually returned a price for. If `priced` stays ~0 while `tracked` is high, Jupiter does not index these new pools yet, so PriceAccel has no data to score (the likely real reason for no signals). `_fetchBatch` now returns the count of emitted PRICE_UPDATEs.
2. `src/engines/momentum/MomentumEngine.ts` — `_maybeEmitSignal` now logs `Momentum below threshold { mint, score, accel, liquidity }` at info whenever a token scores > 0 but < threshold, so we can watch how close tokens get to 15 (throttled to one per 2s per token).

No behavior change — logging only. Requires `npm run build` + restart to take effect.

## Pass 19 — Track safety-passed tokens + backfill existing backlog

**Goal:** Widen price-tracking coverage so momentum scoring sees more real candidates, and stop losing the backlog on restart.

**Files changed (1):**
- `src/index.ts`
  1. TOKEN_CREATED safety handler now price-tracks a token **only when it passes safety** (real entry candidate). Replaces the Pass 17 blanket "track every new token" line — junk that fails safety can never clear the entry gate, so polling it just wasted Jupiter calls. Safety report is still persisted to the DB for the gate.
  2. **Startup backfill:** after `priceOracle.start()`, load recently-seen tokens (last 2h, up to 200) from `TokenRepository`, and re-track the ones that already passed safety (using persisted rug/auth/honeypot/liquidity fields). Previously only pools discovered AFTER startup got tracked, so a restart dropped the known backlog to near-zero coverage.

**Net effect:** tracked set = (safe new pools) + (safe recent backlog). Expect the `[PriceOracle] poll complete {tracked, priced}` line to show a higher `tracked` after restart.

**Rebuild + restart:**
```
npm run build && pm2 restart solana-meme-bot
```

**Honest expectation:** even with wider coverage, a trade only fires when a *safe* token actually accelerates (price-only momentum, max ~20, threshold 15). Volume/buy-pressure stay 0 without a real trade stream — reliable entries still need the Helius `accountInclude` narrowed to Raydium/Pump AMM program IDs (the "trade stream" fix).

## Pass 20 — Make the bot actually trade on price-only data

**Problem traced end-to-end:** Pass 19 widened tracking (tracked:5, priced:4) but still no trade. Full pipeline audit showed:
- `HybridEntryGate.evaluateMomentum` approves on a momentum signal ALONE (`requireBoth` is dead config — never enforced). Downstream gate checks all pass for backfilled tokens: token age OK, safety passes, `rejectOnDecline:false` (liquidity health = true), holder health = true (no data), `multiWalletConfirmation.enabled:false` (skipped), mcap min = 0, liquidity/slippage OK at ≥$20k.
- **The ONLY blocker is that the momentum score never reaches the threshold (15).** With no trade stream, volume/buy/velocity detectors stay at 0, so the only live signal is `PriceAccel`. But `PriceAccel` scored the 2nd derivative (acceleration) and returned 0 unless price was *curving upward* — a steadily-rising or flat token scored 0. That's why there were ZERO `Momentum below threshold` logs: the signal could never fire on the data we actually have (Jupiter price polling only).

**Fix (1 file): `src/engines/momentum/PriceAccel.ts`**
- `getScore` now returns the STRONGER of two upward signals:
  - **A) Price RETURN over the window** (1st order): `ret = (last - first)/first`. Reused `priceAccelThreshold` (0.02) as the return threshold → a ~2% gain over the ~50s window scores 15 (crosses threshold), ~2.7% scores the 20-pt max.
  - **B) Acceleration** (original 2nd-derivative logic) — kept so sharp curve-ups still score.
- Net: a normally-moving (trending-up) tracked token now emits `MOMENTUM_SIGNAL` → passes the gate → real buy.

**Rebuild + restart:**
```
npm run build && pm2 restart solana-meme-bot
```

**What to watch for in logs (in order):**
1. `Momentum below threshold {score, accel, ...}` — now you'll finally see non-zero scores as tokens move.
2. `Momentum signal {mint, score}` — a token crossed 15.
3. `Entry approved {mint, strategy:"momentum"}` — gate passed.
4. Execution / `TRADE_FILLED` — a REAL buy of ~0.01 SOL.

**CRITICAL before this fires:**
- The trading wallet `44tX9DS7D4YFycMfAeyNQJCXCt1NXR3b7MhNRk8Uuapg` MUST hold SOL (≥ ~0.02 SOL) or the buy fails at execution with insufficient balance.
- This is REAL money. A ~2% upward move now triggers a real ~0.01 SOL buy. This is a price-only heuristic (lower quality than full multi-signal momentum) — it's what's possible without a real trade stream. The higher-quality fix is still narrowing the Helius `accountInclude` to Raydium/Pump program IDs so volume/buy-pressure feed the score.
- ROTATE the leaked Helius/QuickNode keys and use a fresh burner wallet before any real-money run.

## Pass 21 — Fix: backfilled tokens were never scored (the real “no trade” cause)

**Symptom:** After Pass 20, backfill ran (scanned:12, tracked:6) and polling showed `tracked:7, priced:6`, but STILL zero `Momentum below threshold` logs and no signal/trade.

**Root cause:** `MomentumEngine` only created per-token scoring state on `TOKEN_CREATED` (`registerToken`). The backfilled backlog tokens were discovered in PRIOR sessions, so `TOKEN_CREATED` never re-fires for them after a restart. `processPriceUpdate` did `if (!state) return;` and silently dropped EVERY price tick for those tokens — they were priced by Jupiter but never scored. That's why there were literally zero below-threshold logs: the price-return logic from Pass 20 never ran on the tokens actually being tracked.

**Fix (1 file): `src/engines/momentum/MomentumEngine.ts`**
- `processPriceUpdate` now lazily registers a momentum state when one is missing (mirrors the lazy registration `processTrade` already does). Any price-tracked token now accumulates price history and gets scored on every tick.

**Rebuild + restart:**
```
npm run build && pm2 restart solana-meme-bot
```

**What to watch (in order):**
1. `Momentum below threshold {score, accel, ...}` — you should now finally see non-zero scores for the priced tokens (this was completely absent before).
2. `Momentum signal {mint, score}` — a token moved up ~2%+ over the window.
3. `Entry approved {strategy:"momentum"}` → real ~0.01 SOL buy.

**Honest note:** if the 6 priced backlog tokens are flat/dead, scores will hover near 0 and a trade only fires when one actually moves up. The surest path to frequent, high-quality signals is still the real trade stream (narrowing Helius `accountInclude` to Raydium/Pump program IDs) so volume + buy-pressure feed the score — the price-only path can only react to price drift. Wallet `44tX9DS7D4YFycMfAeyNQJCXCt1NXR3b7MhNRk8Uuapg` must hold ≥ ~0.02 SOL for the buy to execute.
