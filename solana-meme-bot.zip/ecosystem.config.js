// PM2 process configuration for the Solana meme-coin trading bot.
//
// IMPORTANT: run a SINGLE instance in fork mode. This bot is stateful
// (open positions, kill switch, cooldowns, in-memory price cache). Running
// it in cluster mode or with instances > 1 would DOUBLE-SUBMIT trades and
// corrupt risk accounting. Do not change exec_mode/instances.
module.exports = {
  apps: [
    {
      name: 'solana-meme-bot',
      script: 'dist/index.js',
      cwd: __dirname,
      instances: 1,
      exec_mode: 'fork',
      autorestart: true,
      max_restarts: 10,
      min_uptime: '30s',
      restart_delay: 5000,
      exp_backoff_restart_delay: 2000,
      max_memory_restart: '1G',
      kill_timeout: 30000, // give graceful shutdown time to flush state
      wait_ready: false,
      node_args: '--enable-source-maps',
      env: {
        NODE_ENV: 'production',
      },
      out_file: 'logs/pm2-out.log',
      error_file: 'logs/pm2-error.log',
      merge_logs: true,
      time: true,
    },
  ],
}
