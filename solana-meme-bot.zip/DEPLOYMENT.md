# Deployment Guide & Architecture

> ⚠️ **Money-safety notice.** This bot signs and broadcasts real Solana transactions. Before pointing it at mainnet with real funds you **must** (1) run it against devnet, (2) run it on mainnet with the smallest possible position size, and (3) confirm the kill switch, stop-loss, and exit paths fire as expected on live fills. No code review substitutes for live testing.

---

## 1. Architecture overview

```mermaid
flowchart TD
    subgraph Ingestion
        H["Helius WS (Atlas)"]
        P["PumpFun Monitor"]
        R["Raydium Monitor"]
        W["Wallet Monitor (smart money)"]
        O["Price Oracle (Jupiter V3)"]
    end

    subgraph Bus["EventBus (queued, dead-letter)"]
        EB((events))
    end

    subgraph Analysis
        SAFE["Safety / Rug Engines"]
        MOM["Momentum Engines"]
        LIQ["Liquidity Inflow"]
        HOLD["Holder Growth"]
        SMART["Smart-Money Cluster"]
        SIG["Signal Filter"]
    end

    subgraph Decision
        GATE["Hybrid Entry Gate"]
        RISK["Risk Manager + Exposure + Dynamic Sizing"]
        KILL["Global Kill Switch"]
        COOL["Cooldown Tracker"]
    end

    subgraph Execution
        EXE["Execution Engine"]
        JUP["Jupiter Client (swap v1)"]
        FEE["Priority Fee Manager"]
        MEV["MEV / Jito Protection"]
        TXC["Tx Confirmation"]
        REC["Failed Trade Recovery"]
    end

    subgraph Exit
        SL["Stop-Loss / Trailing / TP Manager"]
    end

    subgraph Persistence
        DB[("SQLite: trades, positions, tokens, wallets, signals, metrics")]
    end

    subgraph Observability
        LOG["Winston logs (redacted)"]
        HTTP["HTTP: /health /metrics /dashboard"]
        ALERT["Telegram / Discord alerts"]
    end

    H & P & R & W & O --> EB
    EB --> SAFE & MOM & LIQ & HOLD & SMART & SIG
    SAFE & MOM & LIQ & HOLD & SMART & SIG --> GATE
    GATE --> RISK
    COOL --> RISK
    KILL --> RISK
    RISK -->|ORDER_READY| EXE
    EXE --> JUP --> MEV --> TXC
    FEE --> EXE
    TXC -->|TRADE_FILLED| EB
    TXC --> REC
    EB --> SL
    SL -->|CLOSE_SIGNAL| EXE
    EXE & RISK & SL --> DB
    EXE & KILL --> ALERT
    DB --> HTTP
```

### Trade lifecycle (happy path)

```mermaid
sequenceDiagram
    participant Ing as Ingestion
    participant Gate as Entry Gate
    participant Risk as Risk Manager
    participant Exe as Execution
    participant Jito as MEV/Jito
    participant RPC as RPC
    participant DB as SQLite

    Ing->>Gate: TOKEN_CREATED / momentum / liquidity / smart-money
    Gate->>Gate: composite score >= threshold?
    Gate->>Risk: ENTRY_APPROVED
    Risk->>Risk: kill switch, cooldown, exposure, dynamic size
    Risk->>Exe: ORDER_READY (sizeSol)
    Exe->>RPC: simulate transaction
    RPC-->>Exe: ok / fail
    Exe->>Jito: submit (bundle + tip)
    Jito->>RPC: confirm
    RPC-->>Exe: confirmed
    Exe->>DB: insert trade + open position (sizeTokens)
    Exe->>Ing: TRADE_FILLED -> track price for SL/TP
```

---

## 2. Prerequisites

- Node.js 20 LTS (or Docker).
- A funded Solana wallet (base58 private key).
- Helius API key (required). QuickNode / Triton URLs optional for failover.
- Build toolchain for the native `better-sqlite3` module (`python3`, `make`, `g++`) — already handled inside the Docker image.

---

## 3. Configuration

1. Copy `.env.example` to `.env` and fill in secrets.
2. Review `src/config/default.yaml` (and `production.yaml`) for thresholds: risk limits, slippage, position sizing, kill-switch limits.
3. **Never commit `.env`.** In production, inject secrets via AWS Secrets Manager / SSM (see §6).

---

## 4. Local / bare-metal run

```bash
npm ci
npm run build
node --enable-source-maps dist/index.js
```

---

## 5. Docker

```bash
# Build
docker compose build

# Run (detached)
docker compose up -d

# Logs / health
docker compose logs -f bot
curl localhost:8080/health
```

The SQLite database and logs persist in `./data` and `./logs` via mounted volumes. `stop_grace_period: 30s` lets the bot flush state and exit positions cleanly on shutdown.

---

## 6. PM2 (single VM)

```bash
npm ci && npm run build
npm install -g pm2
pm2 start ecosystem.config.js
pm2 save
pm2 startup    # follow printed instructions to enable on boot
pm2 logs solana-meme-bot
```

> The PM2 config runs **one** instance in fork mode on purpose. Do **not** scale to cluster mode — the bot is stateful and would double-trade.

---

## 7. AWS deployment

### Option A — EC2 + PM2 (simplest)

1. Launch an **t3.small** (2 vCPU / 2 GB) Amazon Linux 2023 / Ubuntu 22.04 instance in a region close to your RPC (us-east-1 / Frankfurt for Jito).
2. Security group: allow outbound 443/HTTPS + your RPC/WS ports; restrict inbound to your IP for 8080 (dashboard) and 22 (SSH). Prefer SSM Session Manager over open SSH.
3. Install Node 20, clone the repo, `npm ci && npm run build`.
4. Store secrets in **SSM Parameter Store** (SecureString) or **Secrets Manager**; load them into the environment at boot instead of a plaintext `.env`:
   ```bash
   export WALLET_PRIVATE_KEY=$(aws ssm get-parameter --name /bot/wallet_key --with-decryption --query Parameter.Value --output text)
   export HELIUS_API_KEY=$(aws ssm get-parameter --name /bot/helius --with-decryption --query Parameter.Value --output text)
   ```
5. Start with PM2 (§6). Use a CloudWatch agent to ship `./logs/*.log`.

### Option B — ECS Fargate (managed)

1. Push the image to ECR:
   ```bash
   aws ecr create-repository --repository-name solana-meme-bot
   docker build -t <acct>.dkr.ecr.<region>.amazonaws.com/solana-meme-bot:latest .
   docker push <acct>.dkr.ecr.<region>.amazonaws.com/solana-meme-bot:latest
   ```
2. Task definition: 0.5 vCPU / 1 GB. **desiredCount = 1** (never >1). Disable autoscaling.
3. Inject secrets via the task definition `secrets` block (Secrets Manager ARNs) — they appear as env vars, never in the image.
4. Mount an **EFS** volume at `/app/data` so the SQLite DB survives task replacement.
5. Route `/health` to an ALB target group health check, or use container healthcheck only.

> Trade-off: SQLite + a single task is intentional. If you need multi-AZ HA you must first migrate the DB layer to Postgres and add a leader-election lock so only one node trades — that is a larger change, not a config flip.

---

## 8. Operational runbook

| Situation | What happens / what to do |
|---|---|
| Daily loss / consecutive-loss / drawdown limit hit | Global Kill Switch pauses entries automatically; alert is sent. Investigate before resetting. |
| RPC outage | Failover to secondary RPC (if configured); kill switch pauses trading if all RPCs are unhealthy. |
| DB failure | Bot halts trading rather than trading blind. Restore the volume / DB file and restart. |
| Restart | `restoreFromDb()` reloads open positions and re-tracks their prices for SL/TP; `reconcilePendingTrades()` resolves in-flight trades. |
| Emergency stop | `docker compose down` / `pm2 stop solana-meme-bot`. Open positions remain in the DB and are restored on next start. |

---

## 9. Health & monitoring endpoints

- `GET /health` — liveness (used by Docker/ALB).
- `GET /metrics` — PnL, win rate, drawdown, open positions.
- `GET /dashboard` — real-time status page.

Alerts are pushed to Telegram and/or Discord when configured (entries, exits, kill-switch trips, errors).
