/** @type {import('jest').Config} */
module.exports = {
  preset: 'ts-jest',
  testEnvironment: 'node',
  roots: ['<rootDir>/tests'],
  testMatch: [
    '**/tests/unit/**/*.test.ts',
    '**/tests/integration/**/*.test.ts',
    '**/tests/simulation/**/*.test.ts',
  ],
  moduleNameMapper: {
    '^@core/(.*)$':      '<rootDir>/src/core/$1',
    '^@config/(.*)$':    '<rootDir>/src/config/$1',
    '^@db/(.*)$':        '<rootDir>/src/db/$1',
    '^@engines/(.*)$':   '<rootDir>/src/engines/$1',
    '^@ingestion/(.*)$': '<rootDir>/src/ingestion/$1',
    '^@risk/(.*)$':      '<rootDir>/src/risk/$1',
    '^@execution/(.*)$': '<rootDir>/src/execution/$1',
    '^@analytics/(.*)$': '<rootDir>/src/analytics/$1',
    '^@gate/(.*)$':      '<rootDir>/src/gate/$1',
  },
  transform: {
    '^.+\\.tsx?$': ['ts-jest', {
      tsconfig: {
        strict: false,          // Relax for test files
        esModuleInterop: true,
        resolveJsonModule: true,
        module: 'commonjs',
        target: 'ES2020',
      },
    }],
  },
  collectCoverageFrom: [
    'src/**/*.ts',
    '!src/index.ts',
    '!src/**/*.d.ts',
  ],
  coverageThreshold: {
    global: {
      branches: 50,
      functions: 60,
      lines: 60,
      statements: 60,
    },
  },
  coverageReporters: ['text', 'lcov', 'html'],
  testTimeout: 30000,
  maxWorkers: 2,           // limit parallelism on 1 vCPU VPS
  forceExit: true,
  detectOpenHandles: true,
  verbose: false,
  globals: {},
};
