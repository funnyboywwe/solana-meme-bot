import { describe, it, expect, beforeEach, afterEach, jest } from '@jest/globals';

jest.mock('../../../src/db/Database', () => ({
  getDb: () => ({
    prepare: () => ({ run: jest.fn(), get: jest.fn(), all: jest.fn(() => []) }),
    transaction: (fn: Function) => () => fn(),
  }),
}));

jest.mock('../../../src/core/EventBus', () => ({
  EventBus: { emit: jest.fn(), on: jest.fn() },
}));

const mockCfg = {} as any;
const mockExtCfg = {
  volumeAcceleration: {
    enabled: true,
    minAccelerationScore: 50,
    windowMs: 300000,
    rankingIntervalMs: 60000,
    maxTrackedTokens: 200,
  },
} as any;

function makeTrade(mint: string, side: 'buy' | 'sell' = 'buy', usd = 1000, tsOffset = 0) {
  return { mint, side, amountUsd: usd, amountSol: usd / 150, priceUsd: 0.001, walletAddress: 'w1', txHash: 'tx', ts: Date.now() - tsOffset, poolAddress: '' };
}

describe('VolumeAccelerationEngine', () => {
  let engine: any;

  beforeEach(async () => {
    jest.clearAllMocks();
    const { VolumeAccelerationEngine } = await import('../../../src/engines/volume/VolumeAccelerationEngine');
    engine = new VolumeAccelerationEngine(mockCfg, mockExtCfg);
  });

  afterEach(() => { engine.stop(); });

  it('returns 0 score for unknown token', () => {
    expect(engine.getScore('unknown')).toBe(0);
  });

  it('returns 0 score with insufficient data (<3 trades)', () => {
    engine.processTrade(makeTrade('mint1'));
    engine.processTrade(makeTrade('mint1'));
    expect(engine.getScore('mint1')).toBe(0);
  });

  it('computes positive score with buy-heavy volume', () => {
    // Add many recent buy trades
    for (let i = 0; i < 20; i++) {
      engine.processTrade(makeTrade('mint1', 'buy', 5000));
    }
    const score = engine.getScore('mint1');
    expect(score).toBeGreaterThan(0);
    expect(score).toBeLessThanOrEqual(100);
  });

  it('buy/sell ratio is lower with mixed trades', () => {
    for (let i = 0; i < 10; i++) engine.processTrade(makeTrade('mint1', 'buy', 2000));
    for (let i = 0; i < 10; i++) engine.processTrade(makeTrade('mint1', 'sell', 2000));
    const score = engine.getScore('mint1');
    expect(score).toBeGreaterThanOrEqual(0);
  });

  it('getTopTokens returns empty array initially', () => {
    expect(engine.getTopTokens(10)).toEqual([]);
  });

  it('tracks multiple tokens independently', () => {
    for (let i = 0; i < 5; i++) engine.processTrade(makeTrade('mintA', 'buy', 5000));
    for (let i = 0; i < 5; i++) engine.processTrade(makeTrade('mintB', 'buy', 100));
    const scoreA = engine.getScore('mintA');
    const scoreB = engine.getScore('mintB');
    expect(scoreA).toBeGreaterThanOrEqual(scoreB);
  });
});
