import { describe, it, expect, beforeEach, afterEach, jest } from '@jest/globals';

// Mock DB before imports
jest.mock('../../../src/db/Database', () => ({
  getDb: () => ({
    prepare: () => ({ run: jest.fn(), get: jest.fn(() => undefined), all: jest.fn(() => []) }),
    transaction: (fn: Function) => fn,
  }),
}));

jest.mock('../../../src/db/repositories/WalletRepository', () => ({
  default: {
    findByAddress: jest.fn(),
    exists: jest.fn(() => false),
  },
}));

jest.mock('../../../src/db/repositories/ClusterRepository', () => ({
  default: {
    insert: jest.fn((c: any) => ({ ...c, id: 'cluster-1' })),
    update: jest.fn(),
    addMember: jest.fn(),
    findByToken: jest.fn(() => []),
    getMembers: jest.fn(() => []),
    expireOld: jest.fn(() => 0),
    markExecuted: jest.fn(),
    countActive: jest.fn(() => 0),
  },
}));

jest.mock('../../../src/core/EventBus', () => ({
  EventBus: { emit: jest.fn(), on: jest.fn() },
}));

import WalletRepository from '../../../src/db/repositories/WalletRepository';
import ClusterRepository from '../../../src/db/repositories/ClusterRepository';
import { EventBus } from '../../../src/core/EventBus';

const mockCfg = {
  rpc: { rpcHttpUrl: 'http://localhost', heliusApiKey: 'key', heliusWsUrl: 'wss://x', commitment: 'confirmed' },
  wallet: { privateKey: 'key', maxBalancePctPerTrade: 0.07 },
} as any;

const mockExtCfg = {
  smartMoney: {
    enabled: true,
    clusterWindowMs: 300000,
    minWalletCount: 3,
    minConfidenceScore: 60,
    minWalletQualityScore: 55,
    expiryMs: 600000,
    maxClustersPerToken: 5,
  },
} as any;

function makeWalletTx(wallet: string, mint: string, side: 'buy' | 'sell' = 'buy') {
  return { walletAddress: wallet, mint, side, amountSol: 0.5, amountTokens: 1000, priceUsd: 0.001, txHash: 'tx1', ts: Date.now(), slot: 1 };
}

function makeWalletStats(overrides = {}) {
  return { qualityScore: 70, winRate: 0.6, avgRoi: 1.5, totalTrades: 20, profitableTrades: 12, totalPnlSol: 2, rank: 1, ...overrides };
}

describe('SmartMoneyClusterEngine', () => {
  let engine: any;

  beforeEach(async () => {
    jest.clearAllMocks();
    const { SmartMoneyClusterEngine } = await import('../../../src/engines/smart-money/SmartMoneyClusterEngine');
    engine = new SmartMoneyClusterEngine(mockCfg, mockExtCfg);
  });

  afterEach(() => { engine.stop(); });

  it('ignores sell events', () => {
    (WalletRepository.findByAddress as jest.Mock).mockReturnValue(makeWalletStats());
    engine.processWalletBuy(makeWalletTx('w1', 'mint1', 'sell'));
    expect(ClusterRepository.insert).not.toHaveBeenCalled();
  });

  it('ignores wallets below quality threshold', () => {
    (WalletRepository.findByAddress as jest.Mock).mockReturnValue(makeWalletStats({ qualityScore: 30 }));
    engine.processWalletBuy(makeWalletTx('w1', 'mint1'));
    expect(ClusterRepository.insert).not.toHaveBeenCalled();
  });

  it('does not create cluster below minWalletCount', () => {
    (WalletRepository.findByAddress as jest.Mock).mockReturnValue(makeWalletStats());
    engine.processWalletBuy(makeWalletTx('w1', 'mint1'));
    engine.processWalletBuy(makeWalletTx('w2', 'mint1'));
    expect(ClusterRepository.insert).not.toHaveBeenCalled();
  });

  it('creates cluster when minWalletCount reached with enough confidence', () => {
    (WalletRepository.findByAddress as jest.Mock).mockReturnValue(makeWalletStats({ qualityScore: 80, winRate: 0.7 }));
    (ClusterRepository.findByToken as jest.Mock).mockReturnValue([]);
    (ClusterRepository.insert as jest.Mock).mockReturnValue({ id: 'cluster-1', walletCount: 3, confidenceScore: 75, totalCapitalSol: 1.5, tokenMint: 'mint1' });

    engine.processWalletBuy(makeWalletTx('w1', 'mint1'));
    engine.processWalletBuy(makeWalletTx('w2', 'mint1'));
    engine.processWalletBuy(makeWalletTx('w3', 'mint1'));

    expect(ClusterRepository.insert).toHaveBeenCalledTimes(1);
    expect(EventBus.emit).toHaveBeenCalledWith('SMART_MONEY_CLUSTER', expect.objectContaining({ tokenMint: 'mint1' }));
  });

  it('deduplicates wallet entries per token', () => {
    (WalletRepository.findByAddress as jest.Mock).mockReturnValue(makeWalletStats({ qualityScore: 80 }));
    engine.processWalletBuy(makeWalletTx('w1', 'mint1'));
    engine.processWalletBuy(makeWalletTx('w1', 'mint1')); // duplicate
    engine.processWalletBuy(makeWalletTx('w2', 'mint1'));
    expect(ClusterRepository.insert).not.toHaveBeenCalled(); // only 2 unique wallets
  });

  it('returns zero confidence for unknown mint', () => {
    expect(engine.getConfidenceScore('unknown-mint')).toBe(0);
  });
});
