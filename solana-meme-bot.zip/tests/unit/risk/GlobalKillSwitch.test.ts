import { describe, it, expect, beforeEach, jest } from '@jest/globals';

jest.mock('../../../src/db/Database', () => ({
  getDb: () => ({ prepare: () => ({ run: jest.fn() }) }),
}));

jest.mock('../../../src/core/EventBus', () => ({
  EventBus: { emit: jest.fn(), on: jest.fn() },
}));

const mockCfg = {} as any;
const mockExtCfg = {
  killSwitch: {
    enabled: true,
    triggers: {
      dailyDrawdownPct: 0.20,
      consecutiveLosses: 5,
      rpcErrorRateThreshold: 0.30,
      liquidityCollapseThreshold: 0.50,
    },
    alertWebhook: '',
    alertOnActivation: false,
    alertOnDeactivation: false,
  },
  exposure: { cooldownAfterKillSwitchMs: 3600000 },
} as any;

describe('GlobalKillSwitch', () => {
  let ks: any;

  beforeEach(async () => {
    jest.clearAllMocks();
    const { GlobalKillSwitch } = await import('../../../src/risk/GlobalKillSwitch');
    ks = new GlobalKillSwitch(mockCfg, mockExtCfg);
  });

  it('starts inactive', () => {
    expect(ks.isActive()).toBe(false);
  });

  it('trips on daily drawdown threshold', () => {
    ks.evaluate({ dailyDrawdownPct: 0.25 });
    expect(ks.isActive()).toBe(true);
    expect(ks.getStatus().reason).toBe('daily_drawdown');
  });

  it('does NOT trip below daily drawdown threshold', () => {
    ks.evaluate({ dailyDrawdownPct: 0.10 });
    expect(ks.isActive()).toBe(false);
  });

  it('trips on consecutive losses', () => {
    ks.evaluate({ consecutiveLosses: 5 });
    expect(ks.isActive()).toBe(true);
    expect(ks.getStatus().reason).toBe('consecutive_losses');
  });

  it('trips on RPC instability', () => {
    // 4 errors out of 10 calls = 40% > 30% threshold
    for (let i = 0; i < 6; i++) ks.recordRPCCall(true);
    for (let i = 0; i < 4; i++) ks.recordRPCCall(false);
    expect(ks.isActive()).toBe(true);
    expect(ks.getStatus().reason).toBe('rpc_instability');
  });

  it('does not trip on low RPC error rate', () => {
    for (let i = 0; i < 9; i++) ks.recordRPCCall(true);
    ks.recordRPCCall(false); // 10% error rate
    expect(ks.isActive()).toBe(false);
  });

  it('trips on liquidity collapse', () => {
    ks.evaluate({ liquidityDropPct: 0.60 });
    expect(ks.isActive()).toBe(true);
    expect(ks.getStatus().reason).toBe('liquidity_collapse');
  });

  it('manual kill activates', () => {
    ks.kill('Test halt');
    expect(ks.isActive()).toBe(true);
  });

  it('manual reset deactivates', () => {
    ks.kill('Test halt');
    ks.reset('Test clear');
    expect(ks.isActive()).toBe(false);
  });

  it('stays inactive if disabled', async () => {
    const disabledCfg = { ...mockExtCfg, killSwitch: { ...mockExtCfg.killSwitch, enabled: false } };
    const { GlobalKillSwitch } = await import('../../../src/risk/GlobalKillSwitch');
    const ks2 = new GlobalKillSwitch(mockCfg, disabledCfg);
    ks2.kill('Force kill');
    expect(ks2.isActive()).toBe(false);
  });
});
