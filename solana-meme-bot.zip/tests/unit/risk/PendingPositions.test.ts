import { describe, it, expect, beforeEach } from '@jest/globals';
import { PendingPositions } from '../../../src/risk/exposure/PendingPositions';

/**
 * Guards the concurrency fix for the "bot fired 2-3 buys in one burst despite
 * maxConcurrentPositions=1" bug. The reservation registry is what makes
 * RiskManager.evaluate serialise concurrent ENTRY_APPROVED events.
 */
describe('PendingPositions reservation registry', () => {
  beforeEach(() => PendingPositions.clear());

  it('reserves and counts in-flight slots', () => {
    expect(PendingPositions.size()).toBe(0);
    PendingPositions.reserve('mintA');
    expect(PendingPositions.has('mintA')).toBe(true);
    expect(PendingPositions.size()).toBe(1);
  });

  it('blocks a second slot once the only slot is reserved (1-slot cap)', () => {
    const maxConcurrent = 1;
    const openCount = 0; // nothing in DB yet

    // First approval claims the slot.
    expect(openCount + PendingPositions.size() >= maxConcurrent).toBe(false);
    PendingPositions.reserve('mintA');

    // Second approval (different token) must now be rejected — this is the
    // exact case that previously slipped through and opened a 2nd position.
    expect(openCount + PendingPositions.size() >= maxConcurrent).toBe(true);
  });

  it('rejects a duplicate in-flight buy for the same mint', () => {
    PendingPositions.reserve('mintA');
    expect(PendingPositions.has('mintA')).toBe(true);
  });

  it('frees the slot on release so the next candidate can trade', () => {
    PendingPositions.reserve('mintA');
    expect(PendingPositions.size()).toBe(1);
    PendingPositions.release('mintA');
    expect(PendingPositions.size()).toBe(0);
    expect(PendingPositions.has('mintA')).toBe(false);
  });

  it('release is idempotent', () => {
    PendingPositions.reserve('mintA');
    PendingPositions.release('mintA');
    PendingPositions.release('mintA'); // must not throw
    expect(PendingPositions.size()).toBe(0);
  });

  it('prunes orphaned reservations after the configured window', async () => {
    PendingPositions.configure({ pruneMs: 20 });
    PendingPositions.reserve('mintStuck');
    expect(PendingPositions.size()).toBe(1);
    await new Promise((r) => setTimeout(r, 40));
    expect(PendingPositions.size()).toBe(0); // self-healed
    PendingPositions.configure({ pruneMs: 180_000 }); // restore default
  });
});
