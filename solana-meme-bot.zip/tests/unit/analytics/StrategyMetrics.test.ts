import { describe, it, expect, jest } from '@jest/globals';

// Realised-PnL series for the equity curve:
//   +1.0  -> equity 1.0  (peak 1.0)
//   -0.5  -> equity 0.5  (drawdown 0.5)
//   +2.0  -> equity 2.5  (peak 2.5)
//   -1.0  -> equity 1.5  (drawdown 1.0  <- max)
const rows = [
  { realised_pnl_sol: 1 },
  { realised_pnl_sol: -0.5 },
  { realised_pnl_sol: 2 },
  { realised_pnl_sol: -1 },
];

jest.mock('../../../src/db/Database', () => ({
  getDb: () => ({
    prepare: () => ({ all: () => rows }),
  }),
}));

import { StrategyMetrics } from '../../../src/analytics/StrategyMetrics';

describe('StrategyMetrics.getRiskAnalytics', () => {
  it('computes max drawdown and risk ratios over the equity curve', () => {
    const r = new StrategyMetrics().getRiskAnalytics();
    expect(r.trades).toBe(4);
    expect(r.equityPeakSol).toBeCloseTo(2.5, 6);
    expect(r.maxDrawdownSol).toBeCloseTo(1.0, 6);
    expect(r.maxDrawdownPct).toBeCloseTo(40, 4);
    expect(r.volatilitySol).toBeGreaterThan(0);
    expect(Number.isFinite(r.sharpe)).toBe(true);
    expect(Number.isFinite(r.sortino)).toBe(true);
  });
});
