import { RpcManager } from '@core/RpcManager';
import type { AppConfig } from '../../../src/config/AppConfig';

/**
 * These tests exercise routing + failover logic WITHOUT hitting the network.
 * web3.js Connection only performs I/O when an RPC method is actually called;
 * constructing it and reading `.rpcEndpoint` is offline-safe, and our failover
 * callbacks are plain functions we control.
 */
function makeCfg(over: Record<string, unknown> = {}): AppConfig {
  return {
    rpc: {
      commitment: 'confirmed',
      rpcHttpUrl: 'https://helius.example/read',
      heliusWsUrl: undefined,
      orbitFlareRpcUrl: 'https://orbitflare.example/write',
      orbitFlareWsUrl: undefined,
      quickNodeRpcUrl: 'https://quicknode.example/fallback',
      quickNodeWsUrl: undefined,
      tritonRpcUrl: undefined,
      tritonWsUrl: undefined,
      fallbackRpcUrls: [],
      healthCheckIntervalMs: 30_000,
      maxRpcFailures: 3,
      rpcMaxRetries: 3,
      rpcRetryBaseDelayMs: 1,
      probeTimeoutMs: 5_000,
      slotLagThreshold: 150,
      ...over,
    },
  } as unknown as AppConfig;
}

describe('RpcManager role-based routing', () => {
  it('routes reads to Helius (primary read)', () => {
    const mgr = new RpcManager(makeCfg());
    expect(mgr.getReadConnection().rpcEndpoint).toContain('helius');
    expect(mgr.getActiveReadLabel()).toBe('helius');
  });

  it('routes writes to OrbitFlare (primary write)', () => {
    const mgr = new RpcManager(makeCfg());
    expect(mgr.getWriteConnection().rpcEndpoint).toContain('orbitflare');
    expect(mgr.getActiveWriteLabel()).toBe('orbitflare');
  });

  it('falls back writes to QuickNode when OrbitFlare is not configured', () => {
    const mgr = new RpcManager(makeCfg({ orbitFlareRpcUrl: undefined }));
    // With no OrbitFlare, QuickNode (writePriority=fallback) beats Helius
    // (writePriority=last-resort) and becomes the write primary.
    expect(mgr.getWriteConnection().rpcEndpoint).toContain('quicknode');
  });

  it('back-compat getConnection() resolves to the read pool', () => {
    const mgr = new RpcManager(makeCfg());
    expect(mgr.getConnection().rpcEndpoint).toContain('helius');
  });
});

describe('RpcManager failover', () => {
  it('returns the operation result on success without switching endpoints', async () => {
    const mgr = new RpcManager(makeCfg());
    const out = await mgr.withReadFailover(async (c) => c.rpcEndpoint, 'test');
    expect(out).toContain('helius');
    expect(mgr.getActiveReadLabel()).toBe('helius');
  });

  it('fails over reads from Helius to QuickNode and promotes the new active', async () => {
    const mgr = new RpcManager(makeCfg());
    const out = await mgr.withReadFailover(async (c) => {
      if (c.rpcEndpoint.includes('helius')) throw new Error('helius down');
      return c.rpcEndpoint;
    }, 'getAccountInfo');
    expect(out).toContain('quicknode');
    expect(mgr.getActiveReadLabel()).toBe('quicknode');
  });

  it('fails over writes from OrbitFlare to QuickNode', async () => {
    const mgr = new RpcManager(makeCfg());
    const out = await mgr.withWriteFailover(async (c) => {
      if (c.rpcEndpoint.includes('orbitflare')) throw new Error('orbitflare down');
      return c.rpcEndpoint;
    }, 'sendRawTransaction');
    expect(out).toContain('quicknode');
    expect(mgr.getActiveWriteLabel()).toBe('quicknode');
  });

  it('retries a transient (rate-limit) error on the same endpoint before succeeding', async () => {
    const mgr = new RpcManager(makeCfg());
    let calls = 0;
    const out = await mgr.withReadFailover(async (c) => {
      calls++;
      if (calls === 1) throw new Error('429 Too Many Requests');
      return c.rpcEndpoint;
    }, 'getSlot');
    expect(calls).toBe(2);
    expect(out).toContain('helius'); // stayed on Helius via retry, no failover
    expect(mgr.getActiveReadLabel()).toBe('helius');
  });

  it('throws after all endpoints fail', async () => {
    const mgr = new RpcManager(makeCfg());
    await expect(
      mgr.withWriteFailover(async () => {
        throw new Error('total outage');
      }, 'sendTransaction'),
    ).rejects.toThrow();
  });
});
