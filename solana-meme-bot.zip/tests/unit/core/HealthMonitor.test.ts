import { HealthMonitor, MonitoredEndpoint } from '@core/HealthMonitor';
import type { Connection } from '@solana/web3.js';

function makeEndpoint(label: string, getSlot: jest.Mock): MonitoredEndpoint {
  return {
    label,
    connection: { getSlot } as unknown as Connection,
    healthy: true,
    consecutiveFailures: 0,
    latencyMs: 0,
    slot: 0,
    successCount: 0,
    failureCount: 0,
    lastCheck: 0,
  };
}

const opts = {
  commitment: 'confirmed' as const,
  intervalMs: 30_000,
  maxFailures: 3,
  probeTimeoutMs: 1_000,
  slotLagThreshold: 150,
};

describe('HealthMonitor', () => {
  it('marks an endpoint unhealthy after 3 consecutive failures', async () => {
    const getSlot = jest.fn().mockRejectedValue(new Error('rpc down'));
    const ep = makeEndpoint('helius', getSlot);
    const mon = new HealthMonitor([ep], opts);

    await mon.checkNow();
    expect(ep.healthy).toBe(true); // 1 failure
    await mon.checkNow();
    expect(ep.healthy).toBe(true); // 2 failures
    await mon.checkNow();
    expect(ep.healthy).toBe(false); // 3 failures -> unhealthy
    expect(ep.consecutiveFailures).toBe(3);
    expect(ep.failureCount).toBe(3);
  });

  it('auto-recovers an unhealthy endpoint on the next successful probe', async () => {
    const getSlot = jest
      .fn()
      .mockRejectedValueOnce(new Error('down'))
      .mockRejectedValueOnce(new Error('down'))
      .mockRejectedValueOnce(new Error('down'))
      .mockResolvedValue(2_000);
    const ep = makeEndpoint('orbitflare', getSlot);
    const mon = new HealthMonitor([ep], opts);

    await mon.checkNow();
    await mon.checkNow();
    await mon.checkNow();
    expect(ep.healthy).toBe(false);

    await mon.checkNow(); // success
    expect(ep.healthy).toBe(true);
    expect(ep.consecutiveFailures).toBe(0);
    expect(ep.slot).toBe(2_000);
    expect(ep.successCount).toBe(1);
  });

  it('marks a responsive but slot-lagged endpoint unhealthy (stale slot)', async () => {
    const fresh = makeEndpoint('helius', jest.fn().mockResolvedValue(10_000));
    const stale = makeEndpoint('quicknode', jest.fn().mockResolvedValue(9_000));
    const mon = new HealthMonitor([fresh, stale], opts);

    await mon.checkNow();
    // lag = 1000 > slotLagThreshold(150)
    expect(fresh.healthy).toBe(true);
    expect(stale.healthy).toBe(false);
  });

  it('tracks success rate across probes', async () => {
    const getSlot = jest
      .fn()
      .mockResolvedValueOnce(100)
      .mockRejectedValueOnce(new Error('blip'))
      .mockResolvedValueOnce(102)
      .mockResolvedValueOnce(103);
    const ep = makeEndpoint('helius', getSlot);
    const mon = new HealthMonitor([ep], opts);

    await mon.checkNow();
    await mon.checkNow();
    await mon.checkNow();
    await mon.checkNow();

    expect(ep.successCount).toBe(3);
    expect(ep.failureCount).toBe(1);
    expect(mon.successRate(ep)).toBeCloseTo(0.75, 5);
  });
});
