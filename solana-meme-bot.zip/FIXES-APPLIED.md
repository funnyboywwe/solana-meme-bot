# Fixes Applied — Solana Meme Bot

This document records every change made in response to the audit report
(`solana-meme-bot-audit-report.md`). Findings are referenced by their audit
number, e.g. **(#4)**.

> **Build/typecheck caveat:** the fixes were applied and verified by static
> inspection (exact-string edits + cross-checking imports, symbols, config
> fields, and call sites). A full `tsc --noEmit` / `npm run build` could **not**
> be run in this environment because there is no network access to install
> dependencies (`@solana/web3.js`, `zod`, `axios`, `better-sqlite3`, `bs58`,
> etc.). Run `npm install && npm run build` on a networked machine to get the
> authoritative compile result. No new dependencies were introduced — every
> import used (`bs58`, `@solana/web3.js`, the internal `SolPrice`,
> `WriteRpcProvider`, `PositionRepository`) already exists in the project.

---

## Build blockers (#1)

- **`tsconfig.json`**: `moduleResolution: "node"` → `"node10"` and
  `ignoreDeprecations: "5.0"` → `"6.0"`, clearing the TS5107 deprecation error
  that blocked compilation under the current TypeScript.
- **`src/config/schema.ts`**: the `dexScreener` section's invalid
  `.default({})` (which does not satisfy the inferred object type) now provides
  a fully-typed default object (`enabled`, `chainId`, `pollIntervalMs`, `topN`,
  `minLiquidityUsd`, `minVolume5mUsd`, `minScoreToSignal`).

## Environment / config injection (#2, #3, #4, #16)

- **`src/config/AppConfig.ts`** now injects the env vars that were previously
  ignored:
  - `HEALTH_PORT` (with `HEALTH_CHECK_PORT` kept as a legacy fallback) → fixes
    the Docker `8080` vs app `3001` mismatch.
  - `DATABASE_PATH` → `db.path`.
  - `TRADING_ENABLED` → `trading.enabled` (real kill-switch, see #16).
  - `JUPITER_API_KEY` → `execution.jupiterApiKey`.
  - `JITO_BLOCK_ENGINE_URL` / `JITO_TIP_LAMPORTS` → `mevProtection.*`.
- **`src/config/schema.ts`**: added `execution.jupiterApiKey` (default `''`).
- **`src/index.ts`** (#16): `ORDER_READY` (buy) and `CLOSE_SIGNAL` (sell)
  handlers are now only wired when `cfg.trading.enabled` is true. When disabled
  the bot runs in **dry-run** mode — discovery, scoring, risk checks and price
  tracking still run, but no order is ever submitted. A warning is logged.

## Jupiter integration (#3, #10)

- **`src/execution/JupiterClient.ts`**: when `jupiterApiKey` is set, the client
  switches from the keyless host (`lite-api.jup.ag`) to the keyed host
  (`api.jup.ag`) and sends the `x-api-key` header on both `/quote` and `/swap`
  calls (higher rate limits, fewer 429s).
- **`src/engines/safety/HoneypotDetector.ts`** (#10): same keyed-host /
  `x-api-key` support, and the sell-simulation probe no longer hardcodes
  `amount: '1000000000'` (which equals **1000 tokens** for a 6-decimal meme
  coin and produced false "extreme price impact" honeypot hits). It now probes
  with ~1 whole token in the token's own base units (`10 ** decimals`,
  `decimals` defaulting to 6, overridable by callers).

> **Note on Jupiter v1 vs v2:** the audit suggested migrating to
> `api.jup.ag/swap/v2`. Independent checking of current Jupiter docs shows the
> live Swap API path is **`/swap/v1`** on both the keyless (`lite-api.jup.ag`)
> and keyed (`api.jup.ag`) hosts; the old `quote-api.jup.ag/v6` is sunset. To
> stay safe and avoid hardcoding a version that may be wrong, the code keeps the
> configured path (`/swap/v1` in `default.yaml`) and only switches the host +
> adds the key header. If your account is provisioned for a different version,
> change `execution.jupiterApiUrl` in config — no code change needed.

## MEV / Jito (#4, #5)

- **`src/execution/mev/MEVProtection.ts`** was reworked:
  - **Broadcasts go through the WRITE RPC pool** (`WriteRpcProvider`:
    OrbitFlare primary, QuickNode fallback) instead of the READ connection.
  - **Jito-first** when `jitoEnabled`: the bundle is submitted *before* any
    public-mempool broadcast (so it can actually prevent the sandwich attacks
    this module defends against), falling back to a direct RPC send only if the
    bundle is rejected.
  - **Real tip transaction (#4):** `_submitViaJito` now builds and signs a
    dedicated SystemProgram tip transfer to a random Jito tip account and
    bundles it with the swap (`params: [[swapTx, tipTx]]`). Tip is floored at
    1000 lamports. Without a tip, Jito will not land a bundle.
  - **Confirmation by signature (#4/#5):** `submit()` returns the real swap
    transaction signature as `txHash` (even for Jito bundles), so
    `TxConfirmation` can poll a real signature instead of an unconfirmable
    bundle ID.
  - **No double-signing (#5):** the transaction is only signed if it is not
    already signed by the caller.
- **`src/execution/JupiterClient.ts`** (#5): passes the **already-signed**
  transaction bytes to `MEVProtection.submit()` (previously it signed one
  object and handed MEV the unsigned base64, causing a redundant second
  signature pass and a simulated-vs-submitted-bytes mismatch).

## Data sources / SOL price (#6, #8, #9)

- **Helius WS endpoint (#6):** `src/config/default.yaml` `heliusWsUrl` changed
  from `wss://atlas-mainnet.helius-rpc.com` (Geyser/Atlas-only; silently
  delivers nothing for standard subscriptions on most plans) to the standard
  enhanced endpoint `wss://mainnet.helius-rpc.com`. Stale Atlas comments in
  `HeliusWebSocket.ts` were corrected.
- **Live SOL price everywhere (#9):** the hardcoded `$150` SOL price was
  replaced with the shared `getSolPriceUsd()` cache in **all** call sites:
  `PumpFunMonitor`, `LiquidityInflowEngine`, `PumpfunMigrationEngine`
  (5 spots), and `HeliusWebSocket`.
- **DexScreener source/decimals (#8):** `DexScreenerMonitor` now emits
  `source: 'dexscreener'` instead of `'unknown'`, with a clear note that
  DexScreener does not expose token decimals (the `6` default is the
  pump.fun/SPL norm, and authoritative decimals are read from the token repo
  when the token is traded).

## Accounting (#12, #14)

- **Exposure on sell (#14):** `src/risk/exposure/ExposureManager.ts` previously
  subtracted **sell proceeds** (`event.sizeSol = solReceived`) from deployed
  capital, which drifts on every win/loss. It now recomputes deployed capital,
  open-position count, and the largest position **authoritatively from
  `PositionRepository.findOpenPositions()`** (the closed row is already removed
  by the time the event fires).
- **Slippage estimate (#12):** `src/gate/EntryConditions.checkSlippage()` no
  longer assumes a fixed `$500` order. It sizes the estimate from the actual
  configured order size (`risk.fixedPositionSizeSol` when set, else a ~1 SOL
  production estimate) converted at the live SOL price.

## Repo hygiene (priority #10)

- Removed committed build artifacts that were checked in next to their
  TypeScript sources: `scripts/{backfill-wallets,health-check,migrate}.{js,js.map,d.ts,d.ts.map}`
  and any `dist/`. Genuine source scripts (`scripts/copy-assets.js` — needed by
  the build — and `scripts/deploy.sh`) were kept.

---

## Findings intentionally NOT auto-rewritten (documented limitations)

These require architectural reworks and/or external API access that cannot be
verified offline. Rewriting them blind (without a typecheck/integration test)
would risk breaking a currently-coherent codebase, so they are flagged here for
a networked follow-up rather than changed speculatively:

- **(#7) Raydium pool discovery** — sorting by `volume24h` misses brand-new
  low-volume pools, and only SOL-paired standard AMM pools are tracked (no
  CLMM/CPMM/PumpSwap/Meteora/Orca). Needs a creation-time-ordered feed and
  multi-program coverage.
- **(#8 / priority #8) Token-discovery rework** — DexScreener search is a
  sampled discovery feed, not a complete newest-token source. Consider Helius
  LaserStream/Yellowstone, Bitquery/Birdeye/Moralis, or direct program
  subscriptions. (The smaller data-quality bug — `source`/decimals — *was*
  fixed above.)
- **(#13) Failed-timeout recovery** — `FailedTradeRecovery.resolveTimeout()`
  only updates trade status; it does not reconstruct amount/price or open/close
  a `positions` row when an ambiguous tx later confirms. Proper reconciliation
  needs on-chain lookups (RPC) to confirm and rebuild fills.
- **(#15) LP-lock checker** — covers only Raydium standard LP mints; extending
  to PumpSwap/CLMM/Meteora/Orca/locked-liquidity services needs per-DEX pool
  resolution. It is a score input (not a hard block) unless
  `safety.requireLpLock` is enabled.
- **`package-lock.json`** — a reproducible lockfile should be generated with
  `npm install` on a networked machine (could not be produced offline).

## Verified on-chain addresses / endpoints (unchanged, confirmed correct)

WSOL `So11111111111111111111111111111111111111112`, USDC
`EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v`, USDT
`Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB`, SPL Token
`TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA`, Raydium AMM V4
`675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8`, Raydium CLMM
`CAMMCzo5YL8w4VFF8KVHrK22GGUsp5VTaW7grrKgrWqK`, Pump.fun
`6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P`, PumpSwap
`pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA`. Jito bundles:
`https://mainnet.block-engine.jito.wtf` (`/api/v1/bundles`, `sendBundle`).
