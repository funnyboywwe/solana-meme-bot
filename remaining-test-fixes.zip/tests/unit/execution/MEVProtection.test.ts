
jest.mock('../../../src/db/Database', () => ({
  getDb: () => ({ prepare: () => ({ run: jest.fn() }) }),
}));

jest.mock('../../../src/core/EventBus', () => ({
  EventBus: { emit: jest.fn(), on: jest.fn() },
}));

jest.mock('@solana/web3.js', () => ({
  Connection: jest.fn().mockImplementation(() => ({
    sendRawTransaction: jest.fn().mockResolvedValue('txhash123'),
  })),
  VersionedTransaction: {
    deserialize: jest.fn().mockReturnValue({
      sign: jest.fn(),
      serialize: jest.fn().mockReturnValue(Buffer.from('fake-tx')),
    }),
  },
  Keypair: jest.fn().mockImplementation(() => ({})),
}));

const mockCfg = {
  rpc: { rpcHttpUrl: 'http://localhost', commitment: 'confirmed' },
} as any;

const mockExtCfg = {
  mevProtection: {
    jitoEnabled: false,
    jitoTipLamports: 10000,
    jitoBlockEngineUrl: 'https://mainnet.block-engine.jito.wtf',
    maxSlippageAdaptBps: 500,
    sandwichDetectionEnabled: true,
    retryWithJitoOnFail: false,
    frontRunProtectionMs: 0,
  },
} as any;

const mockKeypair = { publicKey: { toBase58: () => 'wallet' } } as any;

describe('MEVProtection', () => {
  let mev: any;

  beforeEach(async () => {
    jest.clearAllMocks();
    const { MEVProtection } = await import('../../../src/execution/mev/MEVProtection');
    mev = new MEVProtection(mockCfg, mockExtCfg, mockKeypair);
  });

  it('submits via RPC successfully', async () => {
    const result = await mev.submit({
      txBase64: Buffer.from('fake').toString('base64'),
      expectedOutAmount: 1000,
      slippageBps: 100,
      priorityFeeMicroLamports: 50000,
    });
    expect(result.success).toBe(true);
    expect(result.usedJito).toBe(false);
    expect(result.txHash).toBe('txhash123');
  });

  it('detects failed fill correctly', () => {
    const isFailed = mev.detectFailedFill(1000, 800, 100); // actual < expected * (1 - slippage)
    expect(isFailed).toBe(true);
  });

  it('does not flag normal fill as failed', () => {
    const isFailed = mev.detectFailedFill(1000, 995, 100); // within 1% slippage
    expect(isFailed).toBe(false);
  });

  it('computes adaptive priority fee', () => {
    const base = 50000;
    mev.consecutiveFailures = 2;
    const adapted = mev.computeAdaptivePriorityFee(base);
    expect(adapted).toBeGreaterThan(base);
  });

  it('adaptive fee resets after resetFailureCount', () => {
    mev.consecutiveFailures = 5;
    mev.resetFailureCount();
    const adapted = mev.computeAdaptivePriorityFee(50000);
    expect(adapted).toBe(50000);
  });

  it('handles RPC failure gracefully when Jito disabled', async () => {
    const { Connection } = await import('@solana/web3.js');
    (Connection as jest.Mock).mockImplementationOnce(() => ({
      sendRawTransaction: jest.fn().mockRejectedValue(new Error('slippage tolerance exceeded')),
    }));
    const { MEVProtection } = await import('../../../src/execution/mev/MEVProtection');
    const mev2 = new MEVProtection(mockCfg, mockExtCfg, mockKeypair);
    const result = await mev2.submit({ txBase64: Buffer.from('x').toString('base64'), expectedOutAmount: 1000, slippageBps: 100, priorityFeeMicroLamports: 50000 });
    expect(result.success).toBe(false);
  });
});
